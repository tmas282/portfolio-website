# MDISC-MST

[Graph](https://en.wikipedia.org/wiki/Graph_(abstract_data_type))

[Kruskal](https://www.geeksforgeeks.org/kruskals-minimum-spanning-tree-algorithm-greedy-algo-2/)