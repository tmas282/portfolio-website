import "./components/css/transacoes.css"
import { Redirect } from "react-router-dom"
import Navbar from "./components/Navbar"
import { FaCircle } from "react-icons/fa"
import { useEffect } from "react"
import jQuery from "jquery"
import { useState } from "react"
import config from "./components/cfg/config.json"
import { useCookies } from "react-cookie"
function Transacoes() {
    const [cookies] = useCookies(["uuid"])
    const [transacoes, setTransacoes] = useState()
    useEffect(function () {
        if (cookies.uuid) {
            var def = {
                method: "GET",
                url: "http://" + config.ip + ":3001/todas-as-transacoes-do-cliente",
                xhrFields: {
                    withCredentials: true
                }
            }
            jQuery.ajax(def).done(function (data) {
                setTransacoes(data)
            })
        }
    }, [cookies.uuid])
    if (!cookies.uuid) {
        return (
            <Redirect to="/" />
        )
    }
    else {
        return (
            <>
                <Navbar />
                <div className="div-tabela">
                    <table>
                        <thead>
                            <tr>
                                <td>ID</td>
                                <td><span style={{color: "#8A4343"}}>Vendedor</span> / <span style={{color: "#B9B85D"}}>Comprador</span></td>
                                <td>Estado</td>
                                <td>Item</td>
                                <td>Data</td>
                                <td>Preço</td>
                            </tr>
                        </thead>
                        <tbody>
                            {transacoes &&
                                transacoes.map(function (element, index) {
                                    var data = new Date(element.transacao_data)
                                    return (
                                        <tr key={index}>
                                            <td>{element.uuid}</td>
                                            <td><a title={element.uuid_cliente ===  element.uuid_comprador ? "Comprador" : "Vendedor"} href={"mailto:" + element.email} target="_blank" rel="noreferrer" style={element.uuid_cliente ===  element.uuid_comprador ? {color: "#B9B85D"} : {color: "#8A4343"}}>{element.email}</a></td>
                                            {element.transacao_estado === 0 &&
                                                <td className="icon-nao-enviado" title="Não Enviado"><FaCircle /></td>
                                            }
                                            {element.transacao_estado === 1 &&
                                                <td className="icon-dinheiro-pronto" title="Dinheiro Pronto"><FaCircle /></td>
                                            }
                                            {element.transacao_estado === 2 &&
                                                <td className="icon-enviado" title="Enviado"><FaCircle /></td>
                                            }
                                            <td>{element.skin_nome}</td>
                                            <td>{data.getDate()}/{(data.getMonth() + 1)}/{data.getFullYear()}</td>
                                            <td>{element.preco_skin.toFixed(2)} €</td>
                                        </tr>
                                    )
                                })}
                        </tbody>
                    </table>
                </div>
            </>
        )
    }
}
export default Transacoes