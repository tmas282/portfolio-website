import { Link } from "react-router-dom"
function Erro404() {
    return (
        <div style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: "100%",
            textAlign: "center"
        }}>
            <span style={{
                display: "block",
                fontSize: "7.5rem",
                color: "#EEEEEE"
            }}>404</span>
            <span style={{
                display: "block",
                fontSize: "2.5rem",
                color: "#393E46"
            }}>Não conseguimos encontrar a página pretendida :(</span>
            <br></br>
            <br></br>
            <Link to="/loja" style={{
                width: "min-content",
                padding: "1.5rem",
                marginLeft: "auto",
                marginRight: "auto",
                borderRadius: "1rem",
                backgroundColor: "#FFD369",
                color: "#393E46"
            }}>Ir para a loja</Link>
        </div>
    )
}
export default Erro404