import { useCallback, useState } from "react"
import { useEffect } from "react"
import jQuery from "jquery"
import { Redirect } from "react-router-dom"
import Navbar from "./components/Navbar"
import Alerta from "./components/Alerta"
import config from "./components/cfg/config.json"
import "./components/css/admin.css"
import AdminAcordeao from "./components/AdminAcordeao"
import { FaCircle } from "react-icons/fa"
import { useCookies } from "react-cookie"
function Admin() {
    const [cookies] = useCookies(["uuid"])
    const [alerta, mostrarAlerta] = useState(false)
    const [alertaTipo, setAlertaTipo] = useState()
    const [alertaMensagem, setAlertaMensagem] = useState()
    const [admin, setAdmin] = useState()
    const [clientes, setClientes] = useState()
    const [pesquisaClientes, setPesquisaClientes] = useState("")
    const [adminPermissao, setAdminPermissao] = useState(0)
    const [utilizador, setUtilizador] = useState(0)
    const [contacto, setContacto] = useState()
    const [verNaoRespondidos, setVerNaoRespondidos] = useState(false)
    const [transacoes, setTransacoes] = useState()
    const [pesquisaUUID, setPesquisaUUID] = useState("")
    const [uuidTransacaoAviso, setUuidTransacaoAviso] = useState("")
    const [dinheiroComprador, setDinheiroComprador] = useState(false)
    const [verTipoCliente, setVerTipoCliente] = useState(true)
    const [verTipoAdmin, setVerTipoAdmin] = useState(true)
    const [verTipoCEO, setVerTipoCEO] = useState(true)
    const obterClientes = useCallback(function () {
        var data = {
            pesquisa: pesquisaClientes
        }
        var def = {
            method: "GET",
            url: "http://" + config.ip + ":3001/pesquisar-clientes",
            data: data,
            xhrFields: {
                withCredentials: true
            }
        }
        jQuery.ajax(def).done(function (data) {
            setClientes(data)
        })
    }, [pesquisaClientes])
    const obterFormContacto = useCallback(function () {
        var data = {
            verNaoRespondidos: verNaoRespondidos
        }
        var def = {
            method: "GET",
            url: "http://" + config.ip + ":3001/obter-form-contacto",
            data: data,
            xhrFields: {
                withCredentials: true
            }
        }
        jQuery.ajax(def).done(function (data) {
            setContacto(data)
        })
    }, [verNaoRespondidos])
    const obterTransacoes = useCallback(function () {
        var data = {
            pesquisaUUID: pesquisaUUID
        }
        var def = {
            method: "GET",
            url: "http://" + config.ip + ":3001/todas-as-transacoes",
            data: data,
            xhrFields: {
                withCredentials: true
            }
        }
        jQuery.ajax(def).done(function (data) {
            setTransacoes(data)
        })
    }, [pesquisaUUID])
    useEffect(function () {
        var def = {
            method: "GET",
            url: "http://" + config.ip + ":3001/info-conta",
            xhrFields: {
                withCredentials: true
            }
        }
        jQuery.ajax(def).done(function (data) {
            setAdmin(data.admin)
            if (data.admin === 0) {
                window.location.reload()
            }
        })
    })
    useEffect(function () {
        if (admin > 0) {
            obterFormContacto()
            obterTransacoes()
            obterClientes()
        }
    }, [admin, obterFormContacto, obterTransacoes, obterClientes])
    if (!cookies.uuid) {
        return (
            <Redirect to="/" />
        )
    }
    if (admin === 0) {
        return (
            <Redirect to="/" />
        )
    }
    else {
        return (
            <div className="admin">
                <Alerta mostrar={alerta} tipo={alertaTipo} mensagem={alertaMensagem} fecharAlerta={
                    function () {
                        mostrarAlerta(false)
                    }
                } />
                <Navbar />
                {admin === 2 &&
                    <>
                        <h1>CEO</h1>
                        <form className="form-mudar-permissao">
                            <h3>Editor de permissões</h3>
                            <select defaultValue={0} onChange={function (e) {
                                setUtilizador(e.target.value)
                            }}>
                                <option value={0} key={0}>Escolhe um</option>
                                {clientes &&
                                    clientes.map(function (element) {
                                        return (
                                            <option value={element.uuid} key={element.uuid}>{element.email} (
                                                {
                                                    element.admin === 2 && "CEO"
                                                }
                                                {
                                                    element.admin === 1 && "Admin"
                                                }
                                                {
                                                    element.admin === 0 && "Cliente"
                                                }
                                                )</option>
                                        )
                                    })}
                            </select>
                            <br></br>
                            <br></br>
                            <select onChange={function (e) {
                                setAdminPermissao(e.target.value)
                            }}>
                                <option key={0} value={0}>Cliente</option>
                                <option key={1} value={1}>Admin</option>
                                <option key={2} value={2}>CEO</option>
                            </select>
                            <br></br>
                            <br></br>
                            <button onClick={function (e) {
                                e.preventDefault()
                                var data = {
                                    utilizador: utilizador,
                                    adminPermissao: adminPermissao
                                }
                                var def = {
                                    method: "PUT",
                                    url: "http://" + config.ip + ":3001/mudar-privilegios",
                                    data: data,
                                    xhrFields: {
                                        withCredentials: true
                                    }
                                }
                                jQuery.ajax(def)
                                    .done(function (data) {
                                        if (data === "O privilégio que escolheste é o atual.") {
                                            setAlertaTipo("info")
                                        }
                                        else {
                                            setAlertaTipo("sucesso")
                                        }
                                        setAlertaMensagem(data)
                                        mostrarAlerta(true)
                                        obterClientes()
                                    })
                                    .fail(function (data) {
                                        setAlertaMensagem(data.responseText)
                                        setAlertaTipo("erro")
                                        mostrarAlerta(true)
                                    })
                            }}>Mudar Privilégios</button>
                        </form>
                        <br></br>
                        <form className="enviar-email-aviso">
                            <h3>Email de aviso</h3>
                            <div className="uuid-transacao-aviso">
                                <label>UUID da transação:&nbsp;</label>
                                <input type="text" placeholder="UUID da transação" value={uuidTransacaoAviso} onChange={function (e) {
                                    setUuidTransacaoAviso(e.target.value)
                                }}></input>
                            </div>
                            <br></br>
                            <div className="check-dinheiro-comprador">
                                <input type="checkbox" checked={dinheiroComprador} onChange={function (e) {
                                    setDinheiroComprador(e.target.checked)
                                }}></input>
                                <label>&nbsp;Já recebeste o dinheiro do comprador?</label>
                            </div>
                            <br></br>
                            <button onClick={function (e) {
                                if (dinheiroComprador) {
                                    setAlertaMensagem("Aguarde...")
                                    setAlertaTipo("info")
                                    mostrarAlerta(true)
                                    var data = {
                                        uuidTransacao: uuidTransacaoAviso
                                    }
                                    var def = {
                                        method: "POST",
                                        url: "http://" + config.ip + ":3001/aviso-email-skin-enviar",
                                        data: data,
                                        xhrFields: {
                                            withCredentials: true
                                        }
                                    }
                                    jQuery.ajax(def)
                                        .done(function (data) {
                                            setAlertaMensagem(data)
                                            setAlertaTipo("sucesso")
                                            mostrarAlerta(true)
                                        })
                                        .fail(function (data) {
                                            setAlertaMensagem(data.responseText)
                                            setAlertaTipo("erro")
                                            mostrarAlerta(true)
                                        })
                                }
                                else {
                                    setAlertaMensagem("Certifique-se que já recebeu o dinheiro do comprador.")
                                    setAlertaTipo("erro")
                                    mostrarAlerta(true)
                                }
                                e.preventDefault()
                            }}>Enviar email de aviso ao vendedor</button>
                        </form>
                        <br></br>
                    </>
                }
                {admin >= 1 &&
                    <>
                        <h1>Admin <button onClick={function (e) {
                            obterFormContacto()
                            obterTransacoes()
                            obterClientes()
                        }}></button></h1>
                        <div className="admin-contacto">
                            <h3>Formulário de contacto</h3>
                            <div className="filtroContactoAdmin">
                                <input type="checkbox" onChange={
                                    function (e) {
                                        setVerNaoRespondidos(e.target.checked)
                                    }
                                }></input>
                                <label>&nbsp;Ver não respondidos apenas</label>
                            </div>
                            {contacto &&
                                contacto.map(function (contacto) {
                                    return <AdminAcordeao key={contacto.id} id={contacto.id} problema={contacto.problema} nome={contacto.nome} email={contacto.email} mensagem={contacto.mensagem} respondido={contacto.respondido} quem_respondeu={contacto.email_respondeu} atualizar={
                                        function (e) {
                                            obterFormContacto()
                                        }
                                    } />
                                })
                            }
                        </div>
                        <br></br>
                        <div className="admin-transacoes">
                            <h3>Transações</h3>
                            <div className="filtro-transacoes-admin">
                                <label>Pesquisar por Id:&nbsp;</label>
                                <input type="text" value={pesquisaUUID} onChange={
                                    function (e) {
                                        setPesquisaUUID(e.target.value)
                                    }
                                }></input>
                            </div>
                            <div className="div-tabela">
                                <table>
                                    <thead>
                                        <tr>
                                            <td>ID</td>
                                            <td>Comprador</td>
                                            <td>Vendedor</td>
                                            <td>Estado</td>
                                            <td>Item</td>
                                            <td>Data</td>
                                            <td>Preço</td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {transacoes &&
                                            transacoes.map(function (element, index) {
                                                var data = new Date(element.transacao_data)
                                                return (
                                                    <tr key={index}>
                                                        <td>{element.uuid}</td>
                                                        <td>{element.uuid_cliente}</td>
                                                        <td>{element.uuid_vendedor}</td>
                                                        {element.transacao_estado === 0 &&
                                                            <td className="icon-nao-enviado" title="Não Enviado"><FaCircle /></td>
                                                        }
                                                        {element.transacao_estado === 1 &&
                                                            <td className="icon-dinheiro-pronto" title="Dinheiro Pronto"><FaCircle /></td>
                                                        }
                                                        {element.transacao_estado === 2 &&
                                                            <td className="icon-enviado" title="Enviado"><FaCircle /></td>
                                                        }
                                                        <td>{element.skin_nome}</td>
                                                        <td>{data.getDate()}/{(data.getMonth() + 1)}/{data.getFullYear()}</td>
                                                        <td>{element.preco_skin.toFixed(2)} €</td>
                                                    </tr>
                                                )
                                            })}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <br></br>
                        <div className="admin-clientes">
                            <h3>Contas existentes</h3>
                            <div className="pesquisar-por-algo-clientes-admin">
                                <label>Pesquisar por UUID ou Email ou Número:&nbsp;</label>
                                <input type="text" value={pesquisaClientes} onChange={
                                    function (e) {
                                        setPesquisaClientes(e.target.value)
                                        obterClientes()
                                    }
                                }></input>
                            </div>
                            <br></br>
                            <div className="selecionar-tipo-clientes">
                                <div>
                                    <input type="checkbox" checked={verTipoCliente} onChange={function (e) {
                                        setVerTipoCliente(e.target.checked)
                                    }}></input>
                                    <label>&nbsp;Cliente</label>
                                </div>
                                <div>
                                    <input type="checkbox" checked={verTipoAdmin} onChange={function (e) {
                                        setVerTipoAdmin(e.target.checked)
                                    }}></input>
                                    <label>&nbsp;Admin</label>
                                </div>
                                <div>
                                    <input type="checkbox" checked={verTipoCEO} onChange={function (e) {
                                        setVerTipoCEO(e.target.checked)
                                    }}></input>
                                    <label>&nbsp;CEO</label>
                                </div>
                            </div>
                            <div className="div-tabela">
                                <table>
                                    <thead>
                                        <tr>
                                            <td>UUID</td>
                                            <td>Email</td>
                                            <td>Perfil</td>
                                            <td>Trade Link</td>
                                            <td>Número</td>
                                            <td>Nível</td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {clientes &&
                                            clientes.map(function (element, index) {
                                                if (verTipoCliente && element.admin === 0) {
                                                    return (
                                                        <tr key={index}>
                                                            <td>{element.uuid}</td>
                                                            <td>{element.email}</td>
                                                            <td><a href={"http://steamcommunity.com/profiles/" + element.steam64} target="_blank" rel="noreferrer">Ver</a></td>
                                                            <td>{element.trade_link}</td>
                                                            <td>{element.numero}</td>
                                                            <td>Cliente</td>
                                                        </tr>
                                                    )
                                                }
                                                if (verTipoAdmin && element.admin === 1) {
                                                    return (
                                                        <tr key={index}>
                                                            <td>{element.uuid}</td>
                                                            <td>{element.email}</td>
                                                            <td><a href={"http://steamcommunity.com/profiles/" + element.steam64} target="_blank" rel="noreferrer">Ver</a></td>
                                                            <td>{element.trade_link}</td>
                                                            <td>{element.numero}</td>
                                                            <td>Admin</td>
                                                        </tr>
                                                    )
                                                }
                                                if (verTipoCEO && element.admin === 2) {
                                                    return (
                                                        <tr key={index}>
                                                            <td>{element.uuid}</td>
                                                            <td>{element.email}</td>
                                                            <td><a href={"http://steamcommunity.com/profiles/" + element.steam64} target="_blank" rel="noreferrer">Ver</a></td>
                                                            <td>{element.trade_link}</td>
                                                            <td>{element.numero}</td>
                                                            <td>CEO</td>
                                                        </tr>
                                                    )
                                                }
                                                return null
                                            })}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </>
                }
            </div >
        )
    }
}
export default Admin