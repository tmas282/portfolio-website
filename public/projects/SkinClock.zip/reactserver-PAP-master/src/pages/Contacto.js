import Navbar from "./components/Navbar"
import "./components/css/contacto.css"
import FAQItem from "./components/FAQitem"
import { FaDiscord, FaEnvelope } from "react-icons/fa"
import jQuery from "jquery"
import { useEffect, useState } from "react"
import Alerta from "./components/Alerta"
import config from "./components/cfg/config.json"
function Contacto() {
    const [array, setArray] = useState([])
    const [alerta, mostrarAlerta] = useState(false)
    const [alertaTipo, setAlertaTipo] = useState()
    const [alertaMensagem, setAlertaMensagem] = useState()
    const [nome, setNome] = useState()
    const [problema, setProblema] = useState()
    const [email, setEmail] = useState()
    const [mensagem, setMensagem] = useState()
    useEffect(function () {
        var def = {
            method: "GET",
            url: "http://" + config.ip + ":3001/perguntas-faq"
        }
        jQuery.ajax(def).done(function (data) {
            setArray(data)
        })
    }, [])
    function submeterFomulario(e) {
        e.preventDefault()
        var regexEmail = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
        if (nome === "" || problema === "" || email === "" || mensagem === "" || nome === undefined || problema === undefined || email === undefined || mensagem === undefined || email.match(regexEmail) === null) {
            setAlertaTipo("erro")
            setAlertaMensagem("Preenche, de forma correta, o formulário.")
            mostrarAlerta(true)
        }
        else {
            var data = {
                nome: nome,
                problema: problema,
                email: email,
                mensagem: mensagem
            }
            var def = {
                method: "POST",
                url: "http://" + config.ip + ":3001/formulario-contacto",
                data: data
            }
            jQuery.ajax(def)
                .done(function (data) {
                    setAlertaTipo("sucesso")
                    setAlertaMensagem(data)
                    mostrarAlerta(true)
                })
        }
    }
    return (
        <>
            <Alerta mostrar={alerta} tipo={alertaTipo} mensagem={alertaMensagem} fecharAlerta={
                function () {
                    mostrarAlerta(false)
                }
            } />
            <Navbar />
            <section>
                {array.map(function (valor) {
                    return <FAQItem titulo={valor.titulo} resposta={valor.resposta} key={array.indexOf(valor)} />
                })}
            </section>
            <section className="form-section">
                <h1>Ainda precisas de ajuda?</h1>
                <h2>Envia-nos uma mensagem ou fala connosco através do discord</h2>
                <form>
                    <div className="inputs">
                        <div className="problema-e-nome">
                            <label>O problema</label>
                            <br></br>
                            <input type="text" placeholder="O problema" onChange={
                                function (e) {
                                    setProblema(e.target.value)
                                }
                            }></input>
                            <br></br>
                            <br></br>
                            <label>O teu nome</label>
                            <br></br>
                            <input type="text" placeholder="O teu nome" onChange={
                                function (e) {
                                    setNome(e.target.value)
                                }
                            }></input>
                            <br></br>
                            <br></br>
                            <label>O teu email</label>
                            <br></br>
                            <input type="email" placeholder="O teu email" onChange={
                                function (e) {
                                    setEmail(e.target.value)
                                }
                            }></input>
                        </div>
                        <br></br>
                        <div className="mensagem">
                            <label>A tua mensagem</label>
                            <br></br>
                            <textarea placeholder="A tua mensagem" onChange={
                                function (e) {
                                    setMensagem(e.target.value)
                                }
                            }></textarea>
                        </div>
                    </div>
                    <button className="btn-submeter" onClick={submeterFomulario}>Enviar!</button>
                </form>
            </section>
            <footer>
                <div className="discord">
                    <a target="_blank" rel="noreferrer" href="https://discord.gg/Wc9j4JeQ3V" style={{display: "flex", alignItems: "center"}}>
                        <FaDiscord className="icon" />
                        &nbsp;
                        <span>https://discord.gg/Wc9j4JeQ3V</span>
                    </a>
                </div>
                <div className="email">
                    <a href="mailto:tomaspintomoreira28@gmail.com" style={{display: "flex", alignItems: "center"}}>
                        <FaEnvelope className="icon" />
                        &nbsp;
                        <span>tomaspintomoreira28@gmail.com</span>
                    </a>
                </div>
            </footer>
        </>
    )
}
export default Contacto