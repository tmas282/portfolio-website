import { useState } from "react"
import { Redirect } from "react-router"
import jQuery from "jquery"
import config from "./components/cfg/config.json"
import Alerta from "./components/Alerta"
function RecuperarPassword() {
    var token = (new URLSearchParams(window.location.search)).get("token")
    var uuid = (new URLSearchParams(window.location.search)).get("uuid")
    const [password, setPassword] = useState("")
    const [foiMudada, setFoiMudada] = useState(false)
    const [alerta, mostrarAlerta] = useState(false)
    const [alertaTipo, setAlertaTipo] = useState()
    const [alertaMensagem, setAlertaMensagem] = useState()
    if (!token) {
        return <Redirect to="/" />
    }
    if (!uuid) {
        return <Redirect to="/" />
    }
    if (foiMudada) {
        return <Redirect to="/" />
    }
    return (
        <>
            <Alerta mostrar={alerta} tipo={alertaTipo} mensagem={alertaMensagem} fecharAlerta={
                function () {
                    mostrarAlerta(false)
                }
            } />
            <form style={{
                position: "fixed",
                top: "50%",
                left: "50%",
                marginRight: "-50%",
                transform: "translate(-50%, -50%)",
                zIndex: "1",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                padding: "1rem",
                width: "100%"
            }}>
                <p style={{
                    color: "#EEEEEE"
                }}>Escolhe a tua password</p>
                <br></br>
                <input style={{
                    padding: "1rem",
                    maxWidth: "100%",
                    width: "25rem",
                    color: "#EEEEEE",
                    backgroundColor: "#393E46",
                    border: "none",
                    borderRadius: "0.25rem",
                    borderBottomColor: "#393E46",
                    borderBottomWidth: "0.1rem",
                    marginRight: "auto",
                    marginLeft: "auto",
                    outline: "none",

                }} type="password" placeholder="Nova password" onChange={
                    function (e) {
                        setPassword(e.target.value)
                    }
                } value={password}></input>
                <br></br>
                <br></br>
                <div>
                    <button onClick={function () {
                        if (prompt("Confirme a sua nova password") === password) {
                            var data = {
                                password: password
                            }
                            var def = {
                                method: "POST",
                                url: "http://" + config.ip + ":3001/mudar-password",
                                data: data,
                                headers: {
                                    uuid: uuid,
                                    token: token
                                }
                            }
                            jQuery.ajax(def).done(function () {
                                setFoiMudada(true)
                            })
                        }
                        else {
                            setAlertaTipo("erro")
                            setAlertaMensagem("Confirmação de password errada.")
                            mostrarAlerta(true)
                        }
                    }}
                        style={{
                            border: "none",
                            background: "none",
                            fontSize: "1.5rem",
                            color: "#393E46",
                            backgroundColor: "#FFD369",
                            padding: "1rem",
                            paddingLeft: "1.5rem",
                            paddingRight: "1.5rem",
                            borderRadius: "1rem",
                        }}>Mudar password</button>
                </div>
            </form>
        </>
    )
}
export default RecuperarPassword