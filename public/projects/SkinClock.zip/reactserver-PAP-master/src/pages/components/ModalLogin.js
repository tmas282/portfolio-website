import "./css/modallogin.css"
import { FaTimes } from "react-icons/fa"
import { useState } from "react"
import Alerta from "./Alerta"
import jQuery from "jquery"
import config from "./cfg/config.json"
import { useCookies } from "react-cookie"
function ModalLogin({ mostrar, fechar }) {
    const [cookies, setCookies, removeCookies] = useCookies(["steam64", "uuid", "avatar"])
    const [alerta, mostrarAlerta] = useState(false)
    const [alertaTipo, setAlertaTipo] = useState()
    const [alertaMensagem, setAlertaMensagem] = useState()
    const [aCriarConta, setACriarConta] = useState(true)
    const [email, setEmail] = useState("")
    const [numero, setNumero] = useState("")
    const [password, setPassword] = useState("")
    const [tradeLink, setTradeLink] = useState("")
    const [ePublico, setEPublico] = useState(false)
    const [temMBWay, setTemMBWay] = useState(false)
    function onClickBtnCabecalho(e) {
        setEmail("")
        setNumero("")
        setPassword("")
        setTradeLink("")
        if (e.target.textContent === "Registar") {
            document.getElementById("body-login").className = "body-modal hidden"
            document.getElementById("body-registar").className = "body-modal show"
            setACriarConta(true)
            document.getElementById("btn-login").style.borderBottomColor = "transparent"
            document.getElementById("btn-registar").style.borderBottomColor = "#FFD369"
        }
        else {
            document.getElementById("body-login").className = "body-modal show"
            document.getElementById("body-registar").className = "body-modal hidden"
            setACriarConta(false)
            document.getElementById("btn-registar").style.borderBottomColor = "transparent"
            document.getElementById("btn-login").style.borderBottomColor = "#FFD369"
        }

    }
    function btnSubmeter(e) {
        e.preventDefault()
        var regexEmail = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
        var regexTelemovel = /^\d{9}$/g
        if (aCriarConta) {
            if (!email || !numero || !password || !tradeLink) {
                setAlertaTipo("erro")
                setAlertaMensagem("Preenche os campos todos.")
                mostrarAlerta(true)
            }
            else if (!email.match(regexEmail)) {
                setAlertaTipo("erro")
                setAlertaMensagem("Coloca um email válido.")
                mostrarAlerta(true)
            }
            else if (!numero.match(regexTelemovel)) {
                setAlertaTipo("erro")
                setAlertaMensagem("Coloca um número de telemóvel válido.")
                mostrarAlerta(true)
            }
            else if (!cookies.steam64) {
                setAlertaTipo("erro")
                setAlertaMensagem("Inicia sessão na steam.")
                mostrarAlerta(true)
            }
            else if (!ePublico) {
                setAlertaTipo("erro")
                setAlertaMensagem("Coloca a tua conta Steam pública.")
                mostrarAlerta(true)
            }
            else if (!temMBWay) {
                setAlertaTipo("erro")
                setAlertaMensagem("Cria uma conta MB Way com o telemóvel mencionado em cima.")
                mostrarAlerta(true)
            }
            else {
                var data = {
                    email: email,
                    numero: numero,
                    password: password,
                    tradeLink: tradeLink
                }
                var def = {
                    method: "POST",
                    url: "http://" + config.ip + ":3001/criar-conta",
                    data: data,
                    xhrFields: {
                        withCredentials: true
                    }
                }
                jQuery.ajax(def)
                    .done(function (data) {
                        setAlertaTipo("sucesso")
                        setAlertaMensagem("Conta criada. A iniciar sessão...")
                        mostrarAlerta(true)
                        setCookies("uuid", data.uuid)
                        setCookies("avatar", data.avatar)
                        removeCookies("steam64")
                        window.location.reload()
                    })
                    .fail(function (data) {
                        setAlertaTipo("erro")
                        setAlertaMensagem(data.responseText)
                        mostrarAlerta(true)
                    })
            }
        }
        else {
            if (!email || !password) {
                setAlertaTipo("erro")
                setAlertaMensagem("Preenche os campos.")
                mostrarAlerta(true)
            }
            else if (!email.match(regexEmail)) {
                setAlertaTipo("erro")
                setAlertaMensagem("Coloca um email válido.")
                mostrarAlerta(true)
            }
            else {
                data = {
                    email: email,
                    password: password
                }
                def = {
                    method: "POST",
                    url: "http://" + config.ip + ":3001/fazer-login",
                    data: data
                }
                jQuery.ajax(def)
                    .done(function (data) {
                        setAlertaTipo("sucesso")
                        setAlertaMensagem("A concluir o login...")
                        mostrarAlerta(true)
                        setCookies("uuid", data.uuid)
                        setCookies("avatar", data.avatar)
                        window.location.reload()
                    })
                    .fail(function (data) {
                        setAlertaTipo("erro")
                        setAlertaMensagem(data.responseText)
                        mostrarAlerta(true)
                    })
            }
        }
    }
    if (mostrar) {
        return (
            <>
                <Alerta mostrar={alerta} tipo={alertaTipo} mensagem={alertaMensagem} fecharAlerta={
                    function (e) {
                        mostrarAlerta(false)
                    }
                } />
                <div className="bg"></div>
                <div className="modal-login">
                    <div className="row1">
                        <div className="btns-login-registo">
                            <button onClick={onClickBtnCabecalho} id="btn-login" >Login</button>
                            <button onClick={onClickBtnCabecalho} id="btn-registar" style={{ borderBottomColor: "#FFD369" }}>Registar</button>
                        </div>
                        <FaTimes className="fechar-btn" onClick={fechar} />
                    </div>
                    <div >
                        <div id="body-login" className="body-modal hidden">
                            <form>
                                <label>Email</label>
                                <br></br>
                                <input type="email" placeholder="Email" onChange={
                                    function (e) {
                                        setEmail(e.target.value)
                                    }
                                } value={email}></input>
                                <br></br>
                                <br></br>
                                <label>Password</label>
                                <br></br>
                                <input type="password" placeholder="Password" onChange={
                                    function (e) {
                                        setPassword(e.target.value)
                                    }
                                } value={password}></input>
                                <br></br>
                                <br></br>
                                <div className="div-btn">
                                    <button onClick={btnSubmeter}>Login</button>
                                </div>
                                <a
                                    style={
                                        {
                                            display: "flex",
                                            justifyContent: "center"
                                        }
                                    }
                                    onClick={
                                        function (e) {
                                            e.preventDefault()
                                            setAlertaTipo("info")
                                            setAlertaMensagem("Aguarde...")
                                            mostrarAlerta(true)
                                            var data = {
                                                email: email
                                            }
                                            var def = {
                                                method: "POST",
                                                url: "http://" + config.ip + ":3001/recuperar-password",
                                                data: data
                                            }
                                            jQuery.ajax(def)
                                                .done(function (data) {
                                                    setAlertaTipo("info")
                                                    setAlertaMensagem(data)
                                                    mostrarAlerta(true)
                                                })
                                                .fail(function (data) {
                                                    setAlertaTipo("erro")
                                                    setAlertaMensagem(data.responseText)
                                                    mostrarAlerta(true)
                                                })
                                        }
                                    } href="loja">Recuperar Password</a>
                            </form>
                        </div>
                        <div id="body-registar" className="body-modal show">
                            <form>
                                <div className="sessao-steam">
                                    {!cookies.steam64 &&
                                        <a className="sessao-steamLink" href={"http://" + config.ip + ":3001/comecar-steam-openid"}><img alt="Steam login" src="https://steamcdn-a.akamaihd.net/steamcommunity/public/images/steamworks_docs/portuguese/sits_small.png"></img></a>
                                    }
                                    {cookies.steam64 &&
                                        <span className="sessao-steam-span">Já tens sessão iniciada na steam. Para concluíres preenche os dados em baixo:</span>
                                    }
                                </div>
                                <label>Email</label>
                                <br></br>
                                <input type="email" placeholder="Email" onChange={
                                    function (e) {
                                        setEmail(e.target.value)
                                    }
                                } value={email}></input>
                                <br></br>
                                <br></br>
                                <label>Número de Telemóvel</label>
                                <br></br>
                                <input type="tel" placeholder="Número de Telemóvel (Ex: 911111111)" pattern="[0-9]{3}[0-9]{3}[0-9]{3}" onChange={
                                    function (e) {
                                        setNumero(e.target.value)
                                    }
                                } value={numero}></input>
                                <br></br>
                                <br></br>
                                <label>Password</label>
                                <br></br>
                                <input type="password" placeholder="Password" onChange={
                                    function (e) {
                                        setPassword(e.target.value)
                                    }
                                } value={password}></input>
                                <br></br>
                                <br></br>
                                <label style={{ display: "inline-block" }}>Trade Link&nbsp;<a target="_blank" rel="noreferrer" href="https://steamcommunity.com/id/me/tradeoffers/privacy#trade_offer_access_url">Obtem aqui</a></label>
                                <br></br>
                                <input type="text" placeholder="Trade Link URL" onChange={
                                    function (e) {
                                        setTradeLink(e.target.value)
                                    }
                                } value={tradeLink}></input>
                                <br></br>
                                <br></br>
                                <div className="checkbox-inputs">
                                    <label>A tua conta steam é pública?</label>
                                    <input type="checkbox" onChange={
                                        function (e) {
                                            setEPublico(e.target.checked)
                                        }
                                    } checked={ePublico}></input>
                                </div>
                                <div className="checkbox-inputs">
                                    <label>Tens MB Way?</label>
                                    <input type="checkbox" onChange={
                                        function (e) {
                                            setTemMBWay(e.target.checked)
                                        }
                                    } checked={temMBWay}></input>
                                </div>
                                <div className="div-btn">
                                    <button onClick={btnSubmeter}>Registar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </>
        )
    }
    else {
        return null
    }

}
export default ModalLogin