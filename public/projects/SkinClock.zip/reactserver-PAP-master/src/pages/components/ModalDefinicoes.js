import "./css/modaldefinicoes.css"
import { FaTimes } from "react-icons/fa"
import { useState } from "react"
import Alerta from "./Alerta"
import jQuery from "jquery"
import { useEffect } from "react"
import config from "./cfg/config.json"
import { useCookies } from "react-cookie"
function ModalDefinicoes({ mostrar, fechar }) {
    const [cookies] = useCookies(["uuid"])
    const [alerta, mostrarAlerta] = useState(false)
    const [alertaTipo, setAlertaTipo] = useState()
    const [alertaMensagem, setAlertaMensagem] = useState()
    const [email, setEmail] = useState()
    const [telemovel, setTelemovel] = useState("")
    const [password, setPassword] = useState()
    const [tradeLink, setTradeLink] = useState("")
    useEffect(function () {
        if (cookies.uuid) {
            var def = {
                method: "GET",
                url: "http://" + config.ip + ":3001/info-conta",
                xhrFields: {
                    withCredentials: true
                }
            }
            jQuery.ajax(def).done(function (data) {
                setEmail(data.email)
                setTelemovel(data.numero)
                setTradeLink(data.tradeLink)
            })

        }
    }, [cookies.uuid])
    function btnSubmeter(e) {
        e.preventDefault()
        var regexEmail = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
        var regexTelemovel = /^\d{9}$/g
        if (!email.match(regexEmail)) {
            setAlertaTipo("erro")
            setAlertaMensagem("Coloca um email válido.")
            mostrarAlerta(true)
        }
        else if (!telemovel.match(regexTelemovel)) {
            setAlertaTipo("erro")
            setAlertaMensagem("Coloca um número de telemóvel válido.")
            mostrarAlerta(true)
        }
        else {
            var data = {
                email: email,
                telemovel: telemovel,
                password: password,
                tradeLink: tradeLink
            }
            if (!email) {
                data.email = ""
            }
            if (!telemovel) {
                data.telemovel = ""
            }
            if (!tradeLink) {
                data.tradeLink = ""
            }
            if (!password) {
                data.password = ""
                var def = {
                    method: "PUT",
                    url: "http://" + config.ip + ":3001/alterar-definicoes-conta",
                    data: data,
                    xhrFields: {
                        withCredentials: true
                    }
                }
                jQuery.ajax(def)
                    .done(function (data) {
                        setAlertaTipo("sucesso")
                        setAlertaMensagem(data)
                        mostrarAlerta(true)
                    })
                    .fail(function (data) {
                        setAlertaTipo("erro")
                        setAlertaMensagem(data.responseText)
                        mostrarAlerta(true)
                    })
            }
            else {
                if (prompt("Confirme a sua nova password") === password) {
                    def = {
                        method: "PUT",
                        url: "http://" + config.ip + ":3001/alterar-definicoes-conta",
                        data: data,
                        xhrFields: {
                            withCredentials: true
                        }
                    }
                    jQuery.ajax(def)
                        .done(function (data) {
                            setAlertaTipo("sucesso")
                            setAlertaMensagem(data)
                            mostrarAlerta(true)
                        })
                        .fail(function (data) {
                            setAlertaTipo("erro")
                            setAlertaMensagem(data.responseText)
                            mostrarAlerta(true)
                        })
                }
                else {
                    setAlertaTipo("erro")
                    setAlertaMensagem("Confirmação errada.")
                    mostrarAlerta(true)
                }
            }
        }
    }
    if (mostrar) {
        return (
            <>
                <Alerta mostrar={alerta} tipo={alertaTipo} mensagem={alertaMensagem} fecharAlerta={
                    function () {
                        mostrarAlerta(false)
                    }
                } />
                <div className="bg"></div>
                <div className="modal-definicoes">
                    <div className="row1">
                        <div className="btn-definicoes">
                            <button>Definições</button>
                        </div>
                        <FaTimes className="fechar-btn" onClick={fechar} />
                    </div>
                    <div >
                        <div className="body-modal show">
                            <form>
                                <label>Email</label>
                                <br></br>
                                <input type="email" placeholder="Email" onChange={
                                    function (e) {
                                        setEmail(e.target.value)
                                    }
                                } value={email}></input>
                                <br></br>
                                <br></br>
                                <label>Número de Telemóvel</label>
                                <br></br>
                                <input type="tel" placeholder="Número de Telemóvel (Ex: 911111111)" onChange={
                                    function (e) {
                                        setTelemovel(e.target.value)
                                    }
                                } value={telemovel}></input>
                                <br></br>
                                <br></br>
                                <label>Password</label>
                                <br></br>
                                <input type="password" placeholder="Password" onChange={
                                    function (e) {
                                        setPassword(e.target.value)
                                    }
                                }></input>
                                <br></br>
                                <br></br>
                                <label style={{ display: "inline-block" }}>Trade Link&nbsp;<a target="_blank" rel="noreferrer" href="https://steamcommunity.com/id/me/tradeoffers/privacy#trade_offer_access_url">Obtem aqui</a></label>
                                <br></br>
                                <input type="text" placeholder="Trade Link" onChange={
                                    function (e) {
                                        setTradeLink(e.target.value)
                                    }
                                } defaultValue={tradeLink}></input>
                                <br></br>
                                <br></br>
                                <div className="div-mudar">
                                    <button onClick={btnSubmeter}>Mudar!</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </>
        )
    }
    else {
        return null
    }

}
export default ModalDefinicoes