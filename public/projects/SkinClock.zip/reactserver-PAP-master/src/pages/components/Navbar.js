import { FaBars, FaTimes, FaCog, FaDoorOpen } from "react-icons/fa"
import "./css/navbar.css"
import logo from "./img/logo.png"
import { Link } from "react-router-dom"
import { useEffect, useState } from "react"
import ModalLogin from "./ModalLogin"
import jQuery from "jquery"
import ModalDefinicoes from "./ModalDefinicoes"
import config from "./cfg/config.json"
import { useCookies } from "react-cookie"
function Navbar() {
	const [cookies, , removeCookie] = useCookies(["uuid", "steam64", "avatar"])
	const [modalLogin, setModalLogin] = useState(false)
	const [modalDefinicoes, setModalDefinicoes] = useState(false)
	const [email, setEmail] = useState()
	const [telemovel, setTelemovel] = useState()
	const [admin, setAdmin] = useState(null)
	function clickTimesBars(e) {
		if (document.getElementById("links-telemovel").classList.contains("off")) {
			document.getElementById("links-telemovel").className = "links on"
		}
		else {
			document.getElementById("links-telemovel").className = "links off"
		}
	}
	function clickLogin(e) {
		setModalLogin(true)
		if (window.innerWidth <= 1000) {
			document.getElementById("links-telemovel").className = "links off"
		}
	}
	useEffect(function () {
		if (cookies.uuid) {
			var def = {
				method: "GET",
				url: "http://" + config.ip + ":3001/info-conta",
				xhrFields: {
					withCredentials: true
				}
			}
			jQuery.ajax(def).done(function (data) {
				setEmail(data.email)
				setAdmin(data.admin)
				setTelemovel(data.numero)
			})
		}
		if (cookies.steam64 && !cookies.uuid) {
			setModalLogin(true)
		}
	}, [cookies.uuid, cookies.steam64])
	useEffect(function () {
		if (cookies.uuid) {
			var def = {
				method: "GET",
				url: "http://" + config.ip + ":3001/info-conta",
				xhrFields: {
					withCredentials: true
				}
			}
			jQuery.ajax(def).done(function (data) {
				setEmail(data.email)
				if (admin) {
					if (data.admin !== admin) {
						window.location.reload()
					}
				}
				setAdmin(data.admin)
			})
		}
	})
	return (
		<>
			<ModalDefinicoes mostrar={modalDefinicoes} fechar={
				function () {
					setModalDefinicoes(false)
				}
			} />
			<ModalLogin mostrar={modalLogin} fechar={
				function () {
					setModalLogin(false)
				}
			} />
			<div className="navbar-pc">
				<div className="info-conta">
					{!cookies.uuid &&
						<div>
							<button className="btn-login" onClick={clickLogin}>Login&nbsp;/&nbsp;Registar</button>
						</div>
					}
					{cookies.uuid &&
						<>
							<div className="email-telemovel-avatar">
								<div className="email-telemovel">
									<span className="email">{email}</span>
									<span className="telemovel">{telemovel}</span>
								</div>
								<img className="avatar" src={cookies.avatar} alt="avatar"></img>
							</div>
							<div className="definicoes-e-logout">
								<FaCog onClick={function (e) {
									setModalDefinicoes(true)
								}} />
								<FaDoorOpen onClick={function (e) {
									removeCookie("uuid")
									removeCookie("steam64")
									removeCookie("avatar")
									window.location.reload()
								}} />
							</div>
						</>
					}
				</div>
				<nav>
					<img src={logo} alt="Logo" className="logo"></img>
					<div className="links">
						{window.location.pathname === "/mercado" &&
							<Link to="/mercado" className="link-ativo">Mercado</Link>
						}
						{window.location.pathname !== "/mercado" &&
							<Link to="/mercado" className="link">Mercado</Link>
						}
						<br></br>
						<br></br>
						{window.location.pathname === "/" &&
							<Link to="/" className="link-ativo">Sobre nós</Link>
						}
						{window.location.pathname !== "/" &&
							<Link to="/" className="link">Sobre nós</Link>
						}
						<br></br>
						<br></br>
						{window.location.pathname === "/contacto" &&
							<Link to="/contacto" className="link-ativo">F.A.Q & Contacto</Link>
						}
						{window.location.pathname !== "/contacto" &&
							<Link to="/contacto" className="link">F.A.Q & Contacto</Link>
						}
						<br></br>
						<br></br>
						{window.location.pathname === "/transacoes" && cookies.uuid &&
							<Link to="/transacoes" className="link-ativo">Transações</Link>
						}
						{window.location.pathname !== "/transacoes" && cookies.uuid &&
							<Link to="/transacoes" className="link">Transações</Link>
						}
						<br></br>
						<br></br>
						{window.location.pathname === "/admin" && cookies.uuid && admin > 0 &&
							<Link to="/admin" className="link-ativo">Admin</Link>
						}
						{window.location.pathname !== "/admin" && cookies.uuid && admin > 0 &&
							<Link to="/admin" className="link">Admin</Link>
						}
					</div>
				</nav>
			</div>
			<div className="navbar-telemovel">
				<div id="links-telemovel" className="links off">
					<div><button className="btnTimes" onClick={clickTimesBars}><FaTimes /></button></div>
					{window.location.pathname === "/mercado" &&
						<Link to="/mercado" className="link-ativo">Mercado</Link>
					}
					{window.location.pathname !== "/mercado" &&
						<Link to="/mercado" className="link">Mercado</Link>
					}
					<br></br>
					<br></br>
					{window.location.pathname === "/" &&
						<Link to="/" className="link-ativo">Sobre nós</Link>
					}
					{window.location.pathname !== "/" &&
						<Link to="/" className="link">Sobre nós</Link>
					}
					<br></br>
					<br></br>
					{window.location.pathname === "/contacto" &&
						<Link to="/contacto" className="link-ativo">F.A.Q & Contacto</Link>
					}
					{window.location.pathname !== "/contacto" &&
						<Link to="/contacto" className="link">F.A.Q & Contacto</Link>
					}
					<br></br>
					<br></br>
					{window.location.pathname === "/transacoes" && cookies.uuid &&
						<Link to="/transacoes" className="link-ativo">Transações</Link>
					}
					{window.location.pathname !== "/transacoes" && cookies.uuid &&
						<Link to="/transacoes" className="link">Transações</Link>
					}
					<br></br>
					<br></br>
					{window.location.pathname === "/admin" && cookies.uuid && admin &&
						<Link to="/admin" className="link-ativo">Admin</Link>
					}
					{window.location.pathname !== "/admin" && cookies.uuid && admin &&
						<Link to="/admin" className="link">Admin</Link>
					}
					<div className="info-conta">
						{!cookies.uuid &&
							<button className="btn-login" onClick={clickLogin}>Login&nbsp;/&nbsp;Registar</button>
						}
						{cookies.uuid &&
							<>
								<div className="email-telemovel">
									<span className="email">{email}</span>
									<span className="telemovel">{telemovel}</span>
								</div>
								<div className="definicoes-e-logout">
									<FaCog onClick={function (e) {
										if (window.innerWidth <= 1000) {
											document.getElementById("links-telemovel").className = "links off"
										}
										setModalDefinicoes(true)
									}} />
									<FaDoorOpen onClick={function (e) {
										removeCookie("uuid")
										removeCookie("steam64")
										removeCookie("avatar")
										window.location.reload()
									}} />
								</div>
							</>
						}
					</div>
				</div>
				<nav>
					<div><img src={logo} alt="Logo" className="logo"></img></div>
					<button className="btnBars" onClick={clickTimesBars}><FaBars /></button>
				</nav>
			</div>
		</>
	)

}

export default Navbar