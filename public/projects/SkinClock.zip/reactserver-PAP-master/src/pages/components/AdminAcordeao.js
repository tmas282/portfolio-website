import { useState } from "react"
import "./css/adminacordeao.css"
import jQuery from "jquery"
import config from "./cfg/config.json"
import Alerta from "./Alerta"
function AdminAcordeao({ id, problema, nome, email, mensagem, respondido, quem_respondeu, atualizar }) {
    const [ativo, setAtivo] = useState(false)
    const [alerta, mostrarAlerta] = useState(false)
    const [alertaTipo, setAlertaTipo] = useState()
    const [alertaMensagem, setAlertaMensagem] = useState()
    return (
        <>
            <Alerta mostrar={alerta} tipo={alertaTipo} mensagem={alertaMensagem} fecharAlerta={
                function () {
                    mostrarAlerta(false)
                }
            } />
            <div className="acordeao-admin">
                <div className="titulo">
                    <input type="checkbox" value={respondido} disabled={Boolean(respondido)} title={"Respondido por: " + quem_respondeu} onChange={function (e) {
                        var data = {
                            id: id
                        }
                        var def = {
                            method: "PUT",
                            url: "http://" + config.ip + ":3001/form-contacto-respondido",
                            data: data,
                            xhrFields: {
                                withCredentials: true
                            }
                        }
                        jQuery.ajax(def)
                            .done(function (data) {
                                setAlertaTipo("sucesso")
                                setAlertaMensagem(data)
                                mostrarAlerta(true)
                                atualizar()
                            })
                    }}></input>
                    <span className="problema">{problema}</span>
                    <button className="abrirFechar" onClick={function () {
                        if (ativo) {
                            setAtivo(false)
                        }
                        else {
                            setAtivo(true)
                        }
                    }}>{ativo && "Esconder"}{!ativo && "Ver mais"}</button>
                </div>
                {ativo &&
                    <div className="info">
                        <span>Nome: {nome}</span>
                        <br></br>
                        <span>Email: {email}</span>
                        <br></br>
                        <span>Mensagem:<br></br>{mensagem}</span>
                    </div>
                }
            </div>
        </>
    )
}
export default AdminAcordeao