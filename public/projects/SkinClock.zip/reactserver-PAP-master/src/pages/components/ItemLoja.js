import { FaCartPlus, FaTrash } from "react-icons/fa"
import "./css/itemloja.css"
import { BsEyeglasses } from "react-icons/bs"
import Alerta from "./Alerta"
import { useState } from "react"
import jQuery from "jquery"
import config from "./cfg/config.json"
import { useCookies } from "react-cookie"
function ItemLoja({ nome, estado, img, link_ver_jogo, preco, uuidVendedor, id }) {
    const [cookies] = useCookies(["uuid"])
    const [alerta, mostrarAlerta] = useState(false)
    const [alertaTipo, setAlertaTipo] = useState()
    const [alertaMensagem, setAlertaMensagem] = useState()
    function verificarVerNoJogo(e) {
        if (!link_ver_jogo) {
            e.preventDefault()
            mostrarAlerta(true)
            setAlertaTipo("erro")
            setAlertaMensagem("Não tem preview disponível")
        }
    }
    function comprarSkin(e) {
        e.preventDefault()
        setAlertaMensagem("Aguarde...")
        setAlertaTipo("info")
        mostrarAlerta(true)
        var data = {
            idSkin: id,
            uuidVendedor: uuidVendedor
        }
        var def = {
            method: "POST",
            url: "http://" + config.ip + ":3001/comprar-skin",
            data: data,
            xhrFields: {
                withCredentials: true
            }
        }
        jQuery.ajax(def)
            .done(function (data) {
                setAlertaMensagem(data)
                setAlertaTipo("info")
                mostrarAlerta(true)
            })
            .fail(function (data) {
                setAlertaMensagem(data.responseText)
                setAlertaTipo("erro")
                mostrarAlerta(true)
            })
    }
    return (
        <>
            <Alerta mostrar={alerta} tipo={alertaTipo} mensagem={alertaMensagem} fecharAlerta={
                function () {
                    mostrarAlerta(false)
                }
            } />
            <article className="item">
                <span className="titulo">{nome}</span>
                <br></br>
                <span className={"estado " + (nome.length <= 26 ? "com-altura" : true)}>{estado}</span>
                <br></br>
                <div className="div-img">
                    <img className="img" alt={nome} src={img}></img>
                </div>
                <div className="row">
                    <div className="btns">
                        <button onClick={comprarSkin}><FaCartPlus /></button>
                        <a href={link_ver_jogo} onClick={verificarVerNoJogo} target="_blank" rel="noreferrer"><BsEyeglasses /></a>
                        {cookies.uuid === uuidVendedor &&
                            <button className="btn-apagar" onClick={
                                function (e) {
                                    e.preventDefault()
                                    var data = {
                                        idSkin: id
                                    }
                                    var def = {
                                        method: "DELETE",
                                        url: "http://" + config.ip + ":3001/remover-item",
                                        data: data,
                                        xhrFields: {
                                            withCredentials: true
                                        }
                                    }
                                    jQuery.ajax(def)
                                        .done(function (data) {
                                            setAlertaTipo("sucesso")
                                            setAlertaMensagem(data)
                                            mostrarAlerta(true)
                                        })
                                }
                            }><FaTrash /></button>
                        }
                    </div>
                    <span className="preco">{preco.toFixed(2)} €</span>
                </div>
            </article>
        </>
    )
}
export default ItemLoja