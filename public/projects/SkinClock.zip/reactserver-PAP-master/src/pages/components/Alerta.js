import { useEffect } from "react"
import { useState } from "react"
import { FaCheck, FaExclamationTriangle, FaInfo, } from "react-icons/fa"
import { HiX } from "react-icons/hi"
import "./css/alerta.css"
function Alerta({ tipo, mostrar, mensagem, fecharAlerta }) {
    const [cor, setCor] = useState()
    useEffect(function () {
        if (tipo === "sucesso") {
            setCor("rgb(74, 112, 74)")
        }
        if (tipo === "erro") {
            setCor("rgb(138, 67, 67)")
        }
        if (tipo === "info") {
            setCor("rgb(185, 184, 93)")
        }
    }, [tipo])
    useEffect(function () {
        if (mostrar) {
            const timer = setTimeout(function () {
                fecharAlerta()
            }, 1000)

            return function () {
                clearTimeout(timer)
            }
        }
    }, [mostrar, fecharAlerta])
    if (mostrar === true) {
        return (
            <div className="alerta" style={{ backgroundColor: cor }}>
                {tipo === "sucesso" &&
                    <FaCheck className="icon" />
                }
                {tipo === "erro" &&
                    <FaExclamationTriangle className="icon" />
                }
                {tipo === "info" &&
                    <FaInfo className="icon" />
                }
                <span className="titulo">{mensagem}</span>
                <div><button className="fechar-btn" onClick={fecharAlerta}><HiX /></button></div>
            </div>
        )
    }
    else {
        return null
    }
}
export default Alerta