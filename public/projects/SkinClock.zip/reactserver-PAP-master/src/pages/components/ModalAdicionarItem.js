import { useEffect, useState } from "react"
import { FaCartPlus, FaTimes } from "react-icons/fa"
import { BsEyeglasses } from "react-icons/bs"
import jQuery from "jquery"
import "./css/modaladicionaritem.css"
import Alerta from "./Alerta"
import config from "./cfg/config.json"
function ModalAdicionarItem({ mostrar, fechar }) {
    const [items, setItems] = useState()
    const [itemSelecionado, setItemSelecionado] = useState()
    const [precoAVender, setPrecoAVender] = useState(0.02)
    const [alerta, mostrarAlerta] = useState(false)
    const [alertaTipo, setAlertaTipo] = useState()
    const [alertaMensagem, setAlertaMensagem] = useState()
    useEffect(function () {
        var def = {
            method: "GET",
            url: "http://" + config.ip + ":3001/pesquisar-inventario",
            xhrFields: {
                withCredentials: true
            }
        }
        jQuery.ajax(def)
            .done(function (data) {
                setAlertaMensagem("Inventário carregado.")
                setAlertaTipo("info")
                mostrarAlerta(true)
                setItems(data)
            })
            .fail(function (data) {
                setAlertaMensagem(data.responseText)
                setAlertaTipo("erro")
                mostrarAlerta(true)
            })
    }, [])
    function adicionarItem(e) {
        e.preventDefault()
        if (itemSelecionado) {
            var data = {
                item: JSON.stringify(itemSelecionado),
                preco: precoAVender
            }
            var def = {
                method: "POST",
                url: "http://" + config.ip + ":3001/adicionar-item",
                data: data,
                xhrFields: {
                    withCredentials: true
                }
            }
            jQuery.ajax(def)
                .done(function () {
                    setAlertaTipo("sucesso")
                    setAlertaMensagem("Item adicionado.")
                    mostrarAlerta(true)
                })
                .fail(function (data) {
                    if (data.status === 409) {
                        setAlertaTipo("erro")
                        setAlertaMensagem("Já colocaste este item à venda.")
                        mostrarAlerta(true)
                    }
                })
        }
    }
    if (mostrar) {
        return (
            <>
                <Alerta mostrar={alerta} tipo={alertaTipo} mensagem={alertaMensagem} fecharAlerta={
                    function (e) {
                        mostrarAlerta(false)
                    }
                } />
                <div className="bg"></div>
                <div className="modal-adicionar-item">
                    <div className="row1">
                        <span>Adicionar Item</span>
                        <FaTimes className="fechar-btn" onClick={fechar} />
                    </div>
                    <div className="body-modal">
                        <div className="ver-preview-div">
                            <select onChange={function (e) {
                                if (e.target.value !== "none") {
                                    setItemSelecionado(JSON.parse(e.target.value))
                                }
                            }} defaultValue={"none"}>
                                <option value={"none"}>Escolhe um</option>
                                {items &&
                                    items.map(function (element, index) {
                                        if (element === null) {
                                            return null
                                        }
                                        return <option key={index} value={JSON.stringify(element)}>{element.market_name}</option>
                                    })
                                }
                            </select>
                        </div>
                        <div className="preview">
                            <span>Preview:</span>
                            {itemSelecionado &&
                                <article className="item" style={{
                                    marginLeft: "auto",
                                    marginRight: "auto"
                                }}>
                                    <span className="titulo">
                                        {(itemSelecionado.type.toUpperCase().includes("STICKER") || itemSelecionado.type.toUpperCase().includes("MUSIC KIT")) &&
                                            itemSelecionado.market_name.slice(itemSelecionado.name.indexOf("|") + 2)
                                        }
                                        {((!itemSelecionado.type.toUpperCase().includes("STICKER") && !itemSelecionado.type.toUpperCase().includes("MUSIC KIT")) || itemSelecionado.type.toUpperCase().includes("AGENT")) &&
                                            itemSelecionado.name
                                        }
                                    </span>
                                    <br></br>
                                    <span className="estado">
                                        {itemSelecionado.tags[0].localized_tag_name.toUpperCase() === "MUSIC KIT" && "Music Kit"}
                                        {itemSelecionado.tags[0].localized_tag_name.toUpperCase() === "STICKER" && "Sticker"}
                                        {itemSelecionado.tags[0].localized_tag_name.toUpperCase() === "AGENT" && "Agent"}
                                        {(itemSelecionado.tags[0].localized_tag_name.toUpperCase() !== "AGENT" && itemSelecionado.tags[0].localized_tag_name.toUpperCase() !== "MUSIC KIT" && itemSelecionado.tags[0].localized_tag_name.toUpperCase() !== "STICKER") &&
                                            itemSelecionado.tags[5].localized_tag_name
                                        }
                                    </span>
                                    <br></br>
                                    <div className="div-img">
                                        <img className="img" alt={itemSelecionado.market_name} src={"https://community.akamai.steamstatic.com/economy/image/" + itemSelecionado.icon_url}></img>
                                    </div>
                                    <div className="row">
                                        <div className="btns">
                                            <button><FaCartPlus /></button>
                                            <button><BsEyeglasses /></button>
                                        </div>
                                        <span className="preco">{precoAVender} €</span>
                                    </div>
                                </article>
                            }
                        </div>
                    </div>
                    <div className="footer-modal">
                        <div className="set-preco-div">
                            <input type="number" value={precoAVender} placeholder="Preço a vender" step={0.01} min={0.02} onChange={
                                function (e) {
                                    if (e.target.value >= 0.02) {
                                        setPrecoAVender(parseFloat(e.target.value).toFixed(2))
                                    }
                                    else {
                                        setPrecoAVender(0.02)
                                    }
                                }
                            }></input>
                        </div>
                        <button className="btn-adicionar-loja" onClick={adicionarItem}>Adicionar!</button>
                    </div>
                </div >
            </>
        )
    }
    else {
        return null
    }
}
export default ModalAdicionarItem