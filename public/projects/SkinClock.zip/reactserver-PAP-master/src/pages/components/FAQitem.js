import { useId, useRef } from "react"
import { FaCaretDown, FaCaretUp } from "react-icons/fa"
import "./css/faqitem.css"
function FAQItem({titulo, resposta}) {
    function clickMostrar(e) {
        if (idResposta.current.classList.contains("hide")) {
            idResposta.current.className = "resposta show"
            document.getElementById(idBaixo).style.display = "none"
            document.getElementById(idCima).style.display = "block"
        }
        else {
            idResposta.current.className = "resposta hide"
            document.getElementById(idBaixo).style.display = "block"
            document.getElementById(idCima).style.display = "none"
        }
    }
    var idResposta = useRef()
    var idBaixo = useId()
    var idCima = useId()
    return (
        <article>
            <h1 className="titulo">{titulo} <button onClick={clickMostrar}><FaCaretDown id={idBaixo} style={{ display: "block" }} /><FaCaretUp id={idCima} style={{ display: "none" }} /></button></h1>
            <ol className="resposta hide" ref={idResposta}>{
                resposta.map(function (valor) {
                    return <li key={resposta.indexOf(valor).toString()} className="respostaItem">{valor}</li>
                })
            }</ol>
        </article>
    )
}
export default FAQItem