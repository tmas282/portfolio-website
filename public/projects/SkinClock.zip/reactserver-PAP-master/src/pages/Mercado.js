import Navbar from "./components/Navbar"
import "./components/css/mercado.css"
import jQuery from "jquery"
import { useCallback, useState } from "react"
import { useEffect } from "react"
import ItemLoja from "./components/ItemLoja"
import ModalAdicionarItem from "./components/ModalAdicionarItem"
import config from "./components/cfg/config.json"
import { useCookies } from "react-cookie"
function Mercado() {
    const [cookies] = useCookies(["uuid"])
    const [items, setItems] = useState(null)
    const [aparencia, setAparencia] = useState("Todos")
    const [filtroPreco, setFiltroPreco] = useState("none")
    const [pesquisa, setPesquisa] = useState("")
    const [modalAdicionarItem, setModalAdicionarItem] = useState(false)
    const obterItems = useCallback(function () {
        var data = {
            aparencia: aparencia,
            filtroPreco: filtroPreco,
            pesquisa: pesquisa
        }
        var def = {
            method: "GET",
            url: "http://" + config.ip + ":3001/skins-em-stock",
            data: data
        }
        jQuery.ajax(def).done(function (data) {
            setItems(data)
        })
    }, [aparencia, filtroPreco, pesquisa])
    function clickBtnFiltro(e) {
        if (window.innerWidth > 1000) {
            jQuery(".aparencia-filtro.ativo").removeClass("ativo")
            e.target.className = "aparencia-filtro ativo"
        }
        setAparencia(e.target.value)
        obterItems()
    }
    function clickOrdemPreco(e) {
        jQuery(".filtro-preco.ativo").removeClass("ativo")
        e.target.className = "filtro-preco ativo"
        setFiltroPreco(e.target.value)
        obterItems()
    }
    useEffect(function () {
        const intervalo = setInterval(function () {
            obterItems()
        }, 1000)
        return function () {
            clearInterval(intervalo)
        }
    }, [obterItems])
    return (
        <>
            {cookies.uuid &&
                <ModalAdicionarItem mostrar={modalAdicionarItem} fechar={
                    function () {
                        setModalAdicionarItem(false)
                    }} />
            }
            <Navbar />
            <section className="aparencia-div-pc">
                <span>Aparência:</span>
                &nbsp;
                <button value={"Todos"} onClick={clickBtnFiltro} className="aparencia-filtro ativo">Todos</button>
                <button value={"Battle-Scarred"} onClick={clickBtnFiltro} className="aparencia-filtro">Battle-Scarred</button>
                <button value={"Well-Worn"} onClick={clickBtnFiltro} className="aparencia-filtro">Well-Worn</button>
                <button value={"Field-Tested"} onClick={clickBtnFiltro} className="aparencia-filtro">Field-Tested</button>
                <button value={"Minimal Wear"} onClick={clickBtnFiltro} className="aparencia-filtro">Minimal Wear</button>
                <button value={"Factory New"} onClick={clickBtnFiltro} className="aparencia-filtro">Factory New</button>
                <button value={"Sticker"} onClick={clickBtnFiltro} className="aparencia-filtro">Sticker</button>
                <button value={"Music Kit"} onClick={clickBtnFiltro} className="aparencia-filtro">Music Kit</button>
                <button value={"Agent"} onClick={clickBtnFiltro} className="aparencia-filtro">Agent</button>
            </section>
            <section className="aparencia-div-telemovel">
                <span>Aparência:</span>
                <select onChange={clickBtnFiltro}>
                    <option value={"Todos"}>Todos</option>
                    <option value={"Battle-Scarred"}>Battle-Scarred</option>
                    <option value={"Well-Worn"}>Well-Worn</option>
                    <option value={"Field-Tested"}>Field-Tested</option>
                    <option value={"Minimal Wear"}>Minimal Wear</option>
                    <option value={"Factory New"}>Factory New</option>
                    <option value={"Sticker"}>Sticker</option>
                    <option value={"Music Kit"}>Music Kit</option>
                    <option value={"Agent"}>Agent</option>
                </select>
            </section>
            <div className="preco-e-pesquisa-div">
                <form className="pesquisa-form">
                    <input type="text" placeholder="Pesquisa aqui..." onChange={function(e){
                        setPesquisa(e.target.value)
                        obterItems()
                    }} defaultValue={pesquisa}></input>
                </form>
                <section className="precos-div">
                    <span>Preço:</span>
                    &nbsp;
                    <button value={"maior-menor"} className="filtro-preco" onClick={clickOrdemPreco} style={{
                        backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 320 512' fill='rgb(238, 238, 238)'><path d='M137.4 374.6c12.5 12.5 32.8 12.5 45.3 0l128-128c9.2-9.2 11.9-22.9 6.9-34.9s-16.6-19.8-29.6-19.8L32 192c-12.9 0-24.6 7.8-29.6 19.8s-2.2 25.7 6.9 34.9l128 128z'/></svg>")`
                    }}></button>
                    <button value={"menor-maior"} className="filtro-preco" onClick={clickOrdemPreco} style={{
                        backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 320 512' fill='rgb(238, 238, 238)'><path d='M182.6 137.4c-12.5-12.5-32.8-12.5-45.3 0l-128 128c-9.2 9.2-11.9 22.9-6.9 34.9s16.6 19.8 29.6 19.8H288c12.9 0 24.6-7.8 29.6-19.8s2.2-25.7-6.9-34.9l-128-128z'/></svg>")`
                    }}></button>
                </section>
            </div>
            {cookies.uuid &&
                <div className="adicionar-skin-div">
                    <button onClick={
                        function () {
                            setModalAdicionarItem(true)
                        }
                    }>Adicionar skin</button>
                </div>
            }
            <section className="items">
                {items !== null &&
                    <>
                        <div className="items-col" key={"col-1"}>{
                            items.map(function (element) {
                                if (element.renderPos === 1) {
                                    return <ItemLoja id={element.id} link_ver_jogo={element.link_ver_jogo} nome={element.nome} estado={element.estado} img={element.img} preco={element.preco} uuidVendedor={element.uuid_vendedor} key={element.id} />
                                }
                                return null
                            })
                        }</div>
                        <div className="items-col" key={"col-2"}>{
                            items.map(function (element) {
                                if (element.renderPos === 2) {
                                    return <ItemLoja id={element.id} link_ver_jogo={element.link_ver_jogo} nome={element.nome} estado={element.estado} img={element.img} preco={element.preco} uuidVendedor={element.uuid_vendedor} key={element.id} />
                                }
                                return null
                            })
                        }</div>
                        <div className="items-col" key={"col-3"}>{
                            items.map(function (element) {
                                if (element.renderPos === 3) {
                                    return <ItemLoja id={element.id} link_ver_jogo={element.link_ver_jogo} nome={element.nome} estado={element.estado} img={element.img} preco={element.preco} uuidVendedor={element.uuid_vendedor} key={element.id} />
                                }
                                return null
                            })
                        }</div>
                    </>
                }
            </section>
        </>
    )
}
export default Mercado