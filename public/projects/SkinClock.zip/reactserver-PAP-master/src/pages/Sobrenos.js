import "./components/css/sobrenos.css"
import redlaminate from "./components/img/redlaminate.png"
import fireserpent from "./components/img/fireserpent.png"
import Navbar from "./components/Navbar"
import { useEffect, useState } from "react"
import jQuery from "jquery"
import config from "./components/cfg/config.json"
function Sobrenos() {
    const [quantidadeSkins, setQuantidadeSkins] = useState(0)
    useEffect(function () {
        var def = {
            method: "GET",
            url: "http://" + config.ip + ":3001/numero-de-skins"
        }
        jQuery.ajax(def).done(function (data) {
            setQuantidadeSkins(data.quantidadeSkins)
        })
    })
    return (
        <>
            <Navbar />
            <section>
                <div className="row1">
                    <div>
                        <h1>Compra as melhores skins</h1>
                        <span>
                            Neste mercado, podes encontrar as melhores skins e outros itens.
                            Pagamento P2P via MB Way.
                        </span>
                    </div>
                    <table>
                        <tbody>
                            <tr>
                                <td></td>
                                <td><img src={fireserpent} alt="FIRE SERPENT"></img></td>
                            </tr>
                            <tr>
                                <td><img src={redlaminate} alt="RED LAMINATE"></img></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div className="row2">
                    <div>
                        <span className="numero">{quantidadeSkins}</span>
                        <hr>
                        </hr>
                        <span className="descricao">Itens no mercado</span>
                    </div>
                    <div>
                        <span className="numero">100%</span>
                        <hr>
                        </hr>
                        <span className="descricao">Português</span>
                    </div>
                </div>
                <div className="row3">
                    <h1>Entra no nosso discord</h1>
                    <a target="_blank" rel="noreferrer" href="https://discord.gg/Wc9j4JeQ3V" className="btn-discord">Convite do discord</a>
                </div>
            </section>
        </>
    )
}

export default Sobrenos