import React from "react"
import ReactDOM from "react-dom/client"
import Mercado from "./pages/Mercado"
import Sobrenos from "./pages/Sobrenos"
import Contacto from "./pages/Contacto"
import "./index.css"
import { BrowserRouter as Router, Switch, Route, withRouter } from "react-router-dom"
import Transacoes from "./pages/Transacoes"
import Admin from "./pages/Admin"
import Erro404 from "./pages/Erro404"
import RecuperarPassword from "./pages/RecuperarPassword"
import { CookiesProvider } from "react-cookie"
const root = ReactDOM.createRoot(document.getElementById("root"))
root.render(
  <React.StrictMode>
    <CookiesProvider>
      <Router>
        <Switch>
          <Route exact path="/" component={withRouter(Sobrenos)} />
          <Route exact path="/mercado" component={withRouter(Mercado)} />
          <Route exact path="/contacto" component={withRouter(Contacto)} />
          <Route exact path="/transacoes" component={withRouter(Transacoes)} />
          <Route exact path="/admin" component={withRouter(Admin)} />
          <Route exact path="/recuperar-password" component={withRouter(RecuperarPassword)} />
          <Route path="*" component={withRouter(Erro404)} />
        </Switch>
      </Router>
    </CookiesProvider>
  </React.StrictMode>
)