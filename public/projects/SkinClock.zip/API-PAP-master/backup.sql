-- --------------------------------------------------------
-- Servidor:                     db4free.net
-- Versão do servidor:           8.0.33 - MySQL Community Server - GPL
-- OS do Servidor:               Linux
-- HeidiSQL Versão:              12.4.0.6659
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Copiando estrutura do banco de dados para paptomas
CREATE DATABASE IF NOT EXISTS `paptomas` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `paptomas`;

-- Copiando estrutura para tabela paptomas.tb_contacto
CREATE TABLE IF NOT EXISTS `tb_contacto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL DEFAULT '0',
  `email` varchar(255) NOT NULL DEFAULT '0',
  `mensagem` varchar(255) NOT NULL DEFAULT '0',
  `problema` varchar(255) NOT NULL DEFAULT '0',
  `respondido` tinyint NOT NULL DEFAULT '0',
  `quem_respondeu` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quem_respondeu` (`quem_respondeu`),
  CONSTRAINT `quem_respondeu` FOREIGN KEY (`quem_respondeu`) REFERENCES `tb_contas` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8mb4_0900_ai_ci;

-- Copiando dados para a tabela paptomas.tb_contacto: ~0 rows (aproximadamente)
DELETE FROM `tb_contacto`;
INSERT INTO `tb_contacto` (`id`, `nome`, `email`, `mensagem`, `problema`, `respondido`, `quem_respondeu`) VALUES
	(34, 'Tomás Moreira', 'tomaspintomoreira@outlook.com', 'Não recebi a minha skin que comprei.\nUUID da compra: 71aa3baf-1609-44da-be39-f8244c7692d1', 'Não recebi a minha skin', 0, NULL);

-- Copiando estrutura para tabela paptomas.tb_contas
CREATE TABLE IF NOT EXISTS `tb_contas` (
  `uuid` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `steam64` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trade_link` varchar(255) DEFAULT NULL,
  `admin` int NOT NULL DEFAULT '0',
  `token` varchar(255) DEFAULT NULL,
  `numero` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `phone` (`numero`) USING BTREE,
  UNIQUE KEY `steam_profile_url` (`steam64`) USING BTREE,
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela paptomas.tb_contas: ~2 rows (aproximadamente)
DELETE FROM `tb_contas`;
INSERT INTO `tb_contas` (`uuid`, `email`, `password`, `steam64`, `trade_link`, `admin`, `token`, `numero`) VALUES
	('0f54d2e8-6cdd-4fa2-96be-f4915b5adaf7', 'tomaspintomoreira@outlook.com', '092e67c30b4b04345863e1f7a9b240637d9450f6a472fa2650ac84a8fe02166d', '76561199497825869', 'https://steamcommunity.com/tradeoffer/new/?partner=1537560141&token=WQTM5LUd', 0, NULL, '916760990'),
	('a4be3fbe-8896-4eae-bfe2-88fbcd7e99bb', 'tomaspintomoreira28@gmail.com', '092e67c30b4b04345863e1f7a9b240637d9450f6a472fa2650ac84a8fe02166d', '76561199050360573', 'https://steamcommunity.com/tradeoffer/new/?partner=1090094845&token=Ag_x9AYZ', 2, NULL, '932961514');

-- Copiando estrutura para tabela paptomas.tb_produtos
CREATE TABLE IF NOT EXISTS `tb_produtos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `img` varchar(350) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `estado` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `preco` double NOT NULL DEFAULT '0',
  `link_ver_jogo` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `uuid_vendedor` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0',
  `assetid` varchar(255) NOT NULL,
  `ativo` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `id_seller` (`uuid_vendedor`) USING BTREE,
  CONSTRAINT `id_seller` FOREIGN KEY (`uuid_vendedor`) REFERENCES `tb_contas` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela paptomas.tb_produtos: ~0 rows (aproximadamente)
DELETE FROM `tb_produtos`;
INSERT INTO `tb_produtos` (`id`, `nome`, `img`, `estado`, `preco`, `link_ver_jogo`, `uuid_vendedor`, `assetid`, `ativo`) VALUES
	(85, 'AK-47 | Uncharted', 'https://community.akamai.steamstatic.com/economy/image/-9a81dlWLwJ2UUGcVs_nsVtzdOEdtWwKGZZLQHTxDZ7I56KU0Zwwo4NUX4oFJZEHLbXH5ApeO4YmlhxYQknCRvCo04DEVlxkKgpot7HxfDhjxszJemkV092sgIWIqPrxN7LEmyUI6ZAm3ujCpNymjFWx-0RtNjzzctWVIQdqYg7X81nok7rp0JbpuJ7M1zI97ZAMLLaU', 'Field-Tested', 0.35, 'steam://rungame/730/76561202255233023/+csgo_econ_action_preview%20S76561199050360573A30503625648D7507190699088863703', 'a4be3fbe-8896-4eae-bfe2-88fbcd7e99bb', '30503625648', 1),
	(86, 'Ground Rebel  | Elite Crew', 'https://community.akamai.steamstatic.com/economy/image/-9a81dlWLwJ2UUGcVs_nsVtzdOEdtWwKGZZLQHTxDZ7I56KU0Zwwo4NUX4oFJZEHLbXA6Q1NL4kmrAlOA0_FVPCi2t_fUkRxNztDu4WpLgJ07OXJYzRD4six2oLZwKGgYOuCxTJUu8dz07yVoo-m3ALhqhY_Zj_2LNORclM3ZQrR-FOggbC48T0J97o', 'Agent', 1.5, 'steam://rungame/730/76561202255233023/+csgo_econ_action_preview%20S76561199050360573A30503540515D173149406270800975', 'a4be3fbe-8896-4eae-bfe2-88fbcd7e99bb', '30503540515', 1),
	(87, 'JOTA | Antwerp 2022', 'https://community.akamai.steamstatic.com/economy/image/-9a81dlWLwJ2UUGcVs_nsVtzdOEdtWwKGZZLQHTxDZ7I56KU0Zwwo4NUX4oFJZEHLbXQ9QVcJY8gulRcQljHQva9hZ-BARJnLANovLWxKklki6DMJmQXvY21x9jbz6KiN-jUzzMCuZZyibDHrdiiiwLs-0JvN2_6OsbLJdLiuF5R', 'Sticker', 0.02, 'steam://rungame/730/76561202255233023/+csgo_econ_action_preview%20S76561199050360573A29779306680D17063133367059994753', 'a4be3fbe-8896-4eae-bfe2-88fbcd7e99bb', '29779306680', 1),
	(88, 'M4A1-S | Flashback', 'https://community.akamai.steamstatic.com/economy/image/-9a81dlWLwJ2UUGcVs_nsVtzdOEdtWwKGZZLQHTxDZ7I56KU0Zwwo4NUX4oFJZEHLbXH5ApeO4YmlhxYQknCRvCo04DEVlxkKgpou-6kejhz2v_Nfz5H_uO1gb-Gw_alDL3dl3hZ6sRygdbM8Ij8nVn6r0FtN2-gJteVIFJoNF6E_1O4k-rthMO66J3InHdhviBx7X2LnhaxhwYMMLKHMI1gQw', 'Field-Tested', 0.7, 'steam://rungame/730/76561202255233023/+csgo_econ_action_preview%20S76561199050360573A29617125888D14711655159515693034', 'a4be3fbe-8896-4eae-bfe2-88fbcd7e99bb', '29617125888', 1),
	(89, 'AWP | Safari Mesh', 'https://community.akamai.steamstatic.com/economy/image/-9a81dlWLwJ2UUGcVs_nsVtzdOEdtWwKGZZLQHTxDZ7I56KU0Zwwo4NUX4oFJZEHLbXH5ApeO4YmlhxYQknCRvCo04DEVlxkKgpot621FBRw7P7NYjV9-N24q4iOluHtfemJxzkCv5V3ibCToN33igXj_hdqZTv6IIWWdwZoNQzT-1O7xO3tgJai_MOeifog2Vk', 'Battle-Scarred', 0.3, 'steam://rungame/730/76561202255233023/+csgo_econ_action_preview%20S76561199050360573A28842647952D5395390170024129669', 'a4be3fbe-8896-4eae-bfe2-88fbcd7e99bb', '28842647952', 1),
	(90, 'Denzel Curry, ULTIMATE', 'https://community.akamai.steamstatic.com/economy/image/-9a81dlWLwJ2UUGcVs_nsVtzdOEdtWwKGZZLQHTxDZ7I56KU0Zwwo4NUX4oFJZEHLbXO9B9WLbU5oA9OA0jVSf6o28zGQU9tGlQG-LnzeFc40fadID8WvN_gx4PblvPwMe6AxG1X7pB12OqYot2miVexqBJyIzekO47Pzk8', 'Music Kit', 5.2, '', 'a4be3fbe-8896-4eae-bfe2-88fbcd7e99bb', '28837905987', 1),
	(91, 'MP9 | Sand Dashed', 'https://community.akamai.steamstatic.com/economy/image/-9a81dlWLwJ2UUGcVs_nsVtzdOEdtWwKGZZLQHTxDZ7I56KU0Zwwo4NUX4oFJZEHLbXH5ApeO4YmlhxYQknCRvCo04DEVlxkKgpou6r8FBRw7OfJYTh9_9S5hpS0hPb6N4Tck29Y_cg_iOrH9Nyh2Fe2rkE-YW77cteUJ1U5MwnT_VW7xb3m15K5vsjPynM2sj5iuygzmcuY6g', 'Well-Worn', 0.02, 'steam://rungame/730/76561202255233023/+csgo_econ_action_preview%20S76561199497825869A30274747604D778252499577233562', '0f54d2e8-6cdd-4fa2-96be-f4915b5adaf7', '30274747604', 1);

-- Copiando estrutura para tabela paptomas.tb_transacoes
CREATE TABLE IF NOT EXISTS `tb_transacoes` (
  `uuid` varchar(255) NOT NULL,
  `uuid_vendedor` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `uuid_cliente` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trade_link_enviado` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `skin_nome` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `transacao_data` date NOT NULL,
  `preco_skin` double NOT NULL DEFAULT '0',
  `transacao_estado` int NOT NULL DEFAULT '0',
  `uuid_admin_responsavel` varchar(255) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `vendedor` (`uuid_vendedor`),
  KEY `cliente` (`uuid_cliente`),
  KEY `uuid_admin_responsavel` (`uuid_admin_responsavel`),
  CONSTRAINT `cliente` FOREIGN KEY (`uuid_cliente`) REFERENCES `tb_contas` (`uuid`),
  CONSTRAINT `uuid_admin_responsavel` FOREIGN KEY (`uuid_admin_responsavel`) REFERENCES `tb_contas` (`uuid`),
  CONSTRAINT `vendedor` FOREIGN KEY (`uuid_vendedor`) REFERENCES `tb_contas` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela paptomas.tb_transacoes: ~0 rows (aproximadamente)
DELETE FROM `tb_transacoes`;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
