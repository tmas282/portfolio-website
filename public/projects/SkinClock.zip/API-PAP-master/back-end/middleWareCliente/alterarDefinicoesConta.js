const crypto = require("crypto")
const { config } = require("../configs/emailConfig")
const { conn } = require("../configs/sqlConexao")
function alterarDefinicoesConta(req, res) {
    try {
        var uuid = req.cookies.uuid
        var email = req.body.email
        var numero = req.body.telemovel
        var password = req.body.password
        var tradeLink = req.body.tradeLink

        if (email) {
            conn.execute("update tb_contas set email=? where uuid=?", [email, uuid], function (erro) {
                if (erro) {
                    res.status(400).send("Já existe uma conta com esse email")
                    res.end()
                }
            })
        }
        if (numero) {
            conn.execute("update tb_contas set numero=? where uuid=?", [numero, uuid], function (erro) {
                if (erro) {
                    res.status(400).send("Já existe uma conta com esse número")
                    res.end()
                }
            })
        }
        if (password) {
            var hashPassword = crypto.createHash("sha256").update(password).digest("hex")
            conn.execute("update tb_contas set password=? where uuid=?", [hashPassword, uuid])
        }
        if (tradeLink) {
            conn.execute("update tb_contas set trade_link=? where uuid=?", [tradeLink, uuid])
        }
        if (email || numero || password || tradeLink) {
            var mensagem = {
                from: "tomaspintomoreira28@gmail.com",
                to: email,
                subject: "Aviso - SkinClock",
                html: `
                <div style="color: #222831; text-align: center;">
                    <h1>Aviso</h1>
                    <p>Alteraraste as definições da tua conta</p>
                    <span>Não foste tu? Comunica através do formulário de contacto.</span>
                </div>
                `
            }
            config.sendMail(mensagem, function (erro) {
                if (erro) {
                    console.log(erro)
                }
                res.send("Alterações feitas!")
                res.end()
            })
        }
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    alterarDefinicoesConta
}