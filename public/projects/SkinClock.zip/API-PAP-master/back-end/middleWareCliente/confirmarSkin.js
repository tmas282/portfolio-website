const ip = require("ip")
const { conn } = require("../configs/sqlConexao")
const { config } = require("../configs/emailConfig")
function confirmarSkin(req, res) {
    var uuidTransacao = req.query.uuidtransacao
    conn.execute("update tb_transacoes set transacao_estado = 2 where uuid=?", [uuidTransacao], function () {
        conn.query("select tb_transacoes.uuid, tb_transacoes.skin_nome, tb_transacoes.preco_skin, tb_transacoes.uuid_admin_responsavel, tb_contas.email from tb_transacoes inner join tb_contas on tb_transacoes.uuid_admin_responsavel = tb_contas.uuid where tb_transacoes.uuid=?", [uuidTransacao], function (erro, resultados) {
            var mensagemAoAdmin = {
                from: "tomaspintomoreira28@gmail.com",
                to: resultados[0].email,
                subject: "O comprador confirmou a receção",
                html: `
            <div style="color: #222831; text-align: center;">
                <h1>O comprador confirmou a receção do item ${resultados[0].skin_nome}</h1>
                <h2>Dá-se por concluída a transação. O UUID dela é ${resultados[0].uuid}</h2>
                <p>Se ainda não enviaste o dinheiro, envia-o!</p>
            </div>
            `
            }
            config.sendMail(mensagemAoAdmin, function (erro) {
                if (erro) {
                    console.log(erro)
                }
            })
        })
        res.redirect("http://" + ip.address() + ":3000/transacoes")
        res.end()
    })
}
module.exports = {
    confirmarSkin
}