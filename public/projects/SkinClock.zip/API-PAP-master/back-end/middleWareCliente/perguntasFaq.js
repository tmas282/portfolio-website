const fs = require("fs")
function perguntasFaq(req, res) {
    try{
        fs.readFile("../API-PAP/back-end/configs/faq.json", function (erro, data) {
            res.send(JSON.parse(data))
            res.end()
        })
    }
    catch{
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    perguntasFaq
}