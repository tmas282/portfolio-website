const axios = require("axios")
const { conn } = require("../configs/sqlConexao")
function pesquisarInventario(req, res) {
    try {
        var uuid = req.cookies.uuid
        conn.query("select steam64 from tb_contas where uuid=?", [uuid], function (erro, resultados) {
            var steam64 = resultados[0].steam64
            var configObterInventario = {
                method: "get",
                maxBodyLength: Infinity,
                url: "https://web-scraper-api.p.rapidapi.com/v1/request?render_js=false&url=https://steamcommunity.com/inventory/" + steam64 + "/730/2",
                headers: {
                    "X-RapidAPI-Key": "971c1c0b71msh12be392c7bb8714p1820e5jsn9263ae69a2c3",
                    "X-RapidAPI-Host": "web-scraper-api.p.rapidapi.com",
                    "Content-Type": "application/json"
                }
            }
            axios.request(configObterInventario)
                .then(function (resposta) {
                    var inventarioOk = []
                    if (resposta.data != "null") {
                        var items = JSON.parse(resposta.data).descriptions
                        items.forEach(function (item) {
                            if (item.tradable == 1) {
                                if (item.tags[0].localized_tag_name == "Agent" || item.tags[1].category == "Weapon" || item.tags[0].localized_tag_name == "Music Kit" || item.tags[0].localized_tag_name == "Sticker") {
                                    JSON.parse(resposta.data).assets.forEach(function (asset) {
                                        if (asset.classid == item.classid && asset.instanceid == item.instanceid) {
                                            item.assetid = asset.assetid
                                        }
                                    })
                                    inventarioOk.push(item)
                                }
                            }
                        })
                        res.send(inventarioOk)
                        res.end()
                    }
                    else {
                        res.status(500).send("Não foi possível carregar o teu inventário")
                        res.end()
                    }
                })
                .catch(function (erro) {
                    console.log(erro)
                    res.status(500).send("Não foi possível carregar o teu inventário")
                    res.end()
                })
        })
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    pesquisarInventario
}