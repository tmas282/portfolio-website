const { config } = require("../configs/emailConfig")
const { conn } = require("../configs/sqlConexao")
const ip = require("ip")

function enviarSkin(req, res) {
    try {
        var uuidTransacao = req.query.uuidtransacao
        var tradeLink = req.query.tradelink
        conn.query("select tb_transacoes.skin_nome, tb_transacoes.preco_skin, tb_contas.email from tb_transacoes inner join tb_contas on tb_transacoes.uuid_cliente = tb_contas.uuid where tb_transacoes.uuid = ?", [uuidTransacao], function(erro, resultados){
            var mensagemAoComprador = {
                from: "tomaspintomoreira28@gmail.com",
                to: resultados[0].email,
                subject: "Recebeste a " + resultados[0].skin_nome + " ?",
                html: `
            <div style="color: #222831; text-align: center;">
                <h1>Recebeste a ${resultados[0].skin_nome} ?</h1>
                <p>Se recebeste o item que te custou ${resultados[0].preco_skin} € clica <a href="http://${ip.address()}:3001/confirmar-skin?uuidtransacao=${encodeURIComponent(uuidTransacao)}"><strong>aqui</strong></a></p>
            </div>
            `
            }
            config.sendMail(mensagemAoComprador, function (erro) {
                if (erro) {
                    console.log(erro)
                }
            })
        })
        res.redirect(tradeLink)
        res.end()

    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    enviarSkin
}