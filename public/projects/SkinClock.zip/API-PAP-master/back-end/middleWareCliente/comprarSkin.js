const { config } = require("../configs/emailConfig")
const { conn } = require("../configs/sqlConexao")
const uuid = require("uuid")
const ip = require("ip")

function comprarSkin(req, res) {
    try {
        var idSkin = req.body.idSkin
        var uuidComprador = req.cookies.uuid
        var uuidVendedor = req.body.uuidVendedor
        if (uuidVendedor == uuidComprador) {
            res.status(409).send("Não podes comprar o teu item!")
        }
        else if (!uuidComprador) {
            res.status(401).send("Inicia sessão primeiro.")
        }
        else {
            conn.query("select * from tb_contas where uuid=?", [uuidComprador], function (erro, resultados) {
                var infoComprador = resultados[0]
                conn.query("select * from tb_contas where uuid=?", [uuidVendedor], function (erro, resultados) {
                    var infoVendedor = resultados[0]
                    conn.query("select * from tb_produtos where id=?", [idSkin], function (erro, resultados) {
                        var infoSkin = resultados[0]
                        var transacaoUUID = uuid.v4()
                        var skinNome = infoSkin.nome + " (" + infoSkin.estado + ")"
                        conn.query("select * from tb_contas where admin=2 order by rand() limit 1", function (erro, resultados) {
                            conn.execute("insert into tb_transacoes(uuid, uuid_vendedor, uuid_cliente, trade_link_enviado, skin_nome, transacao_data, preco_skin, uuid_admin_responsavel) values(?, ?, ?, ?, ?, ?, ?, ?)", [transacaoUUID, uuidVendedor, uuidComprador, infoComprador.trade_link, skinNome, new Date(), infoSkin.preco, resultados[0].uuid])
                            var mensagemAoComprador = {
                                from: "tomaspintomoreira28@gmail.com",
                                to: infoComprador.email,
                                subject: "Compra - " + skinNome,
                                html: `
                            <div style="color: #222831; text-align: center;">
                                <h1>Queres comprar a ${skinNome} ?</h1>
                                <p>Então envia o dinheiro para o número: ${resultados[0].numero} (Número do administrador que controla esta transação). O email do administrador é ${resultados[0].email}</p>
                                <p>O email do vendedor é ${infoVendedor.email}, o seu número é ${infoVendedor.numero} e a sua conta steam é <a href="https://steamcommunity.com/profiles/${infoVendedor.steam64}"><strong>esta.<strong/></a></p>
                            </div>
                            `
                            }
                            var mensagemAoAdmin = {
                                from: "tomaspintomoreira28@gmail.com",
                                to: resultados[0].email,
                                subject: "És o encarregado da transação: " + transacaoUUID,
                                html: `
                            <div style="color: #222831; text-align: center;">
                                <h1>O uuid da transação é ${transacaoUUID}</h1>
                                <p>És o encarregado desta transação. Quando receberes o dinheiro via MB WAY do número ${infoComprador.numero} (Número do comprador):</p>
                                <ol>
                                    <li>Envia o email de aviso para o vendedor, que é ${infoVendedor.email};</li>
                                    <li>Certifica-te que o comprador recebe o item, ou seja, que o vendedor envia o item;</li>
                                    <li>Envia ${infoSkin.preco} € para o número do vendedor: ${infoVendedor.numero} .</li>
                                </ol>
                            </div>
                            `
                            }
                            config.sendMail(mensagemAoComprador, function (erro) {
                                if (erro) {
                                    console.log(erro)
                                }
                                conn.execute("update tb_produtos set ativo=0 where id=?", [idSkin])
                                res.send("Email com informação de compra enviado.")
                                res.end()
                            })
                            config.sendMail(mensagemAoAdmin, function (erro) {
                                if (erro) {
                                    console.log(erro)
                                }
                            })
                        })
                    })
                })
            })
        }
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    comprarSkin
}