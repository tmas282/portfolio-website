const { conn } = require("../configs/sqlConexao")
function removerItem(req, res) {
    try {
        var uuid = req.cookies.uuid
        var idSkin = req.body.idSkin
        conn.execute("update tb_produtos set ativo=0 where id=? and uuid_vendedor=?", [idSkin, uuid], function () {
            res.send("Removido com sucesso.")
            res.end()
        })
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    removerItem
}