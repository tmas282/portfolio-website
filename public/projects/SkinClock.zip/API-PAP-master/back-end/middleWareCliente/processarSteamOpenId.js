const axios = require("axios")

function processarSteamOpenId(req, res) {
    var steam64 = req.query["openid.identity"].substr(-17)
    res.cookie("steam64",steam64)
    res.redirect("http://" + require("ip").address() + ":3000")
    res.end()  
}
module.exports = {
    processarSteamOpenId
}