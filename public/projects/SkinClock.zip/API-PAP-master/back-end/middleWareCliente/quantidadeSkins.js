const { conn } = require("../configs/sqlConexao")
function quantidadeSkins(req, res) {
    try {
        conn.query("select count(*) as numero from tb_produtos", function (erro, resultados) {
            var data = {
                quantidadeSkins: resultados[0].numero
            }
            res.send(data)
            res.end()
        })
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    quantidadeSkins
}