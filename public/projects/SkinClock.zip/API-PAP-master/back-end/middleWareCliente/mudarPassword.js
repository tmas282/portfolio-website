const { conn } = require("../configs/sqlConexao")
const crypto = require("crypto")
const { config } = require("../configs/emailConfig")
function mudarPassword(req, res) {
    try {
        var token = req.get("token")
        var uuid = req.get("uuid")
        conn.query("select * from tb_contas where uuid=? and token=?", [uuid, token], function (erro, resultados) {
            if (resultados.length > 0) {
                var hashPassword = crypto.createHash("sha256").update(req.body.password).digest("hex")
                conn.execute("update tb_contas set password=? where uuid=?", [hashPassword, uuid], function () {
                    var mensagem = {
                        from: "tomaspintomoreira28@gmail.com",
                        to: resultados[0].email,
                        subject: "Aviso - SkinClock",
                        html: `
                        <div style="color: #222831; text-align: center;">
                            <h1>SkinClock</h1>
                            <p>Password atualizada!</p>
                        </div>
                        `
                    }
                    config.sendMail(mensagem, function (erro) {
                        if (erro) {
                            return console.log(erro)
                        }
                    })
                    res.send("Atualizado.")
                    res.end()
                })
            }
        })
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    mudarPassword
}