const { conn } = require("../configs/sqlConexao")
function infoConta(req, res) {
    try {
        var uuid = req.cookies.uuid
        conn.query("select * from tb_contas where uuid=?", [uuid], function (erro, resultados) {
            if (resultados.length == 1) {
                var resposta = {
                    admin: resultados[0].admin,
                    email: resultados[0].email,
                    steam64: resultados[0].steam64,
                    numero: resultados[0].numero,
                    tradeLink: resultados[0].trade_link
                }
                res.send(resposta)
                res.end()
            }
            else {
                res.status(400).send("Erro no uuid")
                res.end()
            }
        })
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    infoConta
}