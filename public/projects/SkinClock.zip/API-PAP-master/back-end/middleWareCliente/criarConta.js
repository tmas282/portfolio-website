const crypto = require("crypto")
const uuid = require("uuid")
const axios = require("axios")
const ip = require("ip")
const { conn } = require("../configs/sqlConexao")
const { config } = require("../configs/emailConfig")
function criarConta(req, res) {
    try {
        var regexEmail = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
        var regexTelemovel = /^\d{9}$/g
        var email = req.body.email
        var numero = req.body.numero
        var steam64 = req.cookies.steam64
        var tradeLink = req.body.tradeLink
        if (email && numero && steam64 && tradeLink && req.body.password && email.match(regexEmail) && numero.match(regexTelemovel)) {
            var hashPassword = crypto.createHash("sha256").update(req.body.password).digest("hex")
            var contaUUID = uuid.v4()
            conn.query("select * from tb_contas where numero=?", [numero], function (erro, resultados) {
                if (resultados.length > 0) {
                    res.status(409).send("Esse número de telemóvel já não está disponível.")
                    res.end()
                }
                else {
                    conn.query("select * from tb_contas where steam64=?", [steam64], function (erro, resultados) {
                        if (resultados.length > 0) {
                            res.status(409).send("Esse Steam profile já está a ser usado.")
                            res.end()
                        }
                        else {
                            conn.query("select email from tb_contas where email=?", [email], function (erro, resultados) {
                                if (resultados.length == 0) {
                                    conn.execute("insert into tb_contas(email, numero, password, steam64, trade_link, uuid) VALUES(?, ?, ?, ?, ?, ?)", [email, numero, hashPassword, steam64, tradeLink, contaUUID], function () {
                                        var mensagem = {
                                            from: "tomaspintomoreira28@gmail.com",
                                            to: email,
                                            subject: "Obrigado por te juntares ao SkinClock",
                                            html: `
                                            <div style="color: #222831; text-align: center;">
                                                <h1>Bem-vindo</h1>
                                                <p>O próximo passo é visitar o nosso website!</p>
                                                <a href="http://${ip.address()}:3000/store" style="font-size: 2rem;"><strong>Clica aqui<strong/></a>
                                            </div>
                                            `
                                        }
                                        config.sendMail(mensagem, function (erro) {
                                            if (erro) {
                                                console.log(erro)
                                            }
                                        })
                                        var configObterInfoSteam = {
                                            method: "get",
                                            maxBodyLength: Infinity,
                                            url: "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=37F17727C44D63703595ADEB811DC446&steamids=" + steam64
                                        }
                                        axios.request(configObterInfoSteam).then(function (resposta) {
                                            var avatar = resposta.data.response.players[0].avatar
                                            res.send({
                                                uuid: contaUUID,
                                                avatar: avatar
                                            })
                                            res.end()
                                        })
                                    })
                                }
                                else {
                                    res.status(409).send("Essa conta já existe.")
                                    res.end()
                                }
                            })
                        }
                    })
                }
            })
        }
        else {
            res.status(400).send("Request errado")
        }
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    criarConta
}