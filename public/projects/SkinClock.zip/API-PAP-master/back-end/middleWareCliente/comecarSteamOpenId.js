function comecarSteamOpenId(req, res) {
    var url = "https://steamcommunity.com/openid/login?"
    url += "openid.ns=" + encodeURIComponent("http://specs.openid.net/auth/2.0")
    url += "&openid.mode=" + encodeURIComponent("checkid_setup")
    url += "&openid.return_to=" + encodeURIComponent("http://" + require("ip").address() + ":3001/processar-steam-openid")
    url += "&openid.realm=" + encodeURIComponent("http://" + require("ip").address())
    url += "&openid.identity=" + encodeURIComponent("http://specs.openid.net/auth/2.0/identifier_select")
    url += "&openid.claimed_id=" + encodeURIComponent("http://specs.openid.net/auth/2.0/identifier_select")
    res.redirect(url)
    res.end()
}
module.exports = {
    comecarSteamOpenId
}