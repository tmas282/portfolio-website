const axios = require("axios")
const { conn } = require("../configs/sqlConexao")
function formularioContacto(req, res) {
    try {
        if (req.body.nome && req.body.email && req.body.mensagem && req.body.problema) {
            conn.execute("insert into tb_contacto(nome, email, mensagem, problema) VALUES(?, ?, ?, ?)", [req.body.nome, req.body.email, req.body.mensagem, req.body.problema], function () {
                res.send("Aguarde uma resposta.")
                res.end()
            })
        }
        else {
            res.status(400).send("Formulário mal feito.")
            res.end()
        }
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    formularioContacto
}