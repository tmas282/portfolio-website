const crypto = require("crypto")
const axios = require("axios")
const { conn } = require("../configs/sqlConexao")
const { config } = require("../configs/emailConfig")
function fazerLogin(req, res) {
    try {
        var email = req.body.email
        var hashPassword = crypto.createHash("sha256").update(req.body.password).digest("hex")
        conn.query("select email, password, uuid, steam64 from tb_contas where email=?", [email], function (erro, resultados) {
            if (resultados.length == 0) {
                res.status(403).send("Essa conta não existe")
            }
            else {
                if (resultados[0].password == hashPassword) {
                    var mensagem = {
                        from: "tomaspintomoreira28@gmail.com",
                        to: email,
                        subject: "Aviso - Início de sessão novo",
                        html: `
                        <div style="color: #222831; text-align: center;">
                            <h1>Aviso</h1>
                            <p>Iniciaram sessão na tua conta.</p>
                            <p>Não foste tu? Contacta-nos!</p>
                        </div>
                        `
                    }
                    config.sendMail(mensagem, function (erro) {
                        if (erro) {
                            console.log(erro)
                        }
                    })
                    var configObterInfoSteam = {
                        method: "get",
                        maxBodyLength: Infinity,
                        url: "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=37F17727C44D63703595ADEB811DC446&steamids=" + resultados[0].steam64
                    }
                    axios.request(configObterInfoSteam).then(function (resposta) {
                        var avatar = resposta.data.response.players[0].avatar
                        res.send({
                            uuid: resultados[0].uuid,
                            avatar: avatar
                        })
                        res.end()
                    })
                }
                else {
                    res.status(401).send("Password errada")
                    res.end()
                }
            }
        })
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    fazerLogin
}