const { conn } = require("../configs/sqlConexao")

function todasTransacoesDoCliente(req, res) {
    try {
        conn.query("select tb_transacoes.uuid, tb_transacoes.uuid_cliente, tb_contas.uuid as uuid_comprador, tb_contas.email, tb_contas.steam64, tb_transacoes.transacao_estado, tb_transacoes.skin_nome, tb_transacoes.transacao_data, tb_transacoes.preco_skin from tb_transacoes inner join tb_contas on (tb_transacoes.uuid_cliente=? and tb_transacoes.uuid_vendedor=tb_contas.uuid) or (tb_transacoes.uuid_cliente=tb_contas.uuid and tb_transacoes.uuid_vendedor=?)", [req.cookies.uuid, req.cookies.uuid], function (erro, resultados) {
            res.send(resultados)
            res.end()
        })
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    todasTransacoesDoCliente
}