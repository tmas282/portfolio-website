const { conn } = require("../configs/sqlConexao")
function adicionarItem(req, res) {
    try {
        var uuid = req.cookies.uuid
        var item = JSON.parse(req.body.item)
        var nome
        if (item.type.toUpperCase().includes("STICKER") == true || item.type.toUpperCase().includes("MUSIC KIT") == true) {
            nome = item.market_name.slice(item.name.indexOf("|") + 2)
        }
        else {
            nome = item.name
        }
        var img = "https://community.akamai.steamstatic.com/economy/image/" + item.icon_url
        var estado
        if (item.tags[0].localized_tag_name.toUpperCase() == "MUSIC KIT") {
            estado = "Music Kit"
        }
        else if (item.tags[0].localized_tag_name.toUpperCase() == "STICKER") {
            estado = "Sticker"
        }
        else if (item.tags[0].localized_tag_name.toUpperCase() == "AGENT") {
            estado = "Agent"
        }
        else {
            estado = item.tags[5].localized_tag_name
        }
        var preco = req.body.preco
        conn.query("select nome from tb_produtos where assetid=? and ativo=1", [item.assetid], function (erro, resultados) {
            if (resultados.length > 0) {
                res.status(409).send("Já adicionaste esse item")
                res.end()
            }
            else if (item.tags[0].localized_tag_name.toUpperCase() == "MUSIC KIT") {
                conn.execute("insert into tb_produtos(nome, img, estado, preco, link_ver_jogo, uuid_vendedor, assetid) values(?,?,?,?,?,?,?)", [nome, img, estado, preco, "", uuid, item.assetid], function () {
                    res.end()
                })
            }
            else {
                conn.query("select steam64 from tb_contas where uuid=?", [uuid], function (erro, resultados) {
                    var linkVerNoJogo = item.actions[0].link.replace("%owner_steamid%", resultados[0].steam64)
                    linkVerNoJogo = linkVerNoJogo.replace("%assetid%", item.assetid)
                    conn.execute("insert into tb_produtos(nome, img, estado, preco, link_ver_jogo, uuid_vendedor, assetid) values(?,?,?,?,?,?,?)", [nome, img, estado, preco, linkVerNoJogo, uuid, item.assetid], function () {
                        res.end()
                    })
                })
            }
        })
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    adicionarItem
}