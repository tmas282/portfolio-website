const { config } = require("../configs/emailConfig")
const { conn } = require("../configs/sqlConexao")
const uuid = require("uuid")
const ip = require("ip")
function recuperarPassword(req, res) {
    try {
        var novoToken = uuid.v4()
        if (req.body.email) {
            conn.execute("update tb_contas set token=? where email=?", [novoToken, req.body.email], function () {
                conn.query("select uuid, token from tb_contas where email=?", [req.body.email], function (erro, resultados) {
                    if (resultados.length == 1) {
                        var token = resultados[0].token
                        var uuid = resultados[0].uuid
                        var mensagem = {
                            from: "tomaspintomoreira28@gmail.com",
                            to: req.body.email,
                            subject: "Recuperação password",
                            html: `
                            <div style="color: #222831; text-align: center;">
                                <h1>Recuperação password</h1>
                                <a href="http://${ip.address()}:3000/recuperar-password/?uuid=${uuid}&token=${token}" style="font-size: 2rem;"><strong>Recupere a password<strong/></a>
                            </div>
                            `
                        }
                        config.sendMail(mensagem, function (erro) {
                            if (erro) {
                                return console.log(erro)
                            }
                            res.send("Email enviado.")
                            res.end()
                        })
                    }
                    else {
                        res.status(403).send("Esse email não existe.")
                        res.end()
                    }
                })
            })
        }
        else {
            res.status(403).send("Coloque um email.")
            res.end()
        }
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    recuperarPassword
}