const { conn } = require("../configs/sqlConexao")

function skinsEmStock(req, res) {
    try {
        var pesquisa = req.query.pesquisa
        if (pesquisa) {
            pesquisa = "%" + pesquisa + "%"
        }
        else {
            pesquisa = "%%"
        }
        if (req.query.aparencia != "Todos" && req.query.filtroPreco != "none") {
            if (req.query.filtroPreco == "maior-menor") {
                conn.query("select id, nome, img, estado, preco, link_ver_jogo, uuid_vendedor from tb_produtos where ativo=1 and estado=? and nome like ? order by preco desc", [req.query.aparencia, pesquisa], function (erro, resultados) {
                    var pos = 1
                    var resArray = resultados.map(function (element) {
                        var data = element
                        data.renderPos = pos
                        if (pos == 3) {
                            pos = 1
                        }
                        else {
                            pos += 1
                        }
                        return data
                    })
                    res.send(resArray)
                    res.end()
                })
            }
            else {
                conn.query("select id, nome, img, estado, preco, link_ver_jogo, uuid_vendedor from tb_produtos where ativo=1 and estado=? and nome like ? order by preco asc", [req.query.aparencia, pesquisa], function (erro, resultados) {
                    var pos = 1
                    var resArray = resultados.map(function (element) {
                        var data = element
                        data.renderPos = pos
                        if (pos == 3) {
                            pos = 1
                        }
                        else {
                            pos += 1
                        }
                        return data
                    })
                    res.send(resArray)
                    res.end()
                })
            }
        }
        else if (req.query.aparencia != "Todos") {
            conn.query("select id, nome, img, estado, preco, link_ver_jogo, uuid_vendedor from tb_produtos where ativo=1 and estado=? and nome like ?", [req.query.aparencia, pesquisa], function (erro, resultados) {
                var pos = 1
                var resArray = resultados.map(function (element) {
                    var data = element
                    data.renderPos = pos
                    if (pos == 3) {
                        pos = 1
                    }
                    else {
                        pos += 1
                    }
                    return data
                })
                res.send(resArray)
                res.end()
            })
        }
        else if (req.query.filtroPreco != "none") {
            if (req.query.filtroPreco == "maior-menor") {
                conn.query("select id, nome, img, estado, preco, link_ver_jogo, uuid_vendedor from tb_produtos where ativo=1 and nome like ? order by preco desc", [pesquisa], function (erro, resultados) {
                    var pos = 1
                    var resArray = resultados.map(function (element) {
                        var data = element
                        data.renderPos = pos
                        if (pos == 3) {
                            pos = 1
                        }
                        else {
                            pos += 1
                        }
                        return data
                    })
                    res.send(resArray)
                    res.end()
                })
            }
            else {
                conn.query("select id, nome, img, estado, preco, link_ver_jogo, uuid_vendedor from tb_produtos where ativo=1 and nome like ? order by preco asc", [pesquisa], function (erro, resultados) {
                    var pos = 1
                    var resArray = resultados.map(function (element) {
                        var data = element
                        data.renderPos = pos
                        if (pos == 3) {
                            pos = 1
                        }
                        else {
                            pos += 1
                        }
                        return data
                    })
                    res.send(resArray)
                    res.end()
                })
            }
        }
        else {
            conn.query("select id, nome, img, estado, preco, link_ver_jogo, uuid_vendedor from tb_produtos where ativo=1 and nome like ?", [pesquisa], function (erro, resultados) {
                var pos = 1
                var resArray = resultados.map(function (element) {
                    var data = element
                    data.renderPos = pos
                    if (pos == 3) {
                        pos = 1
                    }
                    else {
                        pos += 1
                    }
                    return data
                })
                res.send(resArray)
                res.end()
            })
        }
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    skinsEmStock
}