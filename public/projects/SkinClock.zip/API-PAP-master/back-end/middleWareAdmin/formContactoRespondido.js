const { conn } = require("../configs/sqlConexao")
function formContactoRespondido(req, res) {
    try {
        conn.query("select admin from tb_contas where uuid=?", [req.cookies.uuid], function (erro, resultados) {
            if (resultados.length > 0 && resultados[0].admin > 0) {
                conn.execute("update tb_contacto set respondido=1, quem_respondeu=? where id=?", [req.cookies.uuid, req.body.id], function () {
                    res.send("Atualizado")
                    res.end()
                })
            }
            else {
                res.status(401).send("Sem autorização")
                res.end()
            }
        })
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    formContactoRespondido
}