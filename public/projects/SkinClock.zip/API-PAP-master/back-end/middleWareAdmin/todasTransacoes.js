const { conn } = require("../configs/sqlConexao")
function todasTransacoes(req, res) {
    try {
        var pesquisa = req.query.pesquisaUUID
        if (pesquisa) {
            pesquisa = "%" + pesquisa + "%"
        }
        else {
            pesquisa = "%%"
        }
        conn.query("select admin from tb_contas where uuid=?", [req.cookies.uuid], function (erro, resultados) {
            if (resultados.length == 1 && resultados[0].admin > 0) {
                conn.query("select * from tb_transacoes where uuid like ?", [pesquisa], function (erro, resultados) {
                    res.send(resultados)
                    res.end()
                })
            }
            else {
                res.status(401).send("Sem autorização")
                res.end()
            }
        })
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    todasTransacoes
}