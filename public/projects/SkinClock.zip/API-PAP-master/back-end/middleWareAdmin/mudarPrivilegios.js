const { conn } = require("../configs/sqlConexao")
function mudarPrivilegios(req, res) {
    try {
        if (req.body.utilizador != "0") {
            conn.query("select admin from tb_contas where uuid=?", [req.cookies.uuid], function (erro, resultados) {
                if (resultados.length == 1 && resultados[0].admin == 2) {
                    conn.query("select admin from tb_contas where uuid=?", [req.body.utilizador], function (erro, resultados) {
                        if (resultados[0].admin == req.body.adminPermissao) {
                            res.send("O privilégio que escolheste é o atual.")
                            res.end()
                        }
                        else {
                            conn.execute("update tb_contas set admin=? where uuid=?", [req.body.adminPermissao, req.body.utilizador], function () {
                                conn.query("select email from tb_contas where uuid=?", [req.body.utilizador], function (erro, resultados) {
                                    res.send("Privilégios do utilizador " + resultados[0].email + " atualizados!")
                                    res.end()
                                })
                            })
                        }
                    })
                }
                else {
                    res.status(401).send("Sem autorização")
                    res.end()
                }
            })
        }
        else {
            res.status(400).send("Escolhe um utilizador!")
            res.end()
        }
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    mudarPrivilegios
}