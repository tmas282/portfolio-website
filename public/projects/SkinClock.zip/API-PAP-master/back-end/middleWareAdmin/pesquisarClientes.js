const { conn } = require("../configs/sqlConexao")

function pesquisarClientes(req, res) {
    try {
        var pesquisa = req.query.pesquisa
        if (pesquisa) {
            pesquisa = "%" + pesquisa + "%"
        }
        else {
            pesquisa = "%%"
        }
        conn.query("select admin from tb_contas where uuid=?", [req.cookies.uuid], function (erro, resultados) {
            if (resultados.length == 1 && resultados[0].admin > 0) {
                conn.query("select uuid, email, steam64, trade_link, admin, numero from tb_contas where (uuid like ? or email like ? or numero like ?)", [pesquisa, pesquisa, pesquisa], function (erro, resultados) {
                    res.send(resultados)
                    res.end()
                })
            }
            else {
                res.status(401).send("Sem autorização")
                res.end()
            }
        })
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    pesquisarClientes
}