const { conn } = require("../configs/sqlConexao")
function obterFormContacto(req, res) {
    try {
        if (req.query.verNaoRespondidos == "false") {
            conn.query("select admin from  tb_contas where uuid=?", [req.cookies.uuid], function (erro, resultados) {
                if (resultados.length > 0 && resultados[0].admin > 0) {
                    conn.query("select tb_contacto.*, tb_contas.email as email_respondeu from tb_contacto left join tb_contas on tb_contacto.quem_respondeu = tb_contas.uuid order by tb_contacto.id desc limit 15", function (erro, resultados) {
                        res.send(resultados)
                        res.end()
                    })
                }
                else {
                    res.status(401).send("Sem autorização")
                    res.end()
                }
            })
        }
        else {
            conn.query("select admin from  tb_contas where uuid=?", [req.cookies.uuid], function (erro, resultados) {
                if (resultados.length > 0 && resultados[0].admin > 0) {
                    conn.query("select * from tb_contacto where respondido=0 order by id desc limit 15", function (erro, resultados) {
                        res.status(200).send(resultados)
                        res.end()
                    })
                }
                else {
                    res.status(401).send("Sem autorização")
                    res.end()
                }
            })
        }
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    obterFormContacto
}