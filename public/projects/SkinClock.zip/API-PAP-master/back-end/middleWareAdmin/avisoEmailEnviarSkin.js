const { config } = require("../configs/emailConfig")
const { conn } = require("../configs/sqlConexao")
const ip = require("ip")
function avisoEmailEnviarSkin(req, res) {
    try {
        if (req.body.utilizador != "0") {
            conn.query("select admin from tb_contas where uuid=?", [req.cookies.uuid], function (erro, resultados) {
                if (resultados.length == 1 && resultados[0].admin == 2) {
                    conn.query("select * from tb_transacoes where uuid=?", [req.body.uuidTransacao], function (erro, resultados) {
                        conn.execute("update tb_transacoes set transacao_estado=1 where uuid=?", [req.body.uuidTransacao])
                        conn.query("select email from tb_contas where uuid=?", [resultados[0].uuid_vendedor], function (erro, resultadosVendedor) {
                            var mensagemAoVendedor = {
                                from: "tomaspintomoreira28@gmail.com",
                                to: resultadosVendedor[0].email,
                                subject: "Venda - " + resultados[0].skin_nome,
                                html: `
                            <div style="color: #222831; text-align: center;">
                                <h1>Querem-te comprar a ${resultados[0].skin_nome} .</h1>
                                <h2><strong>ENVIA O ITEM PARA RECEBERES O DINHEIRO!</strong></h2>
                                <p>Envia o item para o link: <a href="http://${ip.address()}:3001/enviar-skin?uuidtransacao=${encodeURIComponent(req.body.uuidTransacao)}&tradelink=${encodeURIComponent(resultados[0].trade_link_enviado)}"><strong>aqui.<strong/></a></p>
                            </div>
                            `
                            }
                            config.sendMail(mensagemAoVendedor, function (erro) {
                                if (erro) {
                                    console.log(erro)
                                }
                                res.send("Email enviado")
                                res.end()
                            })
                        })
                    })
                }
                else {
                    res.status(401).send("Sem autorização")
                    res.end()
                }
            })
        }
        else {
            res.status(400).send("Escolhe um utilizador!")
            res.end()
        }
    }
    catch {
        res.status(500).send("Erro do servidor")
        res.end()
    }
}
module.exports = {
    avisoEmailEnviarSkin
}