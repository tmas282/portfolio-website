const nodemailer = require("nodemailer")
//SMTP config para enviar emails
var config = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    secure: false,
    auth: {
        user: "tomaspintomoreira28@gmail.com",
        pass: "xzjobvowsanmdsak"
    }
})
module.exports = {
    config
}