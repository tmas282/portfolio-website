const mysql = require("mysql2")
var conn = mysql.createConnection({
    host: "db4free.net",
    port: "3306",
    user: "tmas282",
    password: "Crisefecha13?",
    database: "paptomas"
})
module.exports = {
    conn
}