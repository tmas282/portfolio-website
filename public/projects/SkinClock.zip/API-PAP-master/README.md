# API - Express JS
Express: https://expressjs.com

# Base de dados - MySQL
Base de dados encontra-se no website: https://www.db4free.net/

Usar Node.js com MySQL: https://www.w3schools.com/nodejs/nodejs_mysql.asp

# Cores
Cores: https://colorhunt.co/palette/222831393e46ffd369eeeeee
Adicionei mais uma cor: #a1a1a1

# ReactJS
React: https://reactjs.org

# React Router
React Router (Para criar várias views no react): https://v5.reactrouter.com

# Logo
Logo: https://www.ucraft.com/free-logo-maker

# Para fazer requests
Para fazer os requests: 
- Front-end: https://api.jquery.com/jquery.ajax/#jQuery-ajax-url-settings
- back-end: https://axios-http.com/docs/intro

# Enviar email
Nodemailer: https://nodemailer.com/about/

# Cookies no react
React Cookies: https://www.npmjs.com/package/react-cookie
