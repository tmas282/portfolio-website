//librarias
const express = require("express")
const cors = require("cors")
const bodyParser = require("body-parser")
const ip = require("ip")
const cookies = require("cookie-parser")

//App e Certificados
const app = express()
const porta = 3001
app.use(cors({ credentials: true, origin: "http://" + ip.address() + ":3000" }))
app.use(cookies())
app.use(bodyParser.urlencoded({ extended: false }))

//Endpoints
//Administração
app.put("/mudar-privilegios", require("./back-end/middleWareAdmin/mudarPrivilegios").mudarPrivilegios)
app.get("/obter-form-contacto", require("./back-end/middleWareAdmin/obterFormContacto").obterFormContacto)
app.put("/form-contacto-respondido", require("./back-end/middleWareAdmin/formContactoRespondido").formContactoRespondido)
app.get("/todas-as-transacoes", require("./back-end/middleWareAdmin/todasTransacoes").todasTransacoes)
app.post("/aviso-email-skin-enviar", require("./back-end/middleWareAdmin/avisoEmailEnviarSkin").avisoEmailEnviarSkin)
app.get("/pesquisar-clientes", require("./back-end/middleWareAdmin/pesquisarClientes").pesquisarClientes)

//Conta
app.get("/comecar-steam-openid", require("./back-end/middleWareCliente/comecarSteamOpenId").comecarSteamOpenId)
app.get("/processar-steam-openid", require("./back-end/middleWareCliente/processarSteamOpenId").processarSteamOpenId)
app.post("/criar-conta", require("./back-end/middleWareCliente/criarConta").criarConta)
app.post("/recuperar-password", require("./back-end/middleWareCliente/recuperarPassword").recuperarPassword)
app.post("/mudar-password", require("./back-end/middleWareCliente/mudarPassword").mudarPassword)
app.post("/fazer-login", require("./back-end/middleWareCliente/fazerLogin").fazerLogin)
app.get("/info-conta", require("./back-end/middleWareCliente/infoConta").infoConta)
app.put("/alterar-definicoes-conta", require("./back-end/middleWareCliente/alterarDefinicoesConta").alterarDefinicoesConta)
app.get("/todas-as-transacoes-do-cliente", require("./back-end/middleWareCliente/todasTransacoesDoCliente").todasTransacoesDoCliente)

//Skins
app.get("/skins-em-stock", require("./back-end/middleWareCliente/skinsEmStock").skinsEmStock)
app.get("/numero-de-skins", require("./back-end/middleWareCliente/quantidadeSkins").quantidadeSkins)
app.get("/pesquisar-inventario", require("./back-end/middleWareCliente/pesquisarInventario").pesquisarInventario)
app.post("/adicionar-item", require("./back-end/middleWareCliente/adicionarItem").adicionarItem)
app.delete("/remover-item", require("./back-end/middleWareCliente/removerItem").removerItem)
app.post("/comprar-skin", require("./back-end/middleWareCliente/comprarSkin").comprarSkin)
app.get("/enviar-skin", require("./back-end/middleWareCliente/enviarSkin").enviarSkin)
app.get("/confirmar-skin", require("./back-end/middleWareCliente/confirmarSkin").confirmarSkin)

//Outros
app.get("/perguntas-faq", require("./back-end/middleWareCliente/perguntasFaq").perguntasFaq)
app.post("/formulario-contacto", require("./back-end/middleWareCliente/formularioContacto").formularioContacto)

//Começar o servidor
app.listen(porta, function () {
  console.log("API a rodar: " + ip.address() + ":" + porta)
})