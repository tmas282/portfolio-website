echo Cleaning .target/ folder
mvn clean
echo Deploying .jar with maven...
mvn compile
mvn package