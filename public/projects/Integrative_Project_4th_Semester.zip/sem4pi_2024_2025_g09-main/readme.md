# Project Shodrone

## 1. Description of the Project

Shodrone it’s a company dedicated to providing customized drone multimedia shows. It has a library
of figures and sequences and allows clients to select sets of them for their personalized shows. It also
allows clients to submit proposals for new figures to be used in their super exclusive shows.

## 2. Planning and Technical Documentation

[Planning and Technical Documentation](docs/readme.md)

## 3. How to Build

To build the project, run the following command in the root directory of the project:

### For Linux/MacOS
    ./build.sh
### For Windows
    .\build.bat

## 4. How to Execute Tests

To execute tests of the project, run the following command in the root directory of the project:

### For Linux/MacOS
    ./build.sh
### For Windows
    .\build.bat

## 5. How to Run

To run the project, run the following command in the root directory of the project:

### For Linux/MacOS
    ./deploy.sh
### For Windows
    .\deploy.bat

After that (if it was successful), follow the steps:

1. Go to the desired app directory;
2. Go to ./target folder;
3. Go to the command line to run: java -jar ./shodrone.appY-X.jar

#### Legend
Y -> Is the app identification number
X -> Is the app version

## 6. How to Install/Deploy into Another Machine (or Virtual Machine)

To install the project, run the following command in the root directory of the project:

### For Linux/MacOS
    ./deploy.sh
### For Windows
    .\deploy.bat

## 7. How to Generate PlantUML Diagrams

To generate plantuml diagrams for documentation execute the script (for the moment, only for linux/unix/macos):

    ./generate-plantuml-diagrams.sh


