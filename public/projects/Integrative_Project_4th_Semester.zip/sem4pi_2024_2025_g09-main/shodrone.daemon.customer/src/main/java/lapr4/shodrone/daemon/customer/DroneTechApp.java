package lapr4.shodrone.daemon.customer;

import lapr4.shodrone.daemon.customer.auth.Session;
import lapr4.shodrone.daemon.customer.ui.LoginUI;
import lapr4.shodrone.daemon.customer.ui.ShowSimulatorUI;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class DroneTechApp {
    private static final Scanner SCANNER = new Scanner(System.in);
    private static final String SIMULATOR_HOST = "localhost";
    private static final int SIMULATOR_PORT = 9999;

    public static void main(String[] args) {
        do {
            new LoginUI().run();
            if (Session.getSession().getType() == Session.UserType.DRONE_TECH) {
                new ShowSimulatorUI().runSimulationInteraction();
            }

            System.out.println("Pretende sair da aplicação? [y/n]");
        } while (!SCANNER.nextLine().equalsIgnoreCase("y"));
    }

    private static void runSimulation() {
        System.out.println("A comunicar com o simulador...");

        try (Socket socket = new Socket(SIMULATOR_HOST, SIMULATOR_PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            out.println("RUN");

            System.out.println("\n=== RELATÓRIO DA SIMULAÇÃO DE COLISÕES ===");
            String line;
            boolean receivedSomething = false;
            while ((line = in.readLine()) != null) {
                System.out.println(line);
                receivedSomething = true;
            }

            if (!receivedSomething) {
                System.out.println("⚠️  Não foram recebidos dados do simulador.");
            }

        } catch (Exception e) {
            System.out.println("\n🚫 Não foi possível comunicar com o servidor de simulação.");
            System.out.println("💡 Certifique-se de que o 'simulator_server' está em execução antes de simular.");
            System.out.println("Detalhes técnicos: " + e.getMessage());
        }
    }
}
