package lapr4.shodrone.daemon.customer.ui;

import java.io.*;
import java.net.Socket;
import java.nio.file.*;
import java.util.Scanner;

public class ShowSimulatorUI {
    private static final Scanner SCANNER = new Scanner(System.in);
    private static final String SIMULATOR_HOST = "localhost";
    private static final int SIMULATOR_PORT = 9999;

    public void runSimulationInteraction() {
        while (true) {
            try {
                File showsDir = new File("shows");
                if (!showsDir.exists() || !showsDir.isDirectory()) {
                    System.out.println("Diretório 'shows/' não existe.");
                    return;
                }

                File[] csvFiles = showsDir.listFiles((dir, name) -> name.endsWith(".csv"));
                if (csvFiles == null || csvFiles.length == 0) {
                    System.out.println("Nenhum ficheiro CSV encontrado em 'shows/'.");
                    return;
                }

                System.out.println("Selecione um show para simular:");
                for (int i = 0; i < csvFiles.length; i++) {
                    System.out.printf("%d. %s\n", i + 1, csvFiles[i].getName());
                }
                System.out.printf("%d. Voltar atrás\n", csvFiles.length + 1);

                int option;
                try {
                    option = Integer.parseInt(SCANNER.nextLine()) - 1;
                } catch (NumberFormatException e) {
                    System.out.println("Opção inválida.");
                    continue;
                }

                if (option == csvFiles.length) {
                    return;
                }
                if (option < 0 || option >= csvFiles.length) {
                    System.out.println("Opção inválida.");
                    continue;
                }

                // Copiar CSV
                Path selected = csvFiles[option].toPath();
                Path dest = Paths.get("simulation/sprint3/drone_movements.csv");
                Files.copy(selected, dest, StandardCopyOption.REPLACE_EXISTING);
                System.out.println("Ficheiro selecionado copiado com sucesso.");
                System.out.println("A simulação será iniciada...\n");

                // TCP
                communicateWithSimulator();

                System.out.println("\nPretende simular outro show? [y/n]");
                String resp = SCANNER.nextLine();
                if (!resp.equalsIgnoreCase("y")) {
                    break;
                }

            } catch (Exception e) {
                System.out.println("Erro na simulação: ");
                e.printStackTrace();
                break;
            }
        }
    }

    private void communicateWithSimulator() {
        try (Socket socket = new Socket(SIMULATOR_HOST, SIMULATOR_PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            out.println("RUN");

            System.out.println("=== RELATÓRIO DA SIMULAÇÃO DE COLISÕES ===");
            String line;
            boolean somethingPrinted = false;
            while ((line = in.readLine()) != null) {
                System.out.println(line);
                somethingPrinted = true;
            }

            if (!somethingPrinted) {
                System.out.println("⚠️  Não foram recebidos dados do simulador.");
            }

        } catch (Exception e) {
            System.out.println("🚫 Não foi possível comunicar com o servidor de simulação.");
            System.out.println("💡 Certifique-se de que o 'simulator_server' está a correr.");
            System.out.println("Detalhes técnicos: " + e.getMessage());
        }
    }
}
