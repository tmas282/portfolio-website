package lapr4.shodrone.daemon.customer.ui;

import lapr4.shodrone.daemon.customer.auth.Session;

import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Scanner;

public class CustomerUI implements Runnable {

    private static final Scanner SCANNER = new Scanner(System.in);

    private void getShowDates() {
        try {
            HttpClient client = HttpClient.newBuilder()
                    .authenticator(Session.authenticator())
                    .build();

            HttpRequest request = HttpRequest.newBuilder()
                    .GET()
                    .uri(new URI("http://localhost:8080/get-shows-dates"))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            System.out.println("Scheduled shows:");
            System.out.println(response.body());

        } catch (Exception e) {
            System.err.println("Error fetching show dates:");
            e.printStackTrace();
        }
    }
    private void acceptOrRejectProposal() {
        try {
            HttpClient client = HttpClient.newBuilder()
                    .authenticator(Session.authenticator())
                    .build();

            HttpRequest request = HttpRequest.newBuilder()
                    .GET()
                    .uri(new URI("http://localhost:8080/get-show-proposals-of-representative"))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            System.out.println("\nAvailable Proposals:");
            System.out.println(response.body());

            System.out.print("Enter the Proposal ID to select: ");
            String proposalId = SCANNER.nextLine().trim();

            if (!proposalId.matches("\\d+")) {
                System.out.println("Invalid Proposal ID.");
                return;
            }

            System.out.print("Do you want to accept or reject the proposal? [accept/reject]: ");
            String action = SCANNER.nextLine().trim().toLowerCase();

            if (!action.equals("accept") && !action.equals("reject")) {
                System.out.println("Invalid action. Please enter 'accept' or 'reject'.");
                return;
            }

            sendProposalDecision(proposalId, action);

        } catch (Exception e) {
            System.err.println("Error handling proposals:");
            e.printStackTrace();
        }
    }


    private boolean sendProposalDecision(String proposalId, String decision) {
        try {
            HttpClient client = HttpClient.newBuilder()
                    .authenticator(Session.authenticator())
                    .build();

            String urlStr = String.format("http://localhost:8080/%s-proposal?id=%s", decision, proposalId);
            URI uri = new URI(urlStr);

            HttpRequest request = HttpRequest.newBuilder()
                    .GET()
                    .uri(uri)
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            int statusCode = response.statusCode();

            if (statusCode == 200 && "true".equalsIgnoreCase(response.body().trim())) {
                System.out.printf(" Proposal with ID %s was successfully %s.\n", proposalId,
                        decision.equals("accept") ? "ACCEPTED" : "REJECTED");
                return true;
            } else {
                System.out.printf("⚠ Failed to %s proposal with ID %s. Server response: %s\n",
                        decision.toUpperCase(), proposalId, response.body());
                return false;
            }

        } catch (Exception e) {
            System.err.printf(" Error sending %s decision for proposal ID %s:\n", decision, proposalId);
            e.printStackTrace();
            return false;
        }
    }


    private void getShowInfo() {
        try {
            System.out.print("Enter the show ID: ");
            String idInput = SCANNER.nextLine();
            Long id = Long.parseLong(idInput);

            HttpClient client = HttpClient.newBuilder()
                    .authenticator(Session.authenticator())
                    .build();

            HttpRequest request = HttpRequest.newBuilder()
                    .GET()
                    .uri(new URI("http://localhost:8080/get-show-info?id=" + id))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                System.out.println("Show information:");
                System.out.println(response.body());
            } else {
                System.out.println("Show not found or error retrieving information.");
            }

        } catch (NumberFormatException e) {
            System.out.println("Invalid ID.");
        } catch (Exception e) {
            System.err.println("Error retrieving show information:");
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        int option = -1;
        do {
            System.out.println("\nCustomer Menu:");
            System.out.println("1. Accept or Reject show proposal");
            System.out.println("2. View scheduled show dates");
            System.out.println("3. View show information");
            System.out.println("0. Exit");
            System.out.print("Choose an option: ");
            String input = SCANNER.nextLine();

            try {
                option = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                option = -1;
            }

            switch (option) {
                case 1:
                    acceptOrRejectProposal();
                    break;
                case 2:
                    getShowDates();
                    break;
                case 3:
                    getShowInfo();
                    break;
                case 0:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid option.");
                    break;
            }
        } while (option != 0);
    }
}
