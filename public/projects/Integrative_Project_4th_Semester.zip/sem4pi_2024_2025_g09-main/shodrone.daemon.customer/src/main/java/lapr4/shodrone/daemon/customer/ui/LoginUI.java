package lapr4.shodrone.daemon.customer.ui;

import lapr4.shodrone.daemon.customer.auth.Session;

import java.util.Scanner;

public class LoginUI implements Runnable{
    private static final Scanner SCANNER = new Scanner(System.in);
    @Override
    public void run() {
        boolean isSignedIn = false;
        do{
            System.out.println("Login: ");
            String email = SCANNER.nextLine();
            System.out.println("Password: ");
            String password = SCANNER.nextLine();
            try{
                Session.createSession(email, password);
                isSignedIn = true;
            } catch (Exception e){
                System.out.println("Error: ");
                e.printStackTrace();
            }
        } while(!isSignedIn);
    }
}
