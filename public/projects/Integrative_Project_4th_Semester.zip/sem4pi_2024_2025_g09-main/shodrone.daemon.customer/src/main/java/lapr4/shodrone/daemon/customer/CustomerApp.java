package lapr4.shodrone.daemon.customer;

import lapr4.shodrone.daemon.customer.auth.Session;
import lapr4.shodrone.daemon.customer.ui.CustomerRepresentativeUI;
import lapr4.shodrone.daemon.customer.ui.CustomerUI;
import lapr4.shodrone.daemon.customer.ui.LoginUI;

import java.util.Scanner;

public class CustomerApp {
    private static final Scanner SCANNER = new Scanner(System.in);
    public static void main(String[] args) {
        do {
            new LoginUI().run();
            if(Session.getSession().getType() == Session.UserType.CUSTOMER_REPRESENTATIVE)
                new CustomerRepresentativeUI().run();
            if(Session.getSession().getType() == Session.UserType.CUSTOMER)
                new CustomerUI().run();
            System.out.println("Do you want to exit the app? [y/n]");
        } while (!SCANNER.nextLine().equalsIgnoreCase("y"));
    }
}
