package lapr4.shodrone.daemon.customer.auth;


import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Base64;

public class Session {
    private static Session session;

    private String email;
    private String password;
    private UserType type;

    private Session(String email, String password, String type) {
        this.email = email;
        this.password = password;
        this.type = UserType.valueOf(type);
    }

    public static Session getSession(){
        return session;
    }

    public UserType getType() {
        return type;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    public static Authenticator authenticator(){
        assert session != null;
        return new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(Session.session.getEmail(), Session.session.getPassword().toCharArray());
            }
        };
    }

    public static Session createSession(String email, String password) throws Exception {
        HttpClient client = HttpClient.newBuilder()
            .authenticator(new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(email, password.toCharArray());
                }
            })
            .build();

        HttpRequest request = HttpRequest.newBuilder()
                .GET()
                .uri(new URI("http://localhost:8080/get-user-type"))
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        if(response.statusCode() != 200)
            throw new Exception("That user doesn't exist");

        session = new Session(email, password, response.body());
        return session;
    }

    public enum UserType{
        DRONE_TECH,
        CUSTOMER,
        CUSTOMER_REPRESENTATIVE;
    }
}
