package lapr4.shodrone.daemon.customer.utils;

import lapr4.shodrone.daemon.customer.auth.Session;

import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class DownloadFileUtils {
    public static Path downloadFile(String fileURL, String saveDir) throws Exception {
        Path filePath = Paths.get(saveDir, "proposal.txt");

        HttpRequest request = HttpRequest.newBuilder()
                .GET()
                .uri(new URI(fileURL))
                .build();

        HttpClient client = HttpClient.newBuilder()
                .authenticator(Session.authenticator())
                .build();

        HttpResponse<byte[]> response = client.send(request, HttpResponse.BodyHandlers.ofByteArray());

        if (response.statusCode() != 200) {
            throw new IOException("HTTP error code: " + response.statusCode());
        }

        Path dirPath = Paths.get(saveDir);
        Files.createDirectories(dirPath);

        Files.write(filePath, response.body(),
                StandardOpenOption.CREATE,
                StandardOpenOption.WRITE,
                StandardOpenOption.TRUNCATE_EXISTING);

        return filePath;
    }
}
