package lapr4.shodrone.daemon.customer.ui;

import lapr4.shodrone.daemon.customer.auth.Session;
import lapr4.shodrone.daemon.customer.utils.DownloadFileUtils;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Path;
import java.util.Scanner;

public class CustomerRepresentativeUI implements Runnable{
    private static final Scanner SCANNER = new Scanner(System.in);

    private static void analyseProposal() {
        try{
            HttpClient client = HttpClient.newBuilder()
                    .authenticator(Session.authenticator())
                    .build();

            HttpRequest request = HttpRequest.newBuilder()
                    .GET()
                    .uri(new URI("http://localhost:8080/get-show-proposals-of-representative"))
                    .build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            System.out.println("Proposals of you: ");
            System.out.println(response.body());
            System.out.println("Type an ID of proposal you want to download: ");
            String id = SCANNER.nextLine();
            Path path = DownloadFileUtils.downloadFile(String.format("http://localhost:8080/download-show-proposal?id=%s", id),
                    "./downloads/");
            System.out.printf("Download to path:%s\n", path.toAbsolutePath());
        } catch (Exception e){
            e.printStackTrace();
        }
    }
    @Override
    public void run() {
        int option = -1;
        do{
            System.out.println("Customer Representative Menu: ");
            System.out.println("1. Analyse proposal");
            System.out.println("0. Leave");
            String opt = SCANNER.nextLine();
            option = Integer.parseInt(opt);
            switch (option){
                case 0: break;
                case 1:
                    analyseProposal();break;
                default:
                    System.out.println("Unavailable"); break;
            }
        } while(option != 0);
    }
}
