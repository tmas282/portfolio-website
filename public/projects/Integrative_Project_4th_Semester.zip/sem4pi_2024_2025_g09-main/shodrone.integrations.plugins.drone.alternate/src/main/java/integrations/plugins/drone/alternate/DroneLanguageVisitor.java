package integrations.plugins.drone.alternate;// Generated from C:/sem4pi_2024_2025_g09/shodrone.integrations.plugins.drone.alternate/src/main/antlr4/DroneLanguage.g4 by ANTLR 4.13.2
import integrations.plugins.drone.alternate.DroneLanguageParser;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link DroneLanguageParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface DroneLanguageVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link DroneLanguageParser#program}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram(DroneLanguageParser.ProgramContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneLanguageParser#header}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHeader(DroneLanguageParser.HeaderContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneLanguageParser#variablesSection}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVariablesSection(DroneLanguageParser.VariablesSectionContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneLanguageParser#variableDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVariableDecl(DroneLanguageParser.VariableDeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneLanguageParser#value}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValue(DroneLanguageParser.ValueContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneLanguageParser#instructionsSection}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInstructionsSection(DroneLanguageParser.InstructionsSectionContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneLanguageParser#instruction}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInstruction(DroneLanguageParser.InstructionContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneLanguageParser#argumentGroupList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArgumentGroupList(DroneLanguageParser.ArgumentGroupListContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneLanguageParser#argumentGroup}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArgumentGroup(DroneLanguageParser.ArgumentGroupContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneLanguageParser#argumentContent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArgumentContent(DroneLanguageParser.ArgumentContentContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneLanguageParser#numericExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumericExpression(DroneLanguageParser.NumericExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneLanguageParser#numericTuple}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumericTuple(DroneLanguageParser.NumericTupleContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneLanguageParser#numericArray}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumericArray(DroneLanguageParser.NumericArrayContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneLanguageParser#identifierArray}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentifierArray(DroneLanguageParser.IdentifierArrayContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneLanguageParser#identifierTuple}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentifierTuple(DroneLanguageParser.IdentifierTupleContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneLanguageParser#literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLiteral(DroneLanguageParser.LiteralContext ctx);
}