package integrations.plugins.drone.alternate;// Generated from C:/sem4pi_2024_2025_g09/shodrone.integrations.plugins.drone.alternate/src/main/antlr4/DroneLanguage.g4 by ANTLR 4.13.2
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue", "this-escape"})
public class DroneLanguageParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.13.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, T__8=9, 
		T__9=10, T__10=11, T__11=12, T__12=13, TYPE_NAME=14, IDENTIFIER=15, INT=16, 
		FLOAT=17, NEWLINE=18, WS=19, COMMENT=20;
	public static final int
		RULE_program = 0, RULE_header = 1, RULE_variablesSection = 2, RULE_variableDecl = 3, 
		RULE_value = 4, RULE_instructionsSection = 5, RULE_instruction = 6, RULE_argumentGroupList = 7, 
		RULE_argumentGroup = 8, RULE_argumentContent = 9, RULE_numericExpression = 10, 
		RULE_numericTuple = 11, RULE_numericArray = 12, RULE_identifierArray = 13, 
		RULE_identifierTuple = 14, RULE_literal = 15;
	private static String[] makeRuleNames() {
		return new String[] {
			"program", "header", "variablesSection", "variableDecl", "value", "instructionsSection", 
			"instruction", "argumentGroupList", "argumentGroup", "argumentContent", 
			"numericExpression", "numericTuple", "numericArray", "identifierArray", 
			"identifierTuple", "literal"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'programming language version'", "'='", "';'", "'('", "')'", "','", 
			"'<'", "'>'", "'-'", "'+'", "'*'", "'/'", "'PI'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, "TYPE_NAME", "IDENTIFIER", "INT", "FLOAT", "NEWLINE", "WS", 
			"COMMENT"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "DroneLanguage.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public DroneLanguageParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ProgramContext extends ParserRuleContext {
		public HeaderContext header() {
			return getRuleContext(HeaderContext.class,0);
		}
		public VariablesSectionContext variablesSection() {
			return getRuleContext(VariablesSectionContext.class,0);
		}
		public InstructionsSectionContext instructionsSection() {
			return getRuleContext(InstructionsSectionContext.class,0);
		}
		public TerminalNode EOF() { return getToken(DroneLanguageParser.EOF, 0); }
		public ProgramContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_program; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener) ((DroneLanguageListener)listener).enterProgram(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).exitProgram(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneLanguageVisitor) return ((DroneLanguageVisitor<? extends T>)visitor).visitProgram(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ProgramContext program() throws RecognitionException {
		ProgramContext _localctx = new ProgramContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_program);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(32);
			header();
			setState(33);
			variablesSection();
			setState(34);
			instructionsSection();
			setState(35);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class HeaderContext extends ParserRuleContext {
		public TerminalNode TYPE_NAME() { return getToken(DroneLanguageParser.TYPE_NAME, 0); }
		public TerminalNode FLOAT() { return getToken(DroneLanguageParser.FLOAT, 0); }
		public List<TerminalNode> NEWLINE() { return getTokens(DroneLanguageParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(DroneLanguageParser.NEWLINE, i);
		}
		public HeaderContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_header; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).enterHeader(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).exitHeader(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneLanguageVisitor) return ((DroneLanguageVisitor<? extends T>)visitor).visitHeader(this);
			else return visitor.visitChildren(this);
		}
	}

	public final HeaderContext header() throws RecognitionException {
		HeaderContext _localctx = new HeaderContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_header);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(37);
			match(TYPE_NAME);
			setState(38);
			match(T__0);
			setState(39);
			match(FLOAT);
			setState(43);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==NEWLINE) {
				{
				{
				setState(40);
				match(NEWLINE);
				}
				}
				setState(45);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class VariablesSectionContext extends ParserRuleContext {
		public List<VariableDeclContext> variableDecl() {
			return getRuleContexts(VariableDeclContext.class);
		}
		public VariableDeclContext variableDecl(int i) {
			return getRuleContext(VariableDeclContext.class,i);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(DroneLanguageParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(DroneLanguageParser.NEWLINE, i);
		}
		public VariablesSectionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_variablesSection; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).enterVariablesSection(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).exitVariablesSection(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneLanguageVisitor) return ((DroneLanguageVisitor<? extends T>)visitor).visitVariablesSection(this);
			else return visitor.visitChildren(this);
		}
	}

	public final VariablesSectionContext variablesSection() throws RecognitionException {
		VariablesSectionContext _localctx = new VariablesSectionContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_variablesSection);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(55);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==TYPE_NAME) {
				{
				{
				setState(46);
				variableDecl();
				setState(50);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==NEWLINE) {
					{
					{
					setState(47);
					match(NEWLINE);
					}
					}
					setState(52);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				}
				setState(57);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class VariableDeclContext extends ParserRuleContext {
		public TerminalNode TYPE_NAME() { return getToken(DroneLanguageParser.TYPE_NAME, 0); }
		public TerminalNode IDENTIFIER() { return getToken(DroneLanguageParser.IDENTIFIER, 0); }
		public ValueContext value() {
			return getRuleContext(ValueContext.class,0);
		}
		public VariableDeclContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_variableDecl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).enterVariableDecl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).exitVariableDecl(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneLanguageVisitor) return ((DroneLanguageVisitor<? extends T>)visitor).visitVariableDecl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final VariableDeclContext variableDecl() throws RecognitionException {
		VariableDeclContext _localctx = new VariableDeclContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_variableDecl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(58);
			match(TYPE_NAME);
			setState(59);
			match(IDENTIFIER);
			setState(60);
			match(T__1);
			setState(61);
			value();
			setState(62);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ValueContext extends ParserRuleContext {
		public NumericExpressionContext numericExpression() {
			return getRuleContext(NumericExpressionContext.class,0);
		}
		public IdentifierArrayContext identifierArray() {
			return getRuleContext(IdentifierArrayContext.class,0);
		}
		public ValueContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_value; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).enterValue(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).exitValue(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneLanguageVisitor) return ((DroneLanguageVisitor<? extends T>)visitor).visitValue(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ValueContext value() throws RecognitionException {
		ValueContext _localctx = new ValueContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_value);
		try {
			setState(66);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,3,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(64);
				numericExpression(0);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(65);
				identifierArray();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InstructionsSectionContext extends ParserRuleContext {
		public List<InstructionContext> instruction() {
			return getRuleContexts(InstructionContext.class);
		}
		public InstructionContext instruction(int i) {
			return getRuleContext(InstructionContext.class,i);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(DroneLanguageParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(DroneLanguageParser.NEWLINE, i);
		}
		public InstructionsSectionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instructionsSection; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).enterInstructionsSection(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).exitInstructionsSection(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneLanguageVisitor) return ((DroneLanguageVisitor<? extends T>)visitor).visitInstructionsSection(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InstructionsSectionContext instructionsSection() throws RecognitionException {
		InstructionsSectionContext _localctx = new InstructionsSectionContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_instructionsSection);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(77);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==IDENTIFIER) {
				{
				{
				setState(68);
				instruction();
				setState(72);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==NEWLINE) {
					{
					{
					setState(69);
					match(NEWLINE);
					}
					}
					setState(74);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				}
				setState(79);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InstructionContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(DroneLanguageParser.IDENTIFIER, 0); }
		public ArgumentGroupListContext argumentGroupList() {
			return getRuleContext(ArgumentGroupListContext.class,0);
		}
		public InstructionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instruction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).enterInstruction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).exitInstruction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneLanguageVisitor) return ((DroneLanguageVisitor<? extends T>)visitor).visitInstruction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InstructionContext instruction() throws RecognitionException {
		InstructionContext _localctx = new InstructionContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_instruction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(80);
			match(IDENTIFIER);
			setState(81);
			match(T__3);
			setState(83);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__6) {
				{
				setState(82);
				argumentGroupList();
				}
			}

			setState(85);
			match(T__4);
			setState(86);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ArgumentGroupListContext extends ParserRuleContext {
		public List<ArgumentGroupContext> argumentGroup() {
			return getRuleContexts(ArgumentGroupContext.class);
		}
		public ArgumentGroupContext argumentGroup(int i) {
			return getRuleContext(ArgumentGroupContext.class,i);
		}
		public ArgumentGroupListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_argumentGroupList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).enterArgumentGroupList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).exitArgumentGroupList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneLanguageVisitor) return ((DroneLanguageVisitor<? extends T>)visitor).visitArgumentGroupList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ArgumentGroupListContext argumentGroupList() throws RecognitionException {
		ArgumentGroupListContext _localctx = new ArgumentGroupListContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_argumentGroupList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(88);
			argumentGroup();
			setState(93);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__5) {
				{
				{
				setState(89);
				match(T__5);
				setState(90);
				argumentGroup();
				}
				}
				setState(95);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ArgumentGroupContext extends ParserRuleContext {
		public List<ArgumentContentContext> argumentContent() {
			return getRuleContexts(ArgumentContentContext.class);
		}
		public ArgumentContentContext argumentContent(int i) {
			return getRuleContext(ArgumentContentContext.class,i);
		}
		public ArgumentGroupContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_argumentGroup; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).enterArgumentGroup(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).exitArgumentGroup(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneLanguageVisitor) return ((DroneLanguageVisitor<? extends T>)visitor).visitArgumentGroup(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ArgumentGroupContext argumentGroup() throws RecognitionException {
		ArgumentGroupContext _localctx = new ArgumentGroupContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_argumentGroup);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(96);
			match(T__6);
			setState(98); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(97);
				argumentContent();
				}
				}
				setState(100); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & 238096L) != 0) );
			setState(102);
			match(T__7);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ArgumentContentContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(DroneLanguageParser.IDENTIFIER, 0); }
		public NumericExpressionContext numericExpression() {
			return getRuleContext(NumericExpressionContext.class,0);
		}
		public ArgumentContentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_argumentContent; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).enterArgumentContent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).exitArgumentContent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneLanguageVisitor) return ((DroneLanguageVisitor<? extends T>)visitor).visitArgumentContent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ArgumentContentContext argumentContent() throws RecognitionException {
		ArgumentContentContext _localctx = new ArgumentContentContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_argumentContent);
		try {
			setState(110);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,9,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(104);
				match(IDENTIFIER);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(105);
				match(T__3);
				setState(106);
				numericExpression(0);
				setState(107);
				match(T__4);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(109);
				numericExpression(0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NumericExpressionContext extends ParserRuleContext {
		public Token op;
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public List<NumericExpressionContext> numericExpression() {
			return getRuleContexts(NumericExpressionContext.class);
		}
		public NumericExpressionContext numericExpression(int i) {
			return getRuleContext(NumericExpressionContext.class,i);
		}
		public NumericTupleContext numericTuple() {
			return getRuleContext(NumericTupleContext.class,0);
		}
		public NumericArrayContext numericArray() {
			return getRuleContext(NumericArrayContext.class,0);
		}
		public NumericExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numericExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).enterNumericExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).exitNumericExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneLanguageVisitor) return ((DroneLanguageVisitor<? extends T>)visitor).visitNumericExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NumericExpressionContext numericExpression() throws RecognitionException {
		return numericExpression(0);
	}

	private NumericExpressionContext numericExpression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		NumericExpressionContext _localctx = new NumericExpressionContext(_ctx, _parentState);
		NumericExpressionContext _prevctx = _localctx;
		int _startState = 20;
		enterRecursionRule(_localctx, 20, RULE_numericExpression, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(122);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,10,_ctx) ) {
			case 1:
				{
				setState(113);
				literal();
				}
				break;
			case 2:
				{
				setState(114);
				match(T__8);
				setState(115);
				numericExpression(5);
				}
				break;
			case 3:
				{
				setState(116);
				match(T__3);
				setState(117);
				numericExpression(0);
				setState(118);
				match(T__4);
				}
				break;
			case 4:
				{
				setState(120);
				numericTuple();
				}
				break;
			case 5:
				{
				setState(121);
				numericArray();
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(129);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,11,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new NumericExpressionContext(_parentctx, _parentState);
					pushNewRecursionContext(_localctx, _startState, RULE_numericExpression);
					setState(124);
					if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
					setState(125);
					((NumericExpressionContext)_localctx).op = _input.LT(1);
					_la = _input.LA(1);
					if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 7680L) != 0)) ) {
						((NumericExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					setState(126);
					numericExpression(5);
					}
					} 
				}
				setState(131);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,11,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NumericTupleContext extends ParserRuleContext {
		public List<NumericExpressionContext> numericExpression() {
			return getRuleContexts(NumericExpressionContext.class);
		}
		public NumericExpressionContext numericExpression(int i) {
			return getRuleContext(NumericExpressionContext.class,i);
		}
		public NumericTupleContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numericTuple; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).enterNumericTuple(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).exitNumericTuple(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneLanguageVisitor) return ((DroneLanguageVisitor<? extends T>)visitor).visitNumericTuple(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NumericTupleContext numericTuple() throws RecognitionException {
		NumericTupleContext _localctx = new NumericTupleContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_numericTuple);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(132);
			match(T__3);
			setState(133);
			numericExpression(0);
			setState(138);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__5) {
				{
				{
				setState(134);
				match(T__5);
				setState(135);
				numericExpression(0);
				}
				}
				setState(140);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(141);
			match(T__4);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NumericArrayContext extends ParserRuleContext {
		public List<NumericTupleContext> numericTuple() {
			return getRuleContexts(NumericTupleContext.class);
		}
		public NumericTupleContext numericTuple(int i) {
			return getRuleContext(NumericTupleContext.class,i);
		}
		public NumericArrayContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numericArray; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).enterNumericArray(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).exitNumericArray(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneLanguageVisitor) return ((DroneLanguageVisitor<? extends T>)visitor).visitNumericArray(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NumericArrayContext numericArray() throws RecognitionException {
		NumericArrayContext _localctx = new NumericArrayContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_numericArray);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(143);
			match(T__3);
			setState(144);
			numericTuple();
			setState(149);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__5) {
				{
				{
				setState(145);
				match(T__5);
				setState(146);
				numericTuple();
				}
				}
				setState(151);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(152);
			match(T__4);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IdentifierArrayContext extends ParserRuleContext {
		public List<IdentifierTupleContext> identifierTuple() {
			return getRuleContexts(IdentifierTupleContext.class);
		}
		public IdentifierTupleContext identifierTuple(int i) {
			return getRuleContext(IdentifierTupleContext.class,i);
		}
		public IdentifierArrayContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_identifierArray; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).enterIdentifierArray(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).exitIdentifierArray(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneLanguageVisitor) return ((DroneLanguageVisitor<? extends T>)visitor).visitIdentifierArray(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IdentifierArrayContext identifierArray() throws RecognitionException {
		IdentifierArrayContext _localctx = new IdentifierArrayContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_identifierArray);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(154);
			match(T__3);
			setState(155);
			identifierTuple();
			setState(160);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__5) {
				{
				{
				setState(156);
				match(T__5);
				setState(157);
				identifierTuple();
				}
				}
				setState(162);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(163);
			match(T__4);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IdentifierTupleContext extends ParserRuleContext {
		public List<TerminalNode> IDENTIFIER() { return getTokens(DroneLanguageParser.IDENTIFIER); }
		public TerminalNode IDENTIFIER(int i) {
			return getToken(DroneLanguageParser.IDENTIFIER, i);
		}
		public IdentifierTupleContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_identifierTuple; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).enterIdentifierTuple(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).exitIdentifierTuple(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneLanguageVisitor) return ((DroneLanguageVisitor<? extends T>)visitor).visitIdentifierTuple(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IdentifierTupleContext identifierTuple() throws RecognitionException {
		IdentifierTupleContext _localctx = new IdentifierTupleContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_identifierTuple);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(165);
			match(T__3);
			setState(166);
			match(IDENTIFIER);
			setState(171);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__5) {
				{
				{
				setState(167);
				match(T__5);
				setState(168);
				match(IDENTIFIER);
				}
				}
				setState(173);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(174);
			match(T__4);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LiteralContext extends ParserRuleContext {
		public TerminalNode FLOAT() { return getToken(DroneLanguageParser.FLOAT, 0); }
		public TerminalNode INT() { return getToken(DroneLanguageParser.INT, 0); }
		public LiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).enterLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneLanguageListener ) ((DroneLanguageListener)listener).exitLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneLanguageVisitor) return ((DroneLanguageVisitor<? extends T>)visitor).visitLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LiteralContext literal() throws RecognitionException {
		LiteralContext _localctx = new LiteralContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_literal);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(176);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 204800L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 10:
			return numericExpression_sempred((NumericExpressionContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean numericExpression_sempred(NumericExpressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 4);
		}
		return true;
	}

	public static final String _serializedATN =
		"\u0004\u0001\u0014\u00b3\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001"+
		"\u0002\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004"+
		"\u0002\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007"+
		"\u0002\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b"+
		"\u0002\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e\u0002\u000f\u0007"+
		"\u000f\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0000\u0001"+
		"\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0005\u0001*\b\u0001\n\u0001"+
		"\f\u0001-\t\u0001\u0001\u0002\u0001\u0002\u0005\u00021\b\u0002\n\u0002"+
		"\f\u00024\t\u0002\u0005\u00026\b\u0002\n\u0002\f\u00029\t\u0002\u0001"+
		"\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001"+
		"\u0004\u0001\u0004\u0003\u0004C\b\u0004\u0001\u0005\u0001\u0005\u0005"+
		"\u0005G\b\u0005\n\u0005\f\u0005J\t\u0005\u0005\u0005L\b\u0005\n\u0005"+
		"\f\u0005O\t\u0005\u0001\u0006\u0001\u0006\u0001\u0006\u0003\u0006T\b\u0006"+
		"\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0007\u0001\u0007\u0001\u0007"+
		"\u0005\u0007\\\b\u0007\n\u0007\f\u0007_\t\u0007\u0001\b\u0001\b\u0004"+
		"\bc\b\b\u000b\b\f\bd\u0001\b\u0001\b\u0001\t\u0001\t\u0001\t\u0001\t\u0001"+
		"\t\u0001\t\u0003\to\b\t\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001"+
		"\n\u0001\n\u0001\n\u0001\n\u0001\n\u0003\n{\b\n\u0001\n\u0001\n\u0001"+
		"\n\u0005\n\u0080\b\n\n\n\f\n\u0083\t\n\u0001\u000b\u0001\u000b\u0001\u000b"+
		"\u0001\u000b\u0005\u000b\u0089\b\u000b\n\u000b\f\u000b\u008c\t\u000b\u0001"+
		"\u000b\u0001\u000b\u0001\f\u0001\f\u0001\f\u0001\f\u0005\f\u0094\b\f\n"+
		"\f\f\f\u0097\t\f\u0001\f\u0001\f\u0001\r\u0001\r\u0001\r\u0001\r\u0005"+
		"\r\u009f\b\r\n\r\f\r\u00a2\t\r\u0001\r\u0001\r\u0001\u000e\u0001\u000e"+
		"\u0001\u000e\u0001\u000e\u0005\u000e\u00aa\b\u000e\n\u000e\f\u000e\u00ad"+
		"\t\u000e\u0001\u000e\u0001\u000e\u0001\u000f\u0001\u000f\u0001\u000f\u0000"+
		"\u0001\u0014\u0010\u0000\u0002\u0004\u0006\b\n\f\u000e\u0010\u0012\u0014"+
		"\u0016\u0018\u001a\u001c\u001e\u0000\u0002\u0001\u0000\t\f\u0002\u0000"+
		"\r\r\u0010\u0011\u00b6\u0000 \u0001\u0000\u0000\u0000\u0002%\u0001\u0000"+
		"\u0000\u0000\u00047\u0001\u0000\u0000\u0000\u0006:\u0001\u0000\u0000\u0000"+
		"\bB\u0001\u0000\u0000\u0000\nM\u0001\u0000\u0000\u0000\fP\u0001\u0000"+
		"\u0000\u0000\u000eX\u0001\u0000\u0000\u0000\u0010`\u0001\u0000\u0000\u0000"+
		"\u0012n\u0001\u0000\u0000\u0000\u0014z\u0001\u0000\u0000\u0000\u0016\u0084"+
		"\u0001\u0000\u0000\u0000\u0018\u008f\u0001\u0000\u0000\u0000\u001a\u009a"+
		"\u0001\u0000\u0000\u0000\u001c\u00a5\u0001\u0000\u0000\u0000\u001e\u00b0"+
		"\u0001\u0000\u0000\u0000 !\u0003\u0002\u0001\u0000!\"\u0003\u0004\u0002"+
		"\u0000\"#\u0003\n\u0005\u0000#$\u0005\u0000\u0000\u0001$\u0001\u0001\u0000"+
		"\u0000\u0000%&\u0005\u000e\u0000\u0000&\'\u0005\u0001\u0000\u0000\'+\u0005"+
		"\u0011\u0000\u0000(*\u0005\u0012\u0000\u0000)(\u0001\u0000\u0000\u0000"+
		"*-\u0001\u0000\u0000\u0000+)\u0001\u0000\u0000\u0000+,\u0001\u0000\u0000"+
		"\u0000,\u0003\u0001\u0000\u0000\u0000-+\u0001\u0000\u0000\u0000.2\u0003"+
		"\u0006\u0003\u0000/1\u0005\u0012\u0000\u00000/\u0001\u0000\u0000\u0000"+
		"14\u0001\u0000\u0000\u000020\u0001\u0000\u0000\u000023\u0001\u0000\u0000"+
		"\u000036\u0001\u0000\u0000\u000042\u0001\u0000\u0000\u00005.\u0001\u0000"+
		"\u0000\u000069\u0001\u0000\u0000\u000075\u0001\u0000\u0000\u000078\u0001"+
		"\u0000\u0000\u00008\u0005\u0001\u0000\u0000\u000097\u0001\u0000\u0000"+
		"\u0000:;\u0005\u000e\u0000\u0000;<\u0005\u000f\u0000\u0000<=\u0005\u0002"+
		"\u0000\u0000=>\u0003\b\u0004\u0000>?\u0005\u0003\u0000\u0000?\u0007\u0001"+
		"\u0000\u0000\u0000@C\u0003\u0014\n\u0000AC\u0003\u001a\r\u0000B@\u0001"+
		"\u0000\u0000\u0000BA\u0001\u0000\u0000\u0000C\t\u0001\u0000\u0000\u0000"+
		"DH\u0003\f\u0006\u0000EG\u0005\u0012\u0000\u0000FE\u0001\u0000\u0000\u0000"+
		"GJ\u0001\u0000\u0000\u0000HF\u0001\u0000\u0000\u0000HI\u0001\u0000\u0000"+
		"\u0000IL\u0001\u0000\u0000\u0000JH\u0001\u0000\u0000\u0000KD\u0001\u0000"+
		"\u0000\u0000LO\u0001\u0000\u0000\u0000MK\u0001\u0000\u0000\u0000MN\u0001"+
		"\u0000\u0000\u0000N\u000b\u0001\u0000\u0000\u0000OM\u0001\u0000\u0000"+
		"\u0000PQ\u0005\u000f\u0000\u0000QS\u0005\u0004\u0000\u0000RT\u0003\u000e"+
		"\u0007\u0000SR\u0001\u0000\u0000\u0000ST\u0001\u0000\u0000\u0000TU\u0001"+
		"\u0000\u0000\u0000UV\u0005\u0005\u0000\u0000VW\u0005\u0003\u0000\u0000"+
		"W\r\u0001\u0000\u0000\u0000X]\u0003\u0010\b\u0000YZ\u0005\u0006\u0000"+
		"\u0000Z\\\u0003\u0010\b\u0000[Y\u0001\u0000\u0000\u0000\\_\u0001\u0000"+
		"\u0000\u0000][\u0001\u0000\u0000\u0000]^\u0001\u0000\u0000\u0000^\u000f"+
		"\u0001\u0000\u0000\u0000_]\u0001\u0000\u0000\u0000`b\u0005\u0007\u0000"+
		"\u0000ac\u0003\u0012\t\u0000ba\u0001\u0000\u0000\u0000cd\u0001\u0000\u0000"+
		"\u0000db\u0001\u0000\u0000\u0000de\u0001\u0000\u0000\u0000ef\u0001\u0000"+
		"\u0000\u0000fg\u0005\b\u0000\u0000g\u0011\u0001\u0000\u0000\u0000ho\u0005"+
		"\u000f\u0000\u0000ij\u0005\u0004\u0000\u0000jk\u0003\u0014\n\u0000kl\u0005"+
		"\u0005\u0000\u0000lo\u0001\u0000\u0000\u0000mo\u0003\u0014\n\u0000nh\u0001"+
		"\u0000\u0000\u0000ni\u0001\u0000\u0000\u0000nm\u0001\u0000\u0000\u0000"+
		"o\u0013\u0001\u0000\u0000\u0000pq\u0006\n\uffff\uffff\u0000q{\u0003\u001e"+
		"\u000f\u0000rs\u0005\t\u0000\u0000s{\u0003\u0014\n\u0005tu\u0005\u0004"+
		"\u0000\u0000uv\u0003\u0014\n\u0000vw\u0005\u0005\u0000\u0000w{\u0001\u0000"+
		"\u0000\u0000x{\u0003\u0016\u000b\u0000y{\u0003\u0018\f\u0000zp\u0001\u0000"+
		"\u0000\u0000zr\u0001\u0000\u0000\u0000zt\u0001\u0000\u0000\u0000zx\u0001"+
		"\u0000\u0000\u0000zy\u0001\u0000\u0000\u0000{\u0081\u0001\u0000\u0000"+
		"\u0000|}\n\u0004\u0000\u0000}~\u0007\u0000\u0000\u0000~\u0080\u0003\u0014"+
		"\n\u0005\u007f|\u0001\u0000\u0000\u0000\u0080\u0083\u0001\u0000\u0000"+
		"\u0000\u0081\u007f\u0001\u0000\u0000\u0000\u0081\u0082\u0001\u0000\u0000"+
		"\u0000\u0082\u0015\u0001\u0000\u0000\u0000\u0083\u0081\u0001\u0000\u0000"+
		"\u0000\u0084\u0085\u0005\u0004\u0000\u0000\u0085\u008a\u0003\u0014\n\u0000"+
		"\u0086\u0087\u0005\u0006\u0000\u0000\u0087\u0089\u0003\u0014\n\u0000\u0088"+
		"\u0086\u0001\u0000\u0000\u0000\u0089\u008c\u0001\u0000\u0000\u0000\u008a"+
		"\u0088\u0001\u0000\u0000\u0000\u008a\u008b\u0001\u0000\u0000\u0000\u008b"+
		"\u008d\u0001\u0000\u0000\u0000\u008c\u008a\u0001\u0000\u0000\u0000\u008d"+
		"\u008e\u0005\u0005\u0000\u0000\u008e\u0017\u0001\u0000\u0000\u0000\u008f"+
		"\u0090\u0005\u0004\u0000\u0000\u0090\u0095\u0003\u0016\u000b\u0000\u0091"+
		"\u0092\u0005\u0006\u0000\u0000\u0092\u0094\u0003\u0016\u000b\u0000\u0093"+
		"\u0091\u0001\u0000\u0000\u0000\u0094\u0097\u0001\u0000\u0000\u0000\u0095"+
		"\u0093\u0001\u0000\u0000\u0000\u0095\u0096\u0001\u0000\u0000\u0000\u0096"+
		"\u0098\u0001\u0000\u0000\u0000\u0097\u0095\u0001\u0000\u0000\u0000\u0098"+
		"\u0099\u0005\u0005\u0000\u0000\u0099\u0019\u0001\u0000\u0000\u0000\u009a"+
		"\u009b\u0005\u0004\u0000\u0000\u009b\u00a0\u0003\u001c\u000e\u0000\u009c"+
		"\u009d\u0005\u0006\u0000\u0000\u009d\u009f\u0003\u001c\u000e\u0000\u009e"+
		"\u009c\u0001\u0000\u0000\u0000\u009f\u00a2\u0001\u0000\u0000\u0000\u00a0"+
		"\u009e\u0001\u0000\u0000\u0000\u00a0\u00a1\u0001\u0000\u0000\u0000\u00a1"+
		"\u00a3\u0001\u0000\u0000\u0000\u00a2\u00a0\u0001\u0000\u0000\u0000\u00a3"+
		"\u00a4\u0005\u0005\u0000\u0000\u00a4\u001b\u0001\u0000\u0000\u0000\u00a5"+
		"\u00a6\u0005\u0004\u0000\u0000\u00a6\u00ab\u0005\u000f\u0000\u0000\u00a7"+
		"\u00a8\u0005\u0006\u0000\u0000\u00a8\u00aa\u0005\u000f\u0000\u0000\u00a9"+
		"\u00a7\u0001\u0000\u0000\u0000\u00aa\u00ad\u0001\u0000\u0000\u0000\u00ab"+
		"\u00a9\u0001\u0000\u0000\u0000\u00ab\u00ac\u0001\u0000\u0000\u0000\u00ac"+
		"\u00ae\u0001\u0000\u0000\u0000\u00ad\u00ab\u0001\u0000\u0000\u0000\u00ae"+
		"\u00af\u0005\u0005\u0000\u0000\u00af\u001d\u0001\u0000\u0000\u0000\u00b0"+
		"\u00b1\u0007\u0001\u0000\u0000\u00b1\u001f\u0001\u0000\u0000\u0000\u0010"+
		"+27BHMS]dnz\u0081\u008a\u0095\u00a0\u00ab";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}