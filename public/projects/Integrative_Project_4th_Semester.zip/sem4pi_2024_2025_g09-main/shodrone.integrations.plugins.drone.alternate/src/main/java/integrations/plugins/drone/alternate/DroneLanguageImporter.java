package integrations.plugins.drone.alternate;

import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * Importer for drone programs written in DroneLanguage.
 */
@Component
public class DroneLanguageImporter {

    public List<DroneInstructionDTO> importFrom(InputStream input) throws IOException {
        // Parsing
        CharStream charStream = CharStreams.fromStream(input);
        DroneLanguageLexer lexer = new DroneLanguageLexer(charStream);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        DroneLanguageParser parser = new DroneLanguageParser(tokens);

        parser.removeErrorListeners();
        ErrorCollector listener = new ErrorCollector();
        parser.addErrorListener(listener);

        ParseTree tree = parser.program();

        if (listener.hasErrors()) {
            throw new IllegalArgumentException("Syntax errors:\n" + listener.getFormattedErrors());
        }

        // Walking parse tree
        DroneProgramListener droneListener = new DroneProgramListener();
        ParseTreeWalker.DEFAULT.walk(droneListener, tree);

        return droneListener.instructions();
    }

    private static class ErrorCollector extends BaseErrorListener {
        private final StringBuilder errors = new StringBuilder();

        @Override
        public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol,
                                int line, int charPositionInLine, String msg, RecognitionException e) {
            errors.append("line ").append(line).append(":").append(charPositionInLine)
                    .append(" ").append(msg).append("\n");
        }

        boolean hasErrors() {
            return errors.length() > 0;
        }

        String getFormattedErrors() {
            return errors.toString();
        }
    }
}

