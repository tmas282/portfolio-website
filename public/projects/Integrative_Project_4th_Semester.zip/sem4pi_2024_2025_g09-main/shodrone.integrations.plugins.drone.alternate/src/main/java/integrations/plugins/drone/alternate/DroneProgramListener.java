package integrations.plugins.drone.alternate;


import org.antlr.v4.runtime.tree.ParseTreeListener;
import java.util.ArrayList;
import java.util.List;

/**
 * Listener to walk the parse tree and extract drone instructions.
 * Follows the ANTLR visitor pattern for DroneLanguage.
 */
public class DroneProgramListener extends DroneLanguageBaseListener implements ParseTreeListener {

    private final List<DroneInstructionDTO> instructions = new ArrayList<>();
    private DroneInstructionDTO current;

    @Override
    public void enterInstruction(DroneLanguageParser.InstructionContext ctx) {
        current = new DroneInstructionDTO();


        current.setCommand(ctx.IDENTIFIER().getText());


        if (ctx.argumentGroupList() != null) {
            List<String> args = new ArrayList<>();
            for (var group : ctx.argumentGroupList().argumentGroup()) {
                StringBuilder sb = new StringBuilder();
                for (var content : group.argumentContent()) {
                    sb.append(content.getText()).append(" ");
                }
                args.add(sb.toString().trim());
            }
            current.setArguments(args);
        }
    }

    @Override
    public void exitInstruction(DroneLanguageParser.InstructionContext ctx) {
        instructions.add(current);
    }

    public List<DroneInstructionDTO> instructions() {
        return instructions;
    }
}
