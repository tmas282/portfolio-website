#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "read_drone.h"




// Allocates and fills 'lines' with CSV lines, returns number of lines read
int read_csv_lines(const char* filename, char* lines[]) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        perror("fopen");
        return -1;
    }

    char buffer[MAX_LINE_LEN];
    int count = 0;

    // Skip header
    if (fgets(buffer, sizeof(buffer), file) == NULL) {
        fclose(file);
        return 0;
    }

    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        buffer[strcspn(buffer, "\r\n")] = 0; // Remove newline
        lines[count] = strdup(buffer);      // Allocate and store line
        if (!lines[count]) {
            perror("strdup");
            break;
        }
        count++;
    }
    
    fclose(file);
    return count;
}




