#ifndef DRONE_H
#define DRONE_H

#include <unistd.h>


typedef struct {
    int x;
    int y;
    int z;
} position_t;

typedef struct {
    position_t delta;
    int duration;
    float velocity;
} movement_t;

void sendPositionToParent(position_t pos);

#endif