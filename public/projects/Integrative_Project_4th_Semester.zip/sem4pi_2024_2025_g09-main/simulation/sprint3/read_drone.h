#ifndef READ_DRONE_H
#define READ_DRONE_H
#define MAX_LINE_LEN 256
#define MAX_LINES    100
int read_csv_lines(const char* filename, char* lines[]);
#endif