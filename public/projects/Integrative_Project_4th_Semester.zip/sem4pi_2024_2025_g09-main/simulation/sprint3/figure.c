#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include <semaphore.h>
#include <pthread.h>
#include <stdatomic.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include "figure.h"
#include "read_drone.h"

atomic_int coll_ready;
int total_collisions;
int reported_collisions;
pthread_mutex_t coll_mut;
pthread_mutex_t step_mut;
pthread_cond_t coll_cond;
pthread_cond_t step_cond;
figure_t *figure;
int time_step;
 //ir para baixo

typedef struct {
    char drone1_id[16];
    char drone2_id[16];
    position_t position;
    int collision_time_step;
} collision_info_t;

collision_info_t collision_log[COLLISION_THRESHOLD * 2];
int collision_log_index = 0;

int are_drones_colliding(position_t pos1, position_t pos2) {
    return pos1.x == pos2.x && pos1.y == pos2.y && pos1.z == pos2.z;
}

//Function to read the csv lines and

void read_csv_lines_and_write(char *csv_name) {
    char* lines[MAX_DRONES];

    figure->drones_n = read_csv_lines(csv_name, lines);

    for (int i = 0; i < figure->drones_n; ++i) {
        figure->drones[i].isFinished = 0;
        sscanf(lines[i], "%[^,],%*d,%*d,%*d,%*d,%*d,%*d,%d,%*f",
               figure->drones[i].id, &(figure->drones[i].duration));

        if (figure->drones[i].duration > MAX_DRONE_STEPS) {
            figure->drones[i].duration = MAX_DRONE_STEPS;
        }

        memset(figure->drones[i].track, 0, sizeof(position_t) * figure->drones[i].duration); // estava em max drones steps antes
        figure->drones[i].current_track_index = 0;
        strncpy(figure->drones[i].line, lines[i], MAX_LINE_LEN);
        figure->drones[i].line[MAX_LINE_LEN - 1] = '\0';



        printf("Initialized drone %s with duration %d\n", figure->drones[i].id, figure->drones[i].duration);
    }
}

void initialize_drone_sems(sem_t **sem_ready, sem_t **sem_finished) {
    for(int i=0; i<figure->drones_n; ++i) {
        char sem_name[32];
        snprintf(sem_name, sizeof(sem_name), "/sem_ready_%s", figure->drones[i].id);
        sem_unlink(sem_name); // Clean up any existing semaphore
        sem_ready[i] = sem_open(sem_name, O_CREAT | O_EXCL, 0644, 0);

        snprintf(sem_name, sizeof(sem_name), "/sem_finished_%s", figure->drones[i].id);
        sem_unlink(sem_name); // Clean up any existing semaphore
        sem_finished[i] = sem_open(sem_name, O_CREAT | O_EXCL, 0644, 0);
    }
}

void *thread_check_for_collisions(void *arg) {
    //printf("Collision detection thread started\n");

    while(total_collisions < COLLISION_THRESHOLD && figure->drones_finished < figure->drones_n) {
        // Wait for signal from main thread AFTER drones have moved
        pthread_mutex_lock(&step_mut);
        while(!atomic_load(&coll_ready)){
            pthread_cond_wait(&step_cond, &step_mut);
        }
        int current_step = time_step; // Get current step under mutex protection
        pthread_mutex_unlock(&step_mut);

        pthread_mutex_lock(&coll_mut);

        printf("Checking for collisions at time step %d\n", current_step+1);

        // Print some positions to verify they're not all zeros
        /*for(int debug_i = 0; debug_i < 3 && debug_i < figure->drones_n; debug_i++) {
            if(!figure->drones[debug_i].isFinished && current_step < figure->drones[debug_i].duration) {
                position_t debug_pos = figure->drones[debug_i].track[current_step];
                printf("DEBUG: %s position at step %d: (%d,%d,%d)\n",
                       figure->drones[debug_i].id, current_step, debug_pos.x, debug_pos.y, debug_pos.z);
            }
        }*/

        // Check all pairs of active drones for collisions
        for(int i = 0; i < figure->drones_n; i++) {
            if(figure->drones[i].isFinished) continue;

            for(int j = i + 1; j < figure->drones_n; j++) {
                if(figure->drones[j].isFinished) continue;

                // Proper bounds checking
                if(current_step >= 0 &&
                   current_step < figure->drones[i].duration &&
                   current_step < figure->drones[j].duration &&
                   current_step < MAX_DRONE_STEPS) {

                    position_t pos1 = figure->drones[i].track[current_step];
                    position_t pos2 = figure->drones[j].track[current_step];

                    if(are_drones_colliding(pos1, pos2)) {
                        if(collision_log_index < COLLISION_THRESHOLD * 2) {
                            strncpy(collision_log[collision_log_index].drone1_id,
                                   figure->drones[i].id, 15);
                            collision_log[collision_log_index].drone1_id[15] = '\0';

                            strncpy(collision_log[collision_log_index].drone2_id,
                                   figure->drones[j].id, 15);
                            collision_log[collision_log_index].drone2_id[15] = '\0';

                            collision_log[collision_log_index].position = pos1;
                            collision_log[collision_log_index].collision_time_step = current_step;
                            collision_log_index++;
                        }

                        total_collisions++;
                        printf("COLLISION DETECTED: %s and %s at position (%d,%d,%d) - Total: %d\n",
                               figure->drones[i].id, figure->drones[j].id,
                               pos1.x, pos1.y, pos1.z, total_collisions);
                        // Mark drones as finished
                        figure->drones[j].isFinished = 1;
                        figure->drones_finished++;
                        figure->drones[i].isFinished = 1;
                        figure->drones_finished++;
                        // terminate the drones
                        kill(figure->drones[j].pid, SIGUSR1);
                        kill(figure->drones[i].pid, SIGUSR1);
                        break;
                    }
                }
            }
            if(total_collisions >= COLLISION_THRESHOLD) break;
        }

        if(total_collisions > reported_collisions) {
            //printf("Signaling report thread - New collisions detected\n");
            pthread_cond_signal(&coll_cond);
        }

        pthread_mutex_unlock(&coll_mut);
        atomic_store(&coll_ready, 0);
    }

    //printf("Collision detection thread exiting\n");
    pthread_exit((void*)NULL);
}

void *thread_write_report(void *arg) {
    FILE *report_file = fopen("collision_report.txt", "w");
    if(!report_file) {
        perror("Failed to open report file");
        pthread_exit((void*)NULL);
    }

    time_t now = time(NULL);
    fprintf(report_file, "=== DRONE COLLISION SIMULATION REPORT ===\n");
    fprintf(report_file, "Report generated at: %s", ctime(&now));
    fprintf(report_file, "Total number of drones: %d\n", figure->drones_n);
    fprintf(report_file, "Collision threshold: %d\n\n", COLLISION_THRESHOLD);
    fflush(report_file);
    //printf("Report generation thread started\n");
    while(reported_collisions < COLLISION_THRESHOLD && figure->drones_finished < figure->drones_n) {
        pthread_mutex_lock(&coll_mut);
        while(reported_collisions == total_collisions &&
               total_collisions < COLLISION_THRESHOLD &&
               figure->drones_finished < figure->drones_n) {
            //printf("Report thread waiting for collision notification...\n");
            pthread_cond_wait(&coll_cond, &coll_mut);
        }
        while(reported_collisions < total_collisions &&
                reported_collisions < collision_log_index &&
                reported_collisions < COLLISION_THRESHOLD * 2) {
            collision_info_t *collision = &collision_log[reported_collisions];
            printf("REPORTING COLLISION #%d: %s <-> %s\n",
                   reported_collisions + 1, collision->drone1_id, collision->drone2_id);
            fprintf(report_file, "COLLISION #%d\n", reported_collisions + 1);
            fprintf(report_file, "  Time Step: %d\n", collision->collision_time_step);
            fprintf(report_file, "  Drones Involved: %s and %s\n",
                collision->drone1_id, collision->drone2_id);
            fprintf(report_file, "  Collision Position: (%d, %d, %d)\n\n",
                collision->position.x, collision->position.y, collision->position.z);
            fflush(report_file);
            reported_collisions++;
        }
        pthread_mutex_unlock(&coll_mut);
    }

    // Final report section after simulation ends
    pthread_mutex_lock(&coll_mut);
    fprintf(report_file, "=== DRONE EXECUTION STATUSES ===\n");
    for(int i = 0; i < figure->drones_n; i++) {
        const char *status;
        if(figure->drones[i].isFinished) {
            // Check if drone was involved in a collision
            int collided = 0;
            for(int j = 0; j < collision_log_index; j++) {
                if (strcmp(collision_log[j].drone1_id, figure->drones[i].id) == 0 ||
                    strcmp(collision_log[j].drone2_id, figure->drones[i].id) == 0) {
                    collided = 1;
                    break;
                }
            }
            if(collided) {
                status = "Terminated due to collision";
            }else if (total_collisions >= COLLISION_THRESHOLD && figure->drones[i].current_track_index < figure->drones[i].duration) {
                status = "Terminated due to collision threshold reached";
            }else {
                status = "Completed normally";
            }
        }else {
            status = "Running (unexpected state)";
        }
        fprintf(report_file, "Drone %s: %s\n", figure->drones[i].id, status);
    }
    fprintf(report_file, "\n=== SIMULATION SUMMARY ===\n");
    fprintf(report_file, "Total collisions detected: %d\n", total_collisions);
    fprintf(report_file, "Total collisions reported: %d\n", reported_collisions);
    fprintf(report_file, "Total drones finished: %d\n", figure->drones_finished);
    const char *validation_result = (total_collisions < COLLISION_THRESHOLD) ? "PASS" : "FAIL";
    fprintf(report_file, "Validation result: %s\n", validation_result);
    fprintf(report_file, "Simulation status: %s\n",
        (total_collisions >= COLLISION_THRESHOLD) ? "TERMINATED - Collision threshold reached" : "COMPLETED");
    pthread_mutex_unlock(&coll_mut);

    fclose(report_file);
    printf("Report generated: collision_report.txt\n");
    pthread_exit((void*)NULL);
}

int main(void) {
    int fd, i, shared_size = sizeof(figure_t);
    pid_t pid;
    time_step = 0;
    pthread_t thread_collisions, thread_report;
    atomic_store(&coll_ready, 0);



    // Clean up any existing shared memory
    shm_unlink("/shm_sim");

    fd = shm_open("/shm_sim", O_CREAT | O_RDWR, S_IWUSR | S_IRUSR);
    if (fd == -1) {
        perror("shm_open");
        return 1;
    }

    if (ftruncate(fd, shared_size) == -1) {
        perror("ftruncate");
        return 1;
    }

    figure = (figure_t*)mmap(NULL, shared_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (figure == MAP_FAILED) {
        perror("mmap");
        return 1;
    }

    memset(figure, 0, sizeof(figure_t));


    //Reads csv lines and initiates data on shared memory
    read_csv_lines_and_write("drone_movements.csv");

    sem_t *sem_ready[figure->drones_n];
    sem_t *sem_finished[figure->drones_n];
    // Allocates memory for the arrays of the semaphores for the drones

    initialize_drone_sems(sem_ready, sem_finished);

    total_collisions = 0;
    reported_collisions = 0;
    collision_log_index = 0;

    pthread_mutex_init(&coll_mut, NULL);
    pthread_mutex_init(&step_mut, NULL);
    pthread_cond_init(&coll_cond, NULL);
    pthread_cond_init(&step_cond, NULL);

    pthread_create(&thread_collisions, NULL, thread_check_for_collisions, (void*)NULL);
    pthread_create(&thread_report, NULL, thread_write_report, (void*)NULL);

    printf("lauching %d drones...\n", figure->drones_n);
    for(i = 0; i < figure->drones_n; ++i) {
        if((pid = fork()) < 0) {
            perror("fork");
            return 1;
        }
        else if(pid > 0) {
            figure->drones[i].pid = pid;
        }
        else {
            char arg[sizeof(int)];
            snprintf(arg, sizeof(int), "%d", i);
            execlp("./drone", "./drone", arg, NULL);
        }
    }

    printf("Starting drone collision simulation system...\n");

    while(figure->drones_finished < figure->drones_n && total_collisions < COLLISION_THRESHOLD) {
        printf("\n--- TIME STEP %d ---\n", time_step + 1);

        // STEP 1: Signal drones to move
        for(i = 0; i < figure->drones_n; ++i) {
            if(!figure->drones[i].isFinished) {
                sem_post(sem_ready[i]);
            }
        }

        // STEP 2: Wait for ALL drones to finish moving
        for(i = 0; i < figure->drones_n; ++i) {
            if(!figure->drones[i].isFinished) {
                sem_wait(sem_finished[i]);
            }
        }

        // STEP 3: Print current positions (now they should be valid!)
        for(i = 0; i < figure->drones_n; ++i) {
            if(!figure->drones[i].isFinished && time_step < figure->drones[i].duration) {
                position_t pos = figure->drones[i].track[time_step];
                printf("%s: (%d,%d,%d)\n", figure->drones[i].id, pos.x, pos.y, pos.z);
            }
        }

        // STEP 4: NOW signal collision detection thread (AFTER positions are written)
        pthread_mutex_lock(&step_mut);
        atomic_store(&coll_ready, 1);
        pthread_cond_broadcast(&step_cond);
        pthread_mutex_unlock(&step_mut);

        // STEP 5: Check for finished drones
        for(i = 0; i < figure->drones_n; ++i) {
            if(!figure->drones[i].isFinished) {
                if(figure->drones[i].current_track_index >= figure->drones[i].duration) {
                    figure->drones[i].isFinished = 1;
                    figure->drones_finished++;
                    printf("%s finished\n", figure->drones[i].id);
                }
            }
        }



        if(total_collisions > 0) {
            printf("Total collisions so far: %d\n", total_collisions);
        }
        sleep(1);
        time_step++;
    }

    if(total_collisions >= COLLISION_THRESHOLD) {
        printf("SIMULATION TERMINATED: Collision threshold (%d) reached!\n", COLLISION_THRESHOLD);
        for(i = 0; i < figure->drones_n; ++i) {
            if(!figure->drones[i].isFinished) {
                kill(figure->drones[i].pid, SIGTERM);
            }
        }
    }

    // debug ->printf("Waiting for threads to finish...\n");

    // Final signal to threads
    pthread_mutex_lock(&step_mut);
    atomic_store(&coll_ready, 1);
    pthread_cond_broadcast(&step_cond);
    pthread_mutex_unlock(&step_mut);

    pthread_mutex_lock(&coll_mut);
    pthread_cond_signal(&coll_cond);
    pthread_mutex_unlock(&coll_mut);


    //wait for threads to finish
    pthread_join(thread_collisions, (void**)NULL);
    // debug -> printf("Collision detection thread finished\n");
    pthread_join(thread_report, (void**)NULL);
    // debug -> printf("Report generation thread finished\n");

    // Cleanup
    pthread_mutex_destroy(&coll_mut);
    pthread_mutex_destroy(&step_mut);
    pthread_cond_destroy(&step_cond);
    pthread_cond_destroy(&coll_cond);
    
    munmap(figure, shared_size);
    close(fd);
    shm_unlink("/shm_sim");

    printf("Simulation completed successfully!\n");
    return 0;
}
