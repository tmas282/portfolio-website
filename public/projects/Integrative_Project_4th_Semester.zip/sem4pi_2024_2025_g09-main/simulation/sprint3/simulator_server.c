#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <pthread.h>
#include <fcntl.h>
#include <sys/wait.h>

#define PORT 9999
#define MAX_DRONES 10
#define BUFFER_SIZE 1024
#define MAX_TIME_STEPS 10

// --- Declarações antecipadas ---
void *tick_thread_func(void *arg);
void *handle_run(void *arg);
void *handle_remote_drone(void *arg);

// --- Estruturas ---
typedef struct {
    int sock;
    char id[32];
    int active;
    int x, y, z;
} RemoteDrone;

typedef struct {
    int sock;
    char buffer[BUFFER_SIZE];
} DroneClientData;

// --- Variáveis globais ---
RemoteDrone drones[MAX_DRONES];
pthread_mutex_t drone_mutex = PTHREAD_MUTEX_INITIALIZER;
int time_step = 0;
int simulation_active = 1;

// --- TCP broadcast para drones remotos ---
void broadcast_step() {
    pthread_mutex_lock(&drone_mutex);
    for (int i = 0; i < MAX_DRONES; i++) {
        if (drones[i].active) {
            write(drones[i].sock, "STEP\n", 5);
        }
    }
    pthread_mutex_unlock(&drone_mutex);
}

void broadcast_stop() {
    pthread_mutex_lock(&drone_mutex);
    for (int i = 0; i < MAX_DRONES; i++) {
        if (drones[i].active) {
            write(drones[i].sock, "STOP\n", 5);
            close(drones[i].sock);
            drones[i].active = 0;
        }
    }
    pthread_mutex_unlock(&drone_mutex);
}

// --- Execução da simulação via fork + pipe ---
void *handle_run(void *arg) {
    int client_fd = *(int *)arg;
    free(arg);

    int pipefd[2];
    if (pipe(pipefd) == -1) {
        perror("pipe");
        close(client_fd);
        return NULL;
    }

    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        close(client_fd);
        return NULL;
    } else if (pid == 0) {
        // Processo filho
        close(pipefd[0]); // Fecha leitura
        dup2(pipefd[1], STDOUT_FILENO);
        dup2(pipefd[1], STDERR_FILENO); // também redireciona erros
        close(pipefd[1]);

        execlp("./show_simulator", "./show_simulator", NULL);
        perror("execlp failed");
        exit(EXIT_FAILURE);
    } else {
        // Processo pai
        close(pipefd[1]); // Fecha escrita
        char buffer[BUFFER_SIZE];
        ssize_t n;

        while ((n = read(pipefd[0], buffer, BUFFER_SIZE)) > 0) {
            send(client_fd, buffer, n, 0);
        }

        close(pipefd[0]);
        close(client_fd);
        waitpid(pid, NULL, 0);
        return NULL;
    }
}

// --- Handler de drone remoto (se usado) ---
void *handle_remote_drone(void *arg) {
    DroneClientData *data = (DroneClientData *)arg;
    int sock = data->sock;
    char *initial_buffer = data->buffer;
    char buffer[BUFFER_SIZE];
    char drone_id[32];
    int slot = -1;

    sscanf(initial_buffer, "DRONE:%s", drone_id);

    pthread_mutex_lock(&drone_mutex);
    for (int i = 0; i < MAX_DRONES; i++) {
        if (!drones[i].active) {
            slot = i;
            drones[i].sock = sock;
            strcpy(drones[i].id, drone_id);
            drones[i].active = 1;
            break;
        }
    }
    pthread_mutex_unlock(&drone_mutex);

    if (slot == -1) {
        fprintf(stderr, "No room for more drones.\n");
        close(sock);
        free(data);
        return NULL;
    }

    printf("Drone remoto conectado: %s\n", drones[slot].id);

    while (simulation_active) {
        memset(buffer, 0, BUFFER_SIZE);
        read(sock, buffer, BUFFER_SIZE);
        if (strncmp(buffer, "POS:", 4) == 0) {
            sscanf(buffer + 4, "%d,%d,%d", &drones[slot].x, &drones[slot].y, &drones[slot].z);
            printf("Drone %s posição: (%d,%d,%d)\n", drones[slot].id, drones[slot].x, drones[slot].y, drones[slot].z);
        }
        sleep(1);
    }

    free(data);
    return NULL;
}

// --- Thread para emitir ticks de STEP ---
void *tick_thread_func(void *arg __attribute__((unused))) {
    printf("🕒 A aguardar drones remotos... (10 segundos)\n");
    sleep(10);

    while (time_step < MAX_TIME_STEPS) {
        printf(">>> STEP %d\n", time_step);
        broadcast_step();
        sleep(1);
        time_step++;
    }

    simulation_active = 0;
    broadcast_stop();
    return NULL;
}

// --- main server loop ---
int main() {
    int server_fd;
    struct sockaddr_in address;
    socklen_t addrlen = sizeof(address);

    memset(drones, 0, sizeof(drones));

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    bind(server_fd, (struct sockaddr *)&address, sizeof(address));
    listen(server_fd, 10);

    printf("Simulator server listening on port %d...\n", PORT);

    pthread_t tick_thread;
    pthread_create(&tick_thread, NULL, tick_thread_func, NULL);

    while (1) {
        DroneClientData *client_data = malloc(sizeof(DroneClientData));
        client_data->sock = accept(server_fd, (struct sockaddr *)&address, &addrlen);

        memset(client_data->buffer, 0, BUFFER_SIZE);
        read(client_data->sock, client_data->buffer, BUFFER_SIZE);

        if (strncmp(client_data->buffer, "RUN", 3) == 0) {
            pthread_t run_thread;
            int *fd_ptr = malloc(sizeof(int));
            *fd_ptr = client_data->sock;
            pthread_create(&run_thread, NULL, handle_run, fd_ptr);
            free(client_data);
        } else if (strncmp(client_data->buffer, "DRONE:", 6) == 0) {
            pthread_t drone_thread;
            pthread_create(&drone_thread, NULL, handle_remote_drone, client_data);
        } else {
            close(client_data->sock);
            free(client_data);
        }
    }

    return 0;
}
