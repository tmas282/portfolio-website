#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <signal.h>
#include <string.h>
#include <fcntl.h>
#include <semaphore.h>

#include "figure.h"

figure_t *figure;
char id[16];
char sem_ready_name[32];
char sem_finished_name[32];
int drone_index;

void handle_usr1(int signum) {
    printf("%s finished due to collision...\n", id);
    sem_unlink(sem_ready_name);
    sem_unlink(sem_finished_name);
    exit(0);
}
void handle_term(int signum) {
    sem_unlink(sem_ready_name);
    sem_unlink(sem_finished_name);
    exit(0);
}

int main(int argc, char **argv) {
    int i, fd, shared_size = sizeof(figure_t);
    
    fd = shm_open("/shm_sim", O_RDWR, 0);
    figure = (figure_t*)mmap(NULL, shared_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

    sem_t  *sem_ready, *sem_finished;
    
    struct sigaction sa_usr1;
    memset(&sa_usr1, 0, sizeof(sa_usr1));
    sa_usr1.sa_handler = handle_usr1;
    sigemptyset(&sa_usr1.sa_mask);
    sigaddset(&sa_usr1.sa_mask, SIGTERM);
    sigaction(SIGUSR1, &sa_usr1, NULL);
    
    struct sigaction sa_term;
    memset(&sa_term, 0, sizeof(sa_term));
    sa_term.sa_handler = handle_term;
    sigemptyset(&sa_term.sa_mask);
    sigaction(SIGTERM, &sa_term, NULL);


    /*
        Registar index do drone  na shared memory
    */
    drone_index = atoi(argv[1]);
    
    position_t pos;
    movement_t mov;
    char *line;
    line = figure->drones[drone_index].line;
    sscanf(line, "%15[^,],%d,%d,%d,%d,%d,%d,%d,%f",
            id,
            &pos.x,
            &pos.y,
            &pos.z,
            &mov.delta.x,
            &mov.delta.y,
            &mov.delta.z,
            &mov.duration,
            &mov.velocity);

    
    snprintf(sem_ready_name, sizeof(sem_ready_name), "/sem_ready_%s", id);
    sem_ready = sem_open(sem_ready_name, 0);
    
    snprintf(sem_finished_name, sizeof(sem_finished_name), "/sem_finished_%s", id);
    sem_finished = sem_open(sem_finished_name, 0);

    for(int t=0; t<mov.duration; ++t) {
        sem_wait(sem_ready);
        figure->drones[drone_index].track[t] = pos;
        pos.x = pos.x + mov.delta.x;
        pos.y = pos.y + mov.delta.y;
        pos.z = pos.z + mov.delta.z;
        figure->drones[drone_index].current_track_index++;
        sem_post(sem_finished);
    }
    sem_unlink(sem_ready_name);
    sem_unlink(sem_finished_name);
    exit(0);
}