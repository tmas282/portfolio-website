#ifndef FIGURE_H
#define FIGURE_H

#include <sys/types.h>
#include <semaphore.h>
#include "drone.h"
#include "read_drone.h"

#define MAX_DRONES 500
#define COLLISION_THRESHOLD 6
#define MAX_DRONE_STEPS 30

typedef struct {
    char line[MAX_LINE_LEN];
    position_t track[MAX_DRONE_STEPS]; // track[0] = t0 = posicao inicial;
    pid_t pid;
    int current_track_index;
    int duration;
    int isFinished;
    char id[16];
} drone_t;

typedef struct {
    drone_t drones[MAX_DRONES];
    int drones_n;
    int drones_finished;
} figure_t;


#endif