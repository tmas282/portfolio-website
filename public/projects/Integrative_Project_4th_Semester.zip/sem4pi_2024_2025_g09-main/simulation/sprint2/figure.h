#ifndef FIGURE_H
#define FIGURE_H

#include <sys/types.h>
#include "drone.h"

typedef struct {
    int to_child[2];
    int from_child[2];
    pid_t pid;
    char id[16];
    Position* track; // track[0] = t0 = posicao inicial;
    int current_track_index;
    int isReady;
    int isFinished;
} Drone;

typedef struct {
    int time;
    char drone1_id[16];
    char drone2_id[16];
    Position pos;
} CollisionInfo;

typedef struct {
    Drone drones[256];
    int fds[256];
    CollisionInfo collisions[256];
} Figure;

#endif