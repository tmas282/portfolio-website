#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <string.h>
#include "drone.h"

void sendPositionToParent(Position pos) {
    printf("%d %d %d\n", pos.x, pos.y, pos.z);
    fflush(stdout);
}

void handle_usr1(int signum) {
    exit(0);
}
void handle_term(int signum) {
    //fprintf(stderr, "Terminating due to too many collisions\n");
    exit(0);
}

int main(void) {
    setbuf(stdout, NULL);

    struct sigaction sa_usr1;
    memset(&sa_usr1, 0, sizeof(sa_usr1));
    sa_usr1.sa_handler = handle_usr1;
    sigemptyset(&sa_usr1.sa_mask);
    sigaddset(&sa_usr1.sa_mask, SIGTERM);
    sigaction(SIGUSR1, &sa_usr1, NULL);
    
    struct sigaction sa_term;
    memset(&sa_term, 0, sizeof(sa_term));
    sa_term.sa_handler = handle_term;
    sigemptyset(&sa_term.sa_mask);
    sigaction(SIGTERM, &sa_term, NULL);

    char id[16];
    Position pos;
    Movement mov;
    char line[256];
    fgets(line, sizeof(line), stdin);
    sscanf(line, "%15[^,],%d,%d,%d,%d,%d,%d,%d,%f",
            id,
            &pos.x,
            &pos.y,
            &pos.z,
            &mov.delta.x,
            &mov.delta.y,
            &mov.delta.z,
            &mov.duration,
            &mov.velocity);


    char step_cmd[16];
    for(int t=0; t<mov.duration; ++t) {
        if (fgets(step_cmd, sizeof(step_cmd), stdin) == NULL) break;
        if (strncmp(step_cmd, "STEP", 4) != 0) break;
        pos.x += mov.delta.x;
        pos.y += mov.delta.y;
        pos.z += mov.delta.z;
        sendPositionToParent(pos);
    }

    kill(getppid(), SIGUSR2);
    exit(0);
}