# Simulation Group 9

## Script

For the movements of the drones, a CSV file with the following format was used:

- DroneID,StartX,StartY,StartZ,DeltaX,DeltaY,DeltaZ,Duration,Velocity

## Diagram

![Sequence Diagram](puml/diagram.svg)

## Explanation of each US

### US261 - Initiate simulation for a figure

For this UserStory, the main idea was that the parent process (figure.c) would first read and store
the movement script for each drone. After that, it would fork new processes and make those child processes execute 
drone.c (file that represents the functions of the drone while running). To ensure proper pipe functionality, the dup2 function was used
to swap the file descriptors of the pipe for STDIN and STDOUT.
The main process would then send the movement script to its designated drone.


### US262 - Capture and process drone movements


Each drone sends its new position to the main process through a printf()
The main process has an array of type Drone and each drone has an array of type position, resulting in time indexed array
of all the positions of the drone while in the air.


### US263 - Detect drone collisions in real time

crio duas funções, uma para dar handle do SIGUSR1 e outro para SIGTERM, 
que dão exit() do script do drone, porque estas funções são executadas 
sempre que é detetada uma colisão. Sempre que é detetada uma colisão no programa, 
envia um SIGUSR1 para os drones envolvidos, se ultrapassar o COLLISION_THRESHOLD, 
envia o SIGTERM para todos os drones existentes para os terminar



### US264 - Synchronize drone execution with a time step

For this UserStory, each drone process waits to receive a "STEP" write() from the
main process and then executes its movement.

### US265. Generate a simulation report


criaram-se duas funções, uma para dar handle do SIGUSR1 
e outro para SIGTERM, que dão exit() do script do drone, 
porque estas funções são executadas sempre que é detetada uma
colisão. Sempre que é detetada uma colisão no programa, envia um 
SIGUSR1 para os drones envolvidos, se ultrapassar o COLLISION_THRESHOLD,
envia o SIGTERM para todos os drones existentes para os termina

## AutoAvaliação

João Teixeira -> 100%

Afonso Ricardo -> 100%

Tomas Moreira -> 100%

