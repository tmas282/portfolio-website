#ifndef DRONE_H
#define DRONE_H

#include <unistd.h>


typedef struct {
    int x;
    int y;
    int z;
} Position;

typedef struct {
    Position delta;
    int duration;
    float velocity;
} Movement;

void sendPositionToParent(Position pos);

#endif