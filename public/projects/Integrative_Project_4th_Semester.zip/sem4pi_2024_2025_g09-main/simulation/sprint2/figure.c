#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
#include "figure.h"
#include "read_drone.h"

#define DRONE_COUNT 20
#define COLLISION_THRESHOLD 5

Drone drones[DRONE_COUNT];
volatile sig_atomic_t drones_finished;
int total_collisions = 0;

CollisionInfo collision_list[COLLISION_THRESHOLD];

void handle_USR2(int signo, siginfo_t *sinfo, void *context) {
    for(int i = 0; i < DRONE_COUNT; ++i) {
        if(drones[i].pid == sinfo->si_pid) {
            printf("[Parent] Drone %d (pid %d) finished\n", i+1, sinfo->si_pid);
        }
    }
}
int positions_equal(Position p1, Position p2) {
    return p1.x == p2.x && p1.y == p2.y && p1.z == p2.z;
}

void write_report() {
    FILE *fp = fopen("simulation_report.txt", "w");
    if (!fp) {
        perror("fopen");
        return;
    }

    fprintf(fp, "Simulation Report\n\n");
    fprintf(fp, "Total number of drones: %d\n\n", DRONE_COUNT);
    fprintf(fp, "Drone execution status:\n");
    for (int i = 0; i < DRONE_COUNT; i++) {
        int nColis = 0;
        for (int k = 0; k < total_collisions; k++) {
            CollisionInfo ci = collision_list[k];
            if(strcmp(drones[i].id, ci.drone1_id) == 0 || strcmp(drones[i].id, ci.drone2_id) == 0)
                nColis++;
        }
        fprintf(fp, "Drone %s: %s\n", drones[i].id,
                nColis == 0 ? "Finished normally" : "Terminated due to collisions");
    }
    fprintf(fp, "\nCollisions:\n");
    if (total_collisions == 0) {
        fprintf(fp, "None\n");
    } else {
        for (int k = 0; k < total_collisions; k++) {
            CollisionInfo ci = collision_list[k];
            fprintf(fp, "Time %d: Drones %s and %s at position (%d, %d, %d)\n",
                    ci.time, ci.drone1_id, ci.drone2_id, ci.pos.x, ci.pos.y, ci.pos.z);
        }
    }
    fprintf(fp, "\nValidation: %s\n",
            total_collisions < COLLISION_THRESHOLD ? "PASSED" : "FAILED due to collisions");
    fprintf(fp, "\nCollision Threshold: %d", COLLISION_THRESHOLD);
    fclose(fp);
}


int main(void) {
    drones_finished = 0;
    struct sigaction act;
    memset(&act, 0, sizeof(struct sigaction));
    act.sa_sigaction = handle_USR2;
    act.sa_flags = SA_SIGINFO;
    sigaction(SIGUSR2, &act, NULL);

    signal(SIGPIPE, SIG_IGN);

    char* lines[DRONE_COUNT];
    read_csv_lines("drone_movements.csv", lines, DRONE_COUNT);
    for (int i = 0; i < DRONE_COUNT; ++i) {
        drones[i].isReady = 0;
        drones[i].isFinished = 0;
        int durationForDrone = 0;
        sscanf(lines[i], "%[^,],%*d,%*d,%*d,%*d,%*d,%*d,%d,%*f", drones[i].id, &durationForDrone);
        drones[i].track = malloc(sizeof(Position) * durationForDrone);
        memset(drones[i].track, 0, sizeof(Position) * durationForDrone);
        drones[i].current_track_index = 0;
    }

    pid_t pid;

    for(int i = 0; i < DRONE_COUNT; ++i) {
        pipe(drones[i].to_child);
        pipe(drones[i].from_child);
        pid = fork();
        drones[i].pid = pid;
        if(pid == 0) {
            close(drones[i].to_child[1]);
            close(drones[i].from_child[0]);
            dup2(drones[i].to_child[0], STDIN_FILENO);
            dup2(drones[i].from_child[1], STDOUT_FILENO);
            close(drones[i].to_child[0]);
            close(drones[i].from_child[1]);
            execlp("./drone", "./drone", NULL);
            perror("execlp");
            exit(1);
        }
        else if (pid < 0) {
            perror("fork");
            exit(1);
        }
        else {
            close(drones[i].to_child[0]);
            close(drones[i].from_child[1]);
            write(drones[i].to_child[1], lines[i], strlen(lines[i]));
            write(drones[i].to_child[1], "\n", 1);
            free(lines[i]);
        }
    }

    int time_step = 0;
    char buffer[256];
    while (drones_finished < DRONE_COUNT) {
        /*
            Collision checking
        */
        for (int i = 0; i < DRONE_COUNT; i++) {
            for (int j = i + 1; j < DRONE_COUNT; j++) {
                if (!drones[i].isFinished && !drones[j].isFinished) {
                    Position pi = drones[i].track[drones[i].current_track_index - 1];
                    Position pj = drones[j].track[drones[j].current_track_index - 1];
                    if (positions_equal(pi, pj) && time_step != 0) {
                        printf("Collision at time %d between drone %d and %d at position %d %d %d\n",
                               time_step, i+1, j+1, pi.x, pi.y, pi.z);
                        collision_list[total_collisions].time = time_step;
                        strcpy(collision_list[total_collisions].drone1_id, drones[i].id);
                        strcpy(collision_list[total_collisions].drone2_id, drones[j].id);
                        collision_list[total_collisions].pos = pi;
                        total_collisions++;
                        close(drones[i].to_child[1]);
                        close(drones[j].to_child[1]);
                        drones[i].isFinished = 1;
                        drones[j].isFinished = 1;
                        drones_finished += 2;
                        kill(drones[i].pid, SIGUSR1);
                        kill(drones[j].pid, SIGUSR1);
                    }
                }
            }
        }
        /*
            Collision threshold checking
        */
        if (total_collisions >= COLLISION_THRESHOLD) {
            printf("Too many collisions! Terminating simulation.\n");
            for (int k = 0; k < DRONE_COUNT; k++) {
                if (!drones[k].isFinished) {
                    kill(drones[k].pid, SIGTERM);
                }
            }
            break;
        }

        /*
            Time step logging
        */
        printf("=== TIME STEP %d ===\n", time_step+1);
        int received = 0;
        // Receber posição de todos os drones ativos
        for (int i = 0; i < DRONE_COUNT; ++i) {
            if (!drones[i].isFinished) {
                write(drones[i].to_child[1], "STEP\n", 5);
                ssize_t n;
                do {
                    n = read(drones[i].from_child[0], buffer, sizeof(buffer) - 1);
                } while (n < 0 && errno == EINTR);  // Retry if interrupted
                if (n > 0) {
                    buffer[n] = '\0';
                    Position p;
                    if (sscanf(buffer, "%d %d %d", &p.x, &p.y, &p.z) == 3) {
                        drones[i].track[drones[i].current_track_index++] = p;
                        printf("[t%d] Drone %d: %s", time_step+1, i+1, buffer);
                    }
                    received++;
                }else if (n == 0) {
                    // EOF: drone closed its output pipe
                    if (!drones[i].isFinished) {
                        drones[i].isFinished = 1;
                        drones_finished++;
                        printf("[Parent] Drone %d (pid %d) finished\n", i + 1, drones[i].pid);
                    }
                } else {
                    perror("read");
                }
                
            }
        }

        //printf("Todos os drones ativos reportaram no time step %d\n", time_step+1);
        time_step++;
        //printf("Drones finished: %d\n", drones_finished);
        sleep(1);
    }

    /*
        Cleanup
    */

    for (int i = 0; i < DRONE_COUNT; ++i) {
        free(drones[i].track);
        close(drones[i].to_child[1]);
        close(drones[i].from_child[0]);
    }

    write_report();
    return 0;
}