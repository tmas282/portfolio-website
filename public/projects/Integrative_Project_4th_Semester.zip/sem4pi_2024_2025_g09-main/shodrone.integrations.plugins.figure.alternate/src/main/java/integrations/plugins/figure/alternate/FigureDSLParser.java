// Generated from FigureDSL.g4 by ANTLR 4.10.1
package integrations.plugins.figure.alternate;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class FigureDSLParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.10.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, T__8=9, 
		T__9=10, T__10=11, T__11=12, T__12=13, T__13=14, T__14=15, T__15=16, T__16=17, 
		T__17=18, T__18=19, T__19=20, T__20=21, T__21=22, T__22=23, T__23=24, 
		T__24=25, T__25=26, T__26=27, T__27=28, COLOR=29, VERSION=30, ID=31, INT=32, 
		FLOAT=33, WS=34, COMMENT=35;
	public static final int
		RULE_program = 0, RULE_header = 1, RULE_declaration = 2, RULE_droneTypeDecl = 3, 
		RULE_positionDecl = 4, RULE_velocityDecl = 5, RULE_distanceDecl = 6, RULE_shapeInitDecl = 7, 
		RULE_instructionBlock = 8, RULE_beforeBlock = 9, RULE_afterBlock = 10, 
		RULE_groupBlock = 11, RULE_instructionBlockContent = 12, RULE_nestedGroup = 13, 
		RULE_pauseInstr = 14, RULE_singleInstruction = 15, RULE_lightsOnInstr = 16, 
		RULE_lightsOffInstr = 17, RULE_moveInstr = 18, RULE_movePosInstr = 19, 
		RULE_rotateInstr = 20, RULE_vector3 = 21, RULE_exprList = 22, RULE_expr = 23, 
		RULE_scalar = 24, RULE_number = 25;
	private static String[] makeRuleNames() {
		return new String[] {
			"program", "header", "declaration", "droneTypeDecl", "positionDecl", 
			"velocityDecl", "distanceDecl", "shapeInitDecl", "instructionBlock", 
			"beforeBlock", "afterBlock", "groupBlock", "instructionBlockContent", 
			"nestedGroup", "pauseInstr", "singleInstruction", "lightsOnInstr", "lightsOffInstr", 
			"moveInstr", "movePosInstr", "rotateInstr", "vector3", "exprList", "expr", 
			"scalar", "number"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'DSL'", "'version'", "';'", "'DroneType'", "'Position'", "'='", 
			"'Velocity'", "'Distance'", "'('", "')'", "'before'", "'endbefore'", 
			"'after'", "'endafter'", "'group'", "'endgroup'", "'pause'", "'.'", "'lightsOn'", 
			"'lightsOff'", "'move'", "','", "'movePos'", "'rotate'", "'*'", "'/'", 
			"'+'", "'-'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, "COLOR", "VERSION", "ID", "INT", "FLOAT", 
			"WS", "COMMENT"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "FigureDSL.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public FigureDSLParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class ProgramContext extends ParserRuleContext {
		public HeaderContext header() {
			return getRuleContext(HeaderContext.class,0);
		}
		public TerminalNode EOF() { return getToken(FigureDSLParser.EOF, 0); }
		public List<DeclarationContext> declaration() {
			return getRuleContexts(DeclarationContext.class);
		}
		public DeclarationContext declaration(int i) {
			return getRuleContext(DeclarationContext.class,i);
		}
		public List<InstructionBlockContext> instructionBlock() {
			return getRuleContexts(InstructionBlockContext.class);
		}
		public InstructionBlockContext instructionBlock(int i) {
			return getRuleContext(InstructionBlockContext.class,i);
		}
		public ProgramContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_program; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterProgram(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitProgram(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitProgram(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ProgramContext program() throws RecognitionException {
		ProgramContext _localctx = new ProgramContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_program);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(52);
			header();
			setState(56);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,0,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(53);
					declaration();
					}
					} 
				}
				setState(58);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,0,_ctx);
			}
			setState(62);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__10) | (1L << T__12) | (1L << T__14) | (1L << T__16) | (1L << ID))) != 0)) {
				{
				{
				setState(59);
				instructionBlock();
				}
				}
				setState(64);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(65);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class HeaderContext extends ParserRuleContext {
		public TerminalNode VERSION() { return getToken(FigureDSLParser.VERSION, 0); }
		public HeaderContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_header; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterHeader(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitHeader(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitHeader(this);
			else return visitor.visitChildren(this);
		}
	}

	public final HeaderContext header() throws RecognitionException {
		HeaderContext _localctx = new HeaderContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_header);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(67);
			match(T__0);
			setState(68);
			match(T__1);
			setState(69);
			match(VERSION);
			setState(70);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DeclarationContext extends ParserRuleContext {
		public DroneTypeDeclContext droneTypeDecl() {
			return getRuleContext(DroneTypeDeclContext.class,0);
		}
		public PositionDeclContext positionDecl() {
			return getRuleContext(PositionDeclContext.class,0);
		}
		public VelocityDeclContext velocityDecl() {
			return getRuleContext(VelocityDeclContext.class,0);
		}
		public DistanceDeclContext distanceDecl() {
			return getRuleContext(DistanceDeclContext.class,0);
		}
		public ShapeInitDeclContext shapeInitDecl() {
			return getRuleContext(ShapeInitDeclContext.class,0);
		}
		public DeclarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_declaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterDeclaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitDeclaration(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitDeclaration(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DeclarationContext declaration() throws RecognitionException {
		DeclarationContext _localctx = new DeclarationContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_declaration);
		try {
			setState(77);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__3:
				enterOuterAlt(_localctx, 1);
				{
				setState(72);
				droneTypeDecl();
				}
				break;
			case T__4:
				enterOuterAlt(_localctx, 2);
				{
				setState(73);
				positionDecl();
				}
				break;
			case T__6:
				enterOuterAlt(_localctx, 3);
				{
				setState(74);
				velocityDecl();
				}
				break;
			case T__7:
				enterOuterAlt(_localctx, 4);
				{
				setState(75);
				distanceDecl();
				}
				break;
			case ID:
				enterOuterAlt(_localctx, 5);
				{
				setState(76);
				shapeInitDecl();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DroneTypeDeclContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(FigureDSLParser.ID, 0); }
		public DroneTypeDeclContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_droneTypeDecl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterDroneTypeDecl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitDroneTypeDecl(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitDroneTypeDecl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DroneTypeDeclContext droneTypeDecl() throws RecognitionException {
		DroneTypeDeclContext _localctx = new DroneTypeDeclContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_droneTypeDecl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(79);
			match(T__3);
			setState(80);
			match(ID);
			setState(81);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PositionDeclContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(FigureDSLParser.ID, 0); }
		public Vector3Context vector3() {
			return getRuleContext(Vector3Context.class,0);
		}
		public PositionDeclContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_positionDecl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterPositionDecl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitPositionDecl(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitPositionDecl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PositionDeclContext positionDecl() throws RecognitionException {
		PositionDeclContext _localctx = new PositionDeclContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_positionDecl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(83);
			match(T__4);
			setState(84);
			match(ID);
			setState(85);
			match(T__5);
			setState(86);
			vector3();
			setState(87);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VelocityDeclContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(FigureDSLParser.ID, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public VelocityDeclContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_velocityDecl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterVelocityDecl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitVelocityDecl(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitVelocityDecl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final VelocityDeclContext velocityDecl() throws RecognitionException {
		VelocityDeclContext _localctx = new VelocityDeclContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_velocityDecl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(89);
			match(T__6);
			setState(90);
			match(ID);
			setState(91);
			match(T__5);
			setState(92);
			expr(0);
			setState(93);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DistanceDeclContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(FigureDSLParser.ID, 0); }
		public NumberContext number() {
			return getRuleContext(NumberContext.class,0);
		}
		public DistanceDeclContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_distanceDecl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterDistanceDecl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitDistanceDecl(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitDistanceDecl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DistanceDeclContext distanceDecl() throws RecognitionException {
		DistanceDeclContext _localctx = new DistanceDeclContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_distanceDecl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(95);
			match(T__7);
			setState(96);
			match(ID);
			setState(97);
			match(T__5);
			setState(98);
			number();
			setState(99);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ShapeInitDeclContext extends ParserRuleContext {
		public List<TerminalNode> ID() { return getTokens(FigureDSLParser.ID); }
		public TerminalNode ID(int i) {
			return getToken(FigureDSLParser.ID, i);
		}
		public ExprListContext exprList() {
			return getRuleContext(ExprListContext.class,0);
		}
		public ShapeInitDeclContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_shapeInitDecl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterShapeInitDecl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitShapeInitDecl(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitShapeInitDecl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ShapeInitDeclContext shapeInitDecl() throws RecognitionException {
		ShapeInitDeclContext _localctx = new ShapeInitDeclContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_shapeInitDecl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(101);
			match(ID);
			setState(102);
			match(ID);
			setState(103);
			match(T__8);
			setState(104);
			exprList();
			setState(105);
			match(T__9);
			setState(106);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InstructionBlockContext extends ParserRuleContext {
		public BeforeBlockContext beforeBlock() {
			return getRuleContext(BeforeBlockContext.class,0);
		}
		public AfterBlockContext afterBlock() {
			return getRuleContext(AfterBlockContext.class,0);
		}
		public GroupBlockContext groupBlock() {
			return getRuleContext(GroupBlockContext.class,0);
		}
		public PauseInstrContext pauseInstr() {
			return getRuleContext(PauseInstrContext.class,0);
		}
		public SingleInstructionContext singleInstruction() {
			return getRuleContext(SingleInstructionContext.class,0);
		}
		public InstructionBlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instructionBlock; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterInstructionBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitInstructionBlock(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitInstructionBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InstructionBlockContext instructionBlock() throws RecognitionException {
		InstructionBlockContext _localctx = new InstructionBlockContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_instructionBlock);
		try {
			setState(113);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__10:
				enterOuterAlt(_localctx, 1);
				{
				setState(108);
				beforeBlock();
				}
				break;
			case T__12:
				enterOuterAlt(_localctx, 2);
				{
				setState(109);
				afterBlock();
				}
				break;
			case T__14:
				enterOuterAlt(_localctx, 3);
				{
				setState(110);
				groupBlock();
				}
				break;
			case T__16:
				enterOuterAlt(_localctx, 4);
				{
				setState(111);
				pauseInstr();
				}
				break;
			case ID:
				enterOuterAlt(_localctx, 5);
				{
				setState(112);
				singleInstruction();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BeforeBlockContext extends ParserRuleContext {
		public InstructionBlockContentContext instructionBlockContent() {
			return getRuleContext(InstructionBlockContentContext.class,0);
		}
		public BeforeBlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_beforeBlock; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterBeforeBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitBeforeBlock(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitBeforeBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BeforeBlockContext beforeBlock() throws RecognitionException {
		BeforeBlockContext _localctx = new BeforeBlockContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_beforeBlock);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(115);
			match(T__10);
			setState(116);
			instructionBlockContent();
			setState(117);
			match(T__11);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AfterBlockContext extends ParserRuleContext {
		public InstructionBlockContentContext instructionBlockContent() {
			return getRuleContext(InstructionBlockContentContext.class,0);
		}
		public AfterBlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_afterBlock; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterAfterBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitAfterBlock(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitAfterBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AfterBlockContext afterBlock() throws RecognitionException {
		AfterBlockContext _localctx = new AfterBlockContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_afterBlock);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(119);
			match(T__12);
			setState(120);
			instructionBlockContent();
			setState(121);
			match(T__13);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class GroupBlockContext extends ParserRuleContext {
		public InstructionBlockContentContext instructionBlockContent() {
			return getRuleContext(InstructionBlockContentContext.class,0);
		}
		public GroupBlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_groupBlock; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterGroupBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitGroupBlock(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitGroupBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GroupBlockContext groupBlock() throws RecognitionException {
		GroupBlockContext _localctx = new GroupBlockContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_groupBlock);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(123);
			match(T__14);
			setState(124);
			instructionBlockContent();
			setState(125);
			match(T__15);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InstructionBlockContentContext extends ParserRuleContext {
		public List<SingleInstructionContext> singleInstruction() {
			return getRuleContexts(SingleInstructionContext.class);
		}
		public SingleInstructionContext singleInstruction(int i) {
			return getRuleContext(SingleInstructionContext.class,i);
		}
		public List<NestedGroupContext> nestedGroup() {
			return getRuleContexts(NestedGroupContext.class);
		}
		public NestedGroupContext nestedGroup(int i) {
			return getRuleContext(NestedGroupContext.class,i);
		}
		public InstructionBlockContentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instructionBlockContent; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterInstructionBlockContent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitInstructionBlockContent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitInstructionBlockContent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InstructionBlockContentContext instructionBlockContent() throws RecognitionException {
		InstructionBlockContentContext _localctx = new InstructionBlockContentContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_instructionBlockContent);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(131);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__14 || _la==ID) {
				{
				setState(129);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case ID:
					{
					setState(127);
					singleInstruction();
					}
					break;
				case T__14:
					{
					setState(128);
					nestedGroup();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(133);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NestedGroupContext extends ParserRuleContext {
		public List<SingleInstructionContext> singleInstruction() {
			return getRuleContexts(SingleInstructionContext.class);
		}
		public SingleInstructionContext singleInstruction(int i) {
			return getRuleContext(SingleInstructionContext.class,i);
		}
		public NestedGroupContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nestedGroup; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterNestedGroup(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitNestedGroup(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitNestedGroup(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NestedGroupContext nestedGroup() throws RecognitionException {
		NestedGroupContext _localctx = new NestedGroupContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_nestedGroup);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(134);
			match(T__14);
			setState(136); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(135);
				singleInstruction();
				}
				}
				setState(138); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ID );
			setState(140);
			match(T__15);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PauseInstrContext extends ParserRuleContext {
		public NumberContext number() {
			return getRuleContext(NumberContext.class,0);
		}
		public PauseInstrContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pauseInstr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterPauseInstr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitPauseInstr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitPauseInstr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PauseInstrContext pauseInstr() throws RecognitionException {
		PauseInstrContext _localctx = new PauseInstrContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_pauseInstr);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(142);
			match(T__16);
			setState(143);
			match(T__8);
			setState(144);
			number();
			setState(145);
			match(T__9);
			setState(146);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SingleInstructionContext extends ParserRuleContext {
		public LightsOnInstrContext lightsOnInstr() {
			return getRuleContext(LightsOnInstrContext.class,0);
		}
		public LightsOffInstrContext lightsOffInstr() {
			return getRuleContext(LightsOffInstrContext.class,0);
		}
		public MoveInstrContext moveInstr() {
			return getRuleContext(MoveInstrContext.class,0);
		}
		public MovePosInstrContext movePosInstr() {
			return getRuleContext(MovePosInstrContext.class,0);
		}
		public RotateInstrContext rotateInstr() {
			return getRuleContext(RotateInstrContext.class,0);
		}
		public SingleInstructionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_singleInstruction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterSingleInstruction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitSingleInstruction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitSingleInstruction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SingleInstructionContext singleInstruction() throws RecognitionException {
		SingleInstructionContext _localctx = new SingleInstructionContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_singleInstruction);
		try {
			setState(153);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,7,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(148);
				lightsOnInstr();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(149);
				lightsOffInstr();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(150);
				moveInstr();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(151);
				movePosInstr();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(152);
				rotateInstr();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LightsOnInstrContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(FigureDSLParser.ID, 0); }
		public TerminalNode COLOR() { return getToken(FigureDSLParser.COLOR, 0); }
		public LightsOnInstrContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_lightsOnInstr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterLightsOnInstr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitLightsOnInstr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitLightsOnInstr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LightsOnInstrContext lightsOnInstr() throws RecognitionException {
		LightsOnInstrContext _localctx = new LightsOnInstrContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_lightsOnInstr);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(155);
			match(ID);
			setState(156);
			match(T__17);
			setState(157);
			match(T__18);
			setState(158);
			match(T__8);
			setState(159);
			match(COLOR);
			setState(160);
			match(T__9);
			setState(161);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LightsOffInstrContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(FigureDSLParser.ID, 0); }
		public LightsOffInstrContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_lightsOffInstr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterLightsOffInstr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitLightsOffInstr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitLightsOffInstr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LightsOffInstrContext lightsOffInstr() throws RecognitionException {
		LightsOffInstrContext _localctx = new LightsOffInstrContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_lightsOffInstr);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(163);
			match(ID);
			setState(164);
			match(T__17);
			setState(165);
			match(T__19);
			setState(166);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MoveInstrContext extends ParserRuleContext {
		public List<TerminalNode> ID() { return getTokens(FigureDSLParser.ID); }
		public TerminalNode ID(int i) {
			return getToken(FigureDSLParser.ID, i);
		}
		public Vector3Context vector3() {
			return getRuleContext(Vector3Context.class,0);
		}
		public NumberContext number() {
			return getRuleContext(NumberContext.class,0);
		}
		public MoveInstrContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_moveInstr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterMoveInstr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitMoveInstr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitMoveInstr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MoveInstrContext moveInstr() throws RecognitionException {
		MoveInstrContext _localctx = new MoveInstrContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_moveInstr);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(168);
			match(ID);
			setState(169);
			match(T__17);
			setState(170);
			match(T__20);
			setState(171);
			match(T__8);
			setState(172);
			vector3();
			setState(173);
			match(T__21);
			setState(174);
			number();
			setState(175);
			match(T__21);
			setState(176);
			match(ID);
			setState(177);
			match(T__9);
			setState(178);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MovePosInstrContext extends ParserRuleContext {
		public List<TerminalNode> ID() { return getTokens(FigureDSLParser.ID); }
		public TerminalNode ID(int i) {
			return getToken(FigureDSLParser.ID, i);
		}
		public MovePosInstrContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_movePosInstr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterMovePosInstr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitMovePosInstr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitMovePosInstr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MovePosInstrContext movePosInstr() throws RecognitionException {
		MovePosInstrContext _localctx = new MovePosInstrContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_movePosInstr);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(180);
			match(ID);
			setState(181);
			match(T__17);
			setState(182);
			match(T__22);
			setState(183);
			match(T__8);
			setState(184);
			match(ID);
			setState(185);
			match(T__21);
			setState(186);
			match(ID);
			setState(187);
			match(T__9);
			setState(188);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RotateInstrContext extends ParserRuleContext {
		public List<TerminalNode> ID() { return getTokens(FigureDSLParser.ID); }
		public TerminalNode ID(int i) {
			return getToken(FigureDSLParser.ID, i);
		}
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public RotateInstrContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_rotateInstr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterRotateInstr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitRotateInstr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitRotateInstr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RotateInstrContext rotateInstr() throws RecognitionException {
		RotateInstrContext _localctx = new RotateInstrContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_rotateInstr);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(190);
			match(ID);
			setState(191);
			match(T__17);
			setState(192);
			match(T__23);
			setState(193);
			match(T__8);
			setState(194);
			match(ID);
			setState(195);
			match(T__21);
			setState(196);
			match(ID);
			setState(197);
			match(T__21);
			setState(198);
			expr(0);
			setState(199);
			match(T__21);
			setState(200);
			match(ID);
			setState(201);
			match(T__9);
			setState(202);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Vector3Context extends ParserRuleContext {
		public List<ScalarContext> scalar() {
			return getRuleContexts(ScalarContext.class);
		}
		public ScalarContext scalar(int i) {
			return getRuleContext(ScalarContext.class,i);
		}
		public Vector3Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_vector3; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterVector3(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitVector3(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitVector3(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Vector3Context vector3() throws RecognitionException {
		Vector3Context _localctx = new Vector3Context(_ctx, getState());
		enterRule(_localctx, 42, RULE_vector3);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(204);
			match(T__8);
			setState(205);
			scalar(0);
			setState(206);
			match(T__21);
			setState(207);
			scalar(0);
			setState(208);
			match(T__21);
			setState(209);
			scalar(0);
			setState(210);
			match(T__9);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExprListContext extends ParserRuleContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public ExprListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_exprList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterExprList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitExprList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitExprList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExprListContext exprList() throws RecognitionException {
		ExprListContext _localctx = new ExprListContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_exprList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(212);
			expr(0);
			setState(217);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__21) {
				{
				{
				setState(213);
				match(T__21);
				setState(214);
				expr(0);
				}
				}
				setState(219);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExprContext extends ParserRuleContext {
		public TerminalNode INT() { return getToken(FigureDSLParser.INT, 0); }
		public TerminalNode FLOAT() { return getToken(FigureDSLParser.FLOAT, 0); }
		public TerminalNode ID() { return getToken(FigureDSLParser.ID, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitExpr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExprContext expr() throws RecognitionException {
		return expr(0);
	}

	private ExprContext expr(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExprContext _localctx = new ExprContext(_ctx, _parentState);
		ExprContext _prevctx = _localctx;
		int _startState = 46;
		enterRecursionRule(_localctx, 46, RULE_expr, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(230);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INT:
				{
				setState(221);
				match(INT);
				}
				break;
			case FLOAT:
				{
				setState(222);
				match(FLOAT);
				}
				break;
			case ID:
				{
				setState(223);
				match(ID);
				}
				break;
			case T__27:
				{
				setState(224);
				match(T__27);
				setState(225);
				expr(2);
				}
				break;
			case T__8:
				{
				setState(226);
				match(T__8);
				setState(227);
				expr(0);
				setState(228);
				match(T__9);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			_ctx.stop = _input.LT(-1);
			setState(246);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,11,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(244);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,10,_ctx) ) {
					case 1:
						{
						_localctx = new ExprContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(232);
						if (!(precpred(_ctx, 6))) throw new FailedPredicateException(this, "precpred(_ctx, 6)");
						setState(233);
						match(T__24);
						setState(234);
						expr(7);
						}
						break;
					case 2:
						{
						_localctx = new ExprContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(235);
						if (!(precpred(_ctx, 5))) throw new FailedPredicateException(this, "precpred(_ctx, 5)");
						setState(236);
						match(T__25);
						setState(237);
						expr(6);
						}
						break;
					case 3:
						{
						_localctx = new ExprContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(238);
						if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
						setState(239);
						match(T__26);
						setState(240);
						expr(5);
						}
						break;
					case 4:
						{
						_localctx = new ExprContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(241);
						if (!(precpred(_ctx, 3))) throw new FailedPredicateException(this, "precpred(_ctx, 3)");
						setState(242);
						match(T__27);
						setState(243);
						expr(4);
						}
						break;
					}
					} 
				}
				setState(248);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,11,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class ScalarContext extends ParserRuleContext {
		public TerminalNode INT() { return getToken(FigureDSLParser.INT, 0); }
		public TerminalNode FLOAT() { return getToken(FigureDSLParser.FLOAT, 0); }
		public List<ScalarContext> scalar() {
			return getRuleContexts(ScalarContext.class);
		}
		public ScalarContext scalar(int i) {
			return getRuleContext(ScalarContext.class,i);
		}
		public ScalarContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_scalar; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterScalar(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitScalar(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitScalar(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ScalarContext scalar() throws RecognitionException {
		return scalar(0);
	}

	private ScalarContext scalar(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ScalarContext _localctx = new ScalarContext(_ctx, _parentState);
		ScalarContext _prevctx = _localctx;
		int _startState = 48;
		enterRecursionRule(_localctx, 48, RULE_scalar, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(258);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INT:
				{
				setState(250);
				match(INT);
				}
				break;
			case FLOAT:
				{
				setState(251);
				match(FLOAT);
				}
				break;
			case T__27:
				{
				setState(252);
				match(T__27);
				setState(253);
				scalar(2);
				}
				break;
			case T__8:
				{
				setState(254);
				match(T__8);
				setState(255);
				scalar(0);
				setState(256);
				match(T__9);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			_ctx.stop = _input.LT(-1);
			setState(274);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,14,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(272);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,13,_ctx) ) {
					case 1:
						{
						_localctx = new ScalarContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_scalar);
						setState(260);
						if (!(precpred(_ctx, 6))) throw new FailedPredicateException(this, "precpred(_ctx, 6)");
						setState(261);
						match(T__24);
						setState(262);
						scalar(7);
						}
						break;
					case 2:
						{
						_localctx = new ScalarContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_scalar);
						setState(263);
						if (!(precpred(_ctx, 5))) throw new FailedPredicateException(this, "precpred(_ctx, 5)");
						setState(264);
						match(T__25);
						setState(265);
						scalar(6);
						}
						break;
					case 3:
						{
						_localctx = new ScalarContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_scalar);
						setState(266);
						if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
						setState(267);
						match(T__26);
						setState(268);
						scalar(5);
						}
						break;
					case 4:
						{
						_localctx = new ScalarContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_scalar);
						setState(269);
						if (!(precpred(_ctx, 3))) throw new FailedPredicateException(this, "precpred(_ctx, 3)");
						setState(270);
						match(T__27);
						setState(271);
						scalar(4);
						}
						break;
					}
					} 
				}
				setState(276);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,14,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class NumberContext extends ParserRuleContext {
		public TerminalNode INT() { return getToken(FigureDSLParser.INT, 0); }
		public TerminalNode FLOAT() { return getToken(FigureDSLParser.FLOAT, 0); }
		public NumberContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_number; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).enterNumber(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof FigureDSLListener ) ((FigureDSLListener)listener).exitNumber(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FigureDSLVisitor ) return ((FigureDSLVisitor<? extends T>)visitor).visitNumber(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NumberContext number() throws RecognitionException {
		NumberContext _localctx = new NumberContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_number);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(277);
			_la = _input.LA(1);
			if ( !(_la==INT || _la==FLOAT) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 23:
			return expr_sempred((ExprContext)_localctx, predIndex);
		case 24:
			return scalar_sempred((ScalarContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean expr_sempred(ExprContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 6);
		case 1:
			return precpred(_ctx, 5);
		case 2:
			return precpred(_ctx, 4);
		case 3:
			return precpred(_ctx, 3);
		}
		return true;
	}
	private boolean scalar_sempred(ScalarContext _localctx, int predIndex) {
		switch (predIndex) {
		case 4:
			return precpred(_ctx, 6);
		case 5:
			return precpred(_ctx, 5);
		case 6:
			return precpred(_ctx, 4);
		case 7:
			return precpred(_ctx, 3);
		}
		return true;
	}

	public static final String _serializedATN =
		"\u0004\u0001#\u0118\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007\u0002"+
		"\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b\u0002"+
		"\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e\u0002\u000f\u0007\u000f"+
		"\u0002\u0010\u0007\u0010\u0002\u0011\u0007\u0011\u0002\u0012\u0007\u0012"+
		"\u0002\u0013\u0007\u0013\u0002\u0014\u0007\u0014\u0002\u0015\u0007\u0015"+
		"\u0002\u0016\u0007\u0016\u0002\u0017\u0007\u0017\u0002\u0018\u0007\u0018"+
		"\u0002\u0019\u0007\u0019\u0001\u0000\u0001\u0000\u0005\u00007\b\u0000"+
		"\n\u0000\f\u0000:\t\u0000\u0001\u0000\u0005\u0000=\b\u0000\n\u0000\f\u0000"+
		"@\t\u0000\u0001\u0000\u0001\u0000\u0001\u0001\u0001\u0001\u0001\u0001"+
		"\u0001\u0001\u0001\u0001\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002"+
		"\u0001\u0002\u0003\u0002N\b\u0002\u0001\u0003\u0001\u0003\u0001\u0003"+
		"\u0001\u0003\u0001\u0004\u0001\u0004\u0001\u0004\u0001\u0004\u0001\u0004"+
		"\u0001\u0004\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005"+
		"\u0001\u0005\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006"+
		"\u0001\u0006\u0001\u0007\u0001\u0007\u0001\u0007\u0001\u0007\u0001\u0007"+
		"\u0001\u0007\u0001\u0007\u0001\b\u0001\b\u0001\b\u0001\b\u0001\b\u0003"+
		"\br\b\b\u0001\t\u0001\t\u0001\t\u0001\t\u0001\n\u0001\n\u0001\n\u0001"+
		"\n\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0001\f\u0001\f\u0005"+
		"\f\u0082\b\f\n\f\f\f\u0085\t\f\u0001\r\u0001\r\u0004\r\u0089\b\r\u000b"+
		"\r\f\r\u008a\u0001\r\u0001\r\u0001\u000e\u0001\u000e\u0001\u000e\u0001"+
		"\u000e\u0001\u000e\u0001\u000e\u0001\u000f\u0001\u000f\u0001\u000f\u0001"+
		"\u000f\u0001\u000f\u0003\u000f\u009a\b\u000f\u0001\u0010\u0001\u0010\u0001"+
		"\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001"+
		"\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0001\u0012\u0001"+
		"\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001"+
		"\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0013\u0001"+
		"\u0013\u0001\u0013\u0001\u0013\u0001\u0013\u0001\u0013\u0001\u0013\u0001"+
		"\u0013\u0001\u0013\u0001\u0013\u0001\u0014\u0001\u0014\u0001\u0014\u0001"+
		"\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001"+
		"\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0015\u0001"+
		"\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001"+
		"\u0015\u0001\u0016\u0001\u0016\u0001\u0016\u0005\u0016\u00d8\b\u0016\n"+
		"\u0016\f\u0016\u00db\t\u0016\u0001\u0017\u0001\u0017\u0001\u0017\u0001"+
		"\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001"+
		"\u0017\u0003\u0017\u00e7\b\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001"+
		"\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001"+
		"\u0017\u0001\u0017\u0001\u0017\u0005\u0017\u00f5\b\u0017\n\u0017\f\u0017"+
		"\u00f8\t\u0017\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018"+
		"\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0003\u0018\u0103\b\u0018"+
		"\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018"+
		"\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018"+
		"\u0005\u0018\u0111\b\u0018\n\u0018\f\u0018\u0114\t\u0018\u0001\u0019\u0001"+
		"\u0019\u0001\u0019\u0000\u0002.0\u001a\u0000\u0002\u0004\u0006\b\n\f\u000e"+
		"\u0010\u0012\u0014\u0016\u0018\u001a\u001c\u001e \"$&(*,.02\u0000\u0001"+
		"\u0001\u0000 !\u011e\u00004\u0001\u0000\u0000\u0000\u0002C\u0001\u0000"+
		"\u0000\u0000\u0004M\u0001\u0000\u0000\u0000\u0006O\u0001\u0000\u0000\u0000"+
		"\bS\u0001\u0000\u0000\u0000\nY\u0001\u0000\u0000\u0000\f_\u0001\u0000"+
		"\u0000\u0000\u000ee\u0001\u0000\u0000\u0000\u0010q\u0001\u0000\u0000\u0000"+
		"\u0012s\u0001\u0000\u0000\u0000\u0014w\u0001\u0000\u0000\u0000\u0016{"+
		"\u0001\u0000\u0000\u0000\u0018\u0083\u0001\u0000\u0000\u0000\u001a\u0086"+
		"\u0001\u0000\u0000\u0000\u001c\u008e\u0001\u0000\u0000\u0000\u001e\u0099"+
		"\u0001\u0000\u0000\u0000 \u009b\u0001\u0000\u0000\u0000\"\u00a3\u0001"+
		"\u0000\u0000\u0000$\u00a8\u0001\u0000\u0000\u0000&\u00b4\u0001\u0000\u0000"+
		"\u0000(\u00be\u0001\u0000\u0000\u0000*\u00cc\u0001\u0000\u0000\u0000,"+
		"\u00d4\u0001\u0000\u0000\u0000.\u00e6\u0001\u0000\u0000\u00000\u0102\u0001"+
		"\u0000\u0000\u00002\u0115\u0001\u0000\u0000\u000048\u0003\u0002\u0001"+
		"\u000057\u0003\u0004\u0002\u000065\u0001\u0000\u0000\u00007:\u0001\u0000"+
		"\u0000\u000086\u0001\u0000\u0000\u000089\u0001\u0000\u0000\u00009>\u0001"+
		"\u0000\u0000\u0000:8\u0001\u0000\u0000\u0000;=\u0003\u0010\b\u0000<;\u0001"+
		"\u0000\u0000\u0000=@\u0001\u0000\u0000\u0000><\u0001\u0000\u0000\u0000"+
		">?\u0001\u0000\u0000\u0000?A\u0001\u0000\u0000\u0000@>\u0001\u0000\u0000"+
		"\u0000AB\u0005\u0000\u0000\u0001B\u0001\u0001\u0000\u0000\u0000CD\u0005"+
		"\u0001\u0000\u0000DE\u0005\u0002\u0000\u0000EF\u0005\u001e\u0000\u0000"+
		"FG\u0005\u0003\u0000\u0000G\u0003\u0001\u0000\u0000\u0000HN\u0003\u0006"+
		"\u0003\u0000IN\u0003\b\u0004\u0000JN\u0003\n\u0005\u0000KN\u0003\f\u0006"+
		"\u0000LN\u0003\u000e\u0007\u0000MH\u0001\u0000\u0000\u0000MI\u0001\u0000"+
		"\u0000\u0000MJ\u0001\u0000\u0000\u0000MK\u0001\u0000\u0000\u0000ML\u0001"+
		"\u0000\u0000\u0000N\u0005\u0001\u0000\u0000\u0000OP\u0005\u0004\u0000"+
		"\u0000PQ\u0005\u001f\u0000\u0000QR\u0005\u0003\u0000\u0000R\u0007\u0001"+
		"\u0000\u0000\u0000ST\u0005\u0005\u0000\u0000TU\u0005\u001f\u0000\u0000"+
		"UV\u0005\u0006\u0000\u0000VW\u0003*\u0015\u0000WX\u0005\u0003\u0000\u0000"+
		"X\t\u0001\u0000\u0000\u0000YZ\u0005\u0007\u0000\u0000Z[\u0005\u001f\u0000"+
		"\u0000[\\\u0005\u0006\u0000\u0000\\]\u0003.\u0017\u0000]^\u0005\u0003"+
		"\u0000\u0000^\u000b\u0001\u0000\u0000\u0000_`\u0005\b\u0000\u0000`a\u0005"+
		"\u001f\u0000\u0000ab\u0005\u0006\u0000\u0000bc\u00032\u0019\u0000cd\u0005"+
		"\u0003\u0000\u0000d\r\u0001\u0000\u0000\u0000ef\u0005\u001f\u0000\u0000"+
		"fg\u0005\u001f\u0000\u0000gh\u0005\t\u0000\u0000hi\u0003,\u0016\u0000"+
		"ij\u0005\n\u0000\u0000jk\u0005\u0003\u0000\u0000k\u000f\u0001\u0000\u0000"+
		"\u0000lr\u0003\u0012\t\u0000mr\u0003\u0014\n\u0000nr\u0003\u0016\u000b"+
		"\u0000or\u0003\u001c\u000e\u0000pr\u0003\u001e\u000f\u0000ql\u0001\u0000"+
		"\u0000\u0000qm\u0001\u0000\u0000\u0000qn\u0001\u0000\u0000\u0000qo\u0001"+
		"\u0000\u0000\u0000qp\u0001\u0000\u0000\u0000r\u0011\u0001\u0000\u0000"+
		"\u0000st\u0005\u000b\u0000\u0000tu\u0003\u0018\f\u0000uv\u0005\f\u0000"+
		"\u0000v\u0013\u0001\u0000\u0000\u0000wx\u0005\r\u0000\u0000xy\u0003\u0018"+
		"\f\u0000yz\u0005\u000e\u0000\u0000z\u0015\u0001\u0000\u0000\u0000{|\u0005"+
		"\u000f\u0000\u0000|}\u0003\u0018\f\u0000}~\u0005\u0010\u0000\u0000~\u0017"+
		"\u0001\u0000\u0000\u0000\u007f\u0082\u0003\u001e\u000f\u0000\u0080\u0082"+
		"\u0003\u001a\r\u0000\u0081\u007f\u0001\u0000\u0000\u0000\u0081\u0080\u0001"+
		"\u0000\u0000\u0000\u0082\u0085\u0001\u0000\u0000\u0000\u0083\u0081\u0001"+
		"\u0000\u0000\u0000\u0083\u0084\u0001\u0000\u0000\u0000\u0084\u0019\u0001"+
		"\u0000\u0000\u0000\u0085\u0083\u0001\u0000\u0000\u0000\u0086\u0088\u0005"+
		"\u000f\u0000\u0000\u0087\u0089\u0003\u001e\u000f\u0000\u0088\u0087\u0001"+
		"\u0000\u0000\u0000\u0089\u008a\u0001\u0000\u0000\u0000\u008a\u0088\u0001"+
		"\u0000\u0000\u0000\u008a\u008b\u0001\u0000\u0000\u0000\u008b\u008c\u0001"+
		"\u0000\u0000\u0000\u008c\u008d\u0005\u0010\u0000\u0000\u008d\u001b\u0001"+
		"\u0000\u0000\u0000\u008e\u008f\u0005\u0011\u0000\u0000\u008f\u0090\u0005"+
		"\t\u0000\u0000\u0090\u0091\u00032\u0019\u0000\u0091\u0092\u0005\n\u0000"+
		"\u0000\u0092\u0093\u0005\u0003\u0000\u0000\u0093\u001d\u0001\u0000\u0000"+
		"\u0000\u0094\u009a\u0003 \u0010\u0000\u0095\u009a\u0003\"\u0011\u0000"+
		"\u0096\u009a\u0003$\u0012\u0000\u0097\u009a\u0003&\u0013\u0000\u0098\u009a"+
		"\u0003(\u0014\u0000\u0099\u0094\u0001\u0000\u0000\u0000\u0099\u0095\u0001"+
		"\u0000\u0000\u0000\u0099\u0096\u0001\u0000\u0000\u0000\u0099\u0097\u0001"+
		"\u0000\u0000\u0000\u0099\u0098\u0001\u0000\u0000\u0000\u009a\u001f\u0001"+
		"\u0000\u0000\u0000\u009b\u009c\u0005\u001f\u0000\u0000\u009c\u009d\u0005"+
		"\u0012\u0000\u0000\u009d\u009e\u0005\u0013\u0000\u0000\u009e\u009f\u0005"+
		"\t\u0000\u0000\u009f\u00a0\u0005\u001d\u0000\u0000\u00a0\u00a1\u0005\n"+
		"\u0000\u0000\u00a1\u00a2\u0005\u0003\u0000\u0000\u00a2!\u0001\u0000\u0000"+
		"\u0000\u00a3\u00a4\u0005\u001f\u0000\u0000\u00a4\u00a5\u0005\u0012\u0000"+
		"\u0000\u00a5\u00a6\u0005\u0014\u0000\u0000\u00a6\u00a7\u0005\u0003\u0000"+
		"\u0000\u00a7#\u0001\u0000\u0000\u0000\u00a8\u00a9\u0005\u001f\u0000\u0000"+
		"\u00a9\u00aa\u0005\u0012\u0000\u0000\u00aa\u00ab\u0005\u0015\u0000\u0000"+
		"\u00ab\u00ac\u0005\t\u0000\u0000\u00ac\u00ad\u0003*\u0015\u0000\u00ad"+
		"\u00ae\u0005\u0016\u0000\u0000\u00ae\u00af\u00032\u0019\u0000\u00af\u00b0"+
		"\u0005\u0016\u0000\u0000\u00b0\u00b1\u0005\u001f\u0000\u0000\u00b1\u00b2"+
		"\u0005\n\u0000\u0000\u00b2\u00b3\u0005\u0003\u0000\u0000\u00b3%\u0001"+
		"\u0000\u0000\u0000\u00b4\u00b5\u0005\u001f\u0000\u0000\u00b5\u00b6\u0005"+
		"\u0012\u0000\u0000\u00b6\u00b7\u0005\u0017\u0000\u0000\u00b7\u00b8\u0005"+
		"\t\u0000\u0000\u00b8\u00b9\u0005\u001f\u0000\u0000\u00b9\u00ba\u0005\u0016"+
		"\u0000\u0000\u00ba\u00bb\u0005\u001f\u0000\u0000\u00bb\u00bc\u0005\n\u0000"+
		"\u0000\u00bc\u00bd\u0005\u0003\u0000\u0000\u00bd\'\u0001\u0000\u0000\u0000"+
		"\u00be\u00bf\u0005\u001f\u0000\u0000\u00bf\u00c0\u0005\u0012\u0000\u0000"+
		"\u00c0\u00c1\u0005\u0018\u0000\u0000\u00c1\u00c2\u0005\t\u0000\u0000\u00c2"+
		"\u00c3\u0005\u001f\u0000\u0000\u00c3\u00c4\u0005\u0016\u0000\u0000\u00c4"+
		"\u00c5\u0005\u001f\u0000\u0000\u00c5\u00c6\u0005\u0016\u0000\u0000\u00c6"+
		"\u00c7\u0003.\u0017\u0000\u00c7\u00c8\u0005\u0016\u0000\u0000\u00c8\u00c9"+
		"\u0005\u001f\u0000\u0000\u00c9\u00ca\u0005\n\u0000\u0000\u00ca\u00cb\u0005"+
		"\u0003\u0000\u0000\u00cb)\u0001\u0000\u0000\u0000\u00cc\u00cd\u0005\t"+
		"\u0000\u0000\u00cd\u00ce\u00030\u0018\u0000\u00ce\u00cf\u0005\u0016\u0000"+
		"\u0000\u00cf\u00d0\u00030\u0018\u0000\u00d0\u00d1\u0005\u0016\u0000\u0000"+
		"\u00d1\u00d2\u00030\u0018\u0000\u00d2\u00d3\u0005\n\u0000\u0000\u00d3"+
		"+\u0001\u0000\u0000\u0000\u00d4\u00d9\u0003.\u0017\u0000\u00d5\u00d6\u0005"+
		"\u0016\u0000\u0000\u00d6\u00d8\u0003.\u0017\u0000\u00d7\u00d5\u0001\u0000"+
		"\u0000\u0000\u00d8\u00db\u0001\u0000\u0000\u0000\u00d9\u00d7\u0001\u0000"+
		"\u0000\u0000\u00d9\u00da\u0001\u0000\u0000\u0000\u00da-\u0001\u0000\u0000"+
		"\u0000\u00db\u00d9\u0001\u0000\u0000\u0000\u00dc\u00dd\u0006\u0017\uffff"+
		"\uffff\u0000\u00dd\u00e7\u0005 \u0000\u0000\u00de\u00e7\u0005!\u0000\u0000"+
		"\u00df\u00e7\u0005\u001f\u0000\u0000\u00e0\u00e1\u0005\u001c\u0000\u0000"+
		"\u00e1\u00e7\u0003.\u0017\u0002\u00e2\u00e3\u0005\t\u0000\u0000\u00e3"+
		"\u00e4\u0003.\u0017\u0000\u00e4\u00e5\u0005\n\u0000\u0000\u00e5\u00e7"+
		"\u0001\u0000\u0000\u0000\u00e6\u00dc\u0001\u0000\u0000\u0000\u00e6\u00de"+
		"\u0001\u0000\u0000\u0000\u00e6\u00df\u0001\u0000\u0000\u0000\u00e6\u00e0"+
		"\u0001\u0000\u0000\u0000\u00e6\u00e2\u0001\u0000\u0000\u0000\u00e7\u00f6"+
		"\u0001\u0000\u0000\u0000\u00e8\u00e9\n\u0006\u0000\u0000\u00e9\u00ea\u0005"+
		"\u0019\u0000\u0000\u00ea\u00f5\u0003.\u0017\u0007\u00eb\u00ec\n\u0005"+
		"\u0000\u0000\u00ec\u00ed\u0005\u001a\u0000\u0000\u00ed\u00f5\u0003.\u0017"+
		"\u0006\u00ee\u00ef\n\u0004\u0000\u0000\u00ef\u00f0\u0005\u001b\u0000\u0000"+
		"\u00f0\u00f5\u0003.\u0017\u0005\u00f1\u00f2\n\u0003\u0000\u0000\u00f2"+
		"\u00f3\u0005\u001c\u0000\u0000\u00f3\u00f5\u0003.\u0017\u0004\u00f4\u00e8"+
		"\u0001\u0000\u0000\u0000\u00f4\u00eb\u0001\u0000\u0000\u0000\u00f4\u00ee"+
		"\u0001\u0000\u0000\u0000\u00f4\u00f1\u0001\u0000\u0000\u0000\u00f5\u00f8"+
		"\u0001\u0000\u0000\u0000\u00f6\u00f4\u0001\u0000\u0000\u0000\u00f6\u00f7"+
		"\u0001\u0000\u0000\u0000\u00f7/\u0001\u0000\u0000\u0000\u00f8\u00f6\u0001"+
		"\u0000\u0000\u0000\u00f9\u00fa\u0006\u0018\uffff\uffff\u0000\u00fa\u0103"+
		"\u0005 \u0000\u0000\u00fb\u0103\u0005!\u0000\u0000\u00fc\u00fd\u0005\u001c"+
		"\u0000\u0000\u00fd\u0103\u00030\u0018\u0002\u00fe\u00ff\u0005\t\u0000"+
		"\u0000\u00ff\u0100\u00030\u0018\u0000\u0100\u0101\u0005\n\u0000\u0000"+
		"\u0101\u0103\u0001\u0000\u0000\u0000\u0102\u00f9\u0001\u0000\u0000\u0000"+
		"\u0102\u00fb\u0001\u0000\u0000\u0000\u0102\u00fc\u0001\u0000\u0000\u0000"+
		"\u0102\u00fe\u0001\u0000\u0000\u0000\u0103\u0112\u0001\u0000\u0000\u0000"+
		"\u0104\u0105\n\u0006\u0000\u0000\u0105\u0106\u0005\u0019\u0000\u0000\u0106"+
		"\u0111\u00030\u0018\u0007\u0107\u0108\n\u0005\u0000\u0000\u0108\u0109"+
		"\u0005\u001a\u0000\u0000\u0109\u0111\u00030\u0018\u0006\u010a\u010b\n"+
		"\u0004\u0000\u0000\u010b\u010c\u0005\u001b\u0000\u0000\u010c\u0111\u0003"+
		"0\u0018\u0005\u010d\u010e\n\u0003\u0000\u0000\u010e\u010f\u0005\u001c"+
		"\u0000\u0000\u010f\u0111\u00030\u0018\u0004\u0110\u0104\u0001\u0000\u0000"+
		"\u0000\u0110\u0107\u0001\u0000\u0000\u0000\u0110\u010a\u0001\u0000\u0000"+
		"\u0000\u0110\u010d\u0001\u0000\u0000\u0000\u0111\u0114\u0001\u0000\u0000"+
		"\u0000\u0112\u0110\u0001\u0000\u0000\u0000\u0112\u0113\u0001\u0000\u0000"+
		"\u0000\u01131\u0001\u0000\u0000\u0000\u0114\u0112\u0001\u0000\u0000\u0000"+
		"\u0115\u0116\u0007\u0000\u0000\u0000\u01163\u0001\u0000\u0000\u0000\u000f"+
		"8>Mq\u0081\u0083\u008a\u0099\u00d9\u00e6\u00f4\u00f6\u0102\u0110\u0112";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}