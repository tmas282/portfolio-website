package integrations.plugins.figure.alternate;

import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Component
public class FigureDSLImporter {

    public List<FigureInstructionDTO> importFrom(InputStream input) throws IOException {
        CharStream charStream = CharStreams.fromStream(input);
        FigureDSLLexer lexer = new FigureDSLLexer(charStream);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        FigureDSLParser parser = new FigureDSLParser(tokens);

        parser.removeErrorListeners();
        ErrorCollector listener = new ErrorCollector();
        parser.addErrorListener(listener);

        ParseTree tree = parser.program();

        if (listener.hasErrors()) {
            throw new IllegalArgumentException("Syntax errors:\n" + listener.getFormattedErrors());
        }

        FigureProgramListener figureListener = new FigureProgramListener();
        ParseTreeWalker.DEFAULT.walk(figureListener, tree);

        return figureListener.instructions();
    }

    private static class ErrorCollector extends BaseErrorListener {
        private final StringBuilder errors = new StringBuilder();

        @Override
        public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol,
                                int line, int charPositionInLine, String msg, RecognitionException e) {
            errors.append("line ").append(line).append(":").append(charPositionInLine)
                    .append(" ").append(msg).append("\n");
        }

        boolean hasErrors() {
            return errors.length() > 0;
        }

        String getFormattedErrors() {
            return errors.toString();
        }
    }
}