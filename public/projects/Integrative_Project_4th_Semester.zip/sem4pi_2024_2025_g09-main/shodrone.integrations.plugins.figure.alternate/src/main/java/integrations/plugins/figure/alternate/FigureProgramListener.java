package integrations.plugins.figure.alternate;

import org.antlr.v4.runtime.tree.ParseTreeListener;
import java.util.ArrayList;
import java.util.List;

public class FigureProgramListener extends FigureDSLBaseListener implements ParseTreeListener {

    private final List<FigureInstructionDTO> instructions = new ArrayList<>();
    private FigureInstructionDTO current;

    @Override
    public void enterSingleInstruction(FigureDSLParser.SingleInstructionContext ctx) {
        current = new FigureInstructionDTO();

        // Exemplo: lightsOnInstr, moveInstr, etc.
        if (ctx.lightsOnInstr() != null) {
            current.setCommand("lightsOn");
            List<String> args = new ArrayList<>();
            args.add(ctx.lightsOnInstr().ID().getText());
            args.add(ctx.lightsOnInstr().COLOR().getText());
            current.setArguments(args);
        } else if (ctx.lightsOffInstr() != null) {
            current.setCommand("lightsOff");
            List<String> args = new ArrayList<>();
            args.add(ctx.lightsOffInstr().ID().getText());
            current.setArguments(args);
        } else if (ctx.moveInstr() != null) {
            current.setCommand("move");
            List<String> args = new ArrayList<>();
            args.add(ctx.moveInstr().ID(0).getText());
            args.add(ctx.moveInstr().vector3().getText());
            args.add(ctx.moveInstr().number().getText());
            args.add(ctx.moveInstr().ID(1).getText());
            current.setArguments(args);
        }
        // Adiciona outros tipos conforme necessário...
    }

    @Override
    public void exitSingleInstruction(FigureDSLParser.SingleInstructionContext ctx) {
        if (current != null) {
            instructions.add(current);
        }
    }

    public List<FigureInstructionDTO> instructions() {
        return instructions;
    }
}