// Generated from FigureDSL.g4 by ANTLR 4.10.1
package integrations.plugins.figure.alternate;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link FigureDSLParser}.
 */
public interface FigureDSLListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(FigureDSLParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(FigureDSLParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#header}.
	 * @param ctx the parse tree
	 */
	void enterHeader(FigureDSLParser.HeaderContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#header}.
	 * @param ctx the parse tree
	 */
	void exitHeader(FigureDSLParser.HeaderContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#declaration}.
	 * @param ctx the parse tree
	 */
	void enterDeclaration(FigureDSLParser.DeclarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#declaration}.
	 * @param ctx the parse tree
	 */
	void exitDeclaration(FigureDSLParser.DeclarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#droneTypeDecl}.
	 * @param ctx the parse tree
	 */
	void enterDroneTypeDecl(FigureDSLParser.DroneTypeDeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#droneTypeDecl}.
	 * @param ctx the parse tree
	 */
	void exitDroneTypeDecl(FigureDSLParser.DroneTypeDeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#positionDecl}.
	 * @param ctx the parse tree
	 */
	void enterPositionDecl(FigureDSLParser.PositionDeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#positionDecl}.
	 * @param ctx the parse tree
	 */
	void exitPositionDecl(FigureDSLParser.PositionDeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#velocityDecl}.
	 * @param ctx the parse tree
	 */
	void enterVelocityDecl(FigureDSLParser.VelocityDeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#velocityDecl}.
	 * @param ctx the parse tree
	 */
	void exitVelocityDecl(FigureDSLParser.VelocityDeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#distanceDecl}.
	 * @param ctx the parse tree
	 */
	void enterDistanceDecl(FigureDSLParser.DistanceDeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#distanceDecl}.
	 * @param ctx the parse tree
	 */
	void exitDistanceDecl(FigureDSLParser.DistanceDeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#shapeInitDecl}.
	 * @param ctx the parse tree
	 */
	void enterShapeInitDecl(FigureDSLParser.ShapeInitDeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#shapeInitDecl}.
	 * @param ctx the parse tree
	 */
	void exitShapeInitDecl(FigureDSLParser.ShapeInitDeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#instructionBlock}.
	 * @param ctx the parse tree
	 */
	void enterInstructionBlock(FigureDSLParser.InstructionBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#instructionBlock}.
	 * @param ctx the parse tree
	 */
	void exitInstructionBlock(FigureDSLParser.InstructionBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#beforeBlock}.
	 * @param ctx the parse tree
	 */
	void enterBeforeBlock(FigureDSLParser.BeforeBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#beforeBlock}.
	 * @param ctx the parse tree
	 */
	void exitBeforeBlock(FigureDSLParser.BeforeBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#afterBlock}.
	 * @param ctx the parse tree
	 */
	void enterAfterBlock(FigureDSLParser.AfterBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#afterBlock}.
	 * @param ctx the parse tree
	 */
	void exitAfterBlock(FigureDSLParser.AfterBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#groupBlock}.
	 * @param ctx the parse tree
	 */
	void enterGroupBlock(FigureDSLParser.GroupBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#groupBlock}.
	 * @param ctx the parse tree
	 */
	void exitGroupBlock(FigureDSLParser.GroupBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#instructionBlockContent}.
	 * @param ctx the parse tree
	 */
	void enterInstructionBlockContent(FigureDSLParser.InstructionBlockContentContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#instructionBlockContent}.
	 * @param ctx the parse tree
	 */
	void exitInstructionBlockContent(FigureDSLParser.InstructionBlockContentContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#nestedGroup}.
	 * @param ctx the parse tree
	 */
	void enterNestedGroup(FigureDSLParser.NestedGroupContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#nestedGroup}.
	 * @param ctx the parse tree
	 */
	void exitNestedGroup(FigureDSLParser.NestedGroupContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#pauseInstr}.
	 * @param ctx the parse tree
	 */
	void enterPauseInstr(FigureDSLParser.PauseInstrContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#pauseInstr}.
	 * @param ctx the parse tree
	 */
	void exitPauseInstr(FigureDSLParser.PauseInstrContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#singleInstruction}.
	 * @param ctx the parse tree
	 */
	void enterSingleInstruction(FigureDSLParser.SingleInstructionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#singleInstruction}.
	 * @param ctx the parse tree
	 */
	void exitSingleInstruction(FigureDSLParser.SingleInstructionContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#lightsOnInstr}.
	 * @param ctx the parse tree
	 */
	void enterLightsOnInstr(FigureDSLParser.LightsOnInstrContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#lightsOnInstr}.
	 * @param ctx the parse tree
	 */
	void exitLightsOnInstr(FigureDSLParser.LightsOnInstrContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#lightsOffInstr}.
	 * @param ctx the parse tree
	 */
	void enterLightsOffInstr(FigureDSLParser.LightsOffInstrContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#lightsOffInstr}.
	 * @param ctx the parse tree
	 */
	void exitLightsOffInstr(FigureDSLParser.LightsOffInstrContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#moveInstr}.
	 * @param ctx the parse tree
	 */
	void enterMoveInstr(FigureDSLParser.MoveInstrContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#moveInstr}.
	 * @param ctx the parse tree
	 */
	void exitMoveInstr(FigureDSLParser.MoveInstrContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#movePosInstr}.
	 * @param ctx the parse tree
	 */
	void enterMovePosInstr(FigureDSLParser.MovePosInstrContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#movePosInstr}.
	 * @param ctx the parse tree
	 */
	void exitMovePosInstr(FigureDSLParser.MovePosInstrContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#rotateInstr}.
	 * @param ctx the parse tree
	 */
	void enterRotateInstr(FigureDSLParser.RotateInstrContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#rotateInstr}.
	 * @param ctx the parse tree
	 */
	void exitRotateInstr(FigureDSLParser.RotateInstrContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#vector3}.
	 * @param ctx the parse tree
	 */
	void enterVector3(FigureDSLParser.Vector3Context ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#vector3}.
	 * @param ctx the parse tree
	 */
	void exitVector3(FigureDSLParser.Vector3Context ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#exprList}.
	 * @param ctx the parse tree
	 */
	void enterExprList(FigureDSLParser.ExprListContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#exprList}.
	 * @param ctx the parse tree
	 */
	void exitExprList(FigureDSLParser.ExprListContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr(FigureDSLParser.ExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr(FigureDSLParser.ExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#scalar}.
	 * @param ctx the parse tree
	 */
	void enterScalar(FigureDSLParser.ScalarContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#scalar}.
	 * @param ctx the parse tree
	 */
	void exitScalar(FigureDSLParser.ScalarContext ctx);
	/**
	 * Enter a parse tree produced by {@link FigureDSLParser#number}.
	 * @param ctx the parse tree
	 */
	void enterNumber(FigureDSLParser.NumberContext ctx);
	/**
	 * Exit a parse tree produced by {@link FigureDSLParser#number}.
	 * @param ctx the parse tree
	 */
	void exitNumber(FigureDSLParser.NumberContext ctx);
}