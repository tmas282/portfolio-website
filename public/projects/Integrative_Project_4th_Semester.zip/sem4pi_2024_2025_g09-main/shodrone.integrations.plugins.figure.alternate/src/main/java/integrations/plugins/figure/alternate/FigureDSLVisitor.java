// Generated from FigureDSL.g4 by ANTLR 4.10.1
package integrations.plugins.figure.alternate;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link FigureDSLParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface FigureDSLVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#program}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram(FigureDSLParser.ProgramContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#header}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHeader(FigureDSLParser.HeaderContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDeclaration(FigureDSLParser.DeclarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#droneTypeDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDroneTypeDecl(FigureDSLParser.DroneTypeDeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#positionDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPositionDecl(FigureDSLParser.PositionDeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#velocityDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVelocityDecl(FigureDSLParser.VelocityDeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#distanceDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDistanceDecl(FigureDSLParser.DistanceDeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#shapeInitDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitShapeInitDecl(FigureDSLParser.ShapeInitDeclContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#instructionBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInstructionBlock(FigureDSLParser.InstructionBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#beforeBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBeforeBlock(FigureDSLParser.BeforeBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#afterBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAfterBlock(FigureDSLParser.AfterBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#groupBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGroupBlock(FigureDSLParser.GroupBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#instructionBlockContent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInstructionBlockContent(FigureDSLParser.InstructionBlockContentContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#nestedGroup}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNestedGroup(FigureDSLParser.NestedGroupContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#pauseInstr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPauseInstr(FigureDSLParser.PauseInstrContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#singleInstruction}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSingleInstruction(FigureDSLParser.SingleInstructionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#lightsOnInstr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLightsOnInstr(FigureDSLParser.LightsOnInstrContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#lightsOffInstr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLightsOffInstr(FigureDSLParser.LightsOffInstrContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#moveInstr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMoveInstr(FigureDSLParser.MoveInstrContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#movePosInstr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMovePosInstr(FigureDSLParser.MovePosInstrContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#rotateInstr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRotateInstr(FigureDSLParser.RotateInstrContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#vector3}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVector3(FigureDSLParser.Vector3Context ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#exprList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprList(FigureDSLParser.ExprListContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpr(FigureDSLParser.ExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#scalar}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitScalar(FigureDSLParser.ScalarContext ctx);
	/**
	 * Visit a parse tree produced by {@link FigureDSLParser#number}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumber(FigureDSLParser.NumberContext ctx);
}