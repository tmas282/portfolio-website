package integrations.plugins.figure.alternate;

import java.util.List;

public class FigureInstructionDTO {
    private String command;
    private List<String> arguments;

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public List<String> getArguments() {
        return arguments;
    }

    public void setArguments(List<String> arguments) {
        this.arguments = arguments;
    }

    @Override
    public String toString() {
        return command + arguments;
    }
}