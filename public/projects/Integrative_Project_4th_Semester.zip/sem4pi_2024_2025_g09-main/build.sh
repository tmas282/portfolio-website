echo Cleaning .target/ folder
mvn clean
echo Building with maven...
mvn compile