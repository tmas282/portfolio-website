package shodrone.figurecategorymanagement;

import jakarta.persistence.Embeddable;
import java.time.LocalDate;

@Embeddable
public class CreationDate {

    private LocalDate date;

    protected CreationDate() {}

    private CreationDate(LocalDate date) {
        this.date = date;
    }

    public static CreationDate now() {
        return new CreationDate(LocalDate.now());
    }

    public LocalDate value() {
        return date;
    }

    @Override
    public String toString() {
        return date.toString();
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof CreationDate && date.equals(((CreationDate) o).date);
    }

    @Override
    public int hashCode() {
        return date.hashCode();
    }
}
