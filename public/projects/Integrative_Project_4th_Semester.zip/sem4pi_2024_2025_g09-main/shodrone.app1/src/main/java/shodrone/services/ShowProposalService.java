package shodrone.services;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import shodrone.customermanagement.Customer;
import shodrone.customermanagement.CustomerType;
import shodrone.customerrepresentativemanagement.CustomerRepresentative;
import shodrone.dronemanagement.Drone;
import shodrone.dronemodelmanagement.DroneModel;
import shodrone.dronemodelmanagement.DroneModelFigure;
import shodrone.dronemodelmanagement.ModelID;
import shodrone.figuremanagement.Code;
import shodrone.figuremanagement.Figure;
import shodrone.repositories.FigureRepository;
import shodrone.repositories.ShowProposalRepository;
import shodrone.repositories.ShowRequestRepository;
import shodrone.repositories.DroneRepository;
import shodrone.showproposalmanagement.*;
import shodrone.showrequestmanagement.NumberOfDrones;
import shodrone.showrequestmanagement.ShowDescription;
import shodrone.showrequestmanagement.ShowRequest;
import shodrone.showrequestmanagement.ShowRequestStatus;
import shodrone.repositories.DroneModelRepository;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;

@Service
public class ShowProposalService {

    private final ShowProposalRepository showProposalRepository;
    private final ShowRequestRepository showRequestRepository;
    private final FigureRepository figureRepository;

    private final DroneRepository droneRepository;
    private final DroneModelRepository droneModelRepository;

    @Autowired
    public ShowProposalService(
            ShowProposalRepository showProposalRepository,
            ShowRequestRepository showRequestRepository,
            FigureRepository figureRepository,
            DroneRepository droneRepository,
            DroneModelRepository droneModelRepository
    ) {
        this.showProposalRepository = showProposalRepository;
        this.showRequestRepository = showRequestRepository;
        this.figureRepository = figureRepository;
        this.droneRepository = droneRepository;
        this.droneModelRepository = droneModelRepository;
    }

    /**
     * US310 — Creates a new show proposal based on a show request.
     * The show proposal is created with the data from the show request.
     */
    @Transactional
    public ShowProposal createShowProposal(int showRequestId) {
        ShowRequest showRequest = showRequestRepository.findById(showRequestId)
                .orElseThrow(() -> new IllegalArgumentException("Show request not found with ID: " + showRequestId));

        // Create status
        ShowProposalStatus status = ShowProposalStatus.DRAFT;

        // Copy data from show request
        NumberOfDrones numberOfDrones = showRequest.getNumberOfDrones();
        ShowDescription description = showRequest.getDescription();

        // Convert date and time
        ShowProposalDate date = new ShowProposalDate(showRequest.getDatetime().getDateTime().toLocalDate());
        ShowProposalTime time = new ShowProposalTime(showRequest.getDatetime().getDateTime().toLocalTime());

        // Convert duration
        ShowProposalDuration duration = new ShowProposalDuration(java.time.Duration.ofSeconds(showRequest.getDuration().getDuration()));

        // Convert place
        ShowProposalPlace place = new ShowProposalPlace(showRequest.getPlace().getPlace());

        ShowProposal showProposal = new ShowProposal(
                showRequest,
                status,
                numberOfDrones,
                description,
                date,
                time,
                duration,
                place
        );

        // Update the status of the ShowRequest to ACCEPTED
        showRequest.getStatus().setStatus(ShowRequestStatus.ShowRequestStatusOptions.ACCEPTED);
        showRequestRepository.save(showRequest);

        return showProposalRepository.save(showProposal);
    }

    @Transactional
    public ShowProposal addFigureToProposalWithoutModel(Long proposalId, String figureCodeStr, int position) {
        if (proposalId == null || figureCodeStr == null || figureCodeStr.isBlank() || position < 0) {
            throw new IllegalArgumentException("Invalid input.");
        }

        ShowProposal proposal = showProposalRepository.findById(proposalId)
                .orElseThrow(() -> new IllegalArgumentException("Show proposal not found with ID: " + proposalId));

        long id = Long.parseLong(figureCodeStr);
        Code figureCode = new Code(id);
        Figure figure = figureRepository.findById(figureCode)
                .orElseThrow(() -> new IllegalArgumentException("Figure not found with code: " + figureCodeStr));

        if (!figure.isActive()) {
            throw new IllegalStateException("Cannot add an inactive figure to a proposal");
        }

        List<ShowProposalFigure> currentFigures = proposal.getFigures();
        currentFigures.sort(Comparator.comparingInt(ShowProposalFigure::getPosition));
        if (!currentFigures.isEmpty()) {
            ShowProposalFigure last = currentFigures.get(currentFigures.size() - 1);
            if (last.getPosition() == position - 1 && last.getFigure().equals(figure)) {
                throw new IllegalStateException("Same figure cannot appear in consecutive positions");
            }
            boolean duplicatePosition = currentFigures.stream()
                    .anyMatch(f -> f.getPosition() == position);
            if (duplicatePosition) {
                throw new IllegalStateException("There is already a figure at position " + position);
            }
        }

        ShowProposalFigure spf = new ShowProposalFigure(figure, position);
        spf.setShowProposal(proposal);
        proposal.getFigures().add(spf);

        return showProposalRepository.save(proposal);
    }

    @Transactional
    public void associateDroneModelToFigure(Long figureCode, String droneModelId) {
        if (figureCode == null || droneModelId == null || droneModelId.isBlank()) {
            throw new IllegalArgumentException("Invalid input.");
        }


        Code code = new Code(figureCode);

        Figure figure = figureRepository.findById(code)
                .orElseThrow(() -> new IllegalArgumentException("Figure not found with code: " + figureCode));

        DroneModel model = droneModelRepository.findById(new ModelID(droneModelId))
                .orElseThrow(() -> new IllegalArgumentException("Drone model not found with ID: " + droneModelId));

        figure.addCompatibleModel(model);
        figureRepository.save(figure);
    }

    @Transactional
    public ShowProposal addSimulationVideoLink(Long proposalId, String videoLink) {
        ShowProposal proposal = showProposalRepository.findById(proposalId)
                .orElseThrow(() -> new IllegalArgumentException("Show proposal not found with ID: " + proposalId));
        proposal.setSimulationVideoLink(new ShowProposalSimulationVideo(videoLink));
        return showProposalRepository.save(proposal);
    }

    @Transactional
    public int sendShowProposal(ShowProposal sp) {
        try {
            // Select template based on customer type
            Customer customer = sp.getShowRequest().getCustomer();
            String templateFileName = customer.type() == CustomerType.VIP ?
                    "Proposta_mod_03.txt" :
                    "Proposta_mod_02.txt";

            // Read the template file
            ClassLoader classLoader = getClass().getClassLoader();
            InputStream inputStream = classLoader.getResourceAsStream(templateFileName);
            if (inputStream == null) {
                throw new IOException("Template file not found: " + templateFileName);
            }

            String template = new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
            inputStream.close();

            // Replace placeholders with actual data
            String proposal = replaceTemplatePlaceholders(template, sp);

            // Create proposals directory if it doesn't exist
            File proposalsDir = new File("proposals");
            if (!proposalsDir.exists()) {
                proposalsDir.mkdirs();
            }

            // Generate a unique filename for the proposal
            String fileName = "proposal_" + sp.getId() + "_" + 
                              sp.getDate().value().toString().replace("-", "") + ".txt";

            // Save the proposal to a file
            File proposalFile = new File(proposalsDir, fileName);
            Files.writeString(proposalFile.toPath(), proposal, StandardCharsets.UTF_8);

            sp.setStatus(ShowProposalStatus.SENT);
            showProposalRepository.save(sp);
            return 1; // Success
        } catch (IOException e) {
            e.printStackTrace();
            return 0; // Failure
        }
    }

    /**
     * Replaces placeholders in the template with actual data from the ShowProposal
     */
    private String replaceTemplatePlaceholders(String template, ShowProposal sp) {
        Customer customer = sp.getShowRequest().getCustomer();
        List<CustomerRepresentative> representatives = customer.representatives();
        CustomerRepresentative representative = representatives.isEmpty() ? null : representatives.get(0);

        // Replace customer information
        template = template.replace("[Customer Representative Name]", 
                    representative != null ? representative.getName().toString() : "");
        template = template.replace("[Company name]", customer.name().value());
        template = template.replace("[Company Name]", customer.name().value());
        template = template.replace("[Address with postal code and country]", customer.adress().value());  // No direct access to address
        template = template.replace("[VAT Number]", customer.identity().value());

        // Replace proposal information
        template = template.replace("[proposal number]", "P-" + sp.getId());
        template = template.replace("[date]", sp.getDate().toString());
        template = template.replace("[link to show video]",
            sp.getSimulationVideoLink() != null ? sp.getSimulationVideoLink().value() : "");
        template = template.replace("[insurance amount]", "€3,000.00"); // Default value
        template = template.replace("[CRM Manager Name]", "André Figueiredo"); // Default value
        template = template.replace("[show proposal number]", "SP-" + sp.getId());

        // Replace show details
        template = template.replace("[GPS coordinates of the location]", sp.getPlace().value());
        template = template.replace("[date of the event]", sp.getDate().toString());
        template = template.replace("[time of the event]", sp.getTime().toString());
        template = template.replace("[duration]", String.valueOf(sp.getDuration().value().toMinutes()));


        // Replace drone models (placeholder for now as we don't have drone model information)
        Map<DroneModel, Integer> mapa = new HashMap<>();
        for(ShowProposalFigure figure: sp.getFigures()) {
            Figure fig = figure.getFigure();
            for(DroneModelFigure dm: fig.getDroneFigures()) {
                DroneModel drm = dm.getDroneModel();
                mapa.putIfAbsent(drm, 1);
                mapa.put(drm, mapa.get(drm) + 1);
            }
        }
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<DroneModel, Integer> entry : mapa.entrySet()) {
            sb.append(entry.getKey().getModelID().value())
                    .append(" - ")
                    .append(entry.getValue())
                    .append("\n");
        }
        String result = sb.toString().trim();
        template = template.replace("[model] – [quantity]", result);

        // Replace figures
        StringBuilder figuresSection = new StringBuilder();
        List<ShowProposalFigure> sortedFigures = new ArrayList<>(sp.getFigures());
        sortedFigures.sort(Comparator.comparingInt(ShowProposalFigure::getPosition));

        for (ShowProposalFigure figure : sortedFigures) {
            Figure fig = figure.getFigure();
            // Use code value as fallback if description is not accessible
            String figureName =  fig.getDescription() != null ? "Figure " + fig.code().value() + " - " + fig.getDescription().value() :  "Figure " + fig.code().value();
            figuresSection.append(figure.getPosition()).append(" – ").append(figureName).append("\n");
        }

        // Replace the figures placeholder with the actual figures list
        template = template.replace("[position in show] – [figure name]", figuresSection.toString().trim());

        return template;
    }

    public List<ShowProposal> getListOfUnsentShowProposals() {
        List<ShowProposal> unsentShowProposals = new ArrayList<>();
        List<ShowProposal> list = showProposalRepository.findAll();
        for(ShowProposal showProposal : list){
            if(showProposal.getStatus() == ShowProposalStatus.DRAFT){
                unsentShowProposals.add(showProposal);
            }
        }
        return unsentShowProposals;
    }
    @Transactional
    public void addDronesToShowProposal(ShowProposal proposal, List<Drone> drones){
        proposal.getDrones().addAll(drones);
        showProposalRepository.save(proposal);
    }
}
