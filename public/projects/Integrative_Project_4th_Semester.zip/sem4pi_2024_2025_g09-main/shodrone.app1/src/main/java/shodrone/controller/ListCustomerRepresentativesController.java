package shodrone.controller;

import org.springframework.stereotype.Component;
import shodrone.customerrepresentativemanagement.CustomerRepresentative;
import shodrone.services.CustomerService;

import java.util.List;

@Component
public class ListCustomerRepresentativesController {

    private final CustomerService customerService;

    public ListCustomerRepresentativesController(CustomerService customerService) {
        this.customerService = customerService;
    }

    public List<CustomerRepresentative> listActiveRepresentatives(String rawVat) {
        return customerService.listActiveRepresentatives(rawVat);
    }
}