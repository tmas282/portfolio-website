package shodrone.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import shodrone.dronemaintenancemanagement.MaintenanceRecord;
import shodrone.dronemaintenancemanagement.MaintenanceType;
import shodrone.dronemanagement.Drone;

import java.time.LocalDate;
import java.util.List;

public interface MaintenanceRecordRepository extends JpaRepository<MaintenanceRecord, Long> {
    List<MaintenanceRecord> findByDroneAndMaintenanceDate_DateBetween(Drone drone, LocalDate start, LocalDate end);
    boolean existsByMaintenanceType(MaintenanceType maintenanceType);
}