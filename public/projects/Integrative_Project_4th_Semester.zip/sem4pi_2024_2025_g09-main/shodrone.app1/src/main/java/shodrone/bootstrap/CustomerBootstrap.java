package shodrone.bootstrap;

import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import shodrone.services.CustomerService;

@Component
@Order(2)
public class CustomerBootstrap implements CommandLineRunner {

    private final CustomerService customerService;

    public CustomerBootstrap(CustomerService customerService) {
        this.customerService = customerService;
    }

    @Override
    public void run(String... args) {
        System.out.println("🔧 [BOOTSTRAP] Initializing customers...");

        try {
            customerService.registerCustomerAndRepresentative(
                    "PT123456789", "CustomerName", "customer@example.com",
                    "Main Street 1", "912345678",
                    "Alice Customer", "representative1@example.com", "Manager", "936584758", "VIP"
            );
            System.out.printf("✅ Customer created: %s (%s)%n", "CustomerName", "PT123456789");
        } catch (Exception e) {
            System.out.printf("❌ Failed to create customer PT123456789: %s%n", e.getMessage());
        }

        try {
            customerService.registerCustomerAndRepresentative(
                    "PT987654321", "Another Customer", "another@example.com",
                    "Avenida Central", "923456789",
                    "Bob Client", "representative2@example.com", "CTO", "926584759", "REGULAR"
            );
            System.out.printf("✅ Customer created: %s (%s)%n", "Another Customer", "PT987654321");
        } catch (Exception e) {
            System.out.printf("❌ Failed to create customer PT987654321: %s%n", e.getMessage());
        }
    }

}