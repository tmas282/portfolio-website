package shodrone.services;


import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import shodrone.figurecategorymanagement.CategoryName;
import shodrone.figurecategorymanagement.FigureCategory;
import shodrone.repositories.CustomerRepository;
import shodrone.repositories.FigureRepository;
import shodrone.utils.UtilFunctions;
import shodrone.figuremanagement.*;
import shodrone.repositories.FigureCategoryRepository;
import java.util.ArrayList;
import java.util.List;

@Service
public class FigureService {
    private final FigureRepository figureRepository;
    private final FigureCategoryRepository figureCategoryRepository;
    private final CustomerRepository customerRepository;

    @Autowired
    public FigureService(FigureRepository figureRepository,
                         FigureCategoryRepository figureCategoryRepository,
                         CustomerRepository customerRepository) {
        this.figureRepository = figureRepository;
        this.figureCategoryRepository = figureCategoryRepository;
        this.customerRepository = customerRepository;
    }


    @Transactional
    public List<Figure> listAllActivePublicFigures() {
        return figureRepository.findAll();
    }

    @Transactional
    public List<Figure> searchByCategory(String rawCategoryName) {
        List<Figure> result = new ArrayList<>();
        String normalizedSearch = UtilFunctions.removeAccents(rawCategoryName).toLowerCase();

        List<Figure> allFigures = figureRepository.findAll();
        for (Figure figure : allFigures) {
            String figureCategoryName = UtilFunctions.removeAccents(figure.category().name().value()).toLowerCase();
            if (figureCategoryName.equals(normalizedSearch)) {
                result.add(figure);
            }
        }

        return result;
    }


    @Transactional
    public List<Figure> searchByKeyword(String keyword) {
        List<Figure> res = new ArrayList<>();
        List<Figure> list = figureRepository.findAll();
        keyword = UtilFunctions.removeAccents(keyword).toLowerCase();
        for (Figure figure : list) {
            for(Keyword keyword2: figure.setOfKeywords()) {
                if(UtilFunctions.removeAccents(keyword2.value()).toLowerCase().equals(keyword)) {
                    res.add(figure);
                    break;
                }

            }
        }
        return res;
    }

    @Transactional
    public List<Figure> searchByCategoryAndKeyword(String categoryName, String keyword) {
        categoryName = UtilFunctions.removeAccents(categoryName).toLowerCase();
        keyword = UtilFunctions.removeAccents(keyword).toLowerCase();
        List<Figure> res = new ArrayList<>();
        List<Figure> list = figureRepository.findAll();
        List<Figure> cat_matches = searchByCategory(categoryName);
        for (Figure figure : cat_matches) {
            for(Keyword keyword2: figure.setOfKeywords()) {
                if(UtilFunctions.removeAccents(keyword2.value()).toLowerCase().equals(keyword)) {
                    res.add(figure);
                    break;
                }
            }
        }
        return res;
    }

    @Transactional
    public int addFigure(long code_id, List<Keyword> keywords, String categoryName) {
        Code code = new Code(code_id);

        if (figureRepository.findByCode(code).isPresent()) {
            return 1;
        }

        CategoryName catName;
        try {
            catName = new CategoryName(categoryName);
        } catch (IllegalArgumentException e) {
            return 2;
        }

        FigureCategory category = figureCategoryRepository
                .findByName_ValueIgnoreCase(catName.value())
                .orElse(null);

        if (category == null) {
            return 2;
        }

        Figure fig = new Figure(code, keywords, category);
        figureRepository.save(fig);

        return 0;
    }


    @Transactional
    public int editDescription(Code code, Description description) {
        if (figureRepository.findByCode(code).isEmpty()) {
            return 1;
        }
        else {
            if(figureRepository.findAll().contains(figureRepository.findByCode(code).get())) {
                Figure figure = figureRepository.findByCode(code).get();
                figure.editDescription(description);
                figureRepository.save(figure);
            }
            else {
                return 2;
            }
        }
        return 0;
    }

    @Transactional
    public int addDslCode(Code code, DSLCode dslCode) {
        if (figureRepository.findByCode(code).isEmpty()) {
            return 1;
        }
        else {
            if(figureRepository.findAll().contains(figureRepository.findByCode(code).get())) {
                Figure figure = figureRepository.findByCode(code).get();
                figure.addDslCode(dslCode);
                figureRepository.save(figure);
            }
            else {
                return 2;
            }
        }
        return 0;
    }

    @Transactional
    public int addExclusivity(Code code, Exclusivity exclusivity) {
        if(figureRepository.findAll().contains(figureRepository.findByCode(code).get())) {
            Figure figure = figureRepository.findByCode(code).get();
            if(customerRepository.findByVat(exclusivity.value()).isPresent()) {
                figure.addExclusivity(exclusivity);
                figureRepository.save(figure);
            }
            else {
                return 2;
            }
        }
        else {
            return 1;
        }
        return 0;
    }

    @Transactional
    public int addKeyword(Code code, Keyword keyword) {
        if (figureRepository.findByCode(code).isEmpty()) {
            return 1;
        }
        else {
            if(figureRepository.findAll().contains(figureRepository.findByCode(code).get())){
                Figure figure = figureRepository.findByCode(code).get();
                figure.addKeyword(keyword);
                figureRepository.save(figure);
            }
            else {
                return 2;
            }
        }
        return 0;
    }

    @Transactional
    public int decommissionFigure(Code code) {
        if (figureRepository.findByCode(code).isEmpty()) {
            return 1;
        }
        else {
            if(figureRepository.findAll().contains(figureRepository.findByCode(code).get())) {
                Figure figure = figureRepository.findByCode(code).get();
                figure.deactivate();
                figureRepository.save(figure);
            }
            else {
                return 2;
            }
        }
        return 0;
    }

    @Transactional
    public int newVersion(Code code, Version version) {
        if (figureRepository.findByCode(code).isEmpty()) {
            return 1;
        }
        else {
            if(figureRepository.findAll().contains(figureRepository.findByCode(code).get())) {
                Figure figure = figureRepository.findByCode(code).get();
                figure.newVersion(version);
                figureRepository.save(figure);
            }
            else {
                return 2;
            }
        }
        return 0;
    }

    @Transactional
    public int addDesigner(Code code, Designer designer) {
        if (figureRepository.findByCode(code).isEmpty()) {
            return 1;
        }
        else {
            if(figureRepository.findAll().contains(figureRepository.findByCode(code).get())) {
                Figure figure = figureRepository.findByCode(code).get();
                figure.addDesigner(designer);
                figureRepository.save(figure);
            }
            else {
                return 2;
            }
        }
        return 0;
    }
}
