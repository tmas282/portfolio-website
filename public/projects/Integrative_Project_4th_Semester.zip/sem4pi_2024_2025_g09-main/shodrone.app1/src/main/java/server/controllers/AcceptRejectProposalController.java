package server.controllers;

import eapli.framework.infrastructure.authz.domain.model.SystemUser;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import server.services.AcceptRejectProposalService;
import shodrone.showproposalmanagement.ShowProposal;
import shodrone.showrequestmanagement.ShowRequest;

import java.util.List;

@RestController
public class AcceptRejectProposalController {

    private final AcceptRejectProposalService acceptRejectProposalService;

    public AcceptRejectProposalController(AcceptRejectProposalService acceptRejectProposalService) {
        this.acceptRejectProposalService = acceptRejectProposalService;
    }
    @GetMapping(value = "/accept-proposal", params = {"id"})
    public boolean acceptProposal(@RequestParam("id") Long showProposalId) {
        ShowProposal proposal = acceptRejectProposalService.acceptProposal(showProposalId);
        return true;
    }

    @GetMapping(value = "/reject-proposal", params = {"id"})
    public boolean rejectProposal(@RequestParam("id") Long showProposalId) {
        ShowProposal proposal = acceptRejectProposalService.rejectProposal(showProposalId);
        return true;
    }
}