package server;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import shodrone.repositories.UserRepository;
import shodrone.usermanagement.User;

@Configuration
public class Security {
    @Bean
    public UserDetailsService userDetailsService(UserRepository userRepository) {
        return email -> {
            User user = userRepository.findByEmail(email)
                    .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));
            return org.springframework.security.core.userdetails.User
                    .withUsername(user.email())
                    .password("{bcrypt}" + user.password())
                    .roles(user.role().getRoleName().toString())
                    .disabled(!user.isEnabled())
                    .build();
        };
    }
}
