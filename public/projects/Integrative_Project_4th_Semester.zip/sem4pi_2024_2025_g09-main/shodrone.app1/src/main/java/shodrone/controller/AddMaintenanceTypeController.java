package shodrone.controller;

import org.springframework.stereotype.Controller;
import shodrone.dronemaintenancemanagement.MaintenanceType;
import shodrone.services.DroneMaintenanceService;

@Controller
public class AddMaintenanceTypeController {
    private final DroneMaintenanceService droneMaintenanceService;

    public AddMaintenanceTypeController(DroneMaintenanceService droneMaintenanceService) {
        this.droneMaintenanceService = droneMaintenanceService;
    }

    public MaintenanceType addMaintenanceType(String description) {
        return droneMaintenanceService.addMaintenanceType(description);
    }
}