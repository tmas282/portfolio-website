package shodrone.services;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import shodrone.dronemaintenancemanagement.*;
import shodrone.dronemanagement.Drone;
import shodrone.dronemanagement.SerialNumber;
import shodrone.dronemodelmanagement.DroneModel;
import shodrone.dronemodelmanagement.MaintenanceThreshold;
import shodrone.repositories.DroneRepository;
import shodrone.repositories.MaintenanceRecordRepository;
import shodrone.repositories.MaintenanceTypeRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class DroneMaintenanceService {

    private final MaintenanceTypeRepository maintenanceTypeRepo;
    private final MaintenanceRecordRepository maintenanceRecordRepo;
    private final DroneRepository droneRepo;

    @Autowired
    public DroneMaintenanceService(
            MaintenanceTypeRepository maintenanceTypeRepo,
            MaintenanceRecordRepository maintenanceRecordRepo,
            DroneRepository droneRepo
    ) {
        this.maintenanceTypeRepo = maintenanceTypeRepo;
        this.maintenanceRecordRepo = maintenanceRecordRepo;
        this.droneRepo = droneRepo;
    }

    public MaintenanceType addMaintenanceType(String description) {
        MaintenanceTypeDescription maintenanceTypeDescription = new MaintenanceTypeDescription(description);
        MaintenanceType maintenanceType = new MaintenanceType(maintenanceTypeDescription);
        return maintenanceTypeRepo.save(maintenanceType);
    }
    public List<MaintenanceType> getAllMaintenanceTypes() {
        return maintenanceTypeRepo.findAll();
    }
    public MaintenanceType editMaintenanceTypeDescription(Long id, String newDescription) {
        MaintenanceType maintenanceType = maintenanceTypeRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Maintenance type not found with ID: " + id));

        boolean hasRecords = maintenanceRecordRepo.existsByMaintenanceType(maintenanceType);
        if (hasRecords) {
            throw new IllegalStateException("Cannot edit maintenance type with associated maintenance records.");
        }
        maintenanceType.getDescription().updateValue(newDescription);
        return maintenanceTypeRepo.save(maintenanceType);
    }

    public List<MaintenanceRecord> listMaintenanceHistory(String serialNumber, LocalDate startDate, LocalDate endDate) {
        if (startDate == null || endDate == null || endDate.isBefore(startDate)) {
            throw new IllegalArgumentException("Invalid date range.");
        }
        try {
            SerialNumber sn = new SerialNumber(serialNumber);
            Drone drone = droneRepo.findBySerialNumber(sn)
                    .orElse(null);
            if (drone == null) {
                // Drone não encontrado, devolve lista vazia
                return List.of();
            }
            return maintenanceRecordRepo.findByDroneAndMaintenanceDate_DateBetween(drone, startDate, endDate);
        } catch (Exception e) {
            // Qualquer erro inesperado, devolve lista vazia
            return List.of();
        }
    }

    public MaintenanceRecord addMaintenanceRecord(String serialNumberStr, Long maintenanceTypeId, String description, LocalDate date) {
        // Validar entrada
        if (serialNumberStr == null || serialNumberStr.isBlank() || maintenanceTypeId == null || description == null || description.isBlank() || date == null) {
            throw new IllegalArgumentException("Invalid input data.");
        }

        // Obter o drone pelo número de série
        SerialNumber serialNumber = new SerialNumber(serialNumberStr);
        Drone drone = droneRepo.findBySerialNumber(serialNumber)
                .orElseThrow(() -> new IllegalArgumentException("Drone not found with serial number: " + serialNumberStr));

        // Obter o tipo de manutenção pelo ID
        MaintenanceType maintenanceType = maintenanceTypeRepo.findById(maintenanceTypeId)
                .orElseThrow(() -> new IllegalArgumentException("Maintenance type not found with ID: " + maintenanceTypeId));

        // Criar objetos de valor para descrição e data
        MaintenanceDescription maintenanceDescription = new MaintenanceDescription(description);
        MaintenanceDate maintenanceDate = new MaintenanceDate(date);

        // Criar o registro de manutenção
        MaintenanceRecord record = new MaintenanceRecord(maintenanceDate, maintenanceDescription, maintenanceType, drone);

        // Verificar se o tipo de manutenção redefine o contador de tempo de uso
        if (maintenanceType.getStatus().isEditable() && maintenanceType.getDescription().value().contains("reset")) {
            drone.resetUsageTime();
            droneRepo.save(drone); // Salvar alterações no drone
        }

        // Salvar o registro de manutenção
        return maintenanceRecordRepo.save(record);
    }

    public void registerDroneUsageTime(String serialNumber, int usageTime) {
        if (usageTime <= 0) {
            throw new IllegalArgumentException("Usage time must be a positive number.");
        }
        SerialNumber sn = new SerialNumber(serialNumber);
        Drone drone = droneRepo.findBySerialNumber(sn)
                .orElseThrow(() -> new IllegalArgumentException("Drone not found with serial number: " + serialNumber));
        drone.usageTime().increment(usageTime);
        droneRepo.save(drone);
    }

    public List<Drone> listDronesNeedingPreventiveMaintenance(LocalDate date) {
        List<Drone> allDrones = droneRepo.findAll();
        List<Drone> needingMaintenance = new ArrayList<>();
        for (Drone drone : allDrones) {
            DroneModel model = drone.getDroneModel();
            MaintenanceThreshold threshold = model.getMaintenanceThreshold();
            int usageTime = drone.usageTime().value();
            int thresholdValue = threshold.value();
            if (usageTime > thresholdValue) {
                needingMaintenance.add(drone);
            }
        }
        return needingMaintenance;
    }


}