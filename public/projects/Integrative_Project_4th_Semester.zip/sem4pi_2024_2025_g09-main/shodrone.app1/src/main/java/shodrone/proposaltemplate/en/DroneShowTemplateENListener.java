// Generated from C:/Users/afons/sem4pi_2024_2025_g09/shodrone.app1/src/main/java/shodrone/proposaltemplate/en/DroneShowTemplateEN.g4 by ANTLR 4.13.2
package shodrone.proposaltemplate.en;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link DroneShowTemplateENParser}.
 */
public interface DroneShowTemplateENListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplateENParser#document}.
	 * @param ctx the parse tree
	 */
	void enterDocument(DroneShowTemplateENParser.DocumentContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplateENParser#document}.
	 * @param ctx the parse tree
	 */
	void exitDocument(DroneShowTemplateENParser.DocumentContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplateENParser#salutation}.
	 * @param ctx the parse tree
	 */
	void enterSalutation(DroneShowTemplateENParser.SalutationContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplateENParser#salutation}.
	 * @param ctx the parse tree
	 */
	void exitSalutation(DroneShowTemplateENParser.SalutationContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplateENParser#clientCompany}.
	 * @param ctx the parse tree
	 */
	void enterClientCompany(DroneShowTemplateENParser.ClientCompanyContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplateENParser#clientCompany}.
	 * @param ctx the parse tree
	 */
	void exitClientCompany(DroneShowTemplateENParser.ClientCompanyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code clientLocationField}
	 * labeled alternative in {@link DroneShowTemplateENParser#clientLocation}.
	 * @param ctx the parse tree
	 */
	void enterClientLocationField(DroneShowTemplateENParser.ClientLocationFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code clientLocationField}
	 * labeled alternative in {@link DroneShowTemplateENParser#clientLocation}.
	 * @param ctx the parse tree
	 */
	void exitClientLocationField(DroneShowTemplateENParser.ClientLocationFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code vatField}
	 * labeled alternative in {@link DroneShowTemplateENParser#vat}.
	 * @param ctx the parse tree
	 */
	void enterVatField(DroneShowTemplateENParser.VatFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code vatField}
	 * labeled alternative in {@link DroneShowTemplateENParser#vat}.
	 * @param ctx the parse tree
	 */
	void exitVatField(DroneShowTemplateENParser.VatFieldContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplateENParser#documentID}.
	 * @param ctx the parse tree
	 */
	void enterDocumentID(DroneShowTemplateENParser.DocumentIDContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplateENParser#documentID}.
	 * @param ctx the parse tree
	 */
	void exitDocumentID(DroneShowTemplateENParser.DocumentIDContext ctx);
	/**
	 * Enter a parse tree produced by the {@code videoURLField}
	 * labeled alternative in {@link DroneShowTemplateENParser#videoURL}.
	 * @param ctx the parse tree
	 */
	void enterVideoURLField(DroneShowTemplateENParser.VideoURLFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code videoURLField}
	 * labeled alternative in {@link DroneShowTemplateENParser#videoURL}.
	 * @param ctx the parse tree
	 */
	void exitVideoURLField(DroneShowTemplateENParser.VideoURLFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code insuranceAmountField}
	 * labeled alternative in {@link DroneShowTemplateENParser#insuranceAmount}.
	 * @param ctx the parse tree
	 */
	void enterInsuranceAmountField(DroneShowTemplateENParser.InsuranceAmountFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code insuranceAmountField}
	 * labeled alternative in {@link DroneShowTemplateENParser#insuranceAmount}.
	 * @param ctx the parse tree
	 */
	void exitInsuranceAmountField(DroneShowTemplateENParser.InsuranceAmountFieldContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplateENParser#signatoryName}.
	 * @param ctx the parse tree
	 */
	void enterSignatoryName(DroneShowTemplateENParser.SignatoryNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplateENParser#signatoryName}.
	 * @param ctx the parse tree
	 */
	void exitSignatoryName(DroneShowTemplateENParser.SignatoryNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplateENParser#pageOne}.
	 * @param ctx the parse tree
	 */
	void enterPageOne(DroneShowTemplateENParser.PageOneContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplateENParser#pageOne}.
	 * @param ctx the parse tree
	 */
	void exitPageOne(DroneShowTemplateENParser.PageOneContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplateENParser#pageTwo}.
	 * @param ctx the parse tree
	 */
	void enterPageTwo(DroneShowTemplateENParser.PageTwoContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplateENParser#pageTwo}.
	 * @param ctx the parse tree
	 */
	void exitPageTwo(DroneShowTemplateENParser.PageTwoContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplateENParser#headerSection}.
	 * @param ctx the parse tree
	 */
	void enterHeaderSection(DroneShowTemplateENParser.HeaderSectionContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplateENParser#headerSection}.
	 * @param ctx the parse tree
	 */
	void exitHeaderSection(DroneShowTemplateENParser.HeaderSectionContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplateENParser#introContent}.
	 * @param ctx the parse tree
	 */
	void enterIntroContent(DroneShowTemplateENParser.IntroContentContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplateENParser#introContent}.
	 * @param ctx the parse tree
	 */
	void exitIntroContent(DroneShowTemplateENParser.IntroContentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code proposalIDField}
	 * labeled alternative in {@link DroneShowTemplateENParser#proposalID}.
	 * @param ctx the parse tree
	 */
	void enterProposalIDField(DroneShowTemplateENParser.ProposalIDFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code proposalIDField}
	 * labeled alternative in {@link DroneShowTemplateENParser#proposalID}.
	 * @param ctx the parse tree
	 */
	void exitProposalIDField(DroneShowTemplateENParser.ProposalIDFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code proposalDateField}
	 * labeled alternative in {@link DroneShowTemplateENParser#proposalDate}.
	 * @param ctx the parse tree
	 */
	void enterProposalDateField(DroneShowTemplateENParser.ProposalDateFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code proposalDateField}
	 * labeled alternative in {@link DroneShowTemplateENParser#proposalDate}.
	 * @param ctx the parse tree
	 */
	void exitProposalDateField(DroneShowTemplateENParser.ProposalDateFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code eventDateField}
	 * labeled alternative in {@link DroneShowTemplateENParser#eventDate}.
	 * @param ctx the parse tree
	 */
	void enterEventDateField(DroneShowTemplateENParser.EventDateFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code eventDateField}
	 * labeled alternative in {@link DroneShowTemplateENParser#eventDate}.
	 * @param ctx the parse tree
	 */
	void exitEventDateField(DroneShowTemplateENParser.EventDateFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code zipCodeField}
	 * labeled alternative in {@link DroneShowTemplateENParser#zipCode}.
	 * @param ctx the parse tree
	 */
	void enterZipCodeField(DroneShowTemplateENParser.ZipCodeFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code zipCodeField}
	 * labeled alternative in {@link DroneShowTemplateENParser#zipCode}.
	 * @param ctx the parse tree
	 */
	void exitZipCodeField(DroneShowTemplateENParser.ZipCodeFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code eventTimeField}
	 * labeled alternative in {@link DroneShowTemplateENParser#eventTime}.
	 * @param ctx the parse tree
	 */
	void enterEventTimeField(DroneShowTemplateENParser.EventTimeFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code eventTimeField}
	 * labeled alternative in {@link DroneShowTemplateENParser#eventTime}.
	 * @param ctx the parse tree
	 */
	void exitEventTimeField(DroneShowTemplateENParser.EventTimeFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code eventLengthField}
	 * labeled alternative in {@link DroneShowTemplateENParser#eventLength}.
	 * @param ctx the parse tree
	 */
	void enterEventLengthField(DroneShowTemplateENParser.EventLengthFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code eventLengthField}
	 * labeled alternative in {@link DroneShowTemplateENParser#eventLength}.
	 * @param ctx the parse tree
	 */
	void exitEventLengthField(DroneShowTemplateENParser.EventLengthFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code gpsLatField}
	 * labeled alternative in {@link DroneShowTemplateENParser#gpsLat}.
	 * @param ctx the parse tree
	 */
	void enterGpsLatField(DroneShowTemplateENParser.GpsLatFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code gpsLatField}
	 * labeled alternative in {@link DroneShowTemplateENParser#gpsLat}.
	 * @param ctx the parse tree
	 */
	void exitGpsLatField(DroneShowTemplateENParser.GpsLatFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code gpsLongField}
	 * labeled alternative in {@link DroneShowTemplateENParser#gpsLong}.
	 * @param ctx the parse tree
	 */
	void enterGpsLongField(DroneShowTemplateENParser.GpsLongFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code gpsLongField}
	 * labeled alternative in {@link DroneShowTemplateENParser#gpsLong}.
	 * @param ctx the parse tree
	 */
	void exitGpsLongField(DroneShowTemplateENParser.GpsLongFieldContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplateENParser#attachmentDetails}.
	 * @param ctx the parse tree
	 */
	void enterAttachmentDetails(DroneShowTemplateENParser.AttachmentDetailsContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplateENParser#attachmentDetails}.
	 * @param ctx the parse tree
	 */
	void exitAttachmentDetails(DroneShowTemplateENParser.AttachmentDetailsContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplateENParser#droneModel}.
	 * @param ctx the parse tree
	 */
	void enterDroneModel(DroneShowTemplateENParser.DroneModelContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplateENParser#droneModel}.
	 * @param ctx the parse tree
	 */
	void exitDroneModel(DroneShowTemplateENParser.DroneModelContext ctx);
	/**
	 * Enter a parse tree produced by the {@code droneCountField}
	 * labeled alternative in {@link DroneShowTemplateENParser#droneCount}.
	 * @param ctx the parse tree
	 */
	void enterDroneCountField(DroneShowTemplateENParser.DroneCountFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code droneCountField}
	 * labeled alternative in {@link DroneShowTemplateENParser#droneCount}.
	 * @param ctx the parse tree
	 */
	void exitDroneCountField(DroneShowTemplateENParser.DroneCountFieldContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplateENParser#droneEntry}.
	 * @param ctx the parse tree
	 */
	void enterDroneEntry(DroneShowTemplateENParser.DroneEntryContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplateENParser#droneEntry}.
	 * @param ctx the parse tree
	 */
	void exitDroneEntry(DroneShowTemplateENParser.DroneEntryContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplateENParser#equipmentList}.
	 * @param ctx the parse tree
	 */
	void enterEquipmentList(DroneShowTemplateENParser.EquipmentListContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplateENParser#equipmentList}.
	 * @param ctx the parse tree
	 */
	void exitEquipmentList(DroneShowTemplateENParser.EquipmentListContext ctx);
	/**
	 * Enter a parse tree produced by the {@code figureNumField}
	 * labeled alternative in {@link DroneShowTemplateENParser#figureNum}.
	 * @param ctx the parse tree
	 */
	void enterFigureNumField(DroneShowTemplateENParser.FigureNumFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code figureNumField}
	 * labeled alternative in {@link DroneShowTemplateENParser#figureNum}.
	 * @param ctx the parse tree
	 */
	void exitFigureNumField(DroneShowTemplateENParser.FigureNumFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code figureNameField}
	 * labeled alternative in {@link DroneShowTemplateENParser#figureName}.
	 * @param ctx the parse tree
	 */
	void enterFigureNameField(DroneShowTemplateENParser.FigureNameFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code figureNameField}
	 * labeled alternative in {@link DroneShowTemplateENParser#figureName}.
	 * @param ctx the parse tree
	 */
	void exitFigureNameField(DroneShowTemplateENParser.FigureNameFieldContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplateENParser#figureEntry}.
	 * @param ctx the parse tree
	 */
	void enterFigureEntry(DroneShowTemplateENParser.FigureEntryContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplateENParser#figureEntry}.
	 * @param ctx the parse tree
	 */
	void exitFigureEntry(DroneShowTemplateENParser.FigureEntryContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplateENParser#performanceElements}.
	 * @param ctx the parse tree
	 */
	void enterPerformanceElements(DroneShowTemplateENParser.PerformanceElementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplateENParser#performanceElements}.
	 * @param ctx the parse tree
	 */
	void exitPerformanceElements(DroneShowTemplateENParser.PerformanceElementsContext ctx);
}