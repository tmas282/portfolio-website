package shodrone.controller;

import org.springframework.stereotype.Controller;
import shodrone.customermanagement.Customer;
import shodrone.customermanagement.VAT;
import shodrone.services.CustomerService;
import shodrone.services.ShowRequestService;
import shodrone.showrequestmanagement.ShowRequest;

import java.util.List;

@Controller
public class ListShowRequestsController {
    private final CustomerService customerService;
    private final ShowRequestService showRequestService;

    public ListShowRequestsController(CustomerService customerService, ShowRequestService showRequestService) {
        this.customerService = customerService;
        this.showRequestService = showRequestService;
    }
    public List<ShowRequest> listShowRequestsOfCustomer(String VAT){
        Customer c = customerService.getCustomer(new VAT(VAT));
        return showRequestService.getShowRequestsOfCustomer(c);
    }
}
