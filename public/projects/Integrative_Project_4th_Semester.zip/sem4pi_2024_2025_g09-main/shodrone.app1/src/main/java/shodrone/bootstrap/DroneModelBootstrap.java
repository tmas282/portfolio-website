package shodrone.bootstrap;

import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import shodrone.controller.CreateDroneModelController;
import shodrone.dronemodelmanagement.WindTolerance;
import shodrone.dronemodelmanagement.MaintenanceThreshold;

import java.util.NavigableMap;
import java.util.TreeMap;

@Component
@Order(3)
public class DroneModelBootstrap implements CommandLineRunner {

    private final CreateDroneModelController controller;

    public DroneModelBootstrap(CreateDroneModelController controller) {
        this.controller = controller;
    }

    @Override
    public void run(String... args) {
        createModel("DM001", "Java", 100);
        createModel("DM002", "Python", 150);
    }

    private void createModel(String modelID, String language, int maintenanceThresholdValue) {
        NavigableMap<Double, Double> toleranceSteps = new TreeMap<>();
        toleranceSteps.put(5.0, 0.0);
        toleranceSteps.put(7.0, 0.3);
        toleranceSteps.put(10.0, 0.5);
        toleranceSteps.put(15.0, 0.8);

        WindTolerance tolerance = new WindTolerance(toleranceSteps);
        MaintenanceThreshold maintenanceThreshold = new MaintenanceThreshold(maintenanceThresholdValue);

        try {
            controller.createDroneModel(modelID, language, tolerance, maintenanceThreshold);
            System.out.printf(" DroneModel '%s' registered.%n", modelID);
        } catch (IllegalStateException e) {
            System.out.printf(" DroneModel '%s' skipped: %s%n", modelID, e.getMessage());
        }
    }
}