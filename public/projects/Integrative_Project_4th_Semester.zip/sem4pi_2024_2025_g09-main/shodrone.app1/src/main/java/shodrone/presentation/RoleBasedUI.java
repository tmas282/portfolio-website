package shodrone.presentation;

import org.springframework.stereotype.Component;
import shodrone.usermanagement.RoleName;
import shodrone.usermanagement.User;

import static shodrone.usermanagement.RoleName.*;

@Component
public class RoleBasedUI {

    private final AdminUI adminUI;
    private final CRMManagerUI crmManagerUI;
    private final CRMCollaboratorUI crmCollaboratorUI;
    private final ShowDesignerUI showDesignerUI;
    private final DroneTechUI droneTechUI;
    private final CustomerUI customerUI;

    public RoleBasedUI(AdminUI adminUI,
                       CRMManagerUI crmManagerUI,
                       CRMCollaboratorUI crmCollaboratorUI,
                       ShowDesignerUI showDesignerUI,
                       DroneTechUI droneTechUI,
                       CustomerUI customerUI) {
        this.adminUI = adminUI;
        this.crmManagerUI = crmManagerUI;
        this.crmCollaboratorUI = crmCollaboratorUI;
        this.showDesignerUI = showDesignerUI;
        this.droneTechUI = droneTechUI;
        this.customerUI = customerUI;
    }

    public void run(User user) {
        RoleName role = user.role() != null ? user.role().getRoleName() : null;

        if (role == null) {
            System.out.println("❌ No UI implemented for role: null");
            return;
        }

        switch (role) {
            case ADMIN -> adminUI.run();
            case CRM_MANAGER -> crmManagerUI.run();
            case CRM_COLLABORATOR -> crmCollaboratorUI.run();
            case SHOW_DESIGNER -> showDesignerUI.run();
            case DRONE_TECH -> droneTechUI.run();
            case CUSTOMER, CUSTOMER_REPRESENTATIVE -> customerUI.run();
            default -> System.out.printf("❌ No UI implemented for role: %s%n", role);
        }
    }

}
