package shodrone.services;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import shodrone.customermanagement.Name;
import shodrone.customermanagement.PhoneNumber;
import shodrone.usermanagement.Role;
import shodrone.usermanagement.RoleName;
import shodrone.usermanagement.User;
import shodrone.repositories.RoleRepository;
import shodrone.repositories.UserRepository;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public UserService(UserRepository userRepository, RoleRepository roleRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
    }

    /**
     * US211 – Registar novo utilizador no sistema backoffice
     */
    @Transactional
    public User registerUser(String email, String rawPassword, RoleName roleName, Name name, PhoneNumber phone) {
        userRepository.findByEmail(email).ifPresent(u -> {
            throw new IllegalStateException("User already exists with email: " + email);
        });

        Role role = roleRepository.findByRoleName(roleName)
                .orElseThrow(() -> new IllegalStateException("Role not found: " + roleName));

        String encodedPassword = passwordEncoder.encode(rawPassword);
        User user = new User(email, encodedPassword, role, true, name, phone);

        return userRepository.save(user);
    }

    /**
     * US212 – Desativar um utilizador
     */
    @Transactional
    public boolean disableUser(String email) {
        Optional<User> userOpt = userRepository.findByEmail(email);
        if (userOpt.isEmpty()) return false;

        User user = userOpt.get();
        user.deactivate();
        userRepository.save(user);
        return true;
    }

    /**
     * US212 – Reativar um utilizador
     */
    @Transactional
    public boolean enableUser(String email) {
        Optional<User> userOpt = userRepository.findByEmail(email);
        if (userOpt.isEmpty()) return false;

        User user = userOpt.get();
        user.activate();
        userRepository.save(user);
        return true;
    }

    /**
     * US213 – Listar todos os utilizadores
     */
    public List<User> listAllUsers() {
        return userRepository.findAll();
    }
}
