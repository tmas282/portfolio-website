package shodrone.usermanagement;

public enum RoleName {
    ADMIN,
    CRM_MANAGER,
    CRM_COLLABORATOR,
    SHOW_DESIGNER,
    DRONE_TECH,
    CUSTOMER,
    CUSTOMER_REPRESENTATIVE
}
