package shodrone.figurecategorymanagement;

import jakarta.persistence.Embeddable;

@Embeddable
public class CategoryStatus {

    private String value;

    protected CategoryStatus() {}

    private CategoryStatus(String value) {
        this.value = value;
    }

    public static CategoryStatus active() {
        return new CategoryStatus("ACTIVE");
    }

    public static CategoryStatus inactive() {
        return new CategoryStatus("INACTIVE");
    }

    public boolean isActive() {
        return "ACTIVE".equals(value);
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return value;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof CategoryStatus && value.equals(((CategoryStatus) o).value);
    }

    @Override
    public int hashCode() {
        return value.hashCode();
    }
}
