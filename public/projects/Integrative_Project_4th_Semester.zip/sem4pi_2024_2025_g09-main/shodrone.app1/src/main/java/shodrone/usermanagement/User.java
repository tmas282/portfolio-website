package shodrone.usermanagement;

import jakarta.persistence.*;
import shodrone.customermanagement.Name;
import shodrone.customermanagement.PhoneNumber;

import java.util.Objects;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Embedded
    @AttributeOverride(name = "fullName", column = @Column(name = "user_name", nullable = false))
    private Name name;

    @Column(unique = true, nullable = false)
    private String email;

    @Embedded
    @AttributeOverride(name = "number", column = @Column(name = "phone_number", nullable = false))
    private PhoneNumber phone;

    @Column(nullable = false)
    private String password;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "role_id")
    private Role role;

    private boolean enabled;

    protected User() {
        // for ORM only
    }

    public User(String email, String encryptedPassword, Role role, boolean enabled, Name name, PhoneNumber phone) {
        if (email == null || email.isBlank())
            throw new IllegalArgumentException("Email cannot be blank");
        if (role == null)
            throw new IllegalArgumentException("Role is required");
        if (!isCustomerOrRepresentative(role) && !isValidShowdroneEmail(email))
            throw new IllegalArgumentException("Email deve ser do domínio @showdrone.com");
        if (encryptedPassword == null || encryptedPassword.isBlank())
            throw new IllegalArgumentException("Password required");
        if (name == null)
            throw new IllegalArgumentException("Name is required");
        if (phone == null)
            throw new IllegalArgumentException("Phone number is required");

        this.email = email;
        this.password = encryptedPassword;
        this.role = role;
        this.enabled = enabled;
        this.name = name;
        this.phone = phone;
    }

    public Long id() {
        return id;
    }

    public String email() {
        return email;
    }

    public Role role() {
        return role;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void activate() {
        this.enabled = true;
    }

    public void deactivate() {
        this.enabled = false;
    }

    public String password() {
        return password;
    }

    public Name getName() {
        return name;
    }

    public PhoneNumber getPhone() {
        return phone;
    }

    public void setEmail(String email) {
        if (email == null || email.isBlank()) {
            throw new IllegalArgumentException("Email cannot be blank");
        }
        if (!isCustomerOrRepresentative(this.role) && !isValidShowdroneEmail(email)) {
            throw new IllegalArgumentException("Email inválido ou fora do domínio @showdrone.com.");
        }
        this.email = email;
    }

    public void setPhoneNumber(PhoneNumber phone) {
        if (phone == null) {
            throw new IllegalArgumentException("Phone number is required");
        }
        this.phone = phone;
    }

    private boolean isValidShowdroneEmail(String email) {
        return email.matches("^[\\w-.]+@showdrone\\.com$");
    }

    private boolean isCustomerOrRepresentative(Role role) {
        return role.getRoleName() == RoleName.CUSTOMER || role.getRoleName() == RoleName.CUSTOMER_REPRESENTATIVE;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof User && Objects.equals(id, ((User) o).id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}