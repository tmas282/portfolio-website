package shodrone.usermanagement;


import java.util.Set;

public final class RolePolicy {

    private RolePolicy() {
    }

    public static final Set<RoleName> BACKOFFICE_ROLES = Set.of(
            RoleName.ADMIN,
            RoleName.CRM_MANAGER,
            RoleName.CRM_COLLABORATOR,
            RoleName.SHOW_DESIGNER,
            RoleName.DRONE_TECH
    );

    public static final Set<RoleName> CUSTOMER_APP_ROLES = Set.of(
            RoleName.CUSTOMER,
            RoleName.CUSTOMER_REPRESENTATIVE
    );
}
