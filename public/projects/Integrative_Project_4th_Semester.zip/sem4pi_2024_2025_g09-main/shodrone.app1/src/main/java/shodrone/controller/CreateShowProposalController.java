package shodrone.controller;

import org.springframework.stereotype.Controller;
import shodrone.customermanagement.VAT;
import shodrone.services.CustomerService;
import shodrone.services.ShowProposalService;
import shodrone.services.ShowRequestService;
import shodrone.showproposalmanagement.*;
import shodrone.showrequestmanagement.NumberOfDrones;
import shodrone.showrequestmanagement.ShowDescription;
import shodrone.showrequestmanagement.ShowRequest;

import java.util.List;

@Controller
public class CreateShowProposalController {

    private final ShowProposalService showProposalService;

    public CreateShowProposalController(
            ShowProposalService showProposalService
    ) {
        this.showProposalService = showProposalService;
    }

    public ShowProposal create(int showRequestId) {
        return showProposalService.createShowProposal(showRequestId);
    }

}