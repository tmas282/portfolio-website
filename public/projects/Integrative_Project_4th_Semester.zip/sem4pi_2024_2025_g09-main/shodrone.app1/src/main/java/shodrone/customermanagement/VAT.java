package shodrone.customermanagement;

import jakarta.persistence.Embeddable;

import java.io.Serializable;

@Embeddable
public class VAT implements Comparable<VAT>, Serializable {

    private String number;

    protected VAT() {}

    public VAT(String number) {
        if (number == null || !number.matches("[A-Z]{2}\\d{9}")) {
            throw new IllegalArgumentException("Invalid VAT format: must follow the pattern [A-Z]{2}\\d{9}.");
        }
        this.number = number;
    }

    public String value() {
        return number;
    }

    @Override
    public int compareTo(VAT other) {
        return this.number.compareTo(other.number);
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof VAT && number.equals(((VAT) o).number);
    }

    @Override
    public int hashCode() {
        return number.hashCode();
    }

    @Override
    public String toString() {
        return number;
    }
}