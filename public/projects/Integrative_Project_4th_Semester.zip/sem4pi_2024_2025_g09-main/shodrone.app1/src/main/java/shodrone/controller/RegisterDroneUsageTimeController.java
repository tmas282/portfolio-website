package shodrone.controller;

import org.springframework.stereotype.Controller;
import shodrone.services.DroneMaintenanceService;

@Controller
public class RegisterDroneUsageTimeController {
    private final DroneMaintenanceService droneMaintenanceService;

    public RegisterDroneUsageTimeController(DroneMaintenanceService droneMaintenanceService) {
        this.droneMaintenanceService = droneMaintenanceService;
    }

    public void registerUsageTime(String serialNumber, int usageTime) {
        droneMaintenanceService.registerDroneUsageTime(serialNumber, usageTime);
    }
}
