package shodrone.controller;

import org.springframework.stereotype.Controller;
import shodrone.dronemanagement.Drone;
import shodrone.services.DroneService;

import java.util.List;

@Controller
public class ListDronesController {

    private final DroneService droneService;

    public ListDronesController(DroneService droneService) {
        this.droneService = droneService;
    }

    public List<Drone> listActiveDrones(String modelID) {
        return droneService.listActiveDronesByModel(modelID);
    }

    public Drone getDroneBySerialNumber(String serialNumber) {
        return droneService.getDroneBySerialNumber(serialNumber)
                .orElseThrow(() -> new IllegalArgumentException("Drone not found with serial number: " + serialNumber));
    }
}
