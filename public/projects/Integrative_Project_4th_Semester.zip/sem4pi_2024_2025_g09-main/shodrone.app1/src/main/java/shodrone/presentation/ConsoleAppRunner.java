package shodrone.presentation;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import shodrone.usermanagement.User;

import java.util.Scanner;

@Component
public class ConsoleAppRunner implements CommandLineRunner {

    private final AuthUI authUI;
    private final RoleBasedUI roleBasedUI;

    public ConsoleAppRunner(AuthUI authUI, RoleBasedUI roleBasedUI) {
        this.authUI = authUI;
        this.roleBasedUI = roleBasedUI;
    }

    @Override
    public void run(String... args) {
        while (true) {
            User loggedInUser = authUI.run();
            if (loggedInUser != null) {
                roleBasedUI.run(loggedInUser);
            } else {
                System.out.println("❌ Failed to authenticate.");
            }
        }
    }



}
