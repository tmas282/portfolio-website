package shodrone.dronemodelmanagement;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Transient;
import java.util.Collections;
import java.util.NavigableMap;
import java.util.Objects;
import java.util.TreeMap;

@Embeddable
public class WindTolerance{

    @Column(name = "wind_tolerance", columnDefinition = "TEXT")
    private String toleranceStepsString;

    @Transient
    private NavigableMap<Double, Double> toleranceSteps = new TreeMap<>();

    protected WindTolerance() {
        // For JPA
    }

    public WindTolerance(NavigableMap<Double, Double> toleranceSteps) {
        if (toleranceSteps == null || toleranceSteps.isEmpty())
            throw new IllegalArgumentException("Tolerance map cannot be null or empty.");
        this.toleranceSteps = new TreeMap<>(toleranceSteps);
        this.toleranceStepsString = serialize(toleranceSteps);
    }

    public WindTolerance(String serialized) {
        if (serialized == null || serialized.isBlank())
            throw new IllegalArgumentException("Serialized tolerance cannot be null or blank.");
        this.toleranceStepsString = serialized;
        this.toleranceSteps = deserialize(serialized);
    }

    public NavigableMap<Double, Double> steps() {
        return Collections.unmodifiableNavigableMap(toleranceSteps);
    }

    private String serialize(NavigableMap<Double, Double> map) {
        StringBuilder sb = new StringBuilder();
        double previousMax = 0.0;
        for (var entry : map.entrySet()) {
            double max = entry.getKey();
            double tolerance = entry.getValue();
            sb.append(previousMax).append("-").append(max).append(":").append(tolerance).append(";");
            previousMax = max;
        }
        if (sb.length() > 0) sb.setLength(sb.length() - 1);
        return sb.toString();
    }


    private NavigableMap<Double, Double> deserialize(String str) {
        NavigableMap<Double, Double> map = new TreeMap<>();
        if (str == null || str.isBlank()) return map;
        String[] intervals = str.split(";");
        for (String interval : intervals) {
            String[] parts = interval.split(":");
            if (parts.length == 2) {
                String[] minMax = parts[0].split("-");
                if (minMax.length == 2) {
                    try {
                        double min = Double.parseDouble(minMax[0]);
                        double max = Double.parseDouble(minMax[1]);
                        double tolerance = Double.parseDouble(parts[1]);
                        map.put(max, tolerance);
                    } catch (NumberFormatException e) {
                        throw new IllegalArgumentException("Invalid tolerance entry: " + interval, e);
                    }
                }
            }
        }
        return map;
    }

    @Override
    public String toString() {
        return toleranceStepsString;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof WindTolerance)) return false;
        WindTolerance that = (WindTolerance) o;
        return toleranceSteps.equals(that.toleranceSteps);
    }

    @Override
    public int hashCode() {
        return Objects.hash(toleranceSteps);
    }
}


