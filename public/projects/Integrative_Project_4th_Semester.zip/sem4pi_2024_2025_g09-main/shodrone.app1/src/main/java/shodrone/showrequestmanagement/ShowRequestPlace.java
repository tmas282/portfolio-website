package shodrone.showrequestmanagement;

import java.util.Objects;

public class ShowRequestPlace {
    private String place;

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        assert place != null;
        this.place = place;
    }
    protected ShowRequestPlace() {
    }
    public ShowRequestPlace(String place) {
        this.place = place;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        ShowRequestPlace that = (ShowRequestPlace) o;
        return Objects.equals(place, that.place);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(place);
    }
}
