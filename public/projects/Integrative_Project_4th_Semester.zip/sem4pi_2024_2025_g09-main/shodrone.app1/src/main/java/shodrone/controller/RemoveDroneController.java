package shodrone.controller;

import org.springframework.stereotype.Controller;
import shodrone.dronemanagement.DroneStatus;
import shodrone.services.DroneService;

import java.time.LocalDate;

@Controller
public class RemoveDroneController {

    private final DroneService droneService;

    public RemoveDroneController(DroneService droneService) {
        this.droneService = droneService;
    }

    public void removeDrone(String serialNumber, String reason, LocalDate date, DroneStatus newStatus) {
        droneService.removeDrone(serialNumber, reason, date, newStatus);
    }
}
