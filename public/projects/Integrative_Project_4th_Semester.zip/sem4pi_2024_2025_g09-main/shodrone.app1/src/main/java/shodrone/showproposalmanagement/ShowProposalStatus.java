package shodrone.showproposalmanagement;

public enum ShowProposalStatus{
        DRAFT, SENT, ACCEPTED, REJECTED, MARKED_AS_ACCEPTED
    }