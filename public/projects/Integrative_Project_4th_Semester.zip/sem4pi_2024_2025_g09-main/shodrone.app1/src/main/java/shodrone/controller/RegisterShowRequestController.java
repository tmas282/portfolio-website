package shodrone.controller;

import org.springframework.stereotype.Controller;
import shodrone.customermanagement.Customer;
import shodrone.customermanagement.VAT;
import shodrone.services.CustomerService;
import shodrone.services.ShowRequestService;
import shodrone.showrequestmanagement.*;

@Controller
public class RegisterShowRequestController {
    private final CustomerService customerService;
    private final ShowRequestService showRequestService;

    public RegisterShowRequestController(CustomerService customerService, ShowRequestService showRequestService) {
        this.customerService = customerService;
        this.showRequestService = showRequestService;
    }

    public boolean checkClientIsRegistered(String vat){
        try{
            customerService.getCustomer(new VAT(vat));
            return true;
        }catch (Exception e) {
            return false;
        }
    }

    public boolean addShowRequest(String vat, String dateTime, int duration, String place, int numberOfDrones, String desc){
        try{
            Customer c = customerService.getCustomer(new VAT(vat));
            ShowRequestDateTime dt = new ShowRequestDateTime(dateTime);
            ShowRequestStatus status = new ShowRequestStatus(ShowRequestStatus.ShowRequestStatusOptions.PENDING);
            ShowRequestDuration d = new ShowRequestDuration(duration);
            ShowRequestPlace p = new ShowRequestPlace(place);
            NumberOfDrones n = new NumberOfDrones(numberOfDrones);
            ShowDescription description = new ShowDescription(desc);
            showRequestService.createShowRequest(c, status, dt, d, p, n, description);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
