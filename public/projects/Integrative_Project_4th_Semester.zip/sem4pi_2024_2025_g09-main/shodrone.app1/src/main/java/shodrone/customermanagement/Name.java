package shodrone.customermanagement;

import jakarta.persistence.Embeddable;

@Embeddable
public class Name {

    private String fullName;

    protected Name() {}

    public Name(String fullName) {
        if (fullName == null || fullName.trim().length() < 2) {
            throw new IllegalArgumentException("Invalid name: must be at least 2 characters long and not null.");
        }
        this.fullName = fullName;
    }

    public String value() {
        return fullName;
    }

    @Override
    public String toString() {
        return fullName;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof Name && fullName.equals(((Name) o).fullName);
    }

    @Override
    public int hashCode() {
        return fullName.hashCode();
    }
}