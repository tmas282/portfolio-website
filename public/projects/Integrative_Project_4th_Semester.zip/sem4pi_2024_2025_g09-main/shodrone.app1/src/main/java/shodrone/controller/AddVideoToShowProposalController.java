package shodrone.controller;

    import org.springframework.stereotype.Controller;
    import shodrone.services.ShowProposalService;
    import shodrone.showproposalmanagement.ShowProposal;

    @Controller
    public class AddVideoToShowProposalController {

        private final ShowProposalService showProposalService;

        public AddVideoToShowProposalController(ShowProposalService showProposalService) {
            this.showProposalService = showProposalService;
        }

        public ShowProposal addSimulationVideoLink(Long proposalId, String videoLink) {
            return showProposalService.addSimulationVideoLink(proposalId, videoLink);
        }
    }