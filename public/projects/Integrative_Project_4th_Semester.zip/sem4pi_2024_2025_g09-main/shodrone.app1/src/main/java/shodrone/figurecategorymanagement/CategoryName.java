package shodrone.figurecategorymanagement;

import jakarta.persistence.Embeddable;

import java.io.Serializable;

@Embeddable
public class CategoryName implements Serializable {

    private String value;

    protected CategoryName() {}

    public CategoryName(final String name) {
        if (name == null || name.isBlank())
            throw new IllegalArgumentException("Category name cannot be blank");
        this.value = name.trim();
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return value;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof CategoryName && value.equalsIgnoreCase(((CategoryName) o).value);
    }

    @Override
    public int hashCode() {
        return value.toLowerCase().hashCode();
    }
}
