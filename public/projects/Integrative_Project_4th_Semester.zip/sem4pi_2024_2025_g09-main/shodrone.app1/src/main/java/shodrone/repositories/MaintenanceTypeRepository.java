package shodrone.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import shodrone.dronemaintenancemanagement.MaintenanceType;

import java.util.Optional;

public interface MaintenanceTypeRepository extends JpaRepository<MaintenanceType, Long> {
}