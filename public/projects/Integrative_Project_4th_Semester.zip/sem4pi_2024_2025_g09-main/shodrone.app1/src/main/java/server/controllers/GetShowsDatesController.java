package server.controllers;

import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import server.dto.ShowProposalDateDTO;
import server.services.GetShowsDatesService;
import shodrone.customermanagement.Email;
import shodrone.customermanagement.VAT;
import java.util.List;

@RestController
public class GetShowsDatesController {

    private final GetShowsDatesService service;

    public GetShowsDatesController(GetShowsDatesService service) {
        this.service = service;
    }

    @GetMapping("/get-shows-dates")
    public List<ShowProposalDateDTO> getShowsDates(Authentication auth) {
        Email email = new Email (auth.getName());
        return service.getShowsDates(email);
    }

}
