package shodrone.dronemodelmanagement;

import jakarta.persistence.Embeddable;
import java.util.Objects;

@Embeddable
public class ProgrammingLanguage{
    private String name;

    protected ProgrammingLanguage() {
    }

    public ProgrammingLanguage(final String name) {
        if (name == null || name.isBlank())
            throw new IllegalArgumentException("Programming language cannot be null or blank.");
        this.name = name.trim();
    }

    public String name() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) return true;
        if (!(o instanceof ProgrammingLanguage)) return false;
        final ProgrammingLanguage that = (ProgrammingLanguage) o;
        return name.equalsIgnoreCase(that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name.toLowerCase());
    }
}