package shodrone.dronemaintenancemanagement;

import jakarta.persistence.Embeddable;

@Embeddable
public class MaintenanceDescription {

    private String description;

    protected MaintenanceDescription() {
        // for JPA
    }

    public MaintenanceDescription(String description) {
        if (description == null || description.isBlank()) {
            throw new IllegalArgumentException("Maintenance description cannot be null or empty.");
        }
        this.description = description.trim();
    }

    public String value() {
        return description;
    }

    @Override
    public String toString() {
        return description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MaintenanceDescription)) return false;
        MaintenanceDescription that = (MaintenanceDescription) o;
        return description.equals(that.description);
    }

    @Override
    public int hashCode() {
        return description.hashCode();
    }
}