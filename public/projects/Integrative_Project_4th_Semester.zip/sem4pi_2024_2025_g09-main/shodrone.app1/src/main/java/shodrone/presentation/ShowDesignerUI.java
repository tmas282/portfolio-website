package shodrone.presentation;

import org.springframework.stereotype.Component;
import shodrone.controller.FigureDSLValidatorController;
import shodrone.controller.FigureCategoryController;
import shodrone.controller.FigureController;
import shodrone.customermanagement.VAT;
import shodrone.figurecategorymanagement.FigureCategory;
import shodrone.figuremanagement.*;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

@Component
public class ShowDesignerUI {

    private final Scanner scanner = new Scanner(System.in);
    private final FigureCategoryController controller;
    private final FigureController figController;

    public ShowDesignerUI(FigureCategoryController controller,
                          FigureController figController) {
        this.controller = controller;
        this.figController = figController;
    }

    public void run() {
        boolean exit = false;

        while (!exit) {
            System.out.println("\n=== Show Designer Menu ===");
            System.out.println("1. Add Figure Category");
            System.out.println("2. Edit Figure Category");
            System.out.println("3. List Figure Categories");
            System.out.println("4. Activate Category");
            System.out.println("5. Deactivate Category");
            System.out.println("6. Validate Figure Description (DSL) Syntax");
            System.out.println("7. Add Figure");
            System.out.println("8. Exit");
            System.out.println("0. Logout");

            System.out.print("Choose an option: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    addFigureCategory();
                    break;
                case "2":
                    editFigureCategory();
                    break;
                case "3":
                    listFigureCategories();
                    break;
                case "4":
                    activateCategory();
                    break;
                case "5":
                    deactivateCategory();
                    break;
                case "6":
                    validateFigureDSL();
                    break;
                case "7":
                    addFigure();
                    break;
                case "8":
                    System.out.println("Exiting...");
                    System.exit(0);
                case "0":
                    System.out.println("Logging out...");
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    private void addFigureCategory() {
        System.out.print("Enter category name: ");
        String name = scanner.nextLine();

        System.out.print("Enter category description: ");
        String description = scanner.nextLine();

        try {
            controller.addCategory(name, description);
            System.out.println("✅ Category added successfully.");
        } catch (IllegalArgumentException e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }


    private void editFigureCategory() {
        System.out.print("Enter current category name: ");
        String currentName = scanner.nextLine();

        System.out.print("Enter new category name: ");
        String newName = scanner.nextLine();

        System.out.print("Enter new category description: ");
        String newDescription = scanner.nextLine();

        try {
            controller.editCategory(currentName, newName, newDescription);
            System.out.println("✅ Category updated successfully.");
        } catch (IllegalArgumentException e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }


    private void listFigureCategories() {
        System.out.println("\n📂 Categories:");
        for (FigureCategory cat : controller.listCategories()) {
            System.out.printf("• %s (%s)%n", cat.name().value(), cat.status().value());
        }
    }


    private void activateCategory() {
        System.out.print("Enter category name to activate: ");
        String name = scanner.nextLine();
        try {
            controller.activateCategory(name);
            System.out.println("✅ Category activated.");
        } catch (Exception e) {
            System.out.println("❌ " + e.getMessage());
        }
    }

    private void deactivateCategory() {
        System.out.print("Enter category name to deactivate: ");
        String name = scanner.nextLine();
        try {
            controller.deactivateCategory(name);
            System.out.println("✅ Category deactivated.");
        } catch (Exception e) {
            System.out.println("❌ " + e.getMessage());
        }
    }

    public void addFigure() {
        long id = 0;
        boolean valid = false;
        System.out.print("Enter the code for the figure");
        while (!valid) {
            System.out.print(": ");
            String code = scanner.nextLine();
            try {
                id = Long.parseLong(code);
                valid = true;
            } catch (NumberFormatException e) {
                System.out.println("Invalid code. Try again.");
            }
        }
        System.out.println("Type a keyword to add to the figure: ");
        List<Keyword> keywords = new ArrayList<>();
        String keyword = scanner.nextLine();
        while (!keyword.equals("")) {
            keywords.add(new Keyword(keyword));
            System.out.println("Type the next keyword you want to add to the figure (Just press enter otherwise): ");
            keyword = scanner.nextLine();
        }
        System.out.println("What category do you want to add the figure to?\n: ");
        for (FigureCategory cat : controller.listCategories()) {
            System.out.println(" - " + cat.name().value());
        }
        String cat_name = scanner.nextLine();
        int res = figController.addFigure(id, keywords, cat_name);
        while (res == 1 || res == 2) {
            if (res == 1) {
                System.out.println("❌ A figure with that code already exists...\nWrite a new code: ");
                id = scanner.nextLong();
                scanner.nextLine();
                res = figController.addFigure(id, keywords, cat_name);
            } else {
                System.out.println("❌ Category name doesn't exist, here's the list of possible categories");
                for (FigureCategory cat : controller.listCategories()) {
                    System.out.println(" - " + cat.name().value());
                }
                cat_name = scanner.nextLine();
                res = figController.addFigure(id, keywords, cat_name);
            }
        }
        System.out.println("Write a description for the figure: ");
        String desc = scanner.nextLine();
        Code code = new Code(id);
        Description description = new Description(desc);
        figController.editDescription(code, description);
        valid = false;
        System.out.print("Is the figure exclusive? If so write the vat of the customer");
        while (!valid) {
            System.out.print(": ");
            String number = scanner.nextLine();
            if (!number.equals("")) {
                try {
                    VAT vat = new VAT(number);
                    Exclusivity exclusivity = new Exclusivity(vat);
                    res = figController.addExclusivity(code, exclusivity);
                    if (res == 2) {
                        System.out.println("❌ Customer doesnt exist, skipping...");
                    }
                } catch (IllegalArgumentException e) {
                    System.out.println("❌ Please insert a valid vat format!");
                }
            } else {
                valid = true;
            }
        }

        System.out.println("✅ Figure added successfully.");
    }

    public void validateFigureDSL() {
        boolean valid = false;
        while (!valid) {
            System.out.print("Enter the path to the DSL file (e.g., src/main/resources/figures/star_logo.txt(.dsl)): ");
            String dslPath = scanner.nextLine();
            File dslFile = new File(dslPath);
            if (!dslFile.exists()) {
                System.out.println("❌ File not found. Try again.");
                continue;
            }
            FigureDSLValidatorController validator = new FigureDSLValidatorController();
            try {
                if (validator.validate(dslFile)) {
                    System.out.println("✅ DSL file is valid!");
                    System.out.print("Do you want to register a figure with this DSL description? (y/n): ");
                    String answer = scanner.nextLine();
                    if (answer.equalsIgnoreCase("y")) {
                        addFigureWithDSL(dslFile);
                    }
                    valid = true;
                } else {
                    System.out.println("❌ DSL is invalid. See errors below. Try again with a valid DSL file.");
                }
            } catch (IOException e) {
                System.out.println("❌ Error reading the DSL file: " + e.getMessage());
            }
        }
    }

    public void addFigureWithDSL(File dslFile) {
        long id = 0;
        boolean valid = false;
        System.out.print("Enter the code for the figure");
        while (!valid) {
            System.out.print(": ");
            String code = scanner.nextLine();
            try {
                id = Long.parseLong(code);
                valid = true;
            } catch (NumberFormatException e) {
                System.out.println("Invalid code. Try again.");
            }
        }
        System.out.println("Type a keyword to add to the figure: ");
        List<Keyword> keywords = new ArrayList<>();
        String keyword = scanner.nextLine();
        while (!keyword.equals("")) {
            keywords.add(new Keyword(keyword));
            System.out.println("Type the next keyword you want to add to the figure (Just press enter otherwise): ");
            keyword = scanner.nextLine();
        }
        System.out.println("What category do you want to add the figure to?\n: ");
        for (FigureCategory cat : controller.listCategories()) {
            if (!controller.listCategories().iterator().hasNext()) {
                System.out.println("❌ There are no categories registered in the system. Please register a figure category first.");
                return;
            }
            System.out.println(" - " + cat.name().value());
        }
        String cat_name = scanner.nextLine();
        int res = figController.addFigure(id, keywords, cat_name);
        while (res == 1 || res == 2) {
            if (res == 1) {
                System.out.println("❌ A figure with that code already exists...\nWrite a new code: ");
                id = scanner.nextLong();
                scanner.nextLine();
                res = figController.addFigure(id, keywords, cat_name);
            } else {
                System.out.println("❌ Category name doesn't exist, here's the list of possible categories");
                for (FigureCategory cat : controller.listCategories()) {
                    System.out.println(" - " + cat.name().value());
                }
                cat_name = scanner.nextLine();
                res = figController.addFigure(id, keywords, cat_name);
            }
        }
        // Em vez de pedir a descrição, usa o DSL
        DSLCode dslCode = new DSLCode(dslFile.getPath());
        Code code = new Code(id);
        figController.addDslCode(code, dslCode);

        valid = false;
        System.out.print("Is the figure exclusive? If so write the vat of the customer");
        while (!valid) {
            System.out.print(": ");
            String number = scanner.nextLine();
            if (!number.equals("")) {
                try {
                    VAT vat = new VAT(number);
                    Exclusivity exclusivity = new Exclusivity(vat);
                    res = figController.addExclusivity(code, exclusivity);
                    if (res == 2) {
                        System.out.println("❌ Customer doesnt exist, skipping...");
                    }
                } catch (IllegalArgumentException e) {
                    System.out.println("❌ Please insert a valid vat format!");
                }
            } else {
                valid = true;
            }
        }

        System.out.println("✅ Figure added successfully with DSL description.");
    }
}
