package shodrone.controller;

import org.springframework.stereotype.Controller;
import shodrone.dronemaintenancemanagement.MaintenanceRecord;
import shodrone.services.DroneMaintenanceService;

import java.time.LocalDate;

@Controller
public class AddMaintenanceRecordController {

    private final DroneMaintenanceService droneMaintenanceService;

    public AddMaintenanceRecordController(DroneMaintenanceService droneMaintenanceService) {
        this.droneMaintenanceService = droneMaintenanceService;
    }

    public MaintenanceRecord addMaintenanceRecord(String serialNumber, Long maintenanceTypeId, String description, LocalDate date) {
        return droneMaintenanceService.addMaintenanceRecord(serialNumber, maintenanceTypeId, description, date);
    }
}