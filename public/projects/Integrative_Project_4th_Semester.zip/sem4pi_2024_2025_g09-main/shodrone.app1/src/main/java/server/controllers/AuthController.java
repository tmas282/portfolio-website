package server.controllers;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import shodrone.repositories.UserRepository;
import shodrone.usermanagement.RoleName;
import shodrone.usermanagement.User;

@RestController
public class AuthController {
    private final UserRepository userRepository;
    public AuthController(UserRepository userRepository){
        this.userRepository = userRepository;
    }
    @GetMapping("/get-user-type")
    public String getUserType(Authentication auth){
        String email = auth.getName();
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));
        return user.role().getRoleName().toString();
    }
}
