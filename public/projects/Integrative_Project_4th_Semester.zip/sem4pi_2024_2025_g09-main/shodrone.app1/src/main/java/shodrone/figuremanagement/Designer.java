package shodrone.figuremanagement;

import eapli.framework.domain.model.ValueObject;
import jakarta.persistence.Embeddable;
import shodrone.customermanagement.Name;

@Embeddable
public class Designer extends Name {
    protected Designer() {};

    public Designer(String name) {
        super(name);
    }
}
