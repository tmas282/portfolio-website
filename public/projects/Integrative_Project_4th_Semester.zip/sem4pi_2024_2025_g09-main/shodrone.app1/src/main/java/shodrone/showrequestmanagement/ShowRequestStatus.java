package shodrone.showrequestmanagement;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Getter;
import lombok.Setter;

@Embeddable
public class ShowRequestStatus{

    @Getter
    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private ShowRequestStatusOptions status;

    public void setStatus(ShowRequestStatusOptions status) {
        assert status != null;
        this.status = status;
    }

    protected ShowRequestStatus(){}
    public ShowRequestStatus(ShowRequestStatusOptions status) {
        assert status != null;
        this.status = status;
    }

    public enum ShowRequestStatusOptions {
        ACCEPTED,
        DECLINED,
        PENDING;
    }

    @Override
    public String toString() {
        return status.toString();
    }
}
