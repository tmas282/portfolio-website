package shodrone.figurecategorymanagement;

import jakarta.persistence.Embeddable;

@Embeddable
public class Description {

    private String text;

    protected Description() {}

    public Description(String raw) {
        if (raw == null || raw.isBlank()) throw new IllegalArgumentException("Description cannot be empty");
        this.text = raw.trim();
    }

    public String value() {
        return text;
    }

    @Override
    public String toString() {
        return text;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof Description && text.equals(((Description) o).text);
    }

    @Override
    public int hashCode() {
        return text.hashCode();
    }
}
