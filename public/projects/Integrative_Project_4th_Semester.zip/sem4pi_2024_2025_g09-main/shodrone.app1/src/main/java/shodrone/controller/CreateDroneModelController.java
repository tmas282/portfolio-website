package shodrone.controller;

import shodrone.dronemodelmanagement.DroneModel;
import shodrone.dronemodelmanagement.WindTolerance;
import shodrone.dronemodelmanagement.MaintenanceThreshold;
import shodrone.services.DroneModelService;
import org.springframework.stereotype.Controller;

@Controller
public class CreateDroneModelController {

    private final DroneModelService droneModelService;

    public CreateDroneModelController(DroneModelService droneModelService) {
        this.droneModelService = droneModelService;
    }

    public DroneModel createDroneModel(String modelID, String programmingLanguage, WindTolerance tolerance, MaintenanceThreshold maintenanceThreshold) {
        return droneModelService.createDroneModel(modelID, programmingLanguage, tolerance, maintenanceThreshold);
    }
}