package shodrone.services;


import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import shodrone.proposaltemplate.en.ProposalTemplateENValidator;
import shodrone.proposaltemplate.pt.ProposalTemplatePTValidator;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;


@Service
public class TemplateService {

    public int configureTemplate(String filepath) {
        if (validateTemplateEN(filepath) || validateTemplatePT(filepath)) {
            try {
                // Create a File object from the filepath
                File templateFile = new File(filepath);

                // Check if the file exists
                if (!templateFile.exists()) {
                    System.err.println("File not found: " + filepath);
                    return 1;
                }

                // Validate the template using the ProposalTemplateValidator


                // If the template is valid, save it to the resources folder

                    // Get the filename from the filepath
                    String fileName = templateFile.getName();

                    // Define the destination path in the resources folder
                    Path destinationPath = Paths.get("shodrone.app1", "src", "main", "resources", fileName);

                    // Copy the file to the resources folder, replacing if it already exists
                    Files.copy(templateFile.toPath(), destinationPath, StandardCopyOption.REPLACE_EXISTING);

                    System.out.println("Template successfully saved to: " + destinationPath);
                    return 0;
            } catch (IOException e) {
                System.err.println("Error processing template file: " + e.getMessage());
                return 2;
            }
        }
        return 3;
    }

    /**
     * Validates a proposal template file using the ANTLR parser.
     *
     * @param templateFile The template file to validate
     * @return true if the template is valid, false otherwise
     */
    private boolean validateTemplateEN(String templateFile) {
        ProposalTemplateENValidator validator = new ProposalTemplateENValidator();
        return validator.validate(templateFile);
    }

    private boolean validateTemplatePT(String templateFile) {
        ProposalTemplatePTValidator validator = new ProposalTemplatePTValidator();
        return validator.validate(templateFile);
    }

}
