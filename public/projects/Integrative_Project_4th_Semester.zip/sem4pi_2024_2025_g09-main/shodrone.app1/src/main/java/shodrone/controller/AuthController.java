package shodrone.controller;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import shodrone.repositories.UserRepository;
import shodrone.usermanagement.User;

import java.util.Optional;

@Controller
public class AuthController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public AuthController(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public User authenticate(String email, String password) {
        Optional<User> optionalUser = userRepository.findByEmail(email);

        if (optionalUser.isPresent()) {
            User user = optionalUser.get();

            if (!user.isEnabled()) {
                System.out.println("❌ User is disabled.");
                return null;
            }

            if (passwordEncoder.matches(password, user.password())) {
                System.out.println("✅ Login successful as " + user.email());
                return user;
            } else {
                System.out.println("❌ Invalid password.");
            }
        } else {
            System.out.println("❌ User not found.");
        }
        return null;
    }
}