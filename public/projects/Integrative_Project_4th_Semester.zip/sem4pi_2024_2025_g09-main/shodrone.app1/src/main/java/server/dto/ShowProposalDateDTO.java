package server.dto;

import java.time.LocalDate;

public record ShowProposalDateDTO(Long id, LocalDate date) {
}
