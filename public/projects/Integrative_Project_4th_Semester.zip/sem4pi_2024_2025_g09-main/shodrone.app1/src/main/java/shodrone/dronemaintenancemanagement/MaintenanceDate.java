package shodrone.dronemaintenancemanagement;

import jakarta.persistence.Embeddable;

import java.time.LocalDate;
import java.util.Objects;

@Embeddable
public class MaintenanceDate {

    private LocalDate date;

    protected MaintenanceDate() {
        // for JPA
    }

    public MaintenanceDate(LocalDate date) {
        if (date == null) {
            throw new IllegalArgumentException("Maintenance date cannot be null.");
        }
        this.date = date;
    }

    public LocalDate value() {
        return date;
    }

    @Override
    public String toString() {
        return date.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MaintenanceDate)) return false;
        MaintenanceDate that = (MaintenanceDate) o;
        return date.equals(that.date);
    }

    @Override
    public int hashCode() {
        return Objects.hash(date);
    }
}