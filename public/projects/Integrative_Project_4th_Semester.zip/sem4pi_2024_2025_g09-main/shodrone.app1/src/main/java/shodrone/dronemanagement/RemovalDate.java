package shodrone.dronemanagement;

import jakarta.persistence.Embeddable;
import java.time.LocalDate;
import java.util.Objects;

@Embeddable
public class RemovalDate{

    private LocalDate date;

    protected RemovalDate() {
        // for JPA
    }

    public RemovalDate(LocalDate date) {
        if (date == null)
            throw new IllegalArgumentException("Removal date cannot be null.");
        this.date = date;
    }

    public LocalDate value() {
        return date;
    }

    @Override
    public String toString() {
        return date.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof RemovalDate)) return false;
        RemovalDate that = (RemovalDate) o;
        return date.equals(that.date);
    }

    @Override
    public int hashCode() {
        return Objects.hash(date);
    }
}
