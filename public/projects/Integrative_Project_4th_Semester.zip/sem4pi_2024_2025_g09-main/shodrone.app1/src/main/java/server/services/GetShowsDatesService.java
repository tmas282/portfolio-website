package server.services;

import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;
import server.dto.ShowProposalDateDTO;
import shodrone.customermanagement.Customer;
import shodrone.customermanagement.Email;
import shodrone.customermanagement.VAT;
import shodrone.repositories.CustomerRepository;
import shodrone.repositories.ShowProposalRepository;
import shodrone.showproposalmanagement.ShowProposal;
import shodrone.showproposalmanagement.ShowProposalStatus;
import shodrone.showrequestmanagement.ShowRequest;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Service
public class GetShowsDatesService {

    private final CustomerRepository customerRepository;
    private final ShowProposalRepository showProposalRepository;

    public GetShowsDatesService(CustomerRepository customerRepository,
                                ShowProposalRepository showProposalRepository) {
        this.customerRepository = customerRepository;
        this.showProposalRepository = showProposalRepository;
    }

    @Transactional
    public List<ShowProposalDateDTO> getShowsDates(Email email) {
        Customer customer = customerRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("Customer not found: " + email));

        List<ShowProposalDateDTO> scheduledDates = new ArrayList<>();

        for (ShowRequest request : customer.getShowRequests()) {
            List<ShowProposal> proposals = showProposalRepository.findByShowRequest(request);
            for (ShowProposal proposal : proposals) {
                if (proposal.getStatus() == ShowProposalStatus.ACCEPTED && proposal.getDate() != null) {
                    scheduledDates.add(new ShowProposalDateDTO(proposal.getId(), proposal.getDate().value()));
                }
            }
        }

        scheduledDates.sort(Comparator.comparing(ShowProposalDateDTO::date));
        return scheduledDates;
    }
}
