package shodrone.controller;

import org.springframework.stereotype.Controller;
import shodrone.services.UserService;
import shodrone.usermanagement.User;

import java.util.List;

@Controller
public class ManageUsersController {

    private final UserService userService;

    public ManageUsersController(UserService userService) {
        this.userService = userService;
    }

    public boolean disable(String email) {
        return userService.disableUser(email);
    }

    public boolean enable(String email) {
        return userService.enableUser(email);
    }

    public List<User> listAll() {
        return userService.listAllUsers();
    }
}
