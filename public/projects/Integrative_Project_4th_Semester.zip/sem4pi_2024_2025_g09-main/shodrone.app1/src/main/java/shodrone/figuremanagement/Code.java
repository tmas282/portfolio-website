package shodrone.figuremanagement;

import eapli.framework.domain.model.ValueObject;
import jakarta.persistence.Embeddable;
import shodrone.customermanagement.Address;

@Embeddable
public class Code {
    private long id;

    protected Code() {}

    public Code(long id){
        this.id = id;
    }

    public long value() {
        return id;
    }

    @Override
    public String toString() {
        return "Id: " + id;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof Code && id == (((Code) o).id);
    }

}
