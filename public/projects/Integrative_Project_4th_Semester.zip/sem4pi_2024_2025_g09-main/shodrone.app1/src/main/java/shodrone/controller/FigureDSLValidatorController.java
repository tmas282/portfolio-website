package shodrone.controller;

import org.antlr.v4.runtime.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import integrations.plugins.figure.alternate.FigureDSLLexer;
import integrations.plugins.figure.alternate.FigureDSLParser;

public class FigureDSLValidatorController {

    public boolean validate(File dslFile) throws IOException {
        CharStream input = CharStreams.fromStream(new FileInputStream(dslFile));
        FigureDSLLexer lexer = new FigureDSLLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        FigureDSLParser parser = new FigureDSLParser(tokens);

        // Regista listener de erro personalizado
        SyntaxErrorListener errorListener = new SyntaxErrorListener();
        parser.removeErrorListeners(); // remove default ConsoleErrorListener
        parser.addErrorListener(errorListener);

        parser.program(); // regra inicial

        return !errorListener.hasErrors();
    }

    private static class SyntaxErrorListener extends BaseErrorListener {
        private boolean hasErrors = false;

        @Override
        public void syntaxError(Recognizer<?, ?> recognizer,
                                Object offendingSymbol,
                                int line, int charPositionInLine,
                                String msg, RecognitionException e) {
            hasErrors = true;
            System.err.printf("Erro de sintaxe na linha %d:%d - %s%n", line, charPositionInLine, msg);
        }

        public boolean hasErrors() {
            return hasErrors;
        }
    }
}
