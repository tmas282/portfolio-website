package shodrone.customermanagement;

public enum CustomerType {
    REGULAR, VIP
}
