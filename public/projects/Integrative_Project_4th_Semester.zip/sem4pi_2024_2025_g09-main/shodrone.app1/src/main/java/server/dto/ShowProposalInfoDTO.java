package server.dto;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Duration;
import java.util.List;

public record ShowProposalInfoDTO(
    Long id,
    LocalDate date,
    LocalTime time,
    Duration duration,
    String place,
    int numberOfDrones,
    String description,
    String status,
    List<String> figures // nomes das figuras
) {}