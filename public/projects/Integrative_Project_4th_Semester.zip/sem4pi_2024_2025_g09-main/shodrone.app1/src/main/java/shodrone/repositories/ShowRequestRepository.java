package shodrone.repositories;

import shodrone.customermanagement.Customer;
import shodrone.showrequestmanagement.ShowRequest;
import shodrone.usermanagement.Role;
import shodrone.usermanagement.RoleName;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ShowRequestRepository extends JpaRepository<ShowRequest, Long> {
    Optional<ShowRequest> findById(int id);
    List<ShowRequest> findByCustomer(Customer customer);
}
