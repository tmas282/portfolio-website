// Generated from C:/Users/afons/sem4pi_2024_2025_g09/shodrone.app1/src/main/java/shodrone/proposaltemplate/en/DroneShowTemplateEN.g4 by ANTLR 4.13.2
package shodrone.proposaltemplate.en;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue", "this-escape"})
public class DroneShowTemplateENParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.13.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, T__8=9, 
		T__9=10, T__10=11, T__11=12, T__12=13, T__13=14, T__14=15, T__15=16, T__16=17, 
		T__17=18, T__18=19, T__19=20, T__20=21, T__21=22, T__22=23, T__23=24, 
		T__24=25, T__25=26, T__26=27, T__27=28, T__28=29, T__29=30, T__30=31, 
		T__31=32, T__32=33, T__33=34, T__34=35, T__35=36, T__36=37, WS=38, NEWLINE=39, 
		COPYRIGHT=40, DASH=41, EURO=42, MONEY=43, INT=44, FLOAT=45, TEXT=46, NAME=47, 
		LINK_TO_VIDEO=48, DIGIT=49;
	public static final int
		RULE_document = 0, RULE_salutation = 1, RULE_clientCompany = 2, RULE_clientLocation = 3, 
		RULE_vat = 4, RULE_documentID = 5, RULE_videoURL = 6, RULE_insuranceAmount = 7, 
		RULE_signatoryName = 8, RULE_pageOne = 9, RULE_pageTwo = 10, RULE_headerSection = 11, 
		RULE_introContent = 12, RULE_proposalID = 13, RULE_proposalDate = 14, 
		RULE_eventDate = 15, RULE_zipCode = 16, RULE_eventTime = 17, RULE_eventLength = 18, 
		RULE_gpsLat = 19, RULE_gpsLong = 20, RULE_attachmentDetails = 21, RULE_droneModel = 22, 
		RULE_droneCount = 23, RULE_droneEntry = 24, RULE_equipmentList = 25, RULE_figureNum = 26, 
		RULE_figureName = 27, RULE_figureEntry = 28, RULE_performanceElements = 29;
	private static String[] makeRuleNames() {
		return new String[] {
			"document", "salutation", "clientCompany", "clientLocation", "vat", "documentID", 
			"videoURL", "insuranceAmount", "signatoryName", "pageOne", "pageTwo", 
			"headerSection", "introContent", "proposalID", "proposalDate", "eventDate", 
			"zipCode", "eventTime", "eventLength", "gpsLat", "gpsLong", "attachmentDetails", 
			"droneModel", "droneCount", "droneEntry", "equipmentList", "figureNum", 
			"figureName", "figureEntry", "performanceElements"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "';'", "'Reference '", "' / '", "'Show Proposal'", "'Shodrone is pleased to submit for your consideration a proposal for the execution of an aerial show with drones, as described below.'", 
			"'Shodrone is a company that prioritizes safety, which is why it uses the most advanced AI technology to support the development of its shows, with all shows being previously and carefully tested/simulated with AI-Test'", 
			"' technology before being presented to the client. In the link '", "' there is a video with a simulation of the proposed show.'", 
			"'With the application of AI-Test'", "', a Shodrone exclusive, we are confident in offering liability insurance in the amount of '", 
			"' for the show. Detailed show data is presented in the attachment.'", 
			"'Being certain that we will be the target of your preference.'", "'We subscribe at your disposal.'", 
			"'Best regards,'", "'CRM Manager'", "'[page break]'", "'-'", "' hours;'", 
			"' minutes;'", "' seconds'", "'North'", "'South'", "'West'", "'East'", 
			"'Attachment '", "' Show Details '", "'Location '", "' latitude: '", 
			"'; longitude: '", "'Date '", "' '", "'Time '", "'Duration '", "' minutes'", 
			"' units.'", "'#List of used drones'", "'#List of figures'", null, null, 
			"'\\u00A9'", null, "'\\u20AC'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, "WS", "NEWLINE", "COPYRIGHT", "DASH", "EURO", "MONEY", "INT", 
			"FLOAT", "TEXT", "NAME", "LINK_TO_VIDEO", "DIGIT"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "DroneShowTemplateEN.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public DroneShowTemplateENParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DocumentContext extends ParserRuleContext {
		public PageOneContext pageOne() {
			return getRuleContext(PageOneContext.class,0);
		}
		public PageTwoContext pageTwo() {
			return getRuleContext(PageTwoContext.class,0);
		}
		public TerminalNode EOF() { return getToken(DroneShowTemplateENParser.EOF, 0); }
		public DocumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_document; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterDocument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitDocument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitDocument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DocumentContext document() throws RecognitionException {
		DocumentContext _localctx = new DocumentContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_document);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(60);
			pageOne();
			setState(61);
			pageTwo();
			setState(62);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SalutationContext extends ParserRuleContext {
		public TerminalNode TEXT() { return getToken(DroneShowTemplateENParser.TEXT, 0); }
		public SalutationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_salutation; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterSalutation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitSalutation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitSalutation(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SalutationContext salutation() throws RecognitionException {
		SalutationContext _localctx = new SalutationContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_salutation);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(64);
			match(TEXT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ClientCompanyContext extends ParserRuleContext {
		public TerminalNode TEXT() { return getToken(DroneShowTemplateENParser.TEXT, 0); }
		public TerminalNode NAME() { return getToken(DroneShowTemplateENParser.NAME, 0); }
		public ClientCompanyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_clientCompany; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterClientCompany(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitClientCompany(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitClientCompany(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ClientCompanyContext clientCompany() throws RecognitionException {
		ClientCompanyContext _localctx = new ClientCompanyContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_clientCompany);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(66);
			_la = _input.LA(1);
			if ( !(_la==TEXT || _la==NAME) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ClientLocationContext extends ParserRuleContext {
		public ClientLocationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_clientLocation; }
	 
		public ClientLocationContext() { }
		public void copyFrom(ClientLocationContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ClientLocationFieldContext extends ClientLocationContext {
		public List<TerminalNode> TEXT() { return getTokens(DroneShowTemplateENParser.TEXT); }
		public TerminalNode TEXT(int i) {
			return getToken(DroneShowTemplateENParser.TEXT, i);
		}
		public ZipCodeContext zipCode() {
			return getRuleContext(ZipCodeContext.class,0);
		}
		public List<TerminalNode> INT() { return getTokens(DroneShowTemplateENParser.INT); }
		public TerminalNode INT(int i) {
			return getToken(DroneShowTemplateENParser.INT, i);
		}
		public ClientLocationFieldContext(ClientLocationContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterClientLocationField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitClientLocationField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitClientLocationField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ClientLocationContext clientLocation() throws RecognitionException {
		ClientLocationContext _localctx = new ClientLocationContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_clientLocation);
		int _la;
		try {
			_localctx = new ClientLocationFieldContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(69); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(68);
				_la = _input.LA(1);
				if ( !(_la==INT || _la==TEXT) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				}
				setState(71); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==INT || _la==TEXT );
			setState(73);
			match(T__0);
			setState(74);
			match(TEXT);
			setState(75);
			match(T__0);
			setState(76);
			zipCode();
			setState(77);
			match(T__0);
			setState(78);
			match(TEXT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class VatContext extends ParserRuleContext {
		public VatContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_vat; }
	 
		public VatContext() { }
		public void copyFrom(VatContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class VatFieldContext extends VatContext {
		public TerminalNode INT() { return getToken(DroneShowTemplateENParser.INT, 0); }
		public VatFieldContext(VatContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterVatField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitVatField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitVatField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final VatContext vat() throws RecognitionException {
		VatContext _localctx = new VatContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_vat);
		try {
			_localctx = new VatFieldContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(80);
			match(INT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DocumentIDContext extends ParserRuleContext {
		public ProposalIDContext proposalID() {
			return getRuleContext(ProposalIDContext.class,0);
		}
		public ProposalDateContext proposalDate() {
			return getRuleContext(ProposalDateContext.class,0);
		}
		public DocumentIDContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_documentID; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterDocumentID(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitDocumentID(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitDocumentID(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DocumentIDContext documentID() throws RecognitionException {
		DocumentIDContext _localctx = new DocumentIDContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_documentID);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(82);
			match(T__1);
			setState(83);
			proposalID();
			setState(84);
			match(T__2);
			setState(85);
			proposalDate();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class VideoURLContext extends ParserRuleContext {
		public VideoURLContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_videoURL; }
	 
		public VideoURLContext() { }
		public void copyFrom(VideoURLContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class VideoURLFieldContext extends VideoURLContext {
		public TerminalNode LINK_TO_VIDEO() { return getToken(DroneShowTemplateENParser.LINK_TO_VIDEO, 0); }
		public VideoURLFieldContext(VideoURLContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterVideoURLField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitVideoURLField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitVideoURLField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final VideoURLContext videoURL() throws RecognitionException {
		VideoURLContext _localctx = new VideoURLContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_videoURL);
		try {
			_localctx = new VideoURLFieldContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(87);
			match(LINK_TO_VIDEO);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InsuranceAmountContext extends ParserRuleContext {
		public InsuranceAmountContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_insuranceAmount; }
	 
		public InsuranceAmountContext() { }
		public void copyFrom(InsuranceAmountContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class InsuranceAmountFieldContext extends InsuranceAmountContext {
		public TerminalNode FLOAT() { return getToken(DroneShowTemplateENParser.FLOAT, 0); }
		public TerminalNode EURO() { return getToken(DroneShowTemplateENParser.EURO, 0); }
		public InsuranceAmountFieldContext(InsuranceAmountContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterInsuranceAmountField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitInsuranceAmountField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitInsuranceAmountField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InsuranceAmountContext insuranceAmount() throws RecognitionException {
		InsuranceAmountContext _localctx = new InsuranceAmountContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_insuranceAmount);
		try {
			_localctx = new InsuranceAmountFieldContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(89);
			match(FLOAT);
			setState(90);
			match(EURO);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SignatoryNameContext extends ParserRuleContext {
		public TerminalNode TEXT() { return getToken(DroneShowTemplateENParser.TEXT, 0); }
		public TerminalNode NAME() { return getToken(DroneShowTemplateENParser.NAME, 0); }
		public SignatoryNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_signatoryName; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterSignatoryName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitSignatoryName(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitSignatoryName(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SignatoryNameContext signatoryName() throws RecognitionException {
		SignatoryNameContext _localctx = new SignatoryNameContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_signatoryName);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(92);
			_la = _input.LA(1);
			if ( !(_la==TEXT || _la==NAME) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PageOneContext extends ParserRuleContext {
		public HeaderSectionContext headerSection() {
			return getRuleContext(HeaderSectionContext.class,0);
		}
		public IntroContentContext introContent() {
			return getRuleContext(IntroContentContext.class,0);
		}
		public PageOneContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pageOne; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterPageOne(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitPageOne(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitPageOne(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PageOneContext pageOne() throws RecognitionException {
		PageOneContext _localctx = new PageOneContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_pageOne);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(94);
			headerSection();
			setState(95);
			introContent();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PageTwoContext extends ParserRuleContext {
		public AttachmentDetailsContext attachmentDetails() {
			return getRuleContext(AttachmentDetailsContext.class,0);
		}
		public EquipmentListContext equipmentList() {
			return getRuleContext(EquipmentListContext.class,0);
		}
		public PerformanceElementsContext performanceElements() {
			return getRuleContext(PerformanceElementsContext.class,0);
		}
		public PageTwoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pageTwo; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterPageTwo(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitPageTwo(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitPageTwo(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PageTwoContext pageTwo() throws RecognitionException {
		PageTwoContext _localctx = new PageTwoContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_pageTwo);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(97);
			attachmentDetails();
			setState(98);
			equipmentList();
			setState(99);
			performanceElements();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class HeaderSectionContext extends ParserRuleContext {
		public SalutationContext salutation() {
			return getRuleContext(SalutationContext.class,0);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(DroneShowTemplateENParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(DroneShowTemplateENParser.NEWLINE, i);
		}
		public ClientCompanyContext clientCompany() {
			return getRuleContext(ClientCompanyContext.class,0);
		}
		public ClientLocationContext clientLocation() {
			return getRuleContext(ClientLocationContext.class,0);
		}
		public VatContext vat() {
			return getRuleContext(VatContext.class,0);
		}
		public DocumentIDContext documentID() {
			return getRuleContext(DocumentIDContext.class,0);
		}
		public HeaderSectionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_headerSection; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterHeaderSection(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitHeaderSection(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitHeaderSection(this);
			else return visitor.visitChildren(this);
		}
	}

	public final HeaderSectionContext headerSection() throws RecognitionException {
		HeaderSectionContext _localctx = new HeaderSectionContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_headerSection);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(101);
			salutation();
			setState(102);
			match(NEWLINE);
			setState(103);
			clientCompany();
			setState(104);
			match(NEWLINE);
			setState(105);
			clientLocation();
			setState(106);
			match(NEWLINE);
			setState(107);
			vat();
			setState(109); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(108);
				match(NEWLINE);
				}
				}
				setState(111); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==NEWLINE );
			setState(113);
			documentID();
			setState(114);
			match(NEWLINE);
			setState(115);
			match(T__3);
			setState(117); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(116);
				match(NEWLINE);
				}
				}
				setState(119); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==NEWLINE );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IntroContentContext extends ParserRuleContext {
		public List<TerminalNode> NEWLINE() { return getTokens(DroneShowTemplateENParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(DroneShowTemplateENParser.NEWLINE, i);
		}
		public List<TerminalNode> COPYRIGHT() { return getTokens(DroneShowTemplateENParser.COPYRIGHT); }
		public TerminalNode COPYRIGHT(int i) {
			return getToken(DroneShowTemplateENParser.COPYRIGHT, i);
		}
		public VideoURLContext videoURL() {
			return getRuleContext(VideoURLContext.class,0);
		}
		public InsuranceAmountContext insuranceAmount() {
			return getRuleContext(InsuranceAmountContext.class,0);
		}
		public SignatoryNameContext signatoryName() {
			return getRuleContext(SignatoryNameContext.class,0);
		}
		public IntroContentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_introContent; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterIntroContent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitIntroContent(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitIntroContent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IntroContentContext introContent() throws RecognitionException {
		IntroContentContext _localctx = new IntroContentContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_introContent);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(121);
			match(T__4);
			setState(122);
			match(NEWLINE);
			setState(123);
			match(T__5);
			setState(124);
			match(COPYRIGHT);
			setState(125);
			match(T__6);
			setState(126);
			videoURL();
			setState(127);
			match(T__7);
			setState(129); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(128);
				match(NEWLINE);
				}
				}
				setState(131); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==NEWLINE );
			setState(133);
			match(T__8);
			setState(134);
			match(COPYRIGHT);
			setState(135);
			match(T__9);
			setState(136);
			insuranceAmount();
			setState(137);
			match(T__10);
			setState(139); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(138);
				match(NEWLINE);
				}
				}
				setState(141); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==NEWLINE );
			setState(143);
			match(T__11);
			setState(145); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(144);
				match(NEWLINE);
				}
				}
				setState(147); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==NEWLINE );
			setState(149);
			match(T__12);
			setState(151); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(150);
				match(NEWLINE);
				}
				}
				setState(153); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==NEWLINE );
			setState(155);
			match(T__13);
			setState(157); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(156);
				match(NEWLINE);
				}
				}
				setState(159); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==NEWLINE );
			setState(161);
			signatoryName();
			setState(162);
			match(NEWLINE);
			setState(163);
			match(T__14);
			setState(165); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(164);
				match(NEWLINE);
				}
				}
				setState(167); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==NEWLINE );
			setState(169);
			match(T__15);
			setState(171); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(170);
				match(NEWLINE);
				}
				}
				setState(173); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==NEWLINE );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ProposalIDContext extends ParserRuleContext {
		public ProposalIDContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_proposalID; }
	 
		public ProposalIDContext() { }
		public void copyFrom(ProposalIDContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ProposalIDFieldContext extends ProposalIDContext {
		public TerminalNode INT() { return getToken(DroneShowTemplateENParser.INT, 0); }
		public ProposalIDFieldContext(ProposalIDContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterProposalIDField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitProposalIDField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitProposalIDField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ProposalIDContext proposalID() throws RecognitionException {
		ProposalIDContext _localctx = new ProposalIDContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_proposalID);
		try {
			_localctx = new ProposalIDFieldContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(175);
			match(INT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ProposalDateContext extends ParserRuleContext {
		public ProposalDateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_proposalDate; }
	 
		public ProposalDateContext() { }
		public void copyFrom(ProposalDateContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ProposalDateFieldContext extends ProposalDateContext {
		public List<TerminalNode> INT() { return getTokens(DroneShowTemplateENParser.INT); }
		public TerminalNode INT(int i) {
			return getToken(DroneShowTemplateENParser.INT, i);
		}
		public ProposalDateFieldContext(ProposalDateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterProposalDateField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitProposalDateField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitProposalDateField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ProposalDateContext proposalDate() throws RecognitionException {
		ProposalDateContext _localctx = new ProposalDateContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_proposalDate);
		try {
			_localctx = new ProposalDateFieldContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(177);
			match(INT);
			setState(178);
			match(T__16);
			setState(179);
			match(INT);
			setState(180);
			match(T__16);
			setState(181);
			match(INT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EventDateContext extends ParserRuleContext {
		public EventDateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_eventDate; }
	 
		public EventDateContext() { }
		public void copyFrom(EventDateContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EventDateFieldContext extends EventDateContext {
		public List<TerminalNode> INT() { return getTokens(DroneShowTemplateENParser.INT); }
		public TerminalNode INT(int i) {
			return getToken(DroneShowTemplateENParser.INT, i);
		}
		public EventDateFieldContext(EventDateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterEventDateField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitEventDateField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitEventDateField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EventDateContext eventDate() throws RecognitionException {
		EventDateContext _localctx = new EventDateContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_eventDate);
		try {
			_localctx = new EventDateFieldContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(183);
			match(INT);
			setState(184);
			match(T__16);
			setState(185);
			match(INT);
			setState(186);
			match(T__16);
			setState(187);
			match(INT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ZipCodeContext extends ParserRuleContext {
		public ZipCodeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_zipCode; }
	 
		public ZipCodeContext() { }
		public void copyFrom(ZipCodeContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ZipCodeFieldContext extends ZipCodeContext {
		public List<TerminalNode> INT() { return getTokens(DroneShowTemplateENParser.INT); }
		public TerminalNode INT(int i) {
			return getToken(DroneShowTemplateENParser.INT, i);
		}
		public ZipCodeFieldContext(ZipCodeContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterZipCodeField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitZipCodeField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitZipCodeField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ZipCodeContext zipCode() throws RecognitionException {
		ZipCodeContext _localctx = new ZipCodeContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_zipCode);
		try {
			_localctx = new ZipCodeFieldContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(189);
			match(INT);
			setState(190);
			match(T__16);
			setState(191);
			match(INT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EventTimeContext extends ParserRuleContext {
		public EventTimeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_eventTime; }
	 
		public EventTimeContext() { }
		public void copyFrom(EventTimeContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EventTimeFieldContext extends EventTimeContext {
		public List<TerminalNode> INT() { return getTokens(DroneShowTemplateENParser.INT); }
		public TerminalNode INT(int i) {
			return getToken(DroneShowTemplateENParser.INT, i);
		}
		public EventTimeFieldContext(EventTimeContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterEventTimeField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitEventTimeField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitEventTimeField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EventTimeContext eventTime() throws RecognitionException {
		EventTimeContext _localctx = new EventTimeContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_eventTime);
		try {
			_localctx = new EventTimeFieldContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(193);
			match(INT);
			setState(194);
			match(T__17);
			setState(195);
			match(INT);
			setState(196);
			match(T__18);
			setState(197);
			match(INT);
			setState(198);
			match(T__19);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EventLengthContext extends ParserRuleContext {
		public EventLengthContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_eventLength; }
	 
		public EventLengthContext() { }
		public void copyFrom(EventLengthContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EventLengthFieldContext extends EventLengthContext {
		public TerminalNode INT() { return getToken(DroneShowTemplateENParser.INT, 0); }
		public EventLengthFieldContext(EventLengthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterEventLengthField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitEventLengthField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitEventLengthField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EventLengthContext eventLength() throws RecognitionException {
		EventLengthContext _localctx = new EventLengthContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_eventLength);
		try {
			_localctx = new EventLengthFieldContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(200);
			match(INT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GpsLatContext extends ParserRuleContext {
		public GpsLatContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_gpsLat; }
	 
		public GpsLatContext() { }
		public void copyFrom(GpsLatContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class GpsLatFieldContext extends GpsLatContext {
		public TerminalNode FLOAT() { return getToken(DroneShowTemplateENParser.FLOAT, 0); }
		public GpsLatFieldContext(GpsLatContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterGpsLatField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitGpsLatField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitGpsLatField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GpsLatContext gpsLat() throws RecognitionException {
		GpsLatContext _localctx = new GpsLatContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_gpsLat);
		int _la;
		try {
			_localctx = new GpsLatFieldContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(202);
			match(FLOAT);
			setState(203);
			_la = _input.LA(1);
			if ( !(_la==T__20 || _la==T__21) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GpsLongContext extends ParserRuleContext {
		public GpsLongContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_gpsLong; }
	 
		public GpsLongContext() { }
		public void copyFrom(GpsLongContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class GpsLongFieldContext extends GpsLongContext {
		public TerminalNode FLOAT() { return getToken(DroneShowTemplateENParser.FLOAT, 0); }
		public GpsLongFieldContext(GpsLongContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterGpsLongField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitGpsLongField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitGpsLongField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GpsLongContext gpsLong() throws RecognitionException {
		GpsLongContext _localctx = new GpsLongContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_gpsLong);
		int _la;
		try {
			_localctx = new GpsLongFieldContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(205);
			match(FLOAT);
			setState(206);
			_la = _input.LA(1);
			if ( !(_la==T__22 || _la==T__23) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AttachmentDetailsContext extends ParserRuleContext {
		public List<TerminalNode> DASH() { return getTokens(DroneShowTemplateENParser.DASH); }
		public TerminalNode DASH(int i) {
			return getToken(DroneShowTemplateENParser.DASH, i);
		}
		public ProposalIDContext proposalID() {
			return getRuleContext(ProposalIDContext.class,0);
		}
		public GpsLatContext gpsLat() {
			return getRuleContext(GpsLatContext.class,0);
		}
		public GpsLongContext gpsLong() {
			return getRuleContext(GpsLongContext.class,0);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(DroneShowTemplateENParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(DroneShowTemplateENParser.NEWLINE, i);
		}
		public EventDateContext eventDate() {
			return getRuleContext(EventDateContext.class,0);
		}
		public EventTimeContext eventTime() {
			return getRuleContext(EventTimeContext.class,0);
		}
		public EventLengthContext eventLength() {
			return getRuleContext(EventLengthContext.class,0);
		}
		public AttachmentDetailsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_attachmentDetails; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterAttachmentDetails(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitAttachmentDetails(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitAttachmentDetails(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AttachmentDetailsContext attachmentDetails() throws RecognitionException {
		AttachmentDetailsContext _localctx = new AttachmentDetailsContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_attachmentDetails);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(208);
			match(T__24);
			setState(209);
			match(DASH);
			setState(210);
			match(T__25);
			setState(211);
			proposalID();
			setState(213); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(212);
				match(NEWLINE);
				}
				}
				setState(215); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==NEWLINE );
			setState(217);
			match(T__26);
			setState(218);
			match(DASH);
			setState(219);
			match(T__27);
			setState(220);
			gpsLat();
			setState(221);
			match(T__28);
			setState(222);
			gpsLong();
			setState(223);
			match(NEWLINE);
			setState(224);
			match(T__29);
			setState(225);
			match(DASH);
			setState(226);
			match(T__30);
			setState(227);
			eventDate();
			setState(228);
			match(NEWLINE);
			setState(229);
			match(T__31);
			setState(230);
			match(DASH);
			setState(231);
			match(T__30);
			setState(232);
			eventTime();
			setState(233);
			match(NEWLINE);
			setState(234);
			match(T__32);
			setState(235);
			match(DASH);
			setState(236);
			match(T__30);
			setState(237);
			eventLength();
			setState(238);
			match(T__33);
			setState(240); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(239);
				match(NEWLINE);
				}
				}
				setState(242); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==NEWLINE );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DroneModelContext extends ParserRuleContext {
		public TerminalNode NAME() { return getToken(DroneShowTemplateENParser.NAME, 0); }
		public TerminalNode TEXT() { return getToken(DroneShowTemplateENParser.TEXT, 0); }
		public DroneModelContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_droneModel; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterDroneModel(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitDroneModel(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitDroneModel(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DroneModelContext droneModel() throws RecognitionException {
		DroneModelContext _localctx = new DroneModelContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_droneModel);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(244);
			_la = _input.LA(1);
			if ( !(_la==TEXT || _la==NAME) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DroneCountContext extends ParserRuleContext {
		public DroneCountContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_droneCount; }
	 
		public DroneCountContext() { }
		public void copyFrom(DroneCountContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DroneCountFieldContext extends DroneCountContext {
		public TerminalNode INT() { return getToken(DroneShowTemplateENParser.INT, 0); }
		public DroneCountFieldContext(DroneCountContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterDroneCountField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitDroneCountField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitDroneCountField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DroneCountContext droneCount() throws RecognitionException {
		DroneCountContext _localctx = new DroneCountContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_droneCount);
		try {
			_localctx = new DroneCountFieldContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(246);
			match(INT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DroneEntryContext extends ParserRuleContext {
		public DroneModelContext droneModel() {
			return getRuleContext(DroneModelContext.class,0);
		}
		public TerminalNode DASH() { return getToken(DroneShowTemplateENParser.DASH, 0); }
		public DroneCountContext droneCount() {
			return getRuleContext(DroneCountContext.class,0);
		}
		public DroneEntryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_droneEntry; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterDroneEntry(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitDroneEntry(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitDroneEntry(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DroneEntryContext droneEntry() throws RecognitionException {
		DroneEntryContext _localctx = new DroneEntryContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_droneEntry);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(248);
			droneModel();
			setState(249);
			match(T__30);
			setState(250);
			match(DASH);
			setState(251);
			match(T__30);
			setState(252);
			droneCount();
			setState(253);
			match(T__34);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EquipmentListContext extends ParserRuleContext {
		public List<TerminalNode> NEWLINE() { return getTokens(DroneShowTemplateENParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(DroneShowTemplateENParser.NEWLINE, i);
		}
		public List<DroneEntryContext> droneEntry() {
			return getRuleContexts(DroneEntryContext.class);
		}
		public DroneEntryContext droneEntry(int i) {
			return getRuleContext(DroneEntryContext.class,i);
		}
		public EquipmentListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_equipmentList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterEquipmentList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitEquipmentList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitEquipmentList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EquipmentListContext equipmentList() throws RecognitionException {
		EquipmentListContext _localctx = new EquipmentListContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_equipmentList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(255);
			match(T__35);
			setState(256);
			match(NEWLINE);
			setState(260); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(257);
				droneEntry();
				setState(258);
				match(NEWLINE);
				}
				}
				setState(262); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==TEXT || _la==NAME );
			setState(267);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==NEWLINE) {
				{
				{
				setState(264);
				match(NEWLINE);
				}
				}
				setState(269);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FigureNumContext extends ParserRuleContext {
		public FigureNumContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_figureNum; }
	 
		public FigureNumContext() { }
		public void copyFrom(FigureNumContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FigureNumFieldContext extends FigureNumContext {
		public TerminalNode INT() { return getToken(DroneShowTemplateENParser.INT, 0); }
		public FigureNumFieldContext(FigureNumContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterFigureNumField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitFigureNumField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitFigureNumField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FigureNumContext figureNum() throws RecognitionException {
		FigureNumContext _localctx = new FigureNumContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_figureNum);
		try {
			_localctx = new FigureNumFieldContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(270);
			match(INT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FigureNameContext extends ParserRuleContext {
		public FigureNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_figureName; }
	 
		public FigureNameContext() { }
		public void copyFrom(FigureNameContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FigureNameFieldContext extends FigureNameContext {
		public TerminalNode NAME() { return getToken(DroneShowTemplateENParser.NAME, 0); }
		public TerminalNode TEXT() { return getToken(DroneShowTemplateENParser.TEXT, 0); }
		public TerminalNode INT() { return getToken(DroneShowTemplateENParser.INT, 0); }
		public FigureNameFieldContext(FigureNameContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterFigureNameField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitFigureNameField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitFigureNameField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FigureNameContext figureName() throws RecognitionException {
		FigureNameContext _localctx = new FigureNameContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_figureName);
		int _la;
		try {
			_localctx = new FigureNameFieldContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(272);
			_la = _input.LA(1);
			if ( !(_la==TEXT || _la==NAME) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(274);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==INT) {
				{
				setState(273);
				match(INT);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FigureEntryContext extends ParserRuleContext {
		public FigureNumContext figureNum() {
			return getRuleContext(FigureNumContext.class,0);
		}
		public TerminalNode DASH() { return getToken(DroneShowTemplateENParser.DASH, 0); }
		public FigureNameContext figureName() {
			return getRuleContext(FigureNameContext.class,0);
		}
		public FigureEntryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_figureEntry; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterFigureEntry(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitFigureEntry(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitFigureEntry(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FigureEntryContext figureEntry() throws RecognitionException {
		FigureEntryContext _localctx = new FigureEntryContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_figureEntry);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(276);
			figureNum();
			setState(277);
			match(T__30);
			setState(278);
			match(DASH);
			setState(279);
			figureName();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PerformanceElementsContext extends ParserRuleContext {
		public List<TerminalNode> NEWLINE() { return getTokens(DroneShowTemplateENParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(DroneShowTemplateENParser.NEWLINE, i);
		}
		public List<FigureEntryContext> figureEntry() {
			return getRuleContexts(FigureEntryContext.class);
		}
		public FigureEntryContext figureEntry(int i) {
			return getRuleContext(FigureEntryContext.class,i);
		}
		public PerformanceElementsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_performanceElements; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).enterPerformanceElements(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof DroneShowTemplateENListener ) ((DroneShowTemplateENListener)listener).exitPerformanceElements(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof DroneShowTemplateENVisitor ) return ((DroneShowTemplateENVisitor<? extends T>)visitor).visitPerformanceElements(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PerformanceElementsContext performanceElements() throws RecognitionException {
		PerformanceElementsContext _localctx = new PerformanceElementsContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_performanceElements);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(281);
			match(T__36);
			setState(282);
			match(NEWLINE);
			setState(286); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(283);
				figureEntry();
				setState(284);
				match(NEWLINE);
				}
				}
				setState(288); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==INT );
			setState(293);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==NEWLINE) {
				{
				{
				setState(290);
				match(NEWLINE);
				}
				}
				setState(295);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\u0004\u00011\u0129\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007\u0002"+
		"\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b\u0002"+
		"\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e\u0002\u000f\u0007\u000f"+
		"\u0002\u0010\u0007\u0010\u0002\u0011\u0007\u0011\u0002\u0012\u0007\u0012"+
		"\u0002\u0013\u0007\u0013\u0002\u0014\u0007\u0014\u0002\u0015\u0007\u0015"+
		"\u0002\u0016\u0007\u0016\u0002\u0017\u0007\u0017\u0002\u0018\u0007\u0018"+
		"\u0002\u0019\u0007\u0019\u0002\u001a\u0007\u001a\u0002\u001b\u0007\u001b"+
		"\u0002\u001c\u0007\u001c\u0002\u001d\u0007\u001d\u0001\u0000\u0001\u0000"+
		"\u0001\u0000\u0001\u0000\u0001\u0001\u0001\u0001\u0001\u0002\u0001\u0002"+
		"\u0001\u0003\u0004\u0003F\b\u0003\u000b\u0003\f\u0003G\u0001\u0003\u0001"+
		"\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001"+
		"\u0004\u0001\u0004\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001"+
		"\u0005\u0001\u0006\u0001\u0006\u0001\u0007\u0001\u0007\u0001\u0007\u0001"+
		"\b\u0001\b\u0001\t\u0001\t\u0001\t\u0001\n\u0001\n\u0001\n\u0001\n\u0001"+
		"\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0001"+
		"\u000b\u0001\u000b\u0004\u000bn\b\u000b\u000b\u000b\f\u000bo\u0001\u000b"+
		"\u0001\u000b\u0001\u000b\u0001\u000b\u0004\u000bv\b\u000b\u000b\u000b"+
		"\f\u000bw\u0001\f\u0001\f\u0001\f\u0001\f\u0001\f\u0001\f\u0001\f\u0001"+
		"\f\u0004\f\u0082\b\f\u000b\f\f\f\u0083\u0001\f\u0001\f\u0001\f\u0001\f"+
		"\u0001\f\u0001\f\u0004\f\u008c\b\f\u000b\f\f\f\u008d\u0001\f\u0001\f\u0004"+
		"\f\u0092\b\f\u000b\f\f\f\u0093\u0001\f\u0001\f\u0004\f\u0098\b\f\u000b"+
		"\f\f\f\u0099\u0001\f\u0001\f\u0004\f\u009e\b\f\u000b\f\f\f\u009f\u0001"+
		"\f\u0001\f\u0001\f\u0001\f\u0004\f\u00a6\b\f\u000b\f\f\f\u00a7\u0001\f"+
		"\u0001\f\u0004\f\u00ac\b\f\u000b\f\f\f\u00ad\u0001\r\u0001\r\u0001\u000e"+
		"\u0001\u000e\u0001\u000e\u0001\u000e\u0001\u000e\u0001\u000e\u0001\u000f"+
		"\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u0010"+
		"\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0011\u0001\u0011\u0001\u0011"+
		"\u0001\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0001\u0012\u0001\u0012"+
		"\u0001\u0013\u0001\u0013\u0001\u0013\u0001\u0014\u0001\u0014\u0001\u0014"+
		"\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0004\u0015"+
		"\u00d6\b\u0015\u000b\u0015\f\u0015\u00d7\u0001\u0015\u0001\u0015\u0001"+
		"\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001"+
		"\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001"+
		"\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001"+
		"\u0015\u0001\u0015\u0001\u0015\u0004\u0015\u00f1\b\u0015\u000b\u0015\f"+
		"\u0015\u00f2\u0001\u0016\u0001\u0016\u0001\u0017\u0001\u0017\u0001\u0018"+
		"\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018"+
		"\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0004\u0019"+
		"\u0105\b\u0019\u000b\u0019\f\u0019\u0106\u0001\u0019\u0005\u0019\u010a"+
		"\b\u0019\n\u0019\f\u0019\u010d\t\u0019\u0001\u001a\u0001\u001a\u0001\u001b"+
		"\u0001\u001b\u0003\u001b\u0113\b\u001b\u0001\u001c\u0001\u001c\u0001\u001c"+
		"\u0001\u001c\u0001\u001c\u0001\u001d\u0001\u001d\u0001\u001d\u0001\u001d"+
		"\u0001\u001d\u0004\u001d\u011f\b\u001d\u000b\u001d\f\u001d\u0120\u0001"+
		"\u001d\u0005\u001d\u0124\b\u001d\n\u001d\f\u001d\u0127\t\u001d\u0001\u001d"+
		"\u0000\u0000\u001e\u0000\u0002\u0004\u0006\b\n\f\u000e\u0010\u0012\u0014"+
		"\u0016\u0018\u001a\u001c\u001e \"$&(*,.02468:\u0000\u0004\u0001\u0000"+
		"./\u0002\u0000,,..\u0001\u0000\u0015\u0016\u0001\u0000\u0017\u0018\u011b"+
		"\u0000<\u0001\u0000\u0000\u0000\u0002@\u0001\u0000\u0000\u0000\u0004B"+
		"\u0001\u0000\u0000\u0000\u0006E\u0001\u0000\u0000\u0000\bP\u0001\u0000"+
		"\u0000\u0000\nR\u0001\u0000\u0000\u0000\fW\u0001\u0000\u0000\u0000\u000e"+
		"Y\u0001\u0000\u0000\u0000\u0010\\\u0001\u0000\u0000\u0000\u0012^\u0001"+
		"\u0000\u0000\u0000\u0014a\u0001\u0000\u0000\u0000\u0016e\u0001\u0000\u0000"+
		"\u0000\u0018y\u0001\u0000\u0000\u0000\u001a\u00af\u0001\u0000\u0000\u0000"+
		"\u001c\u00b1\u0001\u0000\u0000\u0000\u001e\u00b7\u0001\u0000\u0000\u0000"+
		" \u00bd\u0001\u0000\u0000\u0000\"\u00c1\u0001\u0000\u0000\u0000$\u00c8"+
		"\u0001\u0000\u0000\u0000&\u00ca\u0001\u0000\u0000\u0000(\u00cd\u0001\u0000"+
		"\u0000\u0000*\u00d0\u0001\u0000\u0000\u0000,\u00f4\u0001\u0000\u0000\u0000"+
		".\u00f6\u0001\u0000\u0000\u00000\u00f8\u0001\u0000\u0000\u00002\u00ff"+
		"\u0001\u0000\u0000\u00004\u010e\u0001\u0000\u0000\u00006\u0110\u0001\u0000"+
		"\u0000\u00008\u0114\u0001\u0000\u0000\u0000:\u0119\u0001\u0000\u0000\u0000"+
		"<=\u0003\u0012\t\u0000=>\u0003\u0014\n\u0000>?\u0005\u0000\u0000\u0001"+
		"?\u0001\u0001\u0000\u0000\u0000@A\u0005.\u0000\u0000A\u0003\u0001\u0000"+
		"\u0000\u0000BC\u0007\u0000\u0000\u0000C\u0005\u0001\u0000\u0000\u0000"+
		"DF\u0007\u0001\u0000\u0000ED\u0001\u0000\u0000\u0000FG\u0001\u0000\u0000"+
		"\u0000GE\u0001\u0000\u0000\u0000GH\u0001\u0000\u0000\u0000HI\u0001\u0000"+
		"\u0000\u0000IJ\u0005\u0001\u0000\u0000JK\u0005.\u0000\u0000KL\u0005\u0001"+
		"\u0000\u0000LM\u0003 \u0010\u0000MN\u0005\u0001\u0000\u0000NO\u0005.\u0000"+
		"\u0000O\u0007\u0001\u0000\u0000\u0000PQ\u0005,\u0000\u0000Q\t\u0001\u0000"+
		"\u0000\u0000RS\u0005\u0002\u0000\u0000ST\u0003\u001a\r\u0000TU\u0005\u0003"+
		"\u0000\u0000UV\u0003\u001c\u000e\u0000V\u000b\u0001\u0000\u0000\u0000"+
		"WX\u00050\u0000\u0000X\r\u0001\u0000\u0000\u0000YZ\u0005-\u0000\u0000"+
		"Z[\u0005*\u0000\u0000[\u000f\u0001\u0000\u0000\u0000\\]\u0007\u0000\u0000"+
		"\u0000]\u0011\u0001\u0000\u0000\u0000^_\u0003\u0016\u000b\u0000_`\u0003"+
		"\u0018\f\u0000`\u0013\u0001\u0000\u0000\u0000ab\u0003*\u0015\u0000bc\u0003"+
		"2\u0019\u0000cd\u0003:\u001d\u0000d\u0015\u0001\u0000\u0000\u0000ef\u0003"+
		"\u0002\u0001\u0000fg\u0005\'\u0000\u0000gh\u0003\u0004\u0002\u0000hi\u0005"+
		"\'\u0000\u0000ij\u0003\u0006\u0003\u0000jk\u0005\'\u0000\u0000km\u0003"+
		"\b\u0004\u0000ln\u0005\'\u0000\u0000ml\u0001\u0000\u0000\u0000no\u0001"+
		"\u0000\u0000\u0000om\u0001\u0000\u0000\u0000op\u0001\u0000\u0000\u0000"+
		"pq\u0001\u0000\u0000\u0000qr\u0003\n\u0005\u0000rs\u0005\'\u0000\u0000"+
		"su\u0005\u0004\u0000\u0000tv\u0005\'\u0000\u0000ut\u0001\u0000\u0000\u0000"+
		"vw\u0001\u0000\u0000\u0000wu\u0001\u0000\u0000\u0000wx\u0001\u0000\u0000"+
		"\u0000x\u0017\u0001\u0000\u0000\u0000yz\u0005\u0005\u0000\u0000z{\u0005"+
		"\'\u0000\u0000{|\u0005\u0006\u0000\u0000|}\u0005(\u0000\u0000}~\u0005"+
		"\u0007\u0000\u0000~\u007f\u0003\f\u0006\u0000\u007f\u0081\u0005\b\u0000"+
		"\u0000\u0080\u0082\u0005\'\u0000\u0000\u0081\u0080\u0001\u0000\u0000\u0000"+
		"\u0082\u0083\u0001\u0000\u0000\u0000\u0083\u0081\u0001\u0000\u0000\u0000"+
		"\u0083\u0084\u0001\u0000\u0000\u0000\u0084\u0085\u0001\u0000\u0000\u0000"+
		"\u0085\u0086\u0005\t\u0000\u0000\u0086\u0087\u0005(\u0000\u0000\u0087"+
		"\u0088\u0005\n\u0000\u0000\u0088\u0089\u0003\u000e\u0007\u0000\u0089\u008b"+
		"\u0005\u000b\u0000\u0000\u008a\u008c\u0005\'\u0000\u0000\u008b\u008a\u0001"+
		"\u0000\u0000\u0000\u008c\u008d\u0001\u0000\u0000\u0000\u008d\u008b\u0001"+
		"\u0000\u0000\u0000\u008d\u008e\u0001\u0000\u0000\u0000\u008e\u008f\u0001"+
		"\u0000\u0000\u0000\u008f\u0091\u0005\f\u0000\u0000\u0090\u0092\u0005\'"+
		"\u0000\u0000\u0091\u0090\u0001\u0000\u0000\u0000\u0092\u0093\u0001\u0000"+
		"\u0000\u0000\u0093\u0091\u0001\u0000\u0000\u0000\u0093\u0094\u0001\u0000"+
		"\u0000\u0000\u0094\u0095\u0001\u0000\u0000\u0000\u0095\u0097\u0005\r\u0000"+
		"\u0000\u0096\u0098\u0005\'\u0000\u0000\u0097\u0096\u0001\u0000\u0000\u0000"+
		"\u0098\u0099\u0001\u0000\u0000\u0000\u0099\u0097\u0001\u0000\u0000\u0000"+
		"\u0099\u009a\u0001\u0000\u0000\u0000\u009a\u009b\u0001\u0000\u0000\u0000"+
		"\u009b\u009d\u0005\u000e\u0000\u0000\u009c\u009e\u0005\'\u0000\u0000\u009d"+
		"\u009c\u0001\u0000\u0000\u0000\u009e\u009f\u0001\u0000\u0000\u0000\u009f"+
		"\u009d\u0001\u0000\u0000\u0000\u009f\u00a0\u0001\u0000\u0000\u0000\u00a0"+
		"\u00a1\u0001\u0000\u0000\u0000\u00a1\u00a2\u0003\u0010\b\u0000\u00a2\u00a3"+
		"\u0005\'\u0000\u0000\u00a3\u00a5\u0005\u000f\u0000\u0000\u00a4\u00a6\u0005"+
		"\'\u0000\u0000\u00a5\u00a4\u0001\u0000\u0000\u0000\u00a6\u00a7\u0001\u0000"+
		"\u0000\u0000\u00a7\u00a5\u0001\u0000\u0000\u0000\u00a7\u00a8\u0001\u0000"+
		"\u0000\u0000\u00a8\u00a9\u0001\u0000\u0000\u0000\u00a9\u00ab\u0005\u0010"+
		"\u0000\u0000\u00aa\u00ac\u0005\'\u0000\u0000\u00ab\u00aa\u0001\u0000\u0000"+
		"\u0000\u00ac\u00ad\u0001\u0000\u0000\u0000\u00ad\u00ab\u0001\u0000\u0000"+
		"\u0000\u00ad\u00ae\u0001\u0000\u0000\u0000\u00ae\u0019\u0001\u0000\u0000"+
		"\u0000\u00af\u00b0\u0005,\u0000\u0000\u00b0\u001b\u0001\u0000\u0000\u0000"+
		"\u00b1\u00b2\u0005,\u0000\u0000\u00b2\u00b3\u0005\u0011\u0000\u0000\u00b3"+
		"\u00b4\u0005,\u0000\u0000\u00b4\u00b5\u0005\u0011\u0000\u0000\u00b5\u00b6"+
		"\u0005,\u0000\u0000\u00b6\u001d\u0001\u0000\u0000\u0000\u00b7\u00b8\u0005"+
		",\u0000\u0000\u00b8\u00b9\u0005\u0011\u0000\u0000\u00b9\u00ba\u0005,\u0000"+
		"\u0000\u00ba\u00bb\u0005\u0011\u0000\u0000\u00bb\u00bc\u0005,\u0000\u0000"+
		"\u00bc\u001f\u0001\u0000\u0000\u0000\u00bd\u00be\u0005,\u0000\u0000\u00be"+
		"\u00bf\u0005\u0011\u0000\u0000\u00bf\u00c0\u0005,\u0000\u0000\u00c0!\u0001"+
		"\u0000\u0000\u0000\u00c1\u00c2\u0005,\u0000\u0000\u00c2\u00c3\u0005\u0012"+
		"\u0000\u0000\u00c3\u00c4\u0005,\u0000\u0000\u00c4\u00c5\u0005\u0013\u0000"+
		"\u0000\u00c5\u00c6\u0005,\u0000\u0000\u00c6\u00c7\u0005\u0014\u0000\u0000"+
		"\u00c7#\u0001\u0000\u0000\u0000\u00c8\u00c9\u0005,\u0000\u0000\u00c9%"+
		"\u0001\u0000\u0000\u0000\u00ca\u00cb\u0005-\u0000\u0000\u00cb\u00cc\u0007"+
		"\u0002\u0000\u0000\u00cc\'\u0001\u0000\u0000\u0000\u00cd\u00ce\u0005-"+
		"\u0000\u0000\u00ce\u00cf\u0007\u0003\u0000\u0000\u00cf)\u0001\u0000\u0000"+
		"\u0000\u00d0\u00d1\u0005\u0019\u0000\u0000\u00d1\u00d2\u0005)\u0000\u0000"+
		"\u00d2\u00d3\u0005\u001a\u0000\u0000\u00d3\u00d5\u0003\u001a\r\u0000\u00d4"+
		"\u00d6\u0005\'\u0000\u0000\u00d5\u00d4\u0001\u0000\u0000\u0000\u00d6\u00d7"+
		"\u0001\u0000\u0000\u0000\u00d7\u00d5\u0001\u0000\u0000\u0000\u00d7\u00d8"+
		"\u0001\u0000\u0000\u0000\u00d8\u00d9\u0001\u0000\u0000\u0000\u00d9\u00da"+
		"\u0005\u001b\u0000\u0000\u00da\u00db\u0005)\u0000\u0000\u00db\u00dc\u0005"+
		"\u001c\u0000\u0000\u00dc\u00dd\u0003&\u0013\u0000\u00dd\u00de\u0005\u001d"+
		"\u0000\u0000\u00de\u00df\u0003(\u0014\u0000\u00df\u00e0\u0005\'\u0000"+
		"\u0000\u00e0\u00e1\u0005\u001e\u0000\u0000\u00e1\u00e2\u0005)\u0000\u0000"+
		"\u00e2\u00e3\u0005\u001f\u0000\u0000\u00e3\u00e4\u0003\u001e\u000f\u0000"+
		"\u00e4\u00e5\u0005\'\u0000\u0000\u00e5\u00e6\u0005 \u0000\u0000\u00e6"+
		"\u00e7\u0005)\u0000\u0000\u00e7\u00e8\u0005\u001f\u0000\u0000\u00e8\u00e9"+
		"\u0003\"\u0011\u0000\u00e9\u00ea\u0005\'\u0000\u0000\u00ea\u00eb\u0005"+
		"!\u0000\u0000\u00eb\u00ec\u0005)\u0000\u0000\u00ec\u00ed\u0005\u001f\u0000"+
		"\u0000\u00ed\u00ee\u0003$\u0012\u0000\u00ee\u00f0\u0005\"\u0000\u0000"+
		"\u00ef\u00f1\u0005\'\u0000\u0000\u00f0\u00ef\u0001\u0000\u0000\u0000\u00f1"+
		"\u00f2\u0001\u0000\u0000\u0000\u00f2\u00f0\u0001\u0000\u0000\u0000\u00f2"+
		"\u00f3\u0001\u0000\u0000\u0000\u00f3+\u0001\u0000\u0000\u0000\u00f4\u00f5"+
		"\u0007\u0000\u0000\u0000\u00f5-\u0001\u0000\u0000\u0000\u00f6\u00f7\u0005"+
		",\u0000\u0000\u00f7/\u0001\u0000\u0000\u0000\u00f8\u00f9\u0003,\u0016"+
		"\u0000\u00f9\u00fa\u0005\u001f\u0000\u0000\u00fa\u00fb\u0005)\u0000\u0000"+
		"\u00fb\u00fc\u0005\u001f\u0000\u0000\u00fc\u00fd\u0003.\u0017\u0000\u00fd"+
		"\u00fe\u0005#\u0000\u0000\u00fe1\u0001\u0000\u0000\u0000\u00ff\u0100\u0005"+
		"$\u0000\u0000\u0100\u0104\u0005\'\u0000\u0000\u0101\u0102\u00030\u0018"+
		"\u0000\u0102\u0103\u0005\'\u0000\u0000\u0103\u0105\u0001\u0000\u0000\u0000"+
		"\u0104\u0101\u0001\u0000\u0000\u0000\u0105\u0106\u0001\u0000\u0000\u0000"+
		"\u0106\u0104\u0001\u0000\u0000\u0000\u0106\u0107\u0001\u0000\u0000\u0000"+
		"\u0107\u010b\u0001\u0000\u0000\u0000\u0108\u010a\u0005\'\u0000\u0000\u0109"+
		"\u0108\u0001\u0000\u0000\u0000\u010a\u010d\u0001\u0000\u0000\u0000\u010b"+
		"\u0109\u0001\u0000\u0000\u0000\u010b\u010c\u0001\u0000\u0000\u0000\u010c"+
		"3\u0001\u0000\u0000\u0000\u010d\u010b\u0001\u0000\u0000\u0000\u010e\u010f"+
		"\u0005,\u0000\u0000\u010f5\u0001\u0000\u0000\u0000\u0110\u0112\u0007\u0000"+
		"\u0000\u0000\u0111\u0113\u0005,\u0000\u0000\u0112\u0111\u0001\u0000\u0000"+
		"\u0000\u0112\u0113\u0001\u0000\u0000\u0000\u01137\u0001\u0000\u0000\u0000"+
		"\u0114\u0115\u00034\u001a\u0000\u0115\u0116\u0005\u001f\u0000\u0000\u0116"+
		"\u0117\u0005)\u0000\u0000\u0117\u0118\u00036\u001b\u0000\u01189\u0001"+
		"\u0000\u0000\u0000\u0119\u011a\u0005%\u0000\u0000\u011a\u011e\u0005\'"+
		"\u0000\u0000\u011b\u011c\u00038\u001c\u0000\u011c\u011d\u0005\'\u0000"+
		"\u0000\u011d\u011f\u0001\u0000\u0000\u0000\u011e\u011b\u0001\u0000\u0000"+
		"\u0000\u011f\u0120\u0001\u0000\u0000\u0000\u0120\u011e\u0001\u0000\u0000"+
		"\u0000\u0120\u0121\u0001\u0000\u0000\u0000\u0121\u0125\u0001\u0000\u0000"+
		"\u0000\u0122\u0124\u0005\'\u0000\u0000\u0123\u0122\u0001\u0000\u0000\u0000"+
		"\u0124\u0127\u0001\u0000\u0000\u0000\u0125\u0123\u0001\u0000\u0000\u0000"+
		"\u0125\u0126\u0001\u0000\u0000\u0000\u0126;\u0001\u0000\u0000\u0000\u0127"+
		"\u0125\u0001\u0000\u0000\u0000\u0011Gow\u0083\u008d\u0093\u0099\u009f"+
		"\u00a7\u00ad\u00d7\u00f2\u0106\u010b\u0112\u0120\u0125";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}