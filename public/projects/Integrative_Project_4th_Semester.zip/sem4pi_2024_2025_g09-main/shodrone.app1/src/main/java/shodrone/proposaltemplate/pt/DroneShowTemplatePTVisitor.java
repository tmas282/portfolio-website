// Generated from C:/Users/afons/sem4pi_2024_2025_g09/shodrone.app1/src/main/java/shodrone/proposaltemplate/pt/DroneShowTemplatePT.g4 by ANTLR 4.13.2
package shodrone.proposaltemplate.pt;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link DroneShowTemplatePTParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface DroneShowTemplatePTVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplatePTParser#document}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDocument(DroneShowTemplatePTParser.DocumentContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplatePTParser#salutation}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSalutation(DroneShowTemplatePTParser.SalutationContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplatePTParser#clientCompany}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClientCompany(DroneShowTemplatePTParser.ClientCompanyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code clientLocationField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#clientLocation}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClientLocationField(DroneShowTemplatePTParser.ClientLocationFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code vatField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#vat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVatField(DroneShowTemplatePTParser.VatFieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplatePTParser#documentID}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDocumentID(DroneShowTemplatePTParser.DocumentIDContext ctx);
	/**
	 * Visit a parse tree produced by the {@code videoURLField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#videoURL}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVideoURLField(DroneShowTemplatePTParser.VideoURLFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code insuranceAmountField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#insuranceAmount}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInsuranceAmountField(DroneShowTemplatePTParser.InsuranceAmountFieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplatePTParser#signatoryName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSignatoryName(DroneShowTemplatePTParser.SignatoryNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplatePTParser#pageOne}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPageOne(DroneShowTemplatePTParser.PageOneContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplatePTParser#pageTwo}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPageTwo(DroneShowTemplatePTParser.PageTwoContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplatePTParser#headerSection}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHeaderSection(DroneShowTemplatePTParser.HeaderSectionContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplatePTParser#introContent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntroContent(DroneShowTemplatePTParser.IntroContentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code proposalIDField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#proposalID}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProposalIDField(DroneShowTemplatePTParser.ProposalIDFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code proposalDateField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#proposalDate}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProposalDateField(DroneShowTemplatePTParser.ProposalDateFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code eventDateField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#eventDate}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEventDateField(DroneShowTemplatePTParser.EventDateFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code zipCodeField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#zipCode}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitZipCodeField(DroneShowTemplatePTParser.ZipCodeFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code eventTimeField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#eventTime}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEventTimeField(DroneShowTemplatePTParser.EventTimeFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code eventLengthField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#eventLength}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEventLengthField(DroneShowTemplatePTParser.EventLengthFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code gpsLatField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#gpsLat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGpsLatField(DroneShowTemplatePTParser.GpsLatFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code gpsLongField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#gpsLong}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGpsLongField(DroneShowTemplatePTParser.GpsLongFieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplatePTParser#attachmentDetails}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttachmentDetails(DroneShowTemplatePTParser.AttachmentDetailsContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplatePTParser#droneModel}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDroneModel(DroneShowTemplatePTParser.DroneModelContext ctx);
	/**
	 * Visit a parse tree produced by the {@code droneCountField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#droneCount}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDroneCountField(DroneShowTemplatePTParser.DroneCountFieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplatePTParser#droneEntry}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDroneEntry(DroneShowTemplatePTParser.DroneEntryContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplatePTParser#equipmentList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEquipmentList(DroneShowTemplatePTParser.EquipmentListContext ctx);
	/**
	 * Visit a parse tree produced by the {@code figureNumField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#figureNum}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFigureNumField(DroneShowTemplatePTParser.FigureNumFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code figureNameField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#figureName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFigureNameField(DroneShowTemplatePTParser.FigureNameFieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplatePTParser#figureEntry}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFigureEntry(DroneShowTemplatePTParser.FigureEntryContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplatePTParser#performanceElements}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPerformanceElements(DroneShowTemplatePTParser.PerformanceElementsContext ctx);
}