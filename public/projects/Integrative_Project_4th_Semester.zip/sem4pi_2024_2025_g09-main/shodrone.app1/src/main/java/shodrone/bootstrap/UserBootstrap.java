package shodrone.bootstrap;

        import org.springframework.beans.factory.annotation.Value;
        import org.springframework.boot.CommandLineRunner;
        import org.springframework.core.annotation.Order;
        import org.springframework.security.crypto.password.PasswordEncoder;
        import org.springframework.stereotype.Component;
        import shodrone.customermanagement.Name;
        import shodrone.customermanagement.PhoneNumber;
        import shodrone.usermanagement.Role;
        import shodrone.usermanagement.RoleName;
        import shodrone.usermanagement.RolePolicy;
        import shodrone.usermanagement.User;
        import shodrone.repositories.RoleRepository;
        import shodrone.repositories.UserRepository;

        @Component
        @Order(1)
        public class UserBootstrap implements CommandLineRunner {

            private final UserRepository userRepository;
            private final PasswordEncoder passwordEncoder;
            private final RoleRepository roleRepository;

            @Value("${admin.username}")
            private String adminUsername;

            @Value("${admin.password}")
            private String adminPassword;

            @Value("${admin.email}")
            private String adminEmail;

            public UserBootstrap(UserRepository userRepository, PasswordEncoder passwordEncoder, RoleRepository roleRepository) {
                this.userRepository = userRepository;
                this.passwordEncoder = passwordEncoder;
                this.roleRepository = roleRepository;
            }

            @Override
            public void run(String... args) {
                System.out.println("🔧 [BOOTSTRAP] A inicializar utilizadores...");

                createRolesIfNotExist();
                createAdminIfNotExist();

                // Utilizadores base de exemplo
                createUserIfNotExist("crm_manager@showdrone.com", "crm_manager", RoleName.CRM_MANAGER, "CRM Manager", "911111111");
                createUserIfNotExist("crm_collaborator@showdrone.com", "crm_collaborator", RoleName.CRM_COLLABORATOR, "CRM Collaborator", "922222222");
                createUserIfNotExist("show_designer@showdrone.com", "show_designer", RoleName.SHOW_DESIGNER, "Show Designer", "933333333");
                createUserIfNotExist("drone_tech@showdrone.com", "drone_tech", RoleName.DRONE_TECH, "Drone Tech", "944444444");
            }

            private void createAdminIfNotExist() {
                if (userRepository.findByEmail(adminEmail).isEmpty()) {
                    Role adminRole = roleRepository.findByRoleName(RoleName.ADMIN)
                            .orElseThrow(() -> new IllegalStateException("Admin role not found"));

                    Name name = new Name(adminUsername);
                    PhoneNumber phone = new PhoneNumber("900000000");

                    User admin = new User(adminEmail, passwordEncoder.encode(adminPassword), adminRole, true, name, phone);
                    userRepository.save(admin);

                    System.out.println("✅ Admin user created: " + adminEmail);
                } else {
                    System.out.println("🔁 Admin user already exists: " + adminEmail);
                }
            }

            public void createUserIfNotExist(String email, String password, RoleName roleName, String fullName, String phoneNumber) {
                if (!RolePolicy.BACKOFFICE_ROLES.contains(roleName)) {
                    System.out.println("❌ Role " + roleName + " não pertence ao backoffice");
                    return;
                }

                if (userRepository.findByEmail(email).isPresent()) {
                    System.out.println("🔁 " + roleName + " user already exists: " + email);
                    return;
                }

                Role role = roleRepository.findByRoleName(roleName)
                        .orElseThrow(() -> new IllegalStateException("Role not found: " + roleName));

                String encodedPassword = passwordEncoder.encode(password);
                Name name = new Name(fullName);
                PhoneNumber phone = new PhoneNumber(phoneNumber);

                User user = new User(email, encodedPassword, role, true, name, phone);
                userRepository.save(user);

                System.out.printf("✅ %s user created: %s%n", roleName, email);
            }

            private void createRolesIfNotExist() {
                for (RoleName roleName : RoleName.values()) {
                    roleRepository.findByRoleName(roleName).orElseGet(() -> {
                        Role newRole = new Role();
                        newRole.setRoleName(roleName);
                        roleRepository.save(newRole);
                        System.out.println("✅ Role criada: " + roleName);
                        return newRole;
                    });
                }
            }
        }