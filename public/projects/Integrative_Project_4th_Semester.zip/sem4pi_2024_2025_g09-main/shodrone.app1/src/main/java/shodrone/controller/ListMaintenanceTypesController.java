package shodrone.controller;

import org.springframework.stereotype.Controller;
import shodrone.dronemaintenancemanagement.MaintenanceType;
import shodrone.services.DroneMaintenanceService;


import java.util.List;

@Controller
public class ListMaintenanceTypesController {

    private final DroneMaintenanceService droneMaintenanceService;

    public ListMaintenanceTypesController(DroneMaintenanceService droneMaintenanceService) {
        this.droneMaintenanceService = droneMaintenanceService;
    }

    public List<MaintenanceType> listMaintenanceTypes() {
        return droneMaintenanceService.getAllMaintenanceTypes();
    }
}