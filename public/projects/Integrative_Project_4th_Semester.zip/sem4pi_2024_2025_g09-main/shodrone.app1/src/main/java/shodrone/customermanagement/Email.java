package shodrone.customermanagement;

import jakarta.persistence.Embeddable;

@Embeddable
public class Email {

    private String email;

    protected Email() {}

    public Email(String email) {
        if (email == null || !email.matches("^[\\w-.]+@[\\w-]+\\.[a-z]{2,}$")) {
            throw new IllegalArgumentException("Invalid email: must follow a valid email format.");
        }
        this.email = email;
    }

    public String value() {
        return email;
    }

    @Override
    public String toString() {
        return email;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof Email && email.equals(((Email) o).email);
    }

    @Override
    public int hashCode() {
        return email.hashCode();
    }
}