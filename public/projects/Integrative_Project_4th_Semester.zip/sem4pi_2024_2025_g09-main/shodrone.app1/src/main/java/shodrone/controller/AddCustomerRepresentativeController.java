package shodrone.controller;

import org.springframework.stereotype.Component;
import shodrone.customermanagement.Customer;
import shodrone.services.CustomerService;
import shodrone.services.UserService;

@Component
public class AddCustomerRepresentativeController {

    private final CustomerService customerService;

    public AddCustomerRepresentativeController(CustomerService customerService) {
        this.customerService = customerService;

    }

    public void addCustomerRepresentative(String rawVat, String name, String email, String position, String phone) {
        customerService.addCustomerRepresentative(rawVat, name, email, position, phone);
    }

    public void editCustomerRepresentative(String currentEmail, String newEmail, String newPhone) {
        customerService.editCustomerRepresentative(currentEmail, newEmail, newPhone);
    }

    public boolean disableCustomerRepresentative(String email) {
        return customerService.disableCustomerRepresentative(email);
    }
}