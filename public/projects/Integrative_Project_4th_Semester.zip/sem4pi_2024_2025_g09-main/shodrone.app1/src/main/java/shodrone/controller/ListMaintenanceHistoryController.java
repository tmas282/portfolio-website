package shodrone.controller;

import org.springframework.stereotype.Controller;
import shodrone.dronemaintenancemanagement.MaintenanceRecord;
import shodrone.services.DroneMaintenanceService;
import shodrone.services.DroneService;

import java.time.LocalDate;
import java.util.List;

@Controller
public class ListMaintenanceHistoryController {
    private final DroneMaintenanceService droneMaintenanceService;
    private final DroneService droneService;

    public ListMaintenanceHistoryController(DroneMaintenanceService droneMaintenanceService,
                                            DroneService droneService) {
        this.droneMaintenanceService = droneMaintenanceService;
        this.droneService = droneService;
    }

    public List<MaintenanceRecord> listMaintenanceHistory(String serialNumber, LocalDate startDate, LocalDate endDate) {
        return droneMaintenanceService.listMaintenanceHistory(serialNumber, startDate, endDate);
    }

    public boolean droneExists(String serialNumber) {
        return droneService.droneExists(serialNumber);
    }
}
