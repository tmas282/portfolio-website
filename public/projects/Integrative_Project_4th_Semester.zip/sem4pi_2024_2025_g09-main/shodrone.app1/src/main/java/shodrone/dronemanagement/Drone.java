package shodrone.dronemanagement;

import jakarta.persistence.*;
import lombok.Getter;
import shodrone.dronemodelmanagement.DroneModel;
import shodrone.showproposalmanagement.ShowProposal;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "drones")
public class Drone {

    @EmbeddedId
    @AttributeOverride(name = "id", column = @Column(name = "serial_number"))
    private SerialNumber serialNumber;

    @ManyToOne(optional = false)
    @JoinColumn(name = "model_id", referencedColumnName = "model_id")
    private DroneModel model;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private DroneStatus status;

    @Embedded
    @AttributeOverride(name = "routine", column = @Column(name = "specific_routine"))
    private SpecificRoutine routine;

    @Embedded
    private RemovalReason removalReason;

    @Embedded
    private RemovalDate removalDate;

    @Embedded
    @AttributeOverride(name = "time", column = @Column(name = "usage_time", nullable = false))
    private UsageTime usageTime;

    @Getter
    @ManyToMany
    private List<ShowProposal> showProposals = new ArrayList<>();

    protected Drone() {
        // for JPA
    }

    public Drone(SerialNumber serialNumber, DroneModel model, DroneStatus status, SpecificRoutine routine) {
        if (serialNumber == null || model == null || status == null || routine == null)
            throw new IllegalArgumentException("Fields must not be null.");
        if (status != DroneStatus.ACTIVE)
            throw new IllegalArgumentException("Drone must be created with status ACTIVE.");

        this.serialNumber = serialNumber;
        this.model = model;
        this.status = status;
        this.routine = routine;
        this.usageTime = new UsageTime(0); // Initialize usage time to zero
    }

    public SerialNumber serialNumber() {
        return serialNumber;
    }

    public DroneModel model() {
        return model;
    }

    public DroneModel getDroneModel() {
        return model;
    }

    public DroneStatus status() {
        return status;
    }

    public SpecificRoutine routine() {
        return routine;
    }

    public RemovalReason removalReason() {
        return removalReason;
    }

    public RemovalDate removalDate() {
        return removalDate;
    }

    public UsageTime usageTime() {
        return usageTime;
    }

    public boolean isActive() {
        return status == DroneStatus.ACTIVE;
    }

    public void markAsRemoved(RemovalReason reason, RemovalDate date, DroneStatus newStatus) {
        if (newStatus != DroneStatus.INACTIVE && newStatus != DroneStatus.MAINTENANCE)
            throw new IllegalArgumentException("Invalid status for removal.");
        this.status = newStatus;
        this.removalReason = reason;
        this.removalDate = date;
    }

    public void resetUsageTime() {
        this.usageTime = new UsageTime(0); // Reset usage time to zero
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Drone)) return false;
        Drone drone = (Drone) o;
        return serialNumber.equals(drone.serialNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(serialNumber);
    }

    @Override
    public String toString() {
        return "Drone{" +
                "serialNumber=" + serialNumber +
                ", model=" + model.getModelID() +
                ", status=" + status +
                ", routine=" + routine +
                ", usageTime=" + usageTime +
                '}';
    }
}