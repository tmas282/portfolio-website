package shodrone.controller;

import org.springframework.stereotype.Controller;
import shodrone.dronemanagement.Drone;
import shodrone.services.DroneService;

@Controller
public class AddDroneController {

    private final DroneService droneService;

    public AddDroneController(DroneService droneService) {
        this.droneService = droneService;
    }

    public Drone addDrone(String serialNumber, String modelId, String routine) {
        return droneService.addDrone(serialNumber, modelId, routine);
    }
}
