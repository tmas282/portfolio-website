package shodrone.presentation;

import shodrone.controller.ListShowRequestsController;
import shodrone.showrequestmanagement.ShowRequest;

import java.util.List;
import java.util.Scanner;

public class ListShowRequestsUI {
    public static final void listShowRequestsOfCustomer(ListShowRequestsController controller, Scanner scanner){
        System.out.println("Please enter the customer VAT: ");
        String VAT = scanner.nextLine();
        try{
            List<ShowRequest> list = controller.listShowRequestsOfCustomer(VAT);
            for(ShowRequest i : list){
                String dt = i.getDatetime().getDateTime().toString().replace("T", " ");
                System.out.printf("%d->\tDescription: %s\tPlace: %s\tDate & Time: %s\tDuration: %d\tNumber of Drones: %d\tStatus: %s\n", i.getId(), i.getDescription().getDescription(), i.getPlace().getPlace(), dt, i.getDuration().getDuration(), i.getNumberOfDrones().getNumber(), i.getStatus().toString());
            }
        } catch (Exception e) {
            System.out.println("An unexpected error occurred");
        }
    }
}
