package shodrone.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import shodrone.repositories.ShowProposalRepository;
import shodrone.showproposalmanagement.ShowProposal;
import shodrone.showproposalmanagement.ShowProposalStatus;

import java.util.List;

@Controller
public class MarkShowProposalController {

    private final ShowProposalRepository showProposalRepository;

    @Autowired
    public MarkShowProposalController(ShowProposalRepository showProposalRepository) {
        this.showProposalRepository = showProposalRepository;
    }

    public List<ShowProposal> seeShowProposalsAcceptedByCustomer(){
        ShowProposalStatus status = ShowProposalStatus.ACCEPTED;
        return showProposalRepository.findByStatus(status);
    }

    @Transactional
    public boolean markShowProposal(Long id){
        try{
            ShowProposal showProposal = showProposalRepository.findById(id).orElseThrow();
            showProposal.setStatus(ShowProposalStatus.MARKED_AS_ACCEPTED);
            showProposalRepository.save(showProposal);
            return true;
        } catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }
}