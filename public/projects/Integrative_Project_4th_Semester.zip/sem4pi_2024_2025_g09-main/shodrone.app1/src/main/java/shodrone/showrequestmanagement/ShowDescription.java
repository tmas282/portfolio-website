package shodrone.showrequestmanagement;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Objects;

@Embeddable
public class ShowDescription {

    @Getter
    @Column(name = "description")
    private String description;

    public void setDescription(String description) {
        assert description != null;
        this.description = description;
    }

    protected ShowDescription(){

    }

    public ShowDescription(String description) {
        assert description != null;
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        ShowDescription that = (ShowDescription) o;
        return Objects.equals(description, that.description);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(description);
    }
}
