package shodrone.dronemodelmanagement;

import jakarta.persistence.*;
import shodrone.figuremanagement.Figure;

import java.util.Objects;

@Entity
@Table(name = "drone_model_figure", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"figure_id", "model_id"})
})
public class DroneModelFigure {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "figure_id")
    private Figure figure;

    @ManyToOne(optional = false)
    @JoinColumn(name = "model_id", referencedColumnName = "model_id")
    private DroneModel model;

    protected DroneModelFigure() {
        // For JPA
    }

    public DroneModelFigure(Figure figure, DroneModel model) {
        if (figure == null || model == null)
            throw new IllegalArgumentException("Figure and DroneModel must not be null.");
        this.figure = figure;
        this.model = model;
    }

    // ✅ Getter que evita o erro
    public DroneModel getDroneModel() {
        return model;
    }

    public Figure getFigure() {
        return figure;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof DroneModelFigure)) return false;
        DroneModelFigure that = (DroneModelFigure) o;
        return Objects.equals(figure, that.figure) &&
                Objects.equals(model, that.model);
    }

    @Override
    public int hashCode() {
        return Objects.hash(figure, model);
    }
}
