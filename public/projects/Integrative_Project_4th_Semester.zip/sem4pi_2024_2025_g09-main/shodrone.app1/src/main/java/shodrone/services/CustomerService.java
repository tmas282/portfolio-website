package shodrone.services;

        import jakarta.persistence.EntityManager;
        import jakarta.persistence.PersistenceContext;
        import jakarta.transaction.Transactional;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.security.crypto.password.PasswordEncoder;
        import org.springframework.stereotype.Service;
        import shodrone.customermanagement.*;
        import shodrone.customerrepresentativemanagement.CustomerRepresentative;
        import shodrone.customerrepresentativemanagement.Position;
        import shodrone.repositories.CustomerRepresentativeRepository;
        import shodrone.usermanagement.Role;
        import shodrone.usermanagement.RoleName;
        import shodrone.usermanagement.User;
        import shodrone.repositories.CustomerRepository;
        import shodrone.repositories.RoleRepository;
        import shodrone.repositories.UserRepository;

        import java.util.List;

        @Service
        public class CustomerService {

            private final CustomerRepository customerRepository;
            private final UserRepository userRepository;
            private final RoleRepository roleRepository;
            private final PasswordEncoder passwordEncoder;
            private final CustomerRepresentativeRepository customerRepresentativeRepository;

            @PersistenceContext
            private EntityManager entityManager;

            @Autowired
            public CustomerService(
                    CustomerRepository customerRepository,
                    UserRepository userRepository,
                    RoleRepository roleRepository,
                    PasswordEncoder passwordEncoder,
                    CustomerRepresentativeRepository customerRepresentativeRepository
            ) {
                this.customerRepository = customerRepository;
                this.userRepository = userRepository;
                this.roleRepository = roleRepository;
                this.passwordEncoder = passwordEncoder;
                this.customerRepresentativeRepository = customerRepresentativeRepository;
            }

            /**
             * US220 — Regista um novo cliente e o seu representante.
             */
            @Transactional
            public void registerCustomerAndRepresentative(
                    String rawVat,
                    String rawName,
                    String rawEmail,
                    String rawAddress,
                    String rawPhone,
                    String repName,
                    String repEmail,
                    String repPosition,
                    String repPhone,
                    String customerType
            ) {
                VAT vat = new VAT(rawVat);
                Email email = new Email(rawEmail);
                Email representativeEmail = new Email(repEmail);

                // Verifica todos os pré-requisitos antes de criar ou persistir nada
                if (customerRepository.findByVat(vat).isPresent()) {
                    throw new IllegalArgumentException(String.format(" Customer with VAT %s already exists.", rawVat));
                }

                if (userRepository.findByEmail(email.value()).isPresent()) {
                    throw new IllegalArgumentException(String.format(" Customer email %s already exists.", rawEmail));
                }

                if (customerRepresentativeRepository.findByEmail(representativeEmail).isPresent()) {
                    throw new IllegalArgumentException(String.format(" Representative email %s already exists.", repEmail));
                }

                // Cria value objects
                Name name = new Name(rawName);
                Address address = new Address(rawAddress);
                PhoneNumber phone = new PhoneNumber(rawPhone);
                Name representativeName = new Name(repName);
                Position position = new Position(repPosition);
                PhoneNumber representativePhone = new PhoneNumber(repPhone);

                // Roles
                Role customerRole = roleRepository.findByRoleName(RoleName.CUSTOMER)
                        .orElseThrow(() -> new IllegalStateException("Role not found: CUSTOMER"));
                Role repRole = roleRepository.findByRoleName(RoleName.CUSTOMER_REPRESENTATIVE)
                        .orElseThrow(() -> new IllegalStateException("Role not found: CUSTOMER_REPRESENTATIVE"));

                // Users
                User customerUser = userRepository.save(
                new User(email.value(), passwordEncoder.encode("defaultPassword"), customerRole, true, name, phone)
                );
                User repUser = userRepository.save(
                        new User(repEmail, passwordEncoder.encode("defaultPassword"), repRole, true, representativeName, representativePhone)
                );

                // Representative
                CustomerRepresentative representative = new CustomerRepresentative(representativeEmail, representativeName, position);
                representative.setPhoneNumber(representativePhone);
                representative.setUser(repUser);

                // Customer
                CustomerType type = (customerType == null || customerType.isBlank())
                        ? CustomerType.REGULAR
                        : CustomerType.valueOf(customerType.trim().toUpperCase());

                Customer customer = new Customer(vat, name, email, address, phone, representative, type);
                customer.setUser(customerUser);

                // Salva no repositório
                customerRepository.save(customer);
                customerRepresentativeRepository.save(representative);
            }

            /**
             * US221 — Adiciona um representante a um cliente existente.
             */
            @Transactional
            public void addCustomerRepresentative(String rawVat, String rawName, String rawEmail, String rawPosition, String rawPhone) {
                // Validations
                if (rawVat == null || !rawVat.matches("^PT\\d{9}$")) {
                    throw new IllegalArgumentException("Invalid VAT format. Must start with 'PT' followed by 9 digits.");
                }
                if (rawName == null || rawName.trim().length() < 2) {
                    throw new IllegalArgumentException("Name must be at least 2 characters.");
                }
                if (rawEmail == null || !rawEmail.matches("^[\\w-.]+@[\\w-]+\\.[a-z]{2,}$")) {
                    throw new IllegalArgumentException("Invalid email format.");
                }
                if (rawPosition == null || rawPosition.isBlank()) {
                    throw new IllegalArgumentException("Position cannot be blank.");
                }

                VAT vat = new VAT(rawVat);
                Customer customer = customerRepository.findByVat(vat)
                        .orElseThrow(() -> new IllegalArgumentException("Customer not found for VAT: " + rawVat));

                Email email = new Email(rawEmail);

                if (customerRepresentativeRepository.findByEmail(email).isPresent()) {
                    throw new IllegalArgumentException("A representative with this email already exists.");
                }
                if (userRepository.findByEmail(email.value()).isPresent()) {
                    throw new IllegalArgumentException("A user with this email already exists.");
                }

                Role repRole = roleRepository.findByRoleName(RoleName.CUSTOMER_REPRESENTATIVE)
                        .orElseThrow(() -> new IllegalStateException("Role not found: CUSTOMER_REPRESENTATIVE"));

                Name name = new Name(rawName);
                Position position = new Position(rawPosition);
                PhoneNumber phone = new PhoneNumber(rawPhone);

                User repUser = new User(email.value(), passwordEncoder.encode("defaultPassword"), repRole, true, name, phone);
                CustomerRepresentative rep = new CustomerRepresentative(email, name, position);
                rep.setPhoneNumber(phone);
                rep.setUser(repUser);

                customer.addRepresentative(rep);

                customerRepository.save(customer);
            }

            /**
             * US222 — Lista os representantes de um cliente.
             */
            @Transactional
            public List<CustomerRepresentative> listActiveRepresentatives(String rawVat) {
                VAT vat = new VAT(rawVat);
                Customer customer = customerRepository.findByVat(vat)
                        .orElseThrow(() -> new IllegalArgumentException("Customer not found for VAT: " + rawVat));

                return customer.representatives().stream()
                        .filter(rep -> userRepository.findByEmail(rep.getEmail().value())
                                .map(User::isEnabled)
                                .orElse(false))
                        .toList();
            }

            /**
             * US223 – Edita o email e número de telefone de um representante de cliente.
             */
            @Transactional
            public void editCustomerRepresentative(String rawEmail, String newEmail, String newPhoneNumber) {
                Email currentEmail = new Email(rawEmail);
                CustomerRepresentative rep = customerRepresentativeRepository.findByEmail(currentEmail)
                        .orElseThrow(() -> new IllegalArgumentException("Representative not found with email: " + rawEmail));

                User user = userRepository.findByEmail(rawEmail)
                        .orElseThrow(() -> new IllegalArgumentException("User not found for representative: " + rawEmail));

                if (!user.isEnabled()) {
                    throw new IllegalArgumentException("Cannot edit a disabled representative.");
                }

                if (newEmail != null && !newEmail.isBlank() && !newEmail.equals(rawEmail)) {
                    Email newEmailObj = new Email(newEmail);

                    if (customerRepresentativeRepository.findByEmail(newEmailObj).isPresent()) {
                        throw new IllegalArgumentException("A representative with this email already exists.");
                    }

                    if (userRepository.findByEmail(newEmail).isPresent()) {
                        throw new IllegalArgumentException("A user with this email already exists.");
                    }

                    user.setEmail(newEmail);
                    rep.setEmail(new Email(user.email()));
                }

                if (newPhoneNumber != null && !newPhoneNumber.isBlank()) {
                    PhoneNumber phoneNumber = new PhoneNumber(newPhoneNumber);
                    rep.setPhoneNumber(phoneNumber);
                    user.setPhoneNumber(phoneNumber);
                }

                customerRepresentativeRepository.save(rep);
                userRepository.save(user);
            }

            /**
             * US224 — Desativa um representante de cliente.
             */
            @Transactional
            public boolean disableCustomerRepresentative(String email) {
                Email representativeEmail = new Email(email);
                CustomerRepresentative representative = customerRepresentativeRepository.findByEmail(representativeEmail)
                        .orElseThrow(() -> new IllegalArgumentException("Representative not found with email: " + email));

                User user = userRepository.findByEmail(email)
                        .orElseThrow(() -> new IllegalArgumentException("User not found for representative: " + email));

                if (!user.isEnabled()) {
                    return false;
                }

                user.deactivate();
                userRepository.save(user);
                return true;
            }

            @Transactional
            public Customer getCustomer(VAT vat) {
                return customerRepository.findByVat(vat)
                        .orElseThrow(() -> new IllegalArgumentException("Customer not found for VAT: " + vat.value()));
            }
        }