package shodrone.figuremanagement;

import jakarta.persistence.*;
import shodrone.customermanagement.VAT;
import shodrone.dronemodelmanagement.DroneModel;
import shodrone.dronemodelmanagement.DroneModelFigure;
import shodrone.figurecategorymanagement.FigureCategory;

import java.util.*;

@Entity
@Table(name = "figures")
public class Figure {

    @EmbeddedId
    @AttributeOverride(name = "id", column = @Column(name = "code"))
    private Code code;

    @Embedded
    @AttributeOverride(name = "content", column = @Column(name = "description"))
    private Description description;

    @Embedded
    @AttributeOverride(name = "fullName", column = @Column(name = "designer"))
    private Designer designer;

    @Embedded
    @AttributeOverride(name = "customer", column = @Column(name = "exclusivity"))
    private Exclusivity exclusivity;

    @Embedded
    @AttributeOverride(name = "version", column = @Column(name = "version"))
    private Version version;

    @Embedded
    @AttributeOverride(name = "path", column = @Column(name = "dsl_code"))
    private DSLCode dslCode;

    @ElementCollection
    @CollectionTable(name = "figure_keywords", joinColumns = @JoinColumn(name = "figure_code"))
    @Column(name = "keyword")
    private List<Keyword> keywords = new ArrayList<>();

    @ManyToOne
    @JoinColumn(name = "category_id")
    private FigureCategory category;

    @OneToMany(mappedBy = "figure", cascade = CascadeType.ALL, orphanRemoval = true, fetch =  FetchType.EAGER)
    private Set<DroneModelFigure> droneFigures = new HashSet<>();

    @Column(name = "is_active")
    private boolean isActive;

    @Column(name = "decommission_date")
    private Date decommissionDate;

    protected Figure() {
    }

    public Figure(Code code, List<Keyword> keywords, FigureCategory category) {
        this.code = code;
        this.keywords = keywords != null ? keywords : new ArrayList<>();
        this.category = category;
        this.isActive = true;
    }

    public boolean isActive() {
        return isActive;
    }

    public Designer designer() {
        return designer;
    }

    public boolean isExclusive() {
        return exclusivity != null && exclusivity.value() != null;
    }

    public VAT customer() {
        return isExclusive() ? exclusivity.value() : null;
    }

    public Version version() {
        return version;
    }

    public Code code() {
        return code;
    }

    public FigureCategory category() {
        return category;
    }

    public List<Keyword> setOfKeywords() {
        return new ArrayList<>(keywords);
    }

    public void addKeyword(Keyword keyword) {
        keywords.add(keyword);
    }

    public boolean hasKeyword(Keyword keyword) {
        return keywords.contains(keyword);
    }

    public void addDslCode(DSLCode dslCode) {
        this.dslCode = dslCode;
    }

    public void deactivate() {
        this.isActive = false;
        this.decommissionDate = new Date();
    }

    public void editDescription(Description description) {
        this.description = description;
    }

    public void addExclusivity(Exclusivity exclusivity) {
        if (this.exclusivity != null) {
            throw new IllegalStateException("Figure already has exclusivity");
        }
        this.exclusivity = exclusivity;
    }

    public void newVersion(Version version) {
        this.version = version;
    }

    public void addDesigner(Designer designer) {
        this.designer = designer;
    }

    public void addCompatibleModel(DroneModel model) {
        if (model == null) throw new IllegalArgumentException("Model cannot be null.");
        // Prevent duplicates
        boolean alreadyExists = droneFigures.stream()
                .anyMatch(dmf -> dmf.getDroneModel().equals(model));
        if (!alreadyExists) {
            DroneModelFigure dmf = new DroneModelFigure(this, model);
            droneFigures.add(dmf);
        }
    }

    public Set<DroneModelFigure> getDroneFigures() {
        return droneFigures;
    }

    public Description getDescription() {
        return description;
    }
    @Override
    public String toString() {
        return "Code: " + code.value() +
                " Category: " + (category != null ? category.name() : "Uncategorized");
    }
}
