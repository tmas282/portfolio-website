package shodrone.dronemaintenancemanagement;

public enum MaintenanceTypeStatus {
    EDITABLE,
    NOTEDITABLE;

    public boolean isEditable() {
        return this == EDITABLE;
    }
    @Override
    public String toString() {
        return name().toLowerCase();
    }
}