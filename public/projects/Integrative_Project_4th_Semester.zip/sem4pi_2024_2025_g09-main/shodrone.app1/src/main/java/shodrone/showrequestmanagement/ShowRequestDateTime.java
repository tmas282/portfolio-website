package shodrone.showrequestmanagement;

import jakarta.persistence.Embeddable;
import java.time.LocalDateTime;
import java.util.Objects;

@Embeddable
public class ShowRequestDateTime {
    private LocalDateTime datetime;

    public LocalDateTime getDateTime() {
        return datetime;
    }

    public void setDateTime(LocalDateTime datetime) {
        assert datetime != null;
        this.datetime = datetime;
    }
    public void setDateTime(String datetime) {
        assert datetime != null;
        String[] strDts = datetime.split(" ");
        this.datetime = LocalDateTime.parse(strDts[0] + "T" + strDts[1]);
    }

    protected ShowRequestDateTime() {
    }

    public ShowRequestDateTime(LocalDateTime datetime) {
        assert datetime != null;
        this.datetime = datetime;
    }
    public ShowRequestDateTime(String datetime) {
        assert datetime != null;
        String[] strDts = datetime.split(" ");
        this.datetime = LocalDateTime.parse(strDts[0] + "T" + strDts[1]);
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        ShowRequestDateTime that = (ShowRequestDateTime) o;
        return Objects.equals(datetime, that.datetime);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(datetime);
    }
}
