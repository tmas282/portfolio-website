package shodrone.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import shodrone.dronemanagement.Drone;
import shodrone.dronemanagement.DroneStatus;
import shodrone.dronemanagement.SerialNumber;
import java.util.List;
import shodrone.dronemodelmanagement.ModelID;
import java.util.Optional;

public interface DroneRepository extends JpaRepository<Drone, SerialNumber> {
    boolean existsBySerialNumber(SerialNumber serialNumber);
    List<Drone> findByModel_ModelIDAndStatus(ModelID modelID, DroneStatus status);
    Optional<Drone> findById(SerialNumber serialNumber);
    Optional<Drone> findBySerialNumber(SerialNumber serialNumber);
}