package shodrone.presentation;

import org.springframework.stereotype.Component;
import shodrone.controller.ConfigureTemplateController;
import shodrone.controller.FigureController;
import shodrone.controller.ListShowRequestsController;
import shodrone.figuremanagement.Code;
import shodrone.figuremanagement.Figure;
import shodrone.proposaltemplate.en.ProposalTemplateENValidator;
import shodrone.proposaltemplate.pt.ProposalTemplatePTValidator;

import java.util.Scanner;

import static shodrone.presentation.ListShowRequestsUI.listShowRequestsOfCustomer;

@Component
public class CRMManagerUI {

    private final Scanner scanner = new Scanner(System.in);
    private final FigureController figureController;
    private final ListShowRequestsController listShowRequestsController;
    private final ConfigureTemplateController configureTemplateController;

    public CRMManagerUI(FigureController figureController, ListShowRequestsController listShowRequestsController,
                            ConfigureTemplateController configureTemplateController) {
        this.figureController = figureController;
        this.listShowRequestsController = listShowRequestsController;
        this.configureTemplateController = configureTemplateController;

    }

    public void run() {
        boolean exit = false;

        while (!exit) {
            System.out.println("\n=== CRM Manager Menu ===");
            System.out.println("1. Decommission A Figure");
            System.out.println("2. List Show Requests of Client");
            System.out.println("3. Validate Proposal Template");
            System.out.println("4. Configure Show Proposal Template");
            System.out.println("5. Exit");
            System.out.println("0. Logout");

            System.out.print("Choose an option: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    System.out.println("-> Decommisioning a figure...");
                    decommissionFigure();
                    break;
                case "2":
                    listShowRequestsOfCustomer(listShowRequestsController, scanner);
                    break;
                case "3":
                    validateProposalTemplate();
                    break;
                case "4":
                    configureTemplate();
                    break;
                case "5":
                    System.out.println("Exiting...");
                    System.exit(0);
                case "0":
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    public void decommissionFigure() {
        System.out.println("List of active figures:");
        for (Figure figure: figureController.allPublicFigures()){
            System.out.println(" - " + figure);
        }
        System.out.println("Type the code of the figure you want to decommission: ");
        Long id;
        String code = scanner.nextLine();
        try {
            id = Long.parseLong(code);
        }
        catch (NumberFormatException e) {
            System.out.println("Invalid code. Try again.");
            return;
        }
        int res = figureController.decommissionFigure(new Code(id));
        if(res == 1) {
            System.out.println("❌ Figure does not exist.");
        }
        else if (res == 2) {
            System.out.println("⚠️ Figure has already been decommissioned...");
        }
        else {
            System.out.println("✅ Figure successfully decommissioned!");
        }
    }

    private void validateProposalTemplate() {
        System.out.print("Enter the path to the proposal template (.txt): ");
        String path = scanner.nextLine();
        System.out.print("Language (en/pt): ");
        String lang = scanner.nextLine().trim().toLowerCase();
        boolean valid;
        if (lang.equals("en")) {
            valid = new ProposalTemplateENValidator().validate(path);
        } else if (lang.equals("pt")) {
            valid = new ProposalTemplatePTValidator().validate(path);
        } else {
            System.out.println("Unsupported language.");
            return;
        }
        if (valid) {
            System.out.println("✅ Proposal template is valid!");
        } else {
            System.out.println("❌ Proposal template is NOT valid.");
        }
    }

    private void configureTemplate() {
        System.out.print("Enter the path to the proposal template (.txt): ");
        String path = scanner.nextLine();
        int res = configureTemplateController.configureTemplate(path);
        if(res==0) {
            System.out.println("✅ Proposal template was saved!");
        }
        else if (res==1) {
            System.out.println("⚠️ File not found!");
        }
        else if(res==2) {
            System.out.println("⚠️ Couldn't process file...");
        }
        else {
            System.out.println("❌ Proposal template is not valid!");
        }
    }


}
