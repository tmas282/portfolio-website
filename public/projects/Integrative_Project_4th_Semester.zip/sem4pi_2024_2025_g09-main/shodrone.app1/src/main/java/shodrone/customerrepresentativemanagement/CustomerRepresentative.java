package shodrone.customerrepresentativemanagement;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import shodrone.customermanagement.Customer;
import shodrone.customermanagement.Email;
import shodrone.customermanagement.Name;
import shodrone.customermanagement.PhoneNumber;
import shodrone.usermanagement.User;

import java.util.Objects;

@Entity
@Table(name = "customer_representatives")
public class CustomerRepresentative {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Embedded
    @NotNull
    @AttributeOverride(name = "fullName", column = @Column(name = "customer_representative_name", nullable = false))
    private Name name;

    @Embedded
    @NotNull
    @AttributeOverride(name = "email", column = @Column(name = "email", nullable = false, unique = true))
    private Email email;

    @Embedded
    @NotNull
    @AttributeOverride(name = "value", column = @Column(name = "position", nullable = false))
    private Position position;

    @Embedded
    @AttributeOverride(name = "number", column = @Column(name = "phone_number", nullable = false))
    private PhoneNumber phoneNumber;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "vat", referencedColumnName = "vat")
    private Customer customer;

    @OneToOne(optional = false, cascade = CascadeType.ALL)
    @MapsId
    @JoinColumn(name = "user_id", unique = true)
    private User user;


    // Default constructor required by JPA
    public CustomerRepresentative() {}

    public CustomerRepresentative(Email email, Name name, Position position) {
        if (email == null || name == null || position == null) {
            throw new IllegalArgumentException("None of the value objects can be null");
        }
        this.email = email;
        this.name = name;
        this.position = position;
    }

    // Getters and setters

    public void setUser(User user) {
        this.user = user;
    }

    public User user() {
        return user;
    }

    public Name getName() {
        return name;
    }

    public Email getEmail() {
        return email;
    }

    public void setEmail(Email email) {
        this.email = email;
    }

    public Position getPosition() {
        return position;
    }

    public PhoneNumber getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(PhoneNumber phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    // Equals and hashCode based on email (primary key)
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CustomerRepresentative)) return false;
        CustomerRepresentative that = (CustomerRepresentative) o;
        return Objects.equals(email, that.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(email);
    }
}