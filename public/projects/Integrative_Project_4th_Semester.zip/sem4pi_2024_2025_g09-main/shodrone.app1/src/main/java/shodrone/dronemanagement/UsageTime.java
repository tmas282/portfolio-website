package shodrone.dronemanagement;

import jakarta.persistence.Embeddable;

@Embeddable
public class UsageTime {

    private int time;

    protected UsageTime() {
        // for JPA
    }

    public UsageTime(int time) {
        if (time < 0) {
            throw new IllegalArgumentException("Usage time cannot be negative.");
        }
        this.time = time;
    }

    public int value() {
        return time;
    }

    public void increment(int additionalTime) {
        if (additionalTime < 0) {
            throw new IllegalArgumentException("Additional time cannot be negative.");
        }
        this.time += additionalTime;
    }

    @Override
    public String toString() {
        return String.valueOf(time);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UsageTime)) return false;
        UsageTime that = (UsageTime) o;
        return time == that.time;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(time);
    }
}
