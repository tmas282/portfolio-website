package shodrone.services;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import shodrone.figurecategorymanagement.*;
import shodrone.repositories.FigureCategoryRepository;

@Service
public class FigureCategoryService {

    private final FigureCategoryRepository categoryRepository;

    @Autowired
    public FigureCategoryService(FigureCategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    /**
     * US245 — Add Figure Category
     */
    @Transactional
    public void addFigureCategory(String rawName, String rawDescription) {
        CategoryName name = new CategoryName(rawName);
        Description description = new Description(rawDescription);

        if (categoryRepository.findByName_ValueIgnoreCase(name.value()).isPresent()) {
            throw new IllegalArgumentException("A category with this name already exists.");
        }

        if (categoryRepository.findByDescription_TextIgnoreCase(description.value()).isPresent()) {
            throw new IllegalArgumentException("A category with this description already exists.");
        }

        FigureCategory newCategory = new FigureCategory(name, description);
        categoryRepository.save(newCategory);
    }

    /**
     * US246 — Edit Figure Category
     */
    @Transactional
    public void editFigureCategory(String currentRawName, String newRawName, String newRawDescription) {
        CategoryName currentName = new CategoryName(currentRawName);
        CategoryName newName = new CategoryName(newRawName);
        Description newDescription = new Description(newRawDescription);

        FigureCategory category = categoryRepository.findByName_ValueIgnoreCase(currentName.value())
                .orElseThrow(() -> new IllegalArgumentException("Category not found: " + currentRawName));

        if (!currentName.value().equalsIgnoreCase(newName.value()) &&
                categoryRepository.findByName_ValueIgnoreCase(newName.value()).isPresent()) {
            throw new IllegalArgumentException("Another category with the new name already exists.");
        }

        if (!category.description().value().equalsIgnoreCase(newDescription.value()) &&
                categoryRepository.findByDescription_TextIgnoreCase(newDescription.value()).isPresent()) {
            throw new IllegalArgumentException("Another category with the same description already exists.");
        }

        category.renameTo(newName);
        category.changeDescription(newDescription);

        categoryRepository.save(category);
    }

    /**
     * US247 — List Figure Categories
     */
    public Iterable<FigureCategory> listAllCategories() {
        return categoryRepository.findAllByOrderByName_ValueAsc();
    }

    /**
     * US248 — Activate
     */
    @Transactional
    public void activateCategory(String rawName) {
        CategoryName name = new CategoryName(rawName);

        FigureCategory category = categoryRepository.findByName_ValueIgnoreCase(name.value())
                .orElseThrow(() -> new IllegalArgumentException("Category not found"));

        if (category.status().isActive()) {
            throw new IllegalArgumentException("Category is already active.");
        }

        category.activate();
        categoryRepository.save(category);
    }

    /**
     * US248 — Deactivate
     */
    @Transactional
    public void deactivateCategory(String rawName) {
        CategoryName name = new CategoryName(rawName);

        FigureCategory category = categoryRepository.findByName_ValueIgnoreCase(name.value())
                .orElseThrow(() -> new IllegalArgumentException("Category not found"));

        if (!category.status().isActive()) {
            throw new IllegalArgumentException("Category is already inactive.");
        }

        category.deactivate();
        categoryRepository.save(category);
    }
}
