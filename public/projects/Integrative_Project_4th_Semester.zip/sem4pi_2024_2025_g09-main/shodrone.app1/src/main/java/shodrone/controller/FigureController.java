package shodrone.controller;


import org.springframework.stereotype.Controller;
import shodrone.figuremanagement.*;
import shodrone.services.FigureService;
import java.util.List;

@Controller
public class FigureController {

    private final FigureService service;

    public FigureController(FigureService service) {
        this.service = service;
    }

    public List<Figure> allPublicFigures() {
        return service.listAllActivePublicFigures();
    }

    public int addFigure(long code, List<Keyword> keywords, String categoryName) {
        return service.addFigure(code, keywords, categoryName);
    }

    public List<Figure> searchByCategory(String cat_name) {
        return service.searchByCategory(cat_name);
    }

    public List<Figure> searchByKeyword(String keyword) {
        return service.searchByKeyword(keyword);
    }

    public List<Figure> searchByCategoryAndKeyword(String cat_name, String keyword) {
        return service.searchByCategoryAndKeyword(cat_name, keyword);
    }

    public int editDescription(Code code, Description description) {
        return service.editDescription(code, description);
    }

    public int addExclusivity(Code code, Exclusivity exclusivity) {
        return service.addExclusivity(code, exclusivity);
    }

    public int addDslCode(Code code, DSLCode dslCode) {
        return service.addDslCode(code, dslCode);
    }

    public int addKeyword(Code code, Keyword keyword) {
        return service.addKeyword(code, keyword);
    }

    public int decommissionFigure(Code code) {
        return service.decommissionFigure(code);
    }

    public int newVersion(Code code, Version version) {
        return service.newVersion(code, version);
    }
}
