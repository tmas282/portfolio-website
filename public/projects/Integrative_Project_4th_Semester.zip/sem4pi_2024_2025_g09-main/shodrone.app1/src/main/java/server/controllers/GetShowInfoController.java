package server.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import server.dto.ShowProposalInfoDTO;
import server.services.GetShowInfoService;

@RestController
public class GetShowInfoController {

    private final GetShowInfoService service;

    public GetShowInfoController(GetShowInfoService service) {
        this.service = service;
    }

    @GetMapping("/get-show-info")
    public ShowProposalInfoDTO getShowInfo(@RequestParam("id") Long id) {
        return service.getShowInfo(id);
    }
}