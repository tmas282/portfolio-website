package shodrone.dronemodelmanagement;

import jakarta.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "dronemodels")
public class DroneModel {

    @EmbeddedId
    @AttributeOverride(name = "id", column = @Column(name = "model_id"))
    private ModelID modelID;

    @Embedded
    @AttributeOverride(name = "name", column = @Column(name = "programming_language"))
    private ProgrammingLanguage programmingLanguage;

    @Embedded
    private WindTolerance windTolerance;

    @Embedded
    @AttributeOverride(name = "thresholdValue", column = @Column(name = "maintenance_threshold"))
    private MaintenanceThreshold maintenanceThreshold;

    protected DroneModel() {
        // for JPA
    }

    public DroneModel(ModelID modelID, ProgrammingLanguage programmingLanguage, WindTolerance windTolerance, MaintenanceThreshold maintenanceThreshold) {
        if (modelID == null || programmingLanguage == null || windTolerance == null || maintenanceThreshold == null)
            throw new IllegalArgumentException("Fields cannot be null");
        this.modelID = modelID;
        this.programmingLanguage = programmingLanguage;
        this.windTolerance = windTolerance;
        this.maintenanceThreshold = maintenanceThreshold;
    }

    public ModelID getModelID() {
        return modelID;
    }

    public ProgrammingLanguage getProgrammingLanguage() {
        return programmingLanguage;
    }

    public WindTolerance getWindTolerance() {
        return windTolerance;
    }

    public MaintenanceThreshold getMaintenanceThreshold() {
        return maintenanceThreshold;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof DroneModel)) return false;
        DroneModel that = (DroneModel) o;
        return Objects.equals(modelID, that.modelID);
    }

    @Override
    public int hashCode() {
        return Objects.hash(modelID);
    }

    @Override
    public String toString() {
        return "DroneModel{" +
                "modelID=" + modelID +
                ", language=" + programmingLanguage +
                ", windTolerance=" + windTolerance +
                ", maintenanceThreshold=" + maintenanceThreshold +
                '}';
    }
}