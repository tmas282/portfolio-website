package shodrone.showproposalmanagement;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import shodrone.dronemanagement.Drone;
import shodrone.figuremanagement.Description;
import shodrone.showrequestmanagement.NumberOfDrones;
import shodrone.showrequestmanagement.ShowDescription;
import shodrone.showrequestmanagement.ShowRequest;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "showproposal")
public class ShowProposal {
    @Getter
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Getter
    @ManyToOne
    @JoinColumn(name = "show_request_id")
    private ShowRequest showRequest;

    @Getter
    @Setter
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private ShowProposalStatus status;

    @Getter
    @Embedded
    @AttributeOverride(name = "date", column = @Column(name = "show_date", nullable = false))
    private ShowProposalDate date;

    @Getter
    @Embedded
    @AttributeOverride(name = "time", column = @Column(name = "show_time", nullable = false))
    private ShowProposalTime time;

    @Getter
    @Embedded
    @AttributeOverride(name = "duration", column = @Column(name = "show_duration", nullable = false))
    private ShowProposalDuration duration;

    @Getter
    @Embedded
    @AttributeOverride(name = "place", column = @Column(name = "show_place", nullable = false))
    private ShowProposalPlace place;

    @Getter
    @Embedded
    @AttributeOverride(name = "number", column = @Column(name = "numberofdrones", nullable = false))
    private NumberOfDrones numberOfDrones;

    @Getter
    @Embedded
    @AttributeOverride(name = "description", column = @Column(name = "show_description", nullable = false))
    private ShowDescription description;

    @Getter
    @OneToMany(mappedBy = "showProposal", cascade = CascadeType.ALL, orphanRemoval = true, fetch =  FetchType.EAGER)
    private List<ShowProposalFigure> figures = new ArrayList<>();

    @Getter
    @ManyToMany
    private List<Drone> drones = new ArrayList<>();

    @Getter
    @Setter
    @Embedded
    @AttributeOverride(name = "link", column = @Column(name = "simulation_video_link"))
    private ShowProposalSimulationVideo simulationVideoLink;
    protected ShowProposal() {
    }

    public ShowProposal(ShowRequest showRequest, ShowProposalStatus status, NumberOfDrones numberOfDrones, 
                        ShowDescription description, ShowProposalDate date, ShowProposalTime time, 
                        ShowProposalDuration duration, ShowProposalPlace place) {
        if (showRequest == null || status == null || numberOfDrones == null || description == null || 
            date == null || time == null || duration == null || place == null) {
            throw new IllegalArgumentException("None of the parameters can be null");
        }
        String reqStatus = showRequest.getStatus().toString();
        if (!reqStatus.equals("ACCEPTED") && !reqStatus.equals("PENDING")) {
            throw new IllegalStateException("Only possible to create a proposal for a show request with status ACCEPTED or PENDING.");
        }
        this.showRequest = showRequest;
        this.status = ShowProposalStatus.DRAFT;
        this.numberOfDrones = numberOfDrones;
        this.description = description;
        this.date = date;
        this.time = time;
        this.duration = duration;
        this.place = place;
    }

    public ShowDescription identity(){
        return description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ShowProposal that = (ShowProposal) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Proposal id: " + id + "| Request id: " + showRequest.getId() + "| Status: " + status;
    }
}