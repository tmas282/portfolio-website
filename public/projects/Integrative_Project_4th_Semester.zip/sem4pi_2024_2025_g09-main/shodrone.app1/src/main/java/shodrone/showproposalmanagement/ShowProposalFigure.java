package shodrone.showproposalmanagement;

import jakarta.persistence.*;
import lombok.Getter;
import shodrone.figuremanagement.Figure;

import java.util.Objects;

@Entity
@Table(name = "showproposalfigure")
public class ShowProposalFigure {
    @Getter
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Getter
    @ManyToOne
    @JoinColumn(name = "show_proposal_id")
    private ShowProposal showProposal;

    @Getter
    @ManyToOne
    @JoinColumn(name = "figure_id")
    private Figure figure;

    @Getter
    @Column(name = "position")
    private int position;

    protected ShowProposalFigure() {
    }

    public ShowProposalFigure(Figure figure, int position) {
        if (figure == null) {
            throw new IllegalArgumentException("Figure cannot be null");
        }
        if (position < 0) {
            throw new IllegalArgumentException("Position must be non-negative");
        }
        this.figure = figure;
        this.position = position;
    }

    public void setShowProposal(ShowProposal showProposal) {
        this.showProposal = showProposal;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ShowProposalFigure that = (ShowProposalFigure) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}