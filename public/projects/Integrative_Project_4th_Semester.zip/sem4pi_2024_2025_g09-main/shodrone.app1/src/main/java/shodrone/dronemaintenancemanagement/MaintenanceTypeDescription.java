package shodrone.dronemaintenancemanagement;

import jakarta.persistence.Embeddable;
@Embeddable
public class MaintenanceTypeDescription {
    private String description;

    protected MaintenanceTypeDescription() {}

    public MaintenanceTypeDescription(String raw) {
        if (raw == null || raw.isBlank()) throw new IllegalArgumentException("Maintenance Type Description cannot be empty");
        this.description = raw.trim();
    }
    public void updateValue(String newDescription) {
        if (newDescription == null || newDescription.isBlank()) {
            throw new IllegalArgumentException("Maintenance Type Description cannot be empty");
        }
        this.description = newDescription.trim();
    }

    public String value() {
        return description;
    }

    @Override
    public String toString() {
        return description;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof MaintenanceTypeDescription && description.equals(((MaintenanceTypeDescription) o).description);
    }

    @Override
    public int hashCode() {
        return description.hashCode();
    }
}