package shodrone.dronemaintenancemanagement;

import jakarta.persistence.*;
import shodrone.dronemanagement.Drone;

import java.time.LocalDate;
import java.util.Objects;

@Entity
@Table(name = "maintenancerecords",
        uniqueConstraints = @UniqueConstraint(columnNames = {"drone_serial_number", "maintenance_date"}))

public class MaintenanceRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Embedded
    @AttributeOverride(name = "date", column = @Column(name = "maintenance_date", nullable = false))
    private MaintenanceDate maintenanceDate;

    @Embedded
    @AttributeOverride(name = "description", column = @Column(name = "maintenance_description", nullable = false))
    private MaintenanceDescription maintenanceDescription;

    @ManyToOne(optional = false)
    @JoinColumn(name = "maintenance_type_id", referencedColumnName = "id")
    private MaintenanceType maintenanceType;

    @ManyToOne(optional = false)
    @JoinColumn(name = "drone_serial_number", referencedColumnName = "serial_number")
    private Drone drone;

    protected MaintenanceRecord() {
        // for JPA
    }

    public MaintenanceRecord(MaintenanceDate maintenanceDate, MaintenanceDescription maintenanceDescription, MaintenanceType maintenanceType, Drone drone) {
        if (maintenanceDate == null || maintenanceDescription == null || maintenanceType == null || drone == null) {
            throw new IllegalArgumentException("Fields must not be null.");
        }
        this.maintenanceDate = maintenanceDate;
        this.maintenanceDescription = maintenanceDescription;
        this.maintenanceType = maintenanceType;
        this.drone = drone;
    }

    public MaintenanceDate getMaintenanceDate() {
        return maintenanceDate;
    }

    public MaintenanceDescription getMaintenanceDescription() {
        return maintenanceDescription;
    }

    public MaintenanceType getMaintenanceType() {
        return maintenanceType;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MaintenanceRecord)) return false;
        MaintenanceRecord that = (MaintenanceRecord) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}