package shodrone.figuremanagement;

import eapli.framework.domain.model.ValueObject;
import jakarta.persistence.Embeddable;


@Embeddable
public class Description implements Comparable<Description> {

    private String content;

    protected Description() {}

    public Description(String content) {
        if (content == null) throw new IllegalArgumentException("Write a description!");
        this.content = content;
    }

    public String value() {
        return content;
    }

    @Override
    public int compareTo(Description other) {
        return this.content.compareTo(other.content);
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof Description && content.equals(((Description) o).content);
    }

    @Override
    public int hashCode() {
        return content.hashCode();
    }

    @Override
    public String toString() {
        return content;
    }
}

