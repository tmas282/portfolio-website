package shodrone.controller;

import org.springframework.stereotype.Controller;
import shodrone.customermanagement.Customer;
import shodrone.customermanagement.VAT;
import shodrone.services.CustomerService;
import shodrone.services.ShowRequestService;
import shodrone.showrequestmanagement.*;

import java.time.LocalDateTime;
import java.util.List;

@Controller
public class EditShowRequestController {
    private final CustomerService customerService;
    private final ShowRequestService showRequestService;

    public EditShowRequestController(CustomerService customerService, ShowRequestService showRequestService) {
        this.customerService = customerService;
        this.showRequestService = showRequestService;
    }
    public List<ShowRequest> listShowRequestsOfCustomer(String VAT){
        Customer c = customerService.getCustomer(new VAT(VAT));
        return showRequestService.getShowRequestsOfCustomer(c);
    }
    public void editShowRequest(String vat, int id, String dateTime, int duration, String place, int numberOfDrones, String desc){
        Customer c = customerService.getCustomer(new VAT(vat));
        List<ShowRequest> showRequests = showRequestService.getShowRequestsOfCustomer(c);
        ShowRequest request = null;
        for(ShowRequest i : showRequests){
            if(i.getId() == id){
                request = i;
                break;
            }
        }
        assert request != null;
        request.getDatetime().setDateTime(dateTime);
        request.getDuration().setDuration(duration);
        request.getPlace().setPlace(place);
        request.getNumberOfDrones().setNumber(numberOfDrones);
        request.getDescription().setDescription(desc);
        showRequestService.editShowRequest(request);
    }
}
