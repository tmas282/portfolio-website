// Generated from C:/sem4pi_2024_2025_g09/shodrone.app1/src/main/java/shodrone/dronelanguage/DroneLanguage.g4 by ANTLR 4.13.2
package shodrone.dronelanguage;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link DroneLanguageParser}.
 */
public interface DroneLanguageListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link DroneLanguageParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(DroneLanguageParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneLanguageParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(DroneLanguageParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneLanguageParser#header}.
	 * @param ctx the parse tree
	 */
	void enterHeader(DroneLanguageParser.HeaderContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneLanguageParser#header}.
	 * @param ctx the parse tree
	 */
	void exitHeader(DroneLanguageParser.HeaderContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneLanguageParser#variablesSection}.
	 * @param ctx the parse tree
	 */
	void enterVariablesSection(DroneLanguageParser.VariablesSectionContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneLanguageParser#variablesSection}.
	 * @param ctx the parse tree
	 */
	void exitVariablesSection(DroneLanguageParser.VariablesSectionContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneLanguageParser#variableDecl}.
	 * @param ctx the parse tree
	 */
	void enterVariableDecl(DroneLanguageParser.VariableDeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneLanguageParser#variableDecl}.
	 * @param ctx the parse tree
	 */
	void exitVariableDecl(DroneLanguageParser.VariableDeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneLanguageParser#value}.
	 * @param ctx the parse tree
	 */
	void enterValue(DroneLanguageParser.ValueContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneLanguageParser#value}.
	 * @param ctx the parse tree
	 */
	void exitValue(DroneLanguageParser.ValueContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneLanguageParser#instructionsSection}.
	 * @param ctx the parse tree
	 */
	void enterInstructionsSection(DroneLanguageParser.InstructionsSectionContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneLanguageParser#instructionsSection}.
	 * @param ctx the parse tree
	 */
	void exitInstructionsSection(DroneLanguageParser.InstructionsSectionContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneLanguageParser#instruction}.
	 * @param ctx the parse tree
	 */
	void enterInstruction(DroneLanguageParser.InstructionContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneLanguageParser#instruction}.
	 * @param ctx the parse tree
	 */
	void exitInstruction(DroneLanguageParser.InstructionContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneLanguageParser#argumentGroupList}.
	 * @param ctx the parse tree
	 */
	void enterArgumentGroupList(DroneLanguageParser.ArgumentGroupListContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneLanguageParser#argumentGroupList}.
	 * @param ctx the parse tree
	 */
	void exitArgumentGroupList(DroneLanguageParser.ArgumentGroupListContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneLanguageParser#argumentGroup}.
	 * @param ctx the parse tree
	 */
	void enterArgumentGroup(DroneLanguageParser.ArgumentGroupContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneLanguageParser#argumentGroup}.
	 * @param ctx the parse tree
	 */
	void exitArgumentGroup(DroneLanguageParser.ArgumentGroupContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneLanguageParser#argumentContent}.
	 * @param ctx the parse tree
	 */
	void enterArgumentContent(DroneLanguageParser.ArgumentContentContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneLanguageParser#argumentContent}.
	 * @param ctx the parse tree
	 */
	void exitArgumentContent(DroneLanguageParser.ArgumentContentContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneLanguageParser#numericExpression}.
	 * @param ctx the parse tree
	 */
	void enterNumericExpression(DroneLanguageParser.NumericExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneLanguageParser#numericExpression}.
	 * @param ctx the parse tree
	 */
	void exitNumericExpression(DroneLanguageParser.NumericExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneLanguageParser#numericTuple}.
	 * @param ctx the parse tree
	 */
	void enterNumericTuple(DroneLanguageParser.NumericTupleContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneLanguageParser#numericTuple}.
	 * @param ctx the parse tree
	 */
	void exitNumericTuple(DroneLanguageParser.NumericTupleContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneLanguageParser#numericArray}.
	 * @param ctx the parse tree
	 */
	void enterNumericArray(DroneLanguageParser.NumericArrayContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneLanguageParser#numericArray}.
	 * @param ctx the parse tree
	 */
	void exitNumericArray(DroneLanguageParser.NumericArrayContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneLanguageParser#identifierArray}.
	 * @param ctx the parse tree
	 */
	void enterIdentifierArray(DroneLanguageParser.IdentifierArrayContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneLanguageParser#identifierArray}.
	 * @param ctx the parse tree
	 */
	void exitIdentifierArray(DroneLanguageParser.IdentifierArrayContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneLanguageParser#identifierTuple}.
	 * @param ctx the parse tree
	 */
	void enterIdentifierTuple(DroneLanguageParser.IdentifierTupleContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneLanguageParser#identifierTuple}.
	 * @param ctx the parse tree
	 */
	void exitIdentifierTuple(DroneLanguageParser.IdentifierTupleContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneLanguageParser#literal}.
	 * @param ctx the parse tree
	 */
	void enterLiteral(DroneLanguageParser.LiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneLanguageParser#literal}.
	 * @param ctx the parse tree
	 */
	void exitLiteral(DroneLanguageParser.LiteralContext ctx);
}