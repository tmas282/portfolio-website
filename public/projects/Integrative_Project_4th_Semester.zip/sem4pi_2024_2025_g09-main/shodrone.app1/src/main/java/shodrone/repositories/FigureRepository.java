package shodrone.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import shodrone.figuremanagement.Figure;
import shodrone.figuremanagement.Code;

import java.util.List;
import java.util.Optional;


@Repository
public interface FigureRepository extends JpaRepository<Figure,Code> {

    @Override
    @Query("SELECT f FROM Figure f WHERE f.exclusivity.customer_vat IS NULL AND f.isActive = true")
    List<Figure> findAll();

    Optional<Figure> findByCode(Code code);


}
