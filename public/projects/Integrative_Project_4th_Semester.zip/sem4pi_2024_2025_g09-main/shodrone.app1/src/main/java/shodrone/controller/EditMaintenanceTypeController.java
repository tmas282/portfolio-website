package shodrone.controller;

import org.springframework.stereotype.Controller;
import shodrone.dronemaintenancemanagement.MaintenanceType;
import shodrone.services.DroneMaintenanceService;

@Controller
public class EditMaintenanceTypeController {

    private final DroneMaintenanceService droneMaintenanceService;

    public EditMaintenanceTypeController(DroneMaintenanceService droneMaintenanceService) {
        this.droneMaintenanceService = droneMaintenanceService;
    }

    public MaintenanceType editMaintenanceTypeDescription(Long id, String newDescription) {
        return droneMaintenanceService.editMaintenanceTypeDescription(id, newDescription);
    }
}