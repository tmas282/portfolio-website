package shodrone.presentation;

import org.springframework.stereotype.Component;

import java.util.Scanner;

@Component
public class CustomerUI {

    private final Scanner scanner = new Scanner(System.in);

    public void run() {
        boolean exit = false;

        while (!exit) {
            System.out.println("\n=== Customer Menu ===");
            System.out.println("1. View My Bookings");
            System.out.println("2. Request a Show");
            System.out.println("0. Logout");

            System.out.print("Choose an option: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    System.out.println("-> Displaying bookings... [placeholder]");
                    break;
                case "2":
                    System.out.println("-> Requesting new show... [placeholder]");
                    break;
                case "0":
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }
}
