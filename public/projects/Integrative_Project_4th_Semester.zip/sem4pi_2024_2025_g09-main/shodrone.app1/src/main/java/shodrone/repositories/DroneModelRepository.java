package shodrone.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import shodrone.dronemodelmanagement.DroneModel;
import shodrone.dronemodelmanagement.ModelID;

import java.util.Optional;

@Repository
public interface DroneModelRepository extends JpaRepository<DroneModel, ModelID> {
    Optional<DroneModel> findByModelID(ModelID id);
}