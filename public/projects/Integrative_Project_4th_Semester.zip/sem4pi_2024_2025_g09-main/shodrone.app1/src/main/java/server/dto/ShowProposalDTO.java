package server.dto;

import java.time.LocalDate;

public record ShowProposalDTO(Long id, LocalDate date, String place, String description) {
}
