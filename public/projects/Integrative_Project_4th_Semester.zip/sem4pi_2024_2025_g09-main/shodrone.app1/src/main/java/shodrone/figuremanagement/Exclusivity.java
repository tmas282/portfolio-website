package shodrone.figuremanagement;

import eapli.framework.domain.model.ValueObject;
import jakarta.persistence.Embeddable;
import shodrone.customermanagement.Customer;
import shodrone.customermanagement.VAT;

import java.util.Optional;

@Embeddable
public class Exclusivity {

    private VAT customer_vat;

    protected Exclusivity() {}

    public Exclusivity(VAT customer_vat) {
        this.customer_vat = customer_vat;
    }

    public VAT value() {
        return customer_vat;
    }
}
