// Generated from C:/Users/afons/sem4pi_2024_2025_g09/shodrone.app1/src/main/java/shodrone/proposaltemplate/en/DroneShowTemplateEN.g4 by ANTLR 4.13.2
package shodrone.proposaltemplate.en;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link DroneShowTemplateENParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface DroneShowTemplateENVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplateENParser#document}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDocument(DroneShowTemplateENParser.DocumentContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplateENParser#salutation}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSalutation(DroneShowTemplateENParser.SalutationContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplateENParser#clientCompany}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClientCompany(DroneShowTemplateENParser.ClientCompanyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code clientLocationField}
	 * labeled alternative in {@link DroneShowTemplateENParser#clientLocation}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClientLocationField(DroneShowTemplateENParser.ClientLocationFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code vatField}
	 * labeled alternative in {@link DroneShowTemplateENParser#vat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVatField(DroneShowTemplateENParser.VatFieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplateENParser#documentID}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDocumentID(DroneShowTemplateENParser.DocumentIDContext ctx);
	/**
	 * Visit a parse tree produced by the {@code videoURLField}
	 * labeled alternative in {@link DroneShowTemplateENParser#videoURL}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVideoURLField(DroneShowTemplateENParser.VideoURLFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code insuranceAmountField}
	 * labeled alternative in {@link DroneShowTemplateENParser#insuranceAmount}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInsuranceAmountField(DroneShowTemplateENParser.InsuranceAmountFieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplateENParser#signatoryName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSignatoryName(DroneShowTemplateENParser.SignatoryNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplateENParser#pageOne}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPageOne(DroneShowTemplateENParser.PageOneContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplateENParser#pageTwo}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPageTwo(DroneShowTemplateENParser.PageTwoContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplateENParser#headerSection}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHeaderSection(DroneShowTemplateENParser.HeaderSectionContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplateENParser#introContent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntroContent(DroneShowTemplateENParser.IntroContentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code proposalIDField}
	 * labeled alternative in {@link DroneShowTemplateENParser#proposalID}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProposalIDField(DroneShowTemplateENParser.ProposalIDFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code proposalDateField}
	 * labeled alternative in {@link DroneShowTemplateENParser#proposalDate}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProposalDateField(DroneShowTemplateENParser.ProposalDateFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code eventDateField}
	 * labeled alternative in {@link DroneShowTemplateENParser#eventDate}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEventDateField(DroneShowTemplateENParser.EventDateFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code zipCodeField}
	 * labeled alternative in {@link DroneShowTemplateENParser#zipCode}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitZipCodeField(DroneShowTemplateENParser.ZipCodeFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code eventTimeField}
	 * labeled alternative in {@link DroneShowTemplateENParser#eventTime}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEventTimeField(DroneShowTemplateENParser.EventTimeFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code eventLengthField}
	 * labeled alternative in {@link DroneShowTemplateENParser#eventLength}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEventLengthField(DroneShowTemplateENParser.EventLengthFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code gpsLatField}
	 * labeled alternative in {@link DroneShowTemplateENParser#gpsLat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGpsLatField(DroneShowTemplateENParser.GpsLatFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code gpsLongField}
	 * labeled alternative in {@link DroneShowTemplateENParser#gpsLong}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGpsLongField(DroneShowTemplateENParser.GpsLongFieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplateENParser#attachmentDetails}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttachmentDetails(DroneShowTemplateENParser.AttachmentDetailsContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplateENParser#droneModel}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDroneModel(DroneShowTemplateENParser.DroneModelContext ctx);
	/**
	 * Visit a parse tree produced by the {@code droneCountField}
	 * labeled alternative in {@link DroneShowTemplateENParser#droneCount}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDroneCountField(DroneShowTemplateENParser.DroneCountFieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplateENParser#droneEntry}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDroneEntry(DroneShowTemplateENParser.DroneEntryContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplateENParser#equipmentList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEquipmentList(DroneShowTemplateENParser.EquipmentListContext ctx);
	/**
	 * Visit a parse tree produced by the {@code figureNumField}
	 * labeled alternative in {@link DroneShowTemplateENParser#figureNum}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFigureNumField(DroneShowTemplateENParser.FigureNumFieldContext ctx);
	/**
	 * Visit a parse tree produced by the {@code figureNameField}
	 * labeled alternative in {@link DroneShowTemplateENParser#figureName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFigureNameField(DroneShowTemplateENParser.FigureNameFieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplateENParser#figureEntry}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFigureEntry(DroneShowTemplateENParser.FigureEntryContext ctx);
	/**
	 * Visit a parse tree produced by {@link DroneShowTemplateENParser#performanceElements}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPerformanceElements(DroneShowTemplateENParser.PerformanceElementsContext ctx);
}