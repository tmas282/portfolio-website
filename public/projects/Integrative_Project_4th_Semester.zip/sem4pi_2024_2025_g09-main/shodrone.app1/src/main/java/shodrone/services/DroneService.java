package shodrone.services;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import shodrone.dronemanagement.*;
import shodrone.dronemodelmanagement.DroneModel;
import shodrone.dronemodelmanagement.ModelID;
import shodrone.repositories.DroneModelRepository;
import shodrone.repositories.DroneRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@Transactional
public class DroneService {

    private final DroneRepository droneRepo;
    private final DroneModelRepository modelRepo;

    @Autowired
    public DroneService(DroneRepository droneRepo, DroneModelRepository modelRepo) {
        this.droneRepo = droneRepo;
        this.modelRepo = modelRepo;
    }

    public Drone addDrone(String serialNumberStr, String modelIdStr, String routineStr) {
        SerialNumber serial = new SerialNumber(serialNumberStr);
        if (droneRepo.existsBySerialNumber(serial)) {
            throw new IllegalStateException("Drone with this serial number already exists.");
        }

        ModelID modelID = new ModelID(modelIdStr);
        DroneModel model = modelRepo.findById(modelID)
                .orElseThrow(() -> new IllegalArgumentException("No such drone model: " + modelIdStr));

        SpecificRoutine routine = new SpecificRoutine(routineStr);
        Drone drone = new Drone(serial, model, DroneStatus.ACTIVE, routine);

        return droneRepo.save(drone);
    }
    public void removeDrone(String serialNumberStr, String reasonStr, LocalDate date, DroneStatus newStatus) {
        SerialNumber serial = new SerialNumber(serialNumberStr);
        Drone drone = droneRepo.findById(serial)
                .orElseThrow(() -> new IllegalArgumentException("Drone with serial " + serialNumberStr + " not found."));

        RemovalReason reason = new RemovalReason(reasonStr);
        RemovalDate removalDate = new RemovalDate(date);

        drone.markAsRemoved(reason, removalDate, newStatus);
        droneRepo.save(drone);
    }
    public List<Drone> listActiveDronesByModel(String modelIdStr) {
        ModelID modelID = new ModelID(modelIdStr);
        return droneRepo.findByModel_ModelIDAndStatus(modelID, DroneStatus.ACTIVE);
    }

    public boolean droneExists(String serialNumber) {
        SerialNumber sn = new SerialNumber(serialNumber);
        return droneRepo.existsBySerialNumber(sn);
    }

    public Optional<Drone> getDroneBySerialNumber(String serialNumber) {
        SerialNumber sn = new SerialNumber(serialNumber);
        return droneRepo.findBySerialNumber(sn);
    }

    public List<Drone> getDronesAvailable(Map<ModelID, Integer> requestedDrones) {
        List<Drone> drones = new ArrayList<>();
        for (Map.Entry<ModelID, Integer> entry : requestedDrones.entrySet()) {
            ModelID modelId = entry.getKey();
            int requested = entry.getValue();
            List<Drone> availableDrones = droneRepo.findByModel_ModelIDAndStatus(modelId, DroneStatus.ACTIVE);
            int available = availableDrones.size();
            if (requested > available) {
                throw new IllegalArgumentException("Request total drone model are less than the available ones");
            }
            else{
                for (int i = 0; i < requested; i++) {
                    drones.add(availableDrones.get(i));
                }
            }

        }
        return drones;
    }
}