package shodrone.figuremanagement;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.util.Objects;

@Embeddable
public class DSLCode {

    @Column(name = "dsl_code", nullable = false)
    private String path;

    protected DSLCode() {
        // necessário para JPA
    }

    public DSLCode(final String path) {
        if (path == null || path.isBlank()) {
            throw new IllegalArgumentException("DSL code path cannot be null or blank");
        }
        this.path = path;
    }

    public String path() {
        return path;
    }

    @Override
    public String toString() {
        return path;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof DSLCode)) return false;
        DSLCode that = (DSLCode) o;
        return Objects.equals(path, that.path);
    }

    @Override
    public int hashCode() {
        return Objects.hash(path);
    }
}
