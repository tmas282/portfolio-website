package shodrone.controller;

import org.springframework.stereotype.Controller;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import shodrone.services.TemplateService;
//import shodrone.proposaltemplate.ProposalTemplateLexer;
//import shodrone.proposaltemplate.ProposalTemplateParser;
/**
 * Controller responsible for configuring proposal templates.
 * This controller handles the validation and storage of proposal templates.
 */
@Controller
public class ConfigureTemplateController {

    private final TemplateService templateService;
    /**
     * Default constructor for the ConfigureTemplateController.
     */
    public ConfigureTemplateController(TemplateService templateService) {
        this.templateService = templateService;
    }
    /**
     * Configures a proposal template by validating it and saving it to the resources folder.
     *
     * @param filepath The path to the template file to be configured
     * @return 1 if the template is valid and was successfully saved, 0 otherwise
     */
    public int configureTemplate(String filepath) {
        return templateService.configureTemplate(filepath);
    }
}