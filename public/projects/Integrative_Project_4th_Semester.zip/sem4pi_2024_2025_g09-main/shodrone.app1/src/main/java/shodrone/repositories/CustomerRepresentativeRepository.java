package shodrone.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import shodrone.customerrepresentativemanagement.CustomerRepresentative;
import shodrone.customermanagement.Email;

import java.util.Optional;

public interface CustomerRepresentativeRepository extends JpaRepository<CustomerRepresentative, Email> {
    Optional<CustomerRepresentative> findByEmail(Email email);
}