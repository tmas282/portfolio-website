package shodrone.proposaltemplate.en;

import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class ProposalTemplateENValidator {
    public boolean validate(String filePath) {
        try {
            String content = new String(Files.readAllBytes(Paths.get(filePath)));
            CharStream input = CharStreams.fromString(content);
            DroneShowTemplateENLexer lexer = new DroneShowTemplateENLexer(input);
            CommonTokenStream tokens = new CommonTokenStream(lexer);
            DroneShowTemplateENParser parser = new DroneShowTemplateENParser(tokens);
            parser.removeErrorListeners();
            parser.addErrorListener(new BaseErrorListener() {
                @Override
                public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol,
                                        int line, int charPositionInLine, String msg, RecognitionException e) {
                    throw new RuntimeException("Syntax error at line " + line + ": " + msg);
                }
            });
            parser.document();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}