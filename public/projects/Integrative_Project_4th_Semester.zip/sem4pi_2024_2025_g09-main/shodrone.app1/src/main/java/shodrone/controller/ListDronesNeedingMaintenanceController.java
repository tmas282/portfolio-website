package shodrone.controller;

import org.springframework.stereotype.Controller;
import shodrone.dronemanagement.Drone;
import shodrone.services.DroneMaintenanceService;

import java.time.LocalDate;
import java.util.List;

@Controller
public class ListDronesNeedingMaintenanceController {

    private final DroneMaintenanceService droneMaintenanceService;

    public ListDronesNeedingMaintenanceController(DroneMaintenanceService droneMaintenanceService) {
        this.droneMaintenanceService = droneMaintenanceService;
    }

    public List<Drone> listDronesNeedingMaintenance(LocalDate date) {
        return droneMaintenanceService.listDronesNeedingPreventiveMaintenance(date);
    }
}