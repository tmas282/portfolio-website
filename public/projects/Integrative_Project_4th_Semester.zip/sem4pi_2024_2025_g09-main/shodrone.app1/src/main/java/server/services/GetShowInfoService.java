package server.services;

import org.springframework.stereotype.Service;
import server.dto.ShowProposalInfoDTO;
import shodrone.repositories.ShowProposalRepository;
import shodrone.showproposalmanagement.ShowProposal;
import shodrone.showproposalmanagement.ShowProposalFigure;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class GetShowInfoService {

    private final ShowProposalRepository showProposalRepository;

    public GetShowInfoService(shodrone.repositories.ShowProposalRepository showProposalRepository) {
        this.showProposalRepository = showProposalRepository;
    }

    public ShowProposalInfoDTO getShowInfo(Long id) {
        ShowProposal proposal = showProposalRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("ShowProposal not found: " + id));

        List<String> figures = proposal.getFigures().stream()
                .map(ShowProposalFigure::getFigure)
                .map(f -> String.valueOf(f.code().value()))
                .collect(Collectors.toList());

        return new ShowProposalInfoDTO(
                proposal.getId(),
                proposal.getDate().value(),
                proposal.getTime().value(),
                proposal.getDuration().value(),
                proposal.getPlace().value(),
                proposal.getNumberOfDrones().getNumber(),
                proposal.getDescription().getDescription(),
                proposal.getStatus().name(),
                figures
        );
    }
}