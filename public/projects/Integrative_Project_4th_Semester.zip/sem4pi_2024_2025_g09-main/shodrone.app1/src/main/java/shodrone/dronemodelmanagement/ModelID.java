package shodrone.dronemodelmanagement;

import jakarta.persistence.Embeddable;

import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class ModelID implements Serializable {
    private String id;

    protected ModelID() {
    }

    public ModelID(String id) {
        if (id == null || id.isBlank())
            throw new IllegalArgumentException("Model ID cannot be null or empty");
        this.id = id.trim();
    }

    public String value() {
        return id;
    }

    @Override
    public String toString() {
        return id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ModelID)) return false;
        ModelID modelID = (ModelID) o;
        return id.equalsIgnoreCase(modelID.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id.toLowerCase());
    }
}