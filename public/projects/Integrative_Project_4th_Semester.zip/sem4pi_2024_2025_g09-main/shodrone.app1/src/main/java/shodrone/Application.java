package shodrone;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = {
        "shodrone",
        "integrations.plugins.drone.alternate",
        "integrations.plugins.figure.alternate"
})
@EnableJpaRepositories(basePackages = "shodrone.repositories")
@EntityScan(basePackages = {
        "shodrone.usermanagement",
        "shodrone.customermanagement",
        "shodrone.customerrepresentativemanagement",
        "shodrone.figurecategorymanagement",
        "shodrone.figuremanagement",
        "shodrone.dronemodelmanagement",
        "shodrone.dronemanagement",
        "shodrone.showrequestmanagement",
        "shodrone.showproposalmanagement",
        "shodrone.dronemaintenancemanagement",
        "shodrone.showmanagement"
})
public class Application {

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(Application.class);
        app.setWebApplicationType(WebApplicationType.NONE);
        app.run(args);
    }
}