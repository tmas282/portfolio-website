package shodrone.showproposalmanagement;

import jakarta.persistence.Embeddable;
import java.util.Objects;

@Embeddable
public class ShowProposalSimulationVideo {
    private String link;

    protected ShowProposalSimulationVideo() {}

    public ShowProposalSimulationVideo(String link) {
        if (link == null || link.isBlank())
            throw new IllegalArgumentException("Simulation video link cannot be null or blank");
        if (!link.startsWith("http://") && !link.startsWith("https://"))
            throw new IllegalArgumentException("Simulation video link should start by http:// ou https://");
        this.link = link;
    }

    public String value() {
        return link;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ShowProposalSimulationVideo that = (ShowProposalSimulationVideo) o;
        return Objects.equals(link, that.link);
    }

    @Override
    public int hashCode() {
        return Objects.hash(link);
    }
}