package shodrone.repositories;


import org.springframework.data.jpa.repository.JpaRepository;
import shodrone.customermanagement.Customer;
import shodrone.customermanagement.Email;
import shodrone.customermanagement.VAT;
import java.util.Optional;

public interface CustomerRepository extends JpaRepository<Customer, VAT> {
    Optional<Customer> findByVat(VAT vat);
    Optional<Customer> findByEmail(Email email);
}


