package shodrone.proposaltemplate.pt;

import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class ProposalTemplatePTValidator {
    public boolean validate(String filePath) {
        try {
            String content = new String(Files.readAllBytes(Paths.get(filePath)));
            CharStream input = CharStreams.fromString(content);
            DroneShowTemplatePTLexer lexer = new DroneShowTemplatePTLexer(input);
            CommonTokenStream tokens = new CommonTokenStream(lexer);
            DroneShowTemplatePTParser parser = new DroneShowTemplatePTParser(tokens);
            parser.removeErrorListeners();
            parser.addErrorListener(new BaseErrorListener() {
                @Override
                public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol,
                                        int line, int charPositionInLine, String msg, RecognitionException e) {
                    throw new RuntimeException("Syntax error at line " + line + ": " + msg);
                }
            });
            parser.document();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}