package shodrone.dronemanagement;

import jakarta.persistence.Embeddable;

import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class SerialNumber implements Serializable {

    private String id;

    protected SerialNumber() {
        // for ORM
    }

    public SerialNumber(final String id) {
        if (id == null || id.isBlank())
            throw new IllegalArgumentException("Serial number cannot be null or empty");
        this.id = id.trim();
    }

    public String value() {
        return id;
    }

    @Override
    public String toString() {
        return id;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) return true;
        if (!(o instanceof SerialNumber)) return false;
        final SerialNumber that = (SerialNumber) o;
        return id.equalsIgnoreCase(that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id.toLowerCase());
    }
}
