package shodrone.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import shodrone.showproposalmanagement.ShowProposal;
import shodrone.showproposalmanagement.ShowProposalStatus;
import shodrone.showrequestmanagement.ShowRequest;

import java.util.List;
import java.util.Optional;

public interface ShowProposalRepository extends JpaRepository<ShowProposal, Long> {
    List<ShowProposal> findByShowRequest(ShowRequest showRequest);
    List<ShowProposal> findByStatus(ShowProposalStatus status);
    Optional<ShowProposal> findById(Long id);
    List<ShowProposal> findAll();
}