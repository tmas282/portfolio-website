package shodrone.customermanagement;

import jakarta.persistence.Embeddable;

@Embeddable
public class PhoneNumber {

    private String number;

    protected PhoneNumber() {}

    public PhoneNumber(String number) {
        if (number == null || !number.matches("\\d{9}")) {
            throw new IllegalArgumentException("Phone number must be 9 digits and not null.");
        }
        this.number = number;
    }

    public String value() {
        return number;
    }

    @Override
    public String toString() {
        return number;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof PhoneNumber && number.equals(((PhoneNumber) o).number);
    }

    @Override
    public int hashCode() {
        return number.hashCode();
    }
}