package server.services;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import shodrone.repositories.ShowProposalRepository;
import shodrone.showproposalmanagement.ShowProposal;
import shodrone.showproposalmanagement.ShowProposalStatus;
import shodrone.showrequestmanagement.ShowRequest;

@Service
public class AcceptRejectProposalService {

    private final ShowProposalRepository showProposalRepository;

    @Autowired
    public AcceptRejectProposalService(ShowProposalRepository showProposalRepository) {
        this.showProposalRepository = showProposalRepository;
    }

    @Transactional
    public ShowProposal acceptProposal(Long proposalId) {
        ShowProposal proposal = showProposalRepository.findById(proposalId)
                .orElseThrow(() -> new IllegalArgumentException("Proposal not found with ID: " + proposalId));

        proposal.setStatus(ShowProposalStatus.ACCEPTED);
        return showProposalRepository.save(proposal);
    }

    @Transactional
    public ShowProposal rejectProposal(Long proposalId) {
        ShowProposal proposal = showProposalRepository.findById(proposalId)
                .orElseThrow(() -> new IllegalArgumentException("Proposal not found with ID: " + proposalId));

        proposal.setStatus(ShowProposalStatus.REJECTED);
        return showProposalRepository.save(proposal);
    }
}