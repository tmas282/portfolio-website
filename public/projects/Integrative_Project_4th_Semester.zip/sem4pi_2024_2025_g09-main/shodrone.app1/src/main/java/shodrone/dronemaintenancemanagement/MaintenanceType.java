package shodrone.dronemaintenancemanagement;
import jakarta.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "maintenancetypes")

public class MaintenanceType {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Embedded
    @AttributeOverride(name = "description", column = @Column(name = "description"))
    private MaintenanceTypeDescription description;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private MaintenanceTypeStatus status;

    protected MaintenanceType() {
        // for JPA
    }

    public MaintenanceType(MaintenanceTypeDescription description) {
        if (description == null) {
            throw new IllegalArgumentException("Description must not be null.");
        }
        this.description = description;
        this.status = MaintenanceTypeStatus.EDITABLE;
    }

    public Long getId() {
        return id;
    }

    public MaintenanceTypeDescription getDescription() {
        return description;
    }

    public MaintenanceTypeStatus getStatus() {
        return status;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MaintenanceType)) return false;
        MaintenanceType that = (MaintenanceType) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}