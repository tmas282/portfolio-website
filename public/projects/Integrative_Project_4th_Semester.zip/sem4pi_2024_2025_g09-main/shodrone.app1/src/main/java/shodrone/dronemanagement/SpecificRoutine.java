package shodrone.dronemanagement;

import jakarta.persistence.Embeddable;
import java.util.Objects;

@Embeddable
public class SpecificRoutine{

    private String routine;

    protected SpecificRoutine() {
        // for JPA
    }

    public SpecificRoutine(final String routine) {
        if (routine == null || routine.isBlank())
            throw new IllegalArgumentException("Routine cannot be null or blank.");
        this.routine = routine.trim();
    }

    public String value() {
        return routine;
    }

    @Override
    public String toString() {
        return routine;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SpecificRoutine)) return false;
        SpecificRoutine that = (SpecificRoutine) o;
        return routine.equalsIgnoreCase(that.routine);
    }

    @Override
    public int hashCode() {
        return Objects.hash(routine.toLowerCase());
    }
}
