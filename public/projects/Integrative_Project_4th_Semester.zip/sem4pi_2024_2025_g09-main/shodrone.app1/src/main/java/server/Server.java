package server;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = {
        "server"
})
@EnableJpaRepositories(basePackages = "shodrone.repositories")
@EntityScan(basePackages = {
        "shodrone.usermanagement",
        "shodrone.customermanagement",
        "shodrone.customerrepresentativemanagement",
        "shodrone.figurecategorymanagement",
        "shodrone.figuremanagement",
        "shodrone.dronemodelmanagement",
        "shodrone.dronemanagement",
        "shodrone.showrequestmanagement",
        "shodrone.showproposalmanagement",
        "shodrone.dronemaintenancemanagement"
})
public class Server {

    public static void main(String[] args) {
        SpringApplication.run(Server.class, args);
    }
}
