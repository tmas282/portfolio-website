package shodrone.repositories;

import org.springframework.data.repository.CrudRepository;
import shodrone.figurecategorymanagement.CategoryName;
import shodrone.figurecategorymanagement.FigureCategory;

import java.util.Optional;

public interface FigureCategoryRepository extends CrudRepository<FigureCategory, Long> {

    Iterable<FigureCategory> findAllByOrderByName_ValueAsc();

    Optional<FigureCategory> findByName_ValueIgnoreCase(String name);

    Optional<FigureCategory> findByDescription_TextIgnoreCase(String text);

}
