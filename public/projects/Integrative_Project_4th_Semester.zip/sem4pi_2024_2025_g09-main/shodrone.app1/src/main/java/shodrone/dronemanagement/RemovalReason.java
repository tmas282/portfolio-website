package shodrone.dronemanagement;

import jakarta.persistence.Embeddable;
import java.util.Objects;

@Embeddable
public class RemovalReason {

    private String reason;

    protected RemovalReason() {
    }

    public RemovalReason(String reason) {
        if (reason == null || reason.isBlank())
            throw new IllegalArgumentException("Removal reason cannot be null or blank.");
        this.reason = reason.trim();
    }

    public String value() {
        return reason;
    }

    @Override
    public String toString() {
        return reason;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof RemovalReason)) return false;
        RemovalReason that = (RemovalReason) o;
        return reason.equalsIgnoreCase(that.reason);
    }

    @Override
    public int hashCode() {
        return Objects.hash(reason.toLowerCase());
    }
}
