package shodrone.customermanagement;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import shodrone.customerrepresentativemanagement.CustomerRepresentative;
import shodrone.showrequestmanagement.ShowRequest;
import shodrone.usermanagement.User;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "customers")
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Embedded
    @AttributeOverride(name = "number", column = @Column(name = "vat", nullable = false, unique = true))
    private VAT vat;

    @Embedded
    @AttributeOverride(name = "fullName", column = @Column(name = "customer_name", nullable = false))
    private Name name;

    @Embedded
    @AttributeOverride(name = "email", column = @Column(name = "email_address", nullable = false))
    private Email email;

    @Embedded
    @AttributeOverride(name = "address", column = @Column(name = "physical_address", nullable = false))
    private Address address;

    @Embedded
    @AttributeOverride(name = "number", column = @Column(name = "phone_number", nullable = false))
    private PhoneNumber phone;

    @Enumerated(EnumType.STRING)
    private CustomerStatus status;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CustomerType type = CustomerType.REGULAR;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private List<CustomerRepresentative> representatives = new ArrayList<>();

    @Getter
    @OneToMany(mappedBy = "customer")
    private List<ShowRequest> showRequests = new ArrayList<>();

    @OneToOne(optional = false)
    @JoinColumn(name = "user_id", unique = true)
    private User user;

    protected Customer() {}

    public Customer(VAT vat, Name name, Email email, Address address, PhoneNumber phone, CustomerRepresentative representative, CustomerType type) {
        if (vat == null || name == null || email == null || address == null || phone == null || representative == null) {
            throw new IllegalArgumentException("None of the value objects or representative can be null");
        }
        this.vat = vat;
        this.name = name;
        this.email = email;
        this.address = address;
        this.phone = phone;
        this.status = CustomerStatus.CREATED;
        this.addRepresentative(representative);
        this.type = (type != null) ? type : CustomerType.REGULAR;
    }

    public CustomerStatus status() {
        return this.status;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public User user() {
        return user;
    }

    public void addRepresentative(CustomerRepresentative rep) {
        rep.setCustomer(this);
        this.representatives.add(rep);
    }

    public List<CustomerRepresentative> representatives() {
        return List.copyOf(representatives);
    }

    public List<String> representativeEmails() {
        return representatives.stream()
                .map(r -> r.getEmail().value())
                .toList();
    }

    public VAT identity() {
        return vat;
    }

    public Name name() {
        return name;
    }

    public Address adress() {
        return address;
    }

    public CustomerType type() {
        return type;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Customer customer = (Customer) o;
        return Objects.equals(vat, customer.vat);
    }

    @Override
    public int hashCode() {
        return vat.hashCode();
    }
}
