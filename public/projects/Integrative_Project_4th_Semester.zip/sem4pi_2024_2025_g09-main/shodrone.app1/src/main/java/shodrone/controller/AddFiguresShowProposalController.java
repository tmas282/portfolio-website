package shodrone.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import shodrone.services.ShowProposalService;
import shodrone.showproposalmanagement.ShowProposal;

@Controller
public class AddFiguresShowProposalController {

    private final ShowProposalService showProposalService;

    @Autowired
    public AddFiguresShowProposalController(ShowProposalService showProposalService) {
        this.showProposalService = showProposalService;
    }

    /**
     * Adds a figure to a proposal without associating a drone model yet.
     *
     * @param proposalId  the ID of the proposal
     * @param figureCode  the code of the figure
     * @param position    the position in the proposal
     * @return the updated proposal
     */
    public ShowProposal addFigureWithoutDroneModel(Long proposalId, String figureCode, int position) {
        return showProposalService.addFigureToProposalWithoutModel(proposalId, figureCode, position);
    }

    /**
     * Associates a drone model with an existing figure.
     *
     * @param figureCode     the code of the figure
     * @param droneModelId   the ID of the drone model to associate
     */
    public void associateDroneModelWithFigure(Long figureCode, String droneModelId) {
        showProposalService.associateDroneModelToFigure(figureCode, droneModelId);
    }
}
