package shodrone.presentation;

import org.springframework.stereotype.Component;
import shodrone.controller.AuthController;
import shodrone.usermanagement.User;
import java.util.Scanner;

@Component
public class AuthUI {

    private final AuthController authController;

    public AuthUI(AuthController authController) {
        this.authController = authController;
    }

    public User run() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("🔐 LOGIN");
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();

        try {
            return authController.authenticate(email, password);
        } catch (Exception e) {
            System.out.println("❌ " + e.getMessage());
            return null;
        }
    }
}
