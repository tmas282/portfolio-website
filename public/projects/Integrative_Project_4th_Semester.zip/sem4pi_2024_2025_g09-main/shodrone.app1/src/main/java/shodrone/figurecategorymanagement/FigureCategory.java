package shodrone.figurecategorymanagement;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name = "FigureCategories")
public class FigureCategory {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Embedded
    @AttributeOverride(name = "value", column = @Column(name = "category_name", nullable = false, unique = true))
    private CategoryName name;

    @Embedded
    @AttributeOverride(name = "value", column = @Column(name = "status", nullable = false))
    private CategoryStatus status;

    @Embedded
    @AttributeOverride(name = "text", column = @Column(name = "description", nullable = false, unique = true))
    private Description description;

    @Embedded
    @AttributeOverride(name = "date", column = @Column(name = "creation_date", nullable = false))
    private CreationDate creationDate;

    protected FigureCategory() {

    }

    public FigureCategory(final CategoryName name, final Description description) {
        if (name == null || description == null) {
            throw new IllegalArgumentException("None of the value objects can be null");
        }
        this.name = name;
        this.description = description;
        this.status = CategoryStatus.active();
        this.creationDate = CreationDate.now();
    }

    public void renameTo(final CategoryName newName) {
        this.name = newName;
    }

    public void changeDescription(final Description newDescription) {
        this.description = newDescription;
    }

    public void deactivate() {
        this.status = CategoryStatus.inactive();
    }

    public void activate() {
        this.status = CategoryStatus.active();
    }

    public CategoryName name() {
        return name;
    }

    public Description description() {
        return description;
    }

    public CategoryStatus status() {
        return status;
    }

    public CreationDate creationDate() {
        return creationDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof FigureCategory)) return false;
        FigureCategory that = (FigureCategory) o;


        if (this.id == null || that.id == null) return false;

        return Objects.equals(id, that.id);
    }


    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}

