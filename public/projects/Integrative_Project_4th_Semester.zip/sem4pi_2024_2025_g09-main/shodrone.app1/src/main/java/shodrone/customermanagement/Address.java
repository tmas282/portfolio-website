package shodrone.customermanagement;

import jakarta.persistence.Embeddable;

@Embeddable
public class Address {

    private String address;

    protected Address() {}

    public Address(String address) {
        if (address == null || address.trim().isEmpty()) {
            throw new IllegalArgumentException("Invalid address: cannot be null or empty.");
        }
        this.address = address;
    }

    public String value() {
        return address;
    }

    @Override
    public String toString() {
        return address;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof Address && address.equals(((Address) o).address);
    }

    @Override
    public int hashCode() {
        return address.hashCode();
    }
}
