package shodrone.services;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import shodrone.customermanagement.Customer;
import shodrone.repositories.*;
import shodrone.showrequestmanagement.*;

import java.util.List;

@Service
public class ShowRequestService {
    private final ShowRequestRepository showRequestRepository;

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    public ShowRequestService(
            ShowRequestRepository showRequestRepository
    ) {
        this.showRequestRepository = showRequestRepository;
    }
    @Transactional
    public ShowRequest createShowRequest(Customer customer, ShowRequestStatus status, ShowRequestDateTime dateTime, ShowRequestDuration duration, ShowRequestPlace place, NumberOfDrones numberOfDrones, ShowDescription description){
        ShowRequest showRequest = new ShowRequest(customer, status, dateTime, duration, place, numberOfDrones, description);
        return showRequestRepository.save(showRequest);
    }
    @Transactional
    public List<ShowRequest> getShowRequestsOfCustomer(Customer customer){
        return showRequestRepository.findByCustomer(customer);
    }
    @Transactional
    public void editShowRequest(ShowRequest showRequest){
        showRequestRepository.save(showRequest);
    }
}
