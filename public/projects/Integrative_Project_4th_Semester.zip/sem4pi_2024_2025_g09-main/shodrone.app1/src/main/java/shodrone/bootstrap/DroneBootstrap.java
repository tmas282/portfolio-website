package shodrone.bootstrap;

import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import shodrone.controller.AddDroneController;
import shodrone.dronemanagement.SerialNumber;
import shodrone.repositories.DroneRepository;

@Component
@Order(3)
public class DroneBootstrap implements CommandLineRunner {

    private final DroneRepository droneRepository;
    private final AddDroneController addController;

    public DroneBootstrap(DroneRepository droneRepository, AddDroneController addController) {
        this.droneRepository = droneRepository;
        this.addController = addController;
    }

    @Override
    public void run(String... args) {
        try {

            SerialNumber serial1 = new SerialNumber("D001");
            if (!droneRepository.existsBySerialNumber(serial1)) {
                addController.addDrone("D001", "DM001", "Straight");
                System.out.println("D001 added.");
            } else {
                System.out.println("DRONE001 already exists in inventory.");
            }

            SerialNumber serial2 = new SerialNumber("D002");
            if (!droneRepository.existsBySerialNumber(serial2)) {
                addController.addDrone("D002", "DM001", "Circle");
                System.out.println("D002 added.");
            } else {
                System.out.println("D002 already exists in inventory.");
            }

        } catch (Exception e) {
            System.out.println("Bootstrap (drone): " + e.getMessage());
        }
    }
}
