package shodrone.controller;

import org.springframework.stereotype.Controller;
import shodrone.figurecategorymanagement.FigureCategory;
import shodrone.services.FigureCategoryService;

@Controller
public class FigureCategoryController {

    private final FigureCategoryService service;

    public FigureCategoryController(FigureCategoryService service) {
        this.service = service;
    }

    /**
     * US245 — Add new category
     */
    public void addCategory(String name, String description) {
        service.addFigureCategory(name, description);
    }

    /**
     * US246 — Rename existing category
     */
    public void editCategory(String currentName, String newName, String newRawDescription) {
        service.editFigureCategory(currentName, newName, newRawDescription);
    }

    /**
     * US247 — List all categories
     */
    public Iterable<FigureCategory> listCategories() {
        return service.listAllCategories();
    }

    /**
     * US248 — Activate category
     */
    public void activateCategory(String name) {
        service.activateCategory(name);
    }

    /**
     * US248 — Deactivate category
     */
    public void deactivateCategory(String name) {
        service.deactivateCategory(name);
    }
}
