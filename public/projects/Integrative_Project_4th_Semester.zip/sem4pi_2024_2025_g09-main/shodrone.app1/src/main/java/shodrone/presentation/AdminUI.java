package shodrone.presentation;

        import org.springframework.stereotype.Component;
        import shodrone.controller.ManageUsersController;
        import shodrone.controller.RegisterUserController;
        import shodrone.usermanagement.RoleName;
        import shodrone.usermanagement.RolePolicy;
        import shodrone.usermanagement.User;

        import java.util.List;
        import java.util.Optional;
        import java.util.Scanner;

        @Component
        public class AdminUI {

            private final RegisterUserController registerUserController;
            private final ManageUsersController manageUsersController;
            private final Scanner scanner = new Scanner(System.in);

            public AdminUI(RegisterUserController registerUserController,
                           ManageUsersController manageUsersController) {
                this.registerUserController = registerUserController;
                this.manageUsersController = manageUsersController;
            }

            public void run() {
                while (true) {
                    System.out.println("\n=== Admin Menu ===");
                    System.out.println("1. Register New User");
                    System.out.println("2. Disable User");
                    System.out.println("3. Enable User");
                    System.out.println("4. List Users");
                    System.out.println("5. Exit");
                    System.out.println("0. Logout");

                    System.out.print("Choose option: ");
                    String option = scanner.nextLine();

                    switch (option) {
                        case "1" -> registerNewUser();
                        case "2" -> disableUserFlow();
                        case "3" -> enableUserFlow();
                        case "4" -> listUsers();
                        case "5" -> {
                            System.out.println("Exiting...");
                            System.exit(0);
                        }
                        case "0" -> {
                            System.out.println("Logging out...");
                            return;
                        }
                        default -> System.out.println("Invalid option.");
                    }
                }
            }

            private void registerNewUser() {
                System.out.println("\n--- Register New User ---");

                System.out.print("Email: ");
                String email = scanner.nextLine();

                System.out.print("Password: ");
                String password = scanner.nextLine();

                System.out.print("Full Name: ");
                String fullName = scanner.nextLine();

                System.out.print("Phone Number (9 dígitos): ");
                String phoneNumber = scanner.nextLine();

                System.out.println("Available roles:");
                for (RoleName role : RolePolicy.BACKOFFICE_ROLES) {
                    System.out.println("- " + role.name());
                }

                System.out.print("Choose role: ");
                String roleInput = scanner.nextLine().trim().toUpperCase().replace(" ", "_");

                Optional<RoleName> maybeRole = RolePolicy.BACKOFFICE_ROLES.stream()
                        .filter(r -> r.name().equals(roleInput))
                        .findFirst();

                if (maybeRole.isEmpty()) {
                    System.out.println("❌ Invalid role: " + roleInput.replace("_", " "));
                    System.out.println("💡 Roles disponíveis:");
                    RolePolicy.BACKOFFICE_ROLES.forEach(r -> System.out.println("- " + r.name()));
                    return;
                }

                try {
                    registerUserController.registerUser(email, password, maybeRole.get(), fullName, phoneNumber);
                    System.out.println("✅ User registered: " + email);
                } catch (Exception e) {
                    System.out.println("❌ Failed to register user: " + e.getMessage());
                }
            }

            private void disableUserFlow() {
                System.out.print("Enter email of user to disable: ");
                String email = scanner.nextLine();
                if (manageUsersController.disable(email)) {
                    System.out.println("✅ User disabled.");
                } else {
                    System.out.println("❌ User not found.");
                }
            }

            private void enableUserFlow() {
                System.out.print("Enter email of user to enable: ");
                String email = scanner.nextLine();
                if (manageUsersController.enable(email)) {
                    System.out.println("✅ User enabled.");
                } else {
                    System.out.println("❌ User not found.");
                }
            }

            private void listUsers() {
                List<User> users = manageUsersController.listAll();
                System.out.println("\n📋 List of Users:");
                users.stream()
                        .filter(user -> RolePolicy.BACKOFFICE_ROLES.contains(user.role().getRoleName()))
                        .forEach(user -> System.out.printf("- %s | %s | %s\n",
                                user.email(),
                                user.role().getRoleName(),
                                user.isEnabled() ? "ENABLED" : "DISABLED"));
            }
        }