package shodrone.presentation;

import org.springframework.stereotype.Component;
import shodrone.controller.*;
import shodrone.controller.DroneProgramValidationController;
import shodrone.dronemaintenancemanagement.MaintenanceType;
import shodrone.dronemanagement.DroneStatus;
import shodrone.dronemodelmanagement.WindTolerance;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.NavigableMap;
import java.util.Scanner;
import java.util.TreeMap;

@Component
public class DroneTechUI {

    private final Scanner scanner = new Scanner(System.in);
    private final CreateDroneModelController createModelController;
    private final AddDroneController addDroneController;
    private final RemoveDroneController removeDroneController;
    private final ListDronesController listDronesController;
    private final AddMaintenanceTypeController addMaintenanceTypeController;
    private final ListMaintenanceTypesController listMaintenanceTypesController;
    private final EditMaintenanceTypeController editMaintenanceTypeController;
    private final ListMaintenanceHistoryController listMaintenanceHistoryController;
    private final AddMaintenanceRecordController addMaintenanceRecordController;
    private final RegisterDroneUsageTimeController registerDroneUsageTimeController;
    private final ListDronesNeedingMaintenanceController listDronesNeedingMaintenanceController;
    private final DroneProgramValidationController droneProgramValidationController;

    public DroneTechUI(
            CreateDroneModelController createModelController,
            AddDroneController addDroneController,
            RemoveDroneController removeDroneController,
            ListDronesController listDronesController,
            AddMaintenanceTypeController addMaintenanceTypeController,
            ListMaintenanceTypesController listMaintenanceTypesController,
            EditMaintenanceTypeController editMaintenanceTypeController,
            ListMaintenanceHistoryController listMaintenanceHistoryController,
            AddMaintenanceRecordController addMaintenanceRecordController,
            RegisterDroneUsageTimeController registerDroneUsageTimeController
            , ListDronesNeedingMaintenanceController listDronesNeedingMaintenanceController, DroneProgramValidationController droneProgramValidationController
    ) {
        this.createModelController = createModelController;
        this.addDroneController = addDroneController;
        this.removeDroneController = removeDroneController;
        this.listDronesController = listDronesController;
        this.addMaintenanceTypeController = addMaintenanceTypeController;
        this.listMaintenanceTypesController = listMaintenanceTypesController;
        this.editMaintenanceTypeController = editMaintenanceTypeController;
        this.listMaintenanceHistoryController = listMaintenanceHistoryController;
        this.addMaintenanceRecordController = addMaintenanceRecordController;
        this.registerDroneUsageTimeController = registerDroneUsageTimeController;
        this.listDronesNeedingMaintenanceController = listDronesNeedingMaintenanceController;
        this.droneProgramValidationController = droneProgramValidationController;
    }

    public void run() {
        boolean exit = false;

        while (!exit) {
            System.out.println("\n=== Drone Tech Menu ===");
            System.out.println("1. Create Drone Model");
            System.out.println("2. Add Drone to Inventory");
            System.out.println("3. Remove Drone from Inventory");
            System.out.println("4. List Drones by Model");
            System.out.println("5. Add Maintenance Type");
            System.out.println("6. List Maintenance Types");
            System.out.println("7. Edit Maintenance Type");
            System.out.println("8. List Maintenance History");
            System.out.println("9. Add Maintenance Record");
            System.out.println("10. Register Drone Usage Time");
            System.out.println("11. List Drones Needing Preventive Maintenance");
            System.out.println("12. Validate Drone Program");
            System.out.println("0. Logout");

            System.out.print("Choose an option: ");
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    handleDroneModelCreation();
                    break;
                case "2":
                    handleAddDroneToInventory();
                    break;
                case "3":
                    handleDroneRemoval();
                    break;
                case "4":
                    handleListDrones();
                    break;
                case "5":
                    handleAddMaintenanceType();
                    break;
                case "6":
                    handleListMaintenanceTypes();
                    break;
                case "7":
                    handleEditMaintenanceTypeDescription();
                    break;
                case "8":
                    handleListMaintenanceHistory();
                    break;
                case "9":
                    handleAddMaintenanceRecord();
                    break;
                case "10":
                    handleRegisterDroneUsageTime();
                    break;
                case "11":
                    handleListDronesNeedingPreventiveMaintenance();
                    break;
                case "12":
                    handleValidateDroneProgram();
                    break;
                case "0":
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    private void handleRegisterDroneUsageTime() {
        System.out.println("\n--- Register Drone Usage Time ---");
        System.out.print("Enter Drone Serial Number: ");
        String serialNumber = scanner.nextLine().trim();

        System.out.print("Enter Usage Time in hours: ");
        String usageTimeStr = scanner.nextLine().trim();

        try {
            int usageTime = Integer.parseInt(usageTimeStr);
            registerDroneUsageTimeController.registerUsageTime(serialNumber, usageTime);
            System.out.println("Usage time registered successfully.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void handleListMaintenanceHistory() {
        System.out.println("\n--- List Maintenance History ---");
        System.out.print("Drone Serial Number: ");
        String serial = scanner.nextLine().trim();

        System.out.print("Start Date (yyyy-MM-dd): ");
        String start = scanner.nextLine().trim();

        System.out.print("End Date (yyyy-MM-dd): ");
        String end = scanner.nextLine().trim();

        try {
            LocalDate startDate = LocalDate.parse(start);
            LocalDate endDate = LocalDate.parse(end);

            if (endDate.isBefore(startDate)) {
                System.out.println("Error: End date cannot be before start date.");
                return;
            }

            var records = listMaintenanceHistoryController.listMaintenanceHistory(serial, startDate, endDate);
            boolean droneExiste = listMaintenanceHistoryController.droneExists(serial);

            if (!droneExiste) {
                System.out.println("Drone not found with serial number: " + serial);
            } else if (records.isEmpty()) {
                System.out.println("Drone found. No maintenance records found for this period.");
            } else {
                System.out.println("Drone found. Maintenance history:");
                records.forEach(r -> {
                    System.out.printf("Date: %s | Type: %s | Description: %s\n",
                            r.getMaintenanceDate().value(),
                            r.getMaintenanceType().getDescription().value(),
                            r.getMaintenanceDescription().value());
                });
            }
        } catch (java.time.format.DateTimeParseException e) {
            System.out.println("Error: Invalid date format. Please use yyyy-MM-dd.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void handleDroneModelCreation() {
        System.out.println("\n--- Create New Drone Model ---");

        System.out.print("Enter Model ID (format: DM<number>): ");
        String modelID = scanner.nextLine().trim();

        if (!validateModelID(modelID)) {
            System.out.println("Error: Model ID must start with 'DM' followed by a number.");
            return;
        }

        System.out.print("Enter Programming Language: ");
        String language = scanner.nextLine().trim();

        NavigableMap<Double, Double> toleranceSteps = new TreeMap<>();
        System.out.print("Enter number of wind intervals: ");
        int intervals = Integer.parseInt(scanner.nextLine().trim());

        double lastMax = 0.0;
        for (int i = 0; i < intervals; i++) {
            System.out.printf("Interval %d - Enter min wind speed: ", i + 1);
            double minSpeed = Double.parseDouble(scanner.nextLine().trim());

            System.out.printf("Interval %d - Enter max wind speed: ", i + 1);
            double maxSpeed = Double.parseDouble(scanner.nextLine().trim());

            System.out.printf("Interval %d - Enter position tolerance: ", i + 1);
            double tolerance = Double.parseDouble(scanner.nextLine().trim());

            if (minSpeed != lastMax) {
                System.out.println("Warning: min speed does not match previous max speed.");
            }
            lastMax = maxSpeed;

            toleranceSteps.put(maxSpeed, tolerance);
        }

        WindTolerance tolerance = new WindTolerance(toleranceSteps);


        System.out.print("Enter Maintenance Threshold (usage hours before maintenance is needed): ");
        String thresholdStr = scanner.nextLine().trim();
        int thresholdValue;
        try {
            thresholdValue = Integer.parseInt(thresholdStr);
            if (thresholdValue < 0) {
                System.out.println("Error: Maintenance threshold must be non-negative.");
                return;
            }
        } catch (NumberFormatException e) {
            System.out.println("Error: Invalid number for maintenance threshold.");
            return;
        }
        shodrone.dronemodelmanagement.MaintenanceThreshold maintenanceThreshold =
                new shodrone.dronemodelmanagement.MaintenanceThreshold(thresholdValue);

        try {
            createModelController.createDroneModel(modelID, language, tolerance, maintenanceThreshold);
            System.out.println("Drone Model created successfully!");
        } catch (IllegalStateException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Unexpected error occurred.");
        }
    }

    private void handleAddDroneToInventory() {
        System.out.println("\n--- Add Drone to Inventory ---");

        System.out.print("Enter Model ID (format: DM<number>): ");
        String modelID = scanner.nextLine().trim();

        if (!validateModelID(modelID)) {
            System.out.println("Error: Model ID must start with 'DM' followed by a number.");
            return;
        }

        System.out.print("Enter Serial Number (format: D<number>): ");
        String serialNumber = scanner.nextLine().trim();

        if (!validateSerialNumber(serialNumber)) {
            System.out.println("Error: Serial Number must start with 'D' followed by a number.");
            return;
        }

        System.out.print("Enter Routine: ");
        String routine = scanner.nextLine().trim();

        try {
            addDroneController.addDrone(serialNumber, modelID, routine);
            System.out.println("Drone added to inventory!");
        } catch (IllegalStateException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Unexpected error occurred.");
        }
    }

    private void handleDroneRemoval() {
        System.out.println("\n--- Remove Drone from Inventory ---");

        System.out.print("Enter Serial Number (format: D<number>): ");
        String serial = scanner.nextLine().trim();

        System.out.print("Enter Removal Reason: ");
        String reason = scanner.nextLine().trim();

        LocalDate date = null;
        while (date == null) {
            System.out.print("Enter Removal Date (dd/MM/yyyy): ");
            String input = scanner.nextLine().trim();
            try {
                date = LocalDate.parse(input, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date format. Try again.");
            }
        }

        System.out.print("Enter New Status (INACTIVE or MAINTENANCE): ");
        String statusStr = scanner.nextLine().trim().toUpperCase();

        try {
            DroneStatus status = DroneStatus.valueOf(statusStr);
            removeDroneController.removeDrone(serial, reason, date, status);
            System.out.println("Drone removed successfully.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void handleListDrones() {
        System.out.print("Enter Model ID to list drones: ");
        String modelID = scanner.nextLine().trim();

        try {
            var drones = listDronesController.listActiveDrones(modelID);
            if (drones.isEmpty()) {
                System.out.println("No active drones found for model " + modelID);
            } else {
                System.out.println("Active drones:");
                drones.forEach(d -> System.out.println("â†’ " + d));
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    private void handleAddMaintenanceType() {
        System.out.println("\n--- Add Maintenance Type ---");

        System.out.print("Enter Maintenance Type Description: ");
        String description = scanner.nextLine().trim();

        if (description.isEmpty()) {
            System.out.println("Error: Description must not be empty.");
            return;
        }

        try {
            var maintenanceType = addMaintenanceTypeController.addMaintenanceType(description);
            System.out.println("Maintenance type added successfully: " + maintenanceType.getDescription());
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Unexpected error occurred.");
        }
    }
    private void handleListMaintenanceTypes() {
        System.out.println("\n--- List Maintenance Types ---");

        try {
            List<MaintenanceType> maintenanceTypes = listMaintenanceTypesController.listMaintenanceTypes();
            if (maintenanceTypes.isEmpty()) {
                System.out.println("No maintenance types found.");
            } else {
                System.out.println("Maintenance Types:");
                for (MaintenanceType mt : maintenanceTypes) {
                    System.out.println("→ ID: " + mt.getId() + ", Description: " + mt.getDescription().value() + ", Status: " + mt.getStatus());
                }
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    private void handleEditMaintenanceTypeDescription() {
        System.out.println("\n--- Edit Maintenance Type Description ---");

        List<MaintenanceType> maintenanceTypes = listMaintenanceTypesController.listMaintenanceTypes();
        if (maintenanceTypes.isEmpty()) {
            System.out.println("No maintenance types available to edit.");
            return;
        }

        System.out.println("Available Maintenance Types:");
        for (int i = 0; i < maintenanceTypes.size(); i++) {
            MaintenanceType type = maintenanceTypes.get(i);
            System.out.printf("%d. Description: %s, Status: %s%n", i + 1, type.getDescription().value(), type.getStatus());
        }

        System.out.print("Select a Maintenance Type to edit (enter number): ");
        int choice;
        try {
            choice = Integer.parseInt(scanner.nextLine().trim());
            if (choice < 1 || choice > maintenanceTypes.size()) {
                System.out.println("Invalid choice. Operation canceled.");
                return;
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Operation canceled.");
            return;
        }

        MaintenanceType selectedType = maintenanceTypes.get(choice - 1);

        System.out.print("Enter New Description: ");
        String newDescription = scanner.nextLine().trim();

        try {
            var updatedType = editMaintenanceTypeController.editMaintenanceTypeDescription(selectedType.getId(), newDescription);
            System.out.println("Maintenance type updated successfully: " + updatedType.getDescription().value());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void handleAddMaintenanceRecord() {
        System.out.println("\n--- Add Maintenance Record ---");

        System.out.print("Enter Drone Serial Number: ");
        String serialNumber = scanner.nextLine().trim();

        System.out.print("Enter Maintenance Type ID: ");
        String maintenanceTypeIdStr = scanner.nextLine().trim();

        System.out.print("Enter Maintenance Description: ");
        String description = scanner.nextLine().trim();

        System.out.print("Enter Maintenance Date (yyyy-MM-dd): ");
        String dateStr = scanner.nextLine().trim();

        try {
            Long maintenanceTypeId = Long.parseLong(maintenanceTypeIdStr);
            LocalDate date = LocalDate.parse(dateStr);
            var record = addMaintenanceRecordController.addMaintenanceRecord(serialNumber, maintenanceTypeId, description, date);
            System.out.println("Maintenance record added successfully!");

            var drone = listDronesController.getDroneBySerialNumber(serialNumber);
            System.out.println("Drone's usage time after maintenance: " + drone.usageTime().value());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void handleListDronesNeedingPreventiveMaintenance() {
        System.out.println("\n--- List Drones Needing Preventive Maintenance ---");
        System.out.print("Enter date (yyyy-MM-dd): ");
        String dateStr = scanner.nextLine().trim();
        try {
            LocalDate date = LocalDate.parse(dateStr);
            var drones = listDronesNeedingMaintenanceController.listDronesNeedingMaintenance(date);
            if (drones.isEmpty()) {
                System.out.println("No drones need preventive maintenance on this date.");
            } else {
                System.out.println("Drones needing preventive maintenance:");
                drones.forEach(d -> {
                    int usage = d.usageTime().value();
                    int threshold = d.getDroneModel().getMaintenanceThreshold().value();
                    System.out.printf("→ %s (usage: %d, threshold: %d) -- EXCEEDED%n", d, usage, threshold);
                });
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    private void handleValidateDroneProgram() {
        System.out.println("\n--- Validate Drone Program ---");

        System.out.print("Enter the file path of the drone program: ");
        String filePath = scanner.nextLine().trim();

        boolean success = droneProgramValidationController.validateAndSaveDroneProgram(filePath);

        if (success) {
            System.out.println("Drone program validated successfully.");
        } else {
            System.out.println("Validation failed. Please check the error messages above.");
        }
    }
    private boolean validateModelID(String modelID) {
        if (modelID == null || modelID.isEmpty()) return false;
        return modelID.startsWith("DM") && modelID.substring(2).matches("\\d+");
    }

    private boolean validateSerialNumber(String serialNumber) {
        if (serialNumber == null || serialNumber.isEmpty()) return false;
        return serialNumber.startsWith("D") && serialNumber.substring(1).matches("\\d+");
    }
}
