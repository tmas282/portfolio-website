package shodrone.figuremanagement;

import eapli.framework.domain.model.ValueObject;
import jakarta.persistence.Embeddable;


@Embeddable
public class Keyword {

    private String keyword;

    protected Keyword() {};

    public Keyword(String keyword) {
        if (keyword == null) throw new IllegalArgumentException("Can't be null!");
        this.keyword = keyword;
    }

    public String value() {
        return keyword;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof Keyword && keyword.equals(((Keyword) o).keyword);
    }
}
