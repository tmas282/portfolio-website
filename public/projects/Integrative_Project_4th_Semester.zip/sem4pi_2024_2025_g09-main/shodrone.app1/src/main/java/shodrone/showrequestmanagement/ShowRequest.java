package shodrone.showrequestmanagement;

import jakarta.persistence.*;
import lombok.Getter;
import shodrone.customermanagement.Customer;

@Entity
@Table(name = "showrequest")
public class ShowRequest {
    @Getter
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Getter
    @ManyToOne
    @JoinColumn(name = "vat")
    private Customer customer;

    @Getter
    @Embedded
    private ShowRequestStatus status;

    @Getter
    @Embedded
    private ShowRequestDateTime datetime;

    @Getter
    @Embedded
    private ShowRequestDuration duration;

    @Getter
    @Embedded
    private ShowRequestPlace place;

    @Getter
    @Embedded
    @AttributeOverride(name = "number", column = @Column(name = "numberofdrones"))
    private NumberOfDrones numberOfDrones;

    @Getter
    @Embedded
    private ShowDescription description;

    protected ShowRequest(){

    }

    public ShowRequest(Customer customer, ShowRequestStatus status, ShowRequestDateTime datetime, ShowRequestDuration duration, ShowRequestPlace place, NumberOfDrones numberOfDrones, ShowDescription description) {
        assert customer != null && status != null && datetime != null && duration != null && place != null && numberOfDrones != null && description != null;
        this.customer = customer;
        this.status = status;
        this.datetime = datetime;
        this.duration = duration;
        this.place = place;
        this.numberOfDrones = numberOfDrones;
        this.description = description;
    }
}
