package shodrone.controller;

import org.springframework.stereotype.Controller;
import shodrone.services.ShowProposalService;
import shodrone.showproposalmanagement.ShowProposal;

import java.util.*;

@Controller
public class SendShowProposalController {
    private final ShowProposalService service;

    public SendShowProposalController(ShowProposalService service){
        this.service = service;
    }

    public List<ShowProposal> listOfUnsentShowProposals() {
        return service.getListOfUnsentShowProposals();
    }

    public int sendShowProposal(ShowProposal sp){
        return service.sendShowProposal(sp);
    }

}
