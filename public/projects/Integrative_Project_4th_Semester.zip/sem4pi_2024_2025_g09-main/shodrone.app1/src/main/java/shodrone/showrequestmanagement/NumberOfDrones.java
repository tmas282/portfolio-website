package shodrone.showrequestmanagement;

import jakarta.persistence.Embeddable;

import java.util.Objects;

@Embeddable
public class NumberOfDrones {
    private int number;

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        assert number >= 0;
        this.number = number;
    }

    protected NumberOfDrones() {
    }

    public NumberOfDrones(int number) {
        assert number >= 0;
        this.number = number;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        NumberOfDrones that = (NumberOfDrones) o;
        return number == that.number;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(number);
    }
}
