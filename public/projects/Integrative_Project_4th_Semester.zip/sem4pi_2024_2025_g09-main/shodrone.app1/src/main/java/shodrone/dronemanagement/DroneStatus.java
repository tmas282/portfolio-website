package shodrone.dronemanagement;

public enum DroneStatus {
    ACTIVE,
    INACTIVE,
    MAINTENANCE;

    public boolean isActive() {
        return this == ACTIVE;
    }

    public boolean isRemovable() {
        return this == INACTIVE || this == MAINTENANCE;
    }

    @Override
    public String toString() {
        return name().toLowerCase();
    }
}
