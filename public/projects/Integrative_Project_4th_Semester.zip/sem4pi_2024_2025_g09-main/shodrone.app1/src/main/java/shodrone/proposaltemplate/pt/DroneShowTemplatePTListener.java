// Generated from C:/Users/afons/sem4pi_2024_2025_g09/shodrone.app1/src/main/java/shodrone/proposaltemplate/pt/DroneShowTemplatePT.g4 by ANTLR 4.13.2
package shodrone.proposaltemplate.pt;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link DroneShowTemplatePTParser}.
 */
public interface DroneShowTemplatePTListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplatePTParser#document}.
	 * @param ctx the parse tree
	 */
	void enterDocument(DroneShowTemplatePTParser.DocumentContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplatePTParser#document}.
	 * @param ctx the parse tree
	 */
	void exitDocument(DroneShowTemplatePTParser.DocumentContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplatePTParser#salutation}.
	 * @param ctx the parse tree
	 */
	void enterSalutation(DroneShowTemplatePTParser.SalutationContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplatePTParser#salutation}.
	 * @param ctx the parse tree
	 */
	void exitSalutation(DroneShowTemplatePTParser.SalutationContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplatePTParser#clientCompany}.
	 * @param ctx the parse tree
	 */
	void enterClientCompany(DroneShowTemplatePTParser.ClientCompanyContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplatePTParser#clientCompany}.
	 * @param ctx the parse tree
	 */
	void exitClientCompany(DroneShowTemplatePTParser.ClientCompanyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code clientLocationField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#clientLocation}.
	 * @param ctx the parse tree
	 */
	void enterClientLocationField(DroneShowTemplatePTParser.ClientLocationFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code clientLocationField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#clientLocation}.
	 * @param ctx the parse tree
	 */
	void exitClientLocationField(DroneShowTemplatePTParser.ClientLocationFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code vatField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#vat}.
	 * @param ctx the parse tree
	 */
	void enterVatField(DroneShowTemplatePTParser.VatFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code vatField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#vat}.
	 * @param ctx the parse tree
	 */
	void exitVatField(DroneShowTemplatePTParser.VatFieldContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplatePTParser#documentID}.
	 * @param ctx the parse tree
	 */
	void enterDocumentID(DroneShowTemplatePTParser.DocumentIDContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplatePTParser#documentID}.
	 * @param ctx the parse tree
	 */
	void exitDocumentID(DroneShowTemplatePTParser.DocumentIDContext ctx);
	/**
	 * Enter a parse tree produced by the {@code videoURLField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#videoURL}.
	 * @param ctx the parse tree
	 */
	void enterVideoURLField(DroneShowTemplatePTParser.VideoURLFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code videoURLField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#videoURL}.
	 * @param ctx the parse tree
	 */
	void exitVideoURLField(DroneShowTemplatePTParser.VideoURLFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code insuranceAmountField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#insuranceAmount}.
	 * @param ctx the parse tree
	 */
	void enterInsuranceAmountField(DroneShowTemplatePTParser.InsuranceAmountFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code insuranceAmountField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#insuranceAmount}.
	 * @param ctx the parse tree
	 */
	void exitInsuranceAmountField(DroneShowTemplatePTParser.InsuranceAmountFieldContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplatePTParser#signatoryName}.
	 * @param ctx the parse tree
	 */
	void enterSignatoryName(DroneShowTemplatePTParser.SignatoryNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplatePTParser#signatoryName}.
	 * @param ctx the parse tree
	 */
	void exitSignatoryName(DroneShowTemplatePTParser.SignatoryNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplatePTParser#pageOne}.
	 * @param ctx the parse tree
	 */
	void enterPageOne(DroneShowTemplatePTParser.PageOneContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplatePTParser#pageOne}.
	 * @param ctx the parse tree
	 */
	void exitPageOne(DroneShowTemplatePTParser.PageOneContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplatePTParser#pageTwo}.
	 * @param ctx the parse tree
	 */
	void enterPageTwo(DroneShowTemplatePTParser.PageTwoContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplatePTParser#pageTwo}.
	 * @param ctx the parse tree
	 */
	void exitPageTwo(DroneShowTemplatePTParser.PageTwoContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplatePTParser#headerSection}.
	 * @param ctx the parse tree
	 */
	void enterHeaderSection(DroneShowTemplatePTParser.HeaderSectionContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplatePTParser#headerSection}.
	 * @param ctx the parse tree
	 */
	void exitHeaderSection(DroneShowTemplatePTParser.HeaderSectionContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplatePTParser#introContent}.
	 * @param ctx the parse tree
	 */
	void enterIntroContent(DroneShowTemplatePTParser.IntroContentContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplatePTParser#introContent}.
	 * @param ctx the parse tree
	 */
	void exitIntroContent(DroneShowTemplatePTParser.IntroContentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code proposalIDField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#proposalID}.
	 * @param ctx the parse tree
	 */
	void enterProposalIDField(DroneShowTemplatePTParser.ProposalIDFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code proposalIDField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#proposalID}.
	 * @param ctx the parse tree
	 */
	void exitProposalIDField(DroneShowTemplatePTParser.ProposalIDFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code proposalDateField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#proposalDate}.
	 * @param ctx the parse tree
	 */
	void enterProposalDateField(DroneShowTemplatePTParser.ProposalDateFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code proposalDateField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#proposalDate}.
	 * @param ctx the parse tree
	 */
	void exitProposalDateField(DroneShowTemplatePTParser.ProposalDateFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code eventDateField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#eventDate}.
	 * @param ctx the parse tree
	 */
	void enterEventDateField(DroneShowTemplatePTParser.EventDateFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code eventDateField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#eventDate}.
	 * @param ctx the parse tree
	 */
	void exitEventDateField(DroneShowTemplatePTParser.EventDateFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code zipCodeField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#zipCode}.
	 * @param ctx the parse tree
	 */
	void enterZipCodeField(DroneShowTemplatePTParser.ZipCodeFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code zipCodeField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#zipCode}.
	 * @param ctx the parse tree
	 */
	void exitZipCodeField(DroneShowTemplatePTParser.ZipCodeFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code eventTimeField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#eventTime}.
	 * @param ctx the parse tree
	 */
	void enterEventTimeField(DroneShowTemplatePTParser.EventTimeFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code eventTimeField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#eventTime}.
	 * @param ctx the parse tree
	 */
	void exitEventTimeField(DroneShowTemplatePTParser.EventTimeFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code eventLengthField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#eventLength}.
	 * @param ctx the parse tree
	 */
	void enterEventLengthField(DroneShowTemplatePTParser.EventLengthFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code eventLengthField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#eventLength}.
	 * @param ctx the parse tree
	 */
	void exitEventLengthField(DroneShowTemplatePTParser.EventLengthFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code gpsLatField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#gpsLat}.
	 * @param ctx the parse tree
	 */
	void enterGpsLatField(DroneShowTemplatePTParser.GpsLatFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code gpsLatField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#gpsLat}.
	 * @param ctx the parse tree
	 */
	void exitGpsLatField(DroneShowTemplatePTParser.GpsLatFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code gpsLongField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#gpsLong}.
	 * @param ctx the parse tree
	 */
	void enterGpsLongField(DroneShowTemplatePTParser.GpsLongFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code gpsLongField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#gpsLong}.
	 * @param ctx the parse tree
	 */
	void exitGpsLongField(DroneShowTemplatePTParser.GpsLongFieldContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplatePTParser#attachmentDetails}.
	 * @param ctx the parse tree
	 */
	void enterAttachmentDetails(DroneShowTemplatePTParser.AttachmentDetailsContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplatePTParser#attachmentDetails}.
	 * @param ctx the parse tree
	 */
	void exitAttachmentDetails(DroneShowTemplatePTParser.AttachmentDetailsContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplatePTParser#droneModel}.
	 * @param ctx the parse tree
	 */
	void enterDroneModel(DroneShowTemplatePTParser.DroneModelContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplatePTParser#droneModel}.
	 * @param ctx the parse tree
	 */
	void exitDroneModel(DroneShowTemplatePTParser.DroneModelContext ctx);
	/**
	 * Enter a parse tree produced by the {@code droneCountField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#droneCount}.
	 * @param ctx the parse tree
	 */
	void enterDroneCountField(DroneShowTemplatePTParser.DroneCountFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code droneCountField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#droneCount}.
	 * @param ctx the parse tree
	 */
	void exitDroneCountField(DroneShowTemplatePTParser.DroneCountFieldContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplatePTParser#droneEntry}.
	 * @param ctx the parse tree
	 */
	void enterDroneEntry(DroneShowTemplatePTParser.DroneEntryContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplatePTParser#droneEntry}.
	 * @param ctx the parse tree
	 */
	void exitDroneEntry(DroneShowTemplatePTParser.DroneEntryContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplatePTParser#equipmentList}.
	 * @param ctx the parse tree
	 */
	void enterEquipmentList(DroneShowTemplatePTParser.EquipmentListContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplatePTParser#equipmentList}.
	 * @param ctx the parse tree
	 */
	void exitEquipmentList(DroneShowTemplatePTParser.EquipmentListContext ctx);
	/**
	 * Enter a parse tree produced by the {@code figureNumField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#figureNum}.
	 * @param ctx the parse tree
	 */
	void enterFigureNumField(DroneShowTemplatePTParser.FigureNumFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code figureNumField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#figureNum}.
	 * @param ctx the parse tree
	 */
	void exitFigureNumField(DroneShowTemplatePTParser.FigureNumFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code figureNameField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#figureName}.
	 * @param ctx the parse tree
	 */
	void enterFigureNameField(DroneShowTemplatePTParser.FigureNameFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code figureNameField}
	 * labeled alternative in {@link DroneShowTemplatePTParser#figureName}.
	 * @param ctx the parse tree
	 */
	void exitFigureNameField(DroneShowTemplatePTParser.FigureNameFieldContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplatePTParser#figureEntry}.
	 * @param ctx the parse tree
	 */
	void enterFigureEntry(DroneShowTemplatePTParser.FigureEntryContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplatePTParser#figureEntry}.
	 * @param ctx the parse tree
	 */
	void exitFigureEntry(DroneShowTemplatePTParser.FigureEntryContext ctx);
	/**
	 * Enter a parse tree produced by {@link DroneShowTemplatePTParser#performanceElements}.
	 * @param ctx the parse tree
	 */
	void enterPerformanceElements(DroneShowTemplatePTParser.PerformanceElementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link DroneShowTemplatePTParser#performanceElements}.
	 * @param ctx the parse tree
	 */
	void exitPerformanceElements(DroneShowTemplatePTParser.PerformanceElementsContext ctx);
}