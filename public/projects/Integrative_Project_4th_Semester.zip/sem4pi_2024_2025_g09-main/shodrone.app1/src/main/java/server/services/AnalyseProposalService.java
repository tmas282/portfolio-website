package server.services;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import shodrone.customermanagement.Customer;
import shodrone.customermanagement.Email;
import shodrone.customerrepresentativemanagement.CustomerRepresentative;
import shodrone.repositories.CustomerRepresentativeRepository;
import shodrone.repositories.ShowProposalRepository;
import shodrone.showproposalmanagement.ShowProposal;
import shodrone.showproposalmanagement.ShowProposalStatus;
import shodrone.showrequestmanagement.ShowRequest;

import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class AnalyseProposalService {

    CustomerRepresentativeRepository customerRepresentativeRepository;
    ShowProposalRepository showProposalRepository;

    @Autowired
    public AnalyseProposalService(
            CustomerRepresentativeRepository customerRepresentativeRepository,
            ShowProposalRepository showProposalRepository
    ) {
        this.customerRepresentativeRepository = customerRepresentativeRepository;
        this.showProposalRepository = showProposalRepository;
    }

    @Transactional
    public List<ShowProposal> getAllShowProposalsOfRepresentative(Email email){
        CustomerRepresentative representative = this.customerRepresentativeRepository.findByEmail(email).orElseThrow();
        Customer customer = representative.getCustomer();
        List<ShowRequest> showRequestList = customer.getShowRequests();
        List<ShowProposal> proposalsAlreadySent = new ArrayList<>();
        for(ShowRequest r : showRequestList){
            List<ShowProposal> proposalList = showProposalRepository.findByShowRequest(r);
            for(ShowProposal proposal : proposalList){
                if(proposal.getStatus() == ShowProposalStatus.SENT){
                    proposalsAlreadySent.add(proposal);
                }
            }
        }
        return proposalsAlreadySent;
    }

    @Transactional
    public ShowProposal getShowProposalById(Long id, Email email){
        this.customerRepresentativeRepository.findByEmail(email).orElseThrow();
        return showProposalRepository.getReferenceById(id);
    }

    @Transactional
    public Resource getShowProposalFile(Long id, LocalDate date) throws MalformedURLException {
        String p = String.format("./proposals/proposal_%d_%04d%02d%02d.txt", id, date.getYear(), date.getMonthValue(), date.getDayOfMonth());
        Path path = Paths.get(p);
        Resource resource = new UrlResource(path.toUri());
        return resource;
    }
}
