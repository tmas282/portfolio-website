// shodrone.app1/src/main/java/shodrone/dronemodelmanagement/MaintenanceThreshold.java
package shodrone.dronemodelmanagement;

import jakarta.persistence.Embeddable;
import jakarta.persistence.Column;

@Embeddable
public class MaintenanceThreshold {
    @Column(name = "maintenance_threshold", nullable = false)
    private int thresholdValue;

    protected MaintenanceThreshold() {}

    public MaintenanceThreshold(int value) {
        if (value < 0) throw new IllegalArgumentException("Threshold must be non-negative");
        this.thresholdValue = value;
    }

    public int value() {
        return thresholdValue;
    }

    @Override
    public String toString() {
        return String.valueOf(thresholdValue);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MaintenanceThreshold)) return false;
        return thresholdValue == ((MaintenanceThreshold) o).thresholdValue;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(thresholdValue);
    }
}