package shodrone.controller;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import shodrone.dronemanagement.Drone;
import shodrone.dronemodelmanagement.DroneModel;
import shodrone.dronemodelmanagement.ModelID;
import shodrone.repositories.DroneModelRepository;
import shodrone.repositories.ShowProposalRepository;
import shodrone.services.DroneService;
import shodrone.services.ShowProposalService;
import shodrone.showproposalmanagement.ShowProposal;

import java.util.List;
import java.util.Map;

@Controller
public class AddDronesProposalController {
    private final DroneService droneService;
    private final ShowProposalService showProposalService;
    private final ShowProposalRepository showProposalRepository;
    private final DroneModelRepository droneModelRepository;

    @Autowired
    public AddDronesProposalController(DroneService droneService, ShowProposalService showProposalService, ShowProposalRepository showProposalRepository, DroneModelRepository droneModelRepository) {
        this.droneService = droneService;
        this.showProposalService = showProposalService;
        this.showProposalRepository = showProposalRepository;
        this.droneModelRepository = droneModelRepository;
    }
    public List<ShowProposal> getAllProposals(){
        return showProposalRepository.findAll();
    }
    public List<DroneModel> getAllDroneModels(){
        return droneModelRepository.findAll();
    }
    @Transactional
    public boolean addDronesToShowProposal(Long id, Map<ModelID, Integer> requestedDrones){
        try{
            List<Drone> drones = droneService.getDronesAvailable(requestedDrones);
            ShowProposal proposal = showProposalRepository.findById(id).orElseThrow(() -> new RuntimeException("Show proposal not exist"));
            showProposalService.addDronesToShowProposal(proposal, drones);
            return true;
        } catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }
}
