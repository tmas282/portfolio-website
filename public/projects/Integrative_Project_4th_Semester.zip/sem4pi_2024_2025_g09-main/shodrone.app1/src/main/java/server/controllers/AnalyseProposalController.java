package server.controllers;

import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import server.dto.ShowProposalDTO;
import server.services.AnalyseProposalService;
import shodrone.customermanagement.Email;
import shodrone.services.CustomerService;
import shodrone.showproposalmanagement.ShowProposal;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;

@RestController
public class AnalyseProposalController {

    private final AnalyseProposalService service;

    public AnalyseProposalController(AnalyseProposalService analyseProposalService) {
        this.service = analyseProposalService;
    }

    @GetMapping("/get-show-proposals-of-representative")
    public List<ShowProposalDTO> getShowProposalsOfRepresentative(Authentication auth){
        Email email = new Email(auth.getName());
        List<ShowProposal> showProposals = service.getAllShowProposalsOfRepresentative(email);
        List<ShowProposalDTO> showProposalDTOS = new ArrayList<>();
        for(ShowProposal proposal : showProposals){
            showProposalDTOS.add(new ShowProposalDTO(
                    proposal.getId(),
                    proposal.getDate().value(),
                    proposal.getPlace().value(),
                    proposal.getDescription().getDescription())
                    );
        }
        return showProposalDTOS;
    }

    @GetMapping(value = "/download-show-proposal", params = {"id"})
    public ResponseEntity<Resource> downloadShowProposal(Authentication auth, @RequestParam("id") Long id) throws MalformedURLException {
        Email email = new Email(auth.getName());
        ShowProposal showProposal = service.getShowProposalById(id, email);
        Resource resource = service.getShowProposalFile(showProposal.getId(), showProposal.getDate().value());
        return ResponseEntity.ok()
                .contentType(MediaType.TEXT_PLAIN)
                .body(resource);
    }
}
