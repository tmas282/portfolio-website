package shodrone.controller;

    import org.springframework.stereotype.Controller;
    import shodrone.customermanagement.Name;
    import shodrone.customermanagement.PhoneNumber;
    import shodrone.services.UserService;
    import shodrone.usermanagement.RoleName;
    import shodrone.usermanagement.User;

    @Controller
    public class RegisterUserController {

        private final UserService userService;

        public RegisterUserController(UserService userService) {
            this.userService = userService;
        }

        public User registerUser(String email, String password, RoleName roleName, String fullName, String phoneNumber) {
            Name name = new Name(fullName);
            PhoneNumber phone = new PhoneNumber(phoneNumber);
            return userService.registerUser(email, password, roleName, name, phone);
        }
    }