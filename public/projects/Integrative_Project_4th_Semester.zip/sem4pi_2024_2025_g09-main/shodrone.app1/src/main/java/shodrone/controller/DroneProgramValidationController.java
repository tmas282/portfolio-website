package shodrone.controller;

import integrations.plugins.drone.alternate.DroneInstructionDTO;
import integrations.plugins.drone.alternate.DroneLanguageImporter;
import org.springframework.stereotype.Controller;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

@Controller
public class DroneProgramValidationController {

    private final DroneLanguageImporter importer;

    public DroneProgramValidationController(DroneLanguageImporter importer) {
        this.importer = importer;
    }

    public boolean validateAndSaveDroneProgram(String filePath) {
        try (InputStream input = Files.newInputStream(Paths.get(filePath))) {
            List<DroneInstructionDTO> instructions = importer.importFrom(input);

            if (instructions == null || instructions.isEmpty()) {
                System.err.println("Validation failed: No valid instructions found.");
                return false;
            }

            System.out.println("Validation successful: The program is syntactically correct.");
            instructions.forEach(System.out::println);

            System.out.println("Drone program saved successfully to the database.");
            return true;
        } catch (Exception e) {
            System.err.println("Error validating drone program: " + e.getMessage());
            return false;
        }
    }
}
