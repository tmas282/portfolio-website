package shodrone.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import shodrone.dronemodelmanagement.*;
import shodrone.repositories.DroneModelRepository;

@Service
public class DroneModelService {

    private final DroneModelRepository droneModelRepository;

    @Autowired
    public DroneModelService(DroneModelRepository droneModelRepository) {
        this.droneModelRepository = droneModelRepository;
    }

    // Add MaintenanceThreshold as a parameter
    @Transactional
    public DroneModel createDroneModel(String modelIDStr, String programmingLanguageStr, WindTolerance tolerance, MaintenanceThreshold maintenanceThreshold) {
        ModelID modelID = new ModelID(modelIDStr);

        if (droneModelRepository.findByModelID(modelID).isPresent()) {
            throw new IllegalStateException("A drone model with ID '" + modelIDStr + "' already exists.");
        }

        ProgrammingLanguage language = new ProgrammingLanguage(programmingLanguageStr);
        DroneModel model = new DroneModel(modelID, language, tolerance, maintenanceThreshold);
        return droneModelRepository.save(model);
    }
}