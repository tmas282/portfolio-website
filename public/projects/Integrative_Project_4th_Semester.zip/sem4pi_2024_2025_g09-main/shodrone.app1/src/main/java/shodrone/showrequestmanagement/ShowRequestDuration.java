package shodrone.showrequestmanagement;

import jakarta.persistence.Embeddable;

import java.util.Objects;

@Embeddable
public class ShowRequestDuration {
    private int duration;

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        assert duration >= 0;
        this.duration = duration;
    }

    protected ShowRequestDuration() {
    }
    public ShowRequestDuration(int duration) {
        assert duration >= 0;
        this.duration = duration;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        ShowRequestDuration that = (ShowRequestDuration) o;
        return duration == that.duration;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(duration);
    }
}
