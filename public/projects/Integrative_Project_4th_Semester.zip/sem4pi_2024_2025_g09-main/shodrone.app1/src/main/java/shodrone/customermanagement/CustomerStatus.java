package shodrone.customermanagement;

public enum CustomerStatus {
    CREATED,
    DELETED,
    INFRINGEMENT
}
