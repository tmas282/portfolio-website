package shodrone.showproposalmanagement;

import jakarta.persistence.Embeddable;

import java.time.Duration;
import java.util.Objects;

@Embeddable
public class ShowProposalDuration {

    private long seconds;

    protected ShowProposalDuration() {
    }

    public ShowProposalDuration(Duration duration) {
        if (duration == null) {
            throw new IllegalArgumentException("Duration cannot be null");
        }
        if (duration.isNegative() || duration.isZero()) {
            throw new IllegalArgumentException("Duration must be positive");
        }
        this.seconds = duration.getSeconds();
    }

    public Duration value() {
        return Duration.ofSeconds(seconds);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ShowProposalDuration that = (ShowProposalDuration) o;
        return seconds == that.seconds;
    }

    @Override
    public int hashCode() {
        return Objects.hash(seconds);
    }

    @Override
    public String toString() {
        Duration duration = Duration.ofSeconds(seconds);
        long hours = duration.toHours();
        long minutes = duration.toMinutesPart();
        long secs = duration.toSecondsPart();
        return String.format("%d:%02d:%02d", hours, minutes, secs);
    }
}