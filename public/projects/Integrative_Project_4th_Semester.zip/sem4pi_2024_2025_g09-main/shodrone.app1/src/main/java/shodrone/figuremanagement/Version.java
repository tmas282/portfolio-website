package shodrone.figuremanagement;

import eapli.framework.domain.model.ValueObject;
import jakarta.persistence.Embeddable;

@Embeddable
public class Version {

    private Float version;

    protected Version() {};

    public Version(Float version) {
        if (version==null) throw new IllegalArgumentException("Version is null");
        this.version = version;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof Version && version.equals(((Version) o).version);
    }
}
