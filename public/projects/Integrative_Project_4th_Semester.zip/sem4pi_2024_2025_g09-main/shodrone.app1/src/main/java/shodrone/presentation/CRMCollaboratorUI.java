package shodrone.presentation;

import org.springframework.stereotype.Component;
import shodrone.controller.*;
import shodrone.customerrepresentativemanagement.CustomerRepresentative;
import shodrone.dronemodelmanagement.DroneModel;
import shodrone.dronemodelmanagement.ModelID;
import shodrone.figurecategorymanagement.FigureCategory;
import shodrone.figuremanagement.Figure;
import shodrone.repositories.CustomerRepository;
import shodrone.showproposalmanagement.*;
import shodrone.showrequestmanagement.NumberOfDrones;
import shodrone.showrequestmanagement.ShowDescription;
import shodrone.showrequestmanagement.ShowRequest;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;

import java.sql.SQLOutput;
import java.util.*;

import static shodrone.presentation.ListShowRequestsUI.listShowRequestsOfCustomer;

@Component
public class CRMCollaboratorUI {

    private final AddCustomerRepresentativeController addCustomerRepresentativeController;
    private final ListCustomerRepresentativesController listCustomerRepresentativesController;
    private final RegisterCustomerController registerCustomerController;
    private final FigureController figureController;
    private final FigureCategoryController figureCategoryController;
    private final RegisterShowRequestController registerShowRequestController;
    private final ListShowRequestsController listShowRequestsController;
    private final EditShowRequestController editShowRequestController;
    private final CreateShowProposalController createShowProposalController;
    private final AddFiguresShowProposalController addFiguresShowProposalController;
    private final AddVideoToShowProposalController addVideoToShowProposalController;
    private final SendShowProposalController sendShowProposalController;
    private final MarkShowProposalController markShowProposalController;
    private final AddDronesProposalController addDronesProposalController;


    public CRMCollaboratorUI(
            AddCustomerRepresentativeController addCustomerRepresentativeController,
            ListCustomerRepresentativesController listCustomerRepresentativesController,
            RegisterCustomerController registerCustomerController,
            FigureController figureController,
            FigureCategoryController figureCategoryController,
            RegisterShowRequestController registerShowRequestController,
            ListShowRequestsController listShowRequestsController,
            EditShowRequestController editShowRequestController,
            CreateShowProposalController createShowProposalController,
            AddFiguresShowProposalController addFiguresShowProposalController,
            AddVideoToShowProposalController addVideoToShowProposalController,
            SendShowProposalController sendShowProposalController,
            MarkShowProposalController markShowProposalController,
            AddDronesProposalController addDronesProposalController


    ) {
        this.addCustomerRepresentativeController = addCustomerRepresentativeController;
        this.listCustomerRepresentativesController = listCustomerRepresentativesController;
        this.registerCustomerController = registerCustomerController;
        this.figureController = figureController;
        this.figureCategoryController = figureCategoryController;
        this.registerShowRequestController = registerShowRequestController;
        this.listShowRequestsController = listShowRequestsController;
        this.editShowRequestController = editShowRequestController;
        this.createShowProposalController = createShowProposalController;
        this.addFiguresShowProposalController = addFiguresShowProposalController;
        this.addVideoToShowProposalController = addVideoToShowProposalController;
        this.sendShowProposalController = sendShowProposalController;
        this.markShowProposalController = markShowProposalController;
        this.addDronesProposalController = addDronesProposalController;
    }


    public void run() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n=== CRM Collaborator Menu ===");
            System.out.println("1. Register Customer");
            System.out.println("2. Add Customer Representative");
            System.out.println("3. List Customer Representatives");
            System.out.println("4. Edit Customer Representative");
            System.out.println("5. Disable Customer Representative");
            System.out.println("6. List All Active Public Figures");
            System.out.println("7. Search For Figures In The Catalogue");
            System.out.println("8. Register Show Request");
            System.out.println("9. List Show Requests of Client");
            System.out.println("10. Edit Show Request of a Client");
            System.out.println("11. Create Show Proposal");
            System.out.println("12. Add drones to a Show Proposal");
            System.out.println("13. Add figures to a Show Proposal");
            System.out.println("14. Add a video to a Show Proposal");
            System.out.println("15. Send show proposal");
            System.out.println("16. Exit");
            System.out.println("0. Logout");

            System.out.print("Choose option: ");
            String option = scanner.nextLine();

            switch (option) {
                case "1":
                    registerCustomer(scanner);
                    break;
                case "2":
                    addCustomerRepresentative(scanner);
                    break;
                case "3":
                    listCustomerRepresentatives(scanner);
                    break;
                case "4":
                    editCustomerRepresentative(scanner);
                    break;
                case "5":
                    disableCustomerRepresentative(scanner);
                    break;
                case "6":
                    listAllActivePublicFigures();
                    break;
                case "7":
                    searchFigures(scanner);
                    break;
                case "8":
                    registerShowRequest(scanner);
                    break;
                case "9":
                    listShowRequestsOfCustomer(listShowRequestsController, scanner);
                    break;
                case "10":
                    editShowRequest(scanner);
                    break;
                case "11":
                    createShowProposal(scanner);
                    break;
                case "12":
                    addDronesToProposal(scanner);
                    break;
                case "13":
                    addMultipleFiguresToProposal(scanner);
                    break;
                case "14":
                    addSimulationVideoToProposal(scanner);
                    break;
                case "15":
                    sendShowProposal(scanner);
                    break;
                case "16":
                    System.out.println("Exiting...");
                    System.exit(0);
                case "0":
                    System.out.println("Logging out...");
                    return;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    private void addDronesToProposal(Scanner scanner) {
        try{
            String temp;
            System.out.println("Show proposals:");
            for(ShowProposal i
                    : addDronesProposalController.getAllProposals()){
                System.out.printf("\t%s: %s %s\n",
                        i.getId(),
                        i.getDescription().getDescription(),
                        i.getDate().value().toString());
            }
            System.out.println("Enter the ID of the show proposal:");
            temp = scanner.nextLine();
            Long proposalId = Long.parseLong(temp);
            System.out.println("Drone models:");
            for(DroneModel m:
                    addDronesProposalController.getAllDroneModels()){
                System.out.printf("\t %s\n",m);
            }
            Map<ModelID, Integer> request = new HashMap<>();
            do{
                System.out.println("Enter the model ID or write 'exit' to leave: ");
                temp = scanner.nextLine();
                if(temp.equalsIgnoreCase("exit"))
                    break;
                ModelID modelID = new ModelID(temp);
                System.out.println("How many drones of that model you need (write 'exit' to leave): ");
                temp = scanner.nextLine();
                if(temp.equalsIgnoreCase("exit"))
                    break;
                Integer qnt = Integer.parseInt(temp);
                request.putIfAbsent(modelID, qnt);
            } while(true);
            if(addDronesProposalController.addDronesToShowProposal(proposalId, request)){
                System.out.println("Success on adding drones to proposal");
                return;
            }
            System.out.println("Error on adding drone to proposal");
        } catch (Exception e){
            System.out.println("Error:");
            e.printStackTrace();
        }
    }

    private void registerCustomer(Scanner scanner) {
        System.out.print("Enter customer VAT: ");
        String vat = scanner.nextLine();

        System.out.print("Enter customer name: ");
        String name = scanner.nextLine();

        System.out.print("Enter customer email: ");
        String email = scanner.nextLine();

        System.out.print("Enter customer address: ");
        String address = scanner.nextLine();

        System.out.print("Enter customer phone number: ");
        String phone = scanner.nextLine();

        System.out.print("Enter customer type (REGULAR/VIP, default REGULAR): ");
        String type = scanner.nextLine().trim();

        System.out.print("Enter representative name: ");
        String repName = scanner.nextLine();

        System.out.print("Enter representative email: ");
        String repEmail = scanner.nextLine();

        System.out.print("Enter representative position: ");
        String repPosition = scanner.nextLine();

        System.out.print("Enter representative phone number: ");
        String repPhone = scanner.nextLine();

        try {
            registerCustomerController.registerCustomerAndRepresentative(
                    vat, name, email, address, phone, repName, repEmail, repPosition, repPhone, type
            );
            System.out.println("✅ Customer and representative registered successfully.");
        } catch (Exception e) {
            System.out.println("❌ Error registering customer and representative: " + e.getMessage());
        }
    }

    private void addCustomerRepresentative(Scanner scanner) {
        System.out.print("Enter customer VAT (9 digits): ");
        String rawVat = scanner.nextLine().trim();

        System.out.print("Enter representative name: ");
        String name = scanner.nextLine().trim();

        System.out.print("Enter representative email: ");
        String email = scanner.nextLine().trim();

        System.out.print("Enter representative position: ");
        String position = scanner.nextLine().trim();

        System.out.print("Enter representative phone number: ");
        String phone = scanner.nextLine().trim();

        try {
            if (!rawVat.matches("^[A-Z]{2}\\d{9}$")) {
                throw new IllegalArgumentException("VAT must start with 2 letters followed by 9 digits (e.g., PT123456789)");
            }
            if (name.length() < 2) {
                System.out.println("❌ Name must be at least 2 characters.");
                return;
            }
            if (!email.matches("^[\\w-.]+@[\\w-]+\\.[a-z]{2,}$")) {
                System.out.println("❌ Invalid email format.");
                return;
            }
            if (position.isBlank()) {
                System.out.println("❌ Position cannot be blank.");
                return;
            }
            if (!phone.matches("^\\d{9}$")) {
                System.out.println("❌ Phone number must be 9 digits.");
                return;
            }

            addCustomerRepresentativeController.addCustomerRepresentative(rawVat, name, email, position, phone);
            System.out.println("✅ Customer representative added successfully.");

        } catch (IllegalArgumentException e) {
            System.out.println("⚠️ Business error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("❌ Unexpected error: " + e.getClass().getSimpleName() + " - " + e.getMessage());
        }
    }

    private void listCustomerRepresentatives(Scanner scanner) {
        System.out.print("Enter customer VAT: ");
        String vat = scanner.nextLine().trim();

        try {
            List<CustomerRepresentative> representatives =
                    listCustomerRepresentativesController.listActiveRepresentatives(vat);
            if (representatives.isEmpty()) {
                System.out.println("No active representatives found for this customer.");
            } else {
                System.out.println("Active Representatives:");
                representatives.forEach(rep -> System.out.printf("- %s (%s, %s)%n",
                        rep.getName().value(), rep.getEmail().value(), rep.getPosition().getValue()));
            }
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }

    private void editCustomerRepresentative(Scanner scanner) {
        System.out.print("Enter current representative email: ");
        String currentEmail = scanner.nextLine().trim();

        System.out.print("Enter new email (leave blank to keep current): ");
        String newEmail = scanner.nextLine().trim();

        System.out.print("Enter new phone number (leave blank to keep current): ");
        String newPhone = scanner.nextLine().trim();

        try {
            addCustomerRepresentativeController.editCustomerRepresentative(currentEmail, newEmail, newPhone);
            System.out.println("✅ Customer representative updated successfully.");
        } catch (IllegalArgumentException e) {
            System.out.println("⚠️ Business error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("❌ Unexpected error: " + e.getClass().getSimpleName() + " - " + e.getMessage());
        }
    }

    private void disableCustomerRepresentative(Scanner scanner) {
        System.out.print("Enter representative email to disable: ");
        String email = scanner.nextLine().trim();

        try {
            boolean success = addCustomerRepresentativeController.disableCustomerRepresentative(email);
            if (success) {
                System.out.println("✅ Customer representative disabled successfully.");
            } else {
                System.out.println("⚠️ Customer representative is already disabled.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }

    public void listAllActivePublicFigures() {
        List<Figure> list = figureController.allPublicFigures();
        if (list.isEmpty()) {
            System.out.println("⚠️ No active public figures found.");
        } else {
            System.out.println("\n=== List Of All Active Public Figures ===");
            for (Figure figure : list) {
                System.out.println("- " + figure);
            }
        }
    }

    public void searchFigures(Scanner scanner) {
        System.out.println("1. Search by category");
        System.out.println("2. Search by keyword");
        System.out.println("3. Search by category and keyword");
        System.out.println("0. Exit");
        int choice = scanner.nextInt();
        scanner.nextLine();
        switch (choice) {
            case 1:
                System.out.println("Available categories:");
                for (FigureCategory cat : figureCategoryController.listCategories()) {
                    System.out.println(" - " + cat.name());
                }
                System.out.println("Enter category name: ");
                String category_name = scanner.nextLine().trim();
                List<Figure> list = figureController.searchByCategory(category_name);
                if(list.isEmpty()) {
                    System.out.println("No figures found...");
                    break;
                }
                else {
                    System.out.println("\n=== List Of All Active Figures Found ===");
                    for (Figure figure : list) {
                        System.out.println("- " + figure);
                    }
                }
                break;
            case 2:
                System.out.println("Enter keyword: ");
                String keyword = scanner.nextLine().trim();
                List<Figure> list2 = figureController.searchByKeyword(keyword);
                if(list2.isEmpty()) {
                    System.out.println("No figures found...");
                    break;
                }
                else {
                    System.out.println("\n=== List Of All Active Figures Found ===");
                    for (Figure figure : list2) {
                        System.out.println("- " + figure);
                    }
                }
                break;
            case 3:
                System.out.println("Available categories:");
                for (FigureCategory cat : figureCategoryController.listCategories()) {
                    System.out.println(" - " + cat.name());
                }
                System.out.println("Enter category name: ");
                String cat_name = scanner.nextLine().trim();
                System.out.println("Enter keyword: ");
                String keyword2 = scanner.nextLine().trim();
                List<Figure> list3 = figureController.searchByCategoryAndKeyword(cat_name, keyword2);
                if(list3.isEmpty()) {
                    System.out.println("No figures found...");
                    break;
                }
                else {
                    System.out.println("\n=== List Of All Active Figures Found ===");
                    for (Figure figure : list3) {
                        System.out.println("- " + figure);
                    }
                }
                break;
        }
    }
    public void registerShowRequest(Scanner scanner){
        System.out.println("Please insert the customer VAT: ");
        String vat = scanner.nextLine();
        if(!registerShowRequestController.checkClientIsRegistered(vat)){
            System.out.println("That customer isn't registered.");
            return;
        }
        System.out.println("Enter date and time (yyyy-MM-dd HH:mm:ss, e.g., 2025-05-15 14:30:00): ");
        String dateTime = scanner.nextLine();
        System.out.println("Enter duration: ");
        String temp = scanner.nextLine();
        int duration = Integer.parseInt(temp);
        System.out.println("Enter place: ");
        String place = scanner.nextLine();
        System.out.println("Enter number of drones: ");
        temp = scanner.nextLine();
        int numberOfDrones = Integer.parseInt(temp);
        System.out.println("Enter a show description: ");
        String desc = scanner.nextLine();
        boolean success = registerShowRequestController.addShowRequest(vat, dateTime, duration, place, numberOfDrones, desc);
        if(success)
            System.out.println("✅ Show request registered successfully ");
        else
            System.out.println("❌ An unexpected error occurred");
    }
    public void editShowRequest(Scanner scanner){
        System.out.println("Please enter the customer VAT: ");
        String VAT = scanner.nextLine();
        try{
            List<ShowRequest> list = editShowRequestController.listShowRequestsOfCustomer(VAT);
            for(ShowRequest i : list){
                String dt = i.getDatetime().getDateTime().toString().replace("T", " ");
                System.out.printf("%d->\tDescription: %s\tPlace: %s\tDate & Time: %s\tDuration: %d\tNumber of Drones: %d\tStatus: %s\n", i.getId(), i.getDescription().getDescription(), i.getPlace().getPlace(), dt, i.getDuration().getDuration(), i.getNumberOfDrones().getNumber(), i.getStatus().toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("An unexpected error occurred");
            return;
        }
        System.out.println("Please choose one show request: ");
        String showRequestId = scanner.nextLine();
        try{
            String dateTime = null;
            System.out.println("Do you want to edit date and/or time? [y/n]");
            if(scanner.nextLine().equalsIgnoreCase("y")){
                System.out.println("Enter date and time (yyyy-MM-dd HH:mm:ss, e.g., 2025-05-15 14:30:00): ");
                dateTime = scanner.nextLine();
            }
            int duration = -1;
            System.out.println("Do you want to edit duration? [y/n]");
            if(scanner.nextLine().equalsIgnoreCase("y")){
                System.out.println("Enter duration: ");
                String temp = scanner.nextLine();
                duration = Integer.parseInt(temp);
            }
            String place = null;
            System.out.println("Do you want to edit place? [y/n]");
            if(scanner.nextLine().equalsIgnoreCase("y")){
                System.out.println("Enter place: ");
                place = scanner.nextLine();
            }
            int numberOfDrones = -1;
            System.out.println("Do you want to edit number of drones? [y/n]");
            if(scanner.nextLine().equalsIgnoreCase("y")){
                System.out.println("Enter number of drones: ");
                String temp = scanner.nextLine();
                numberOfDrones = Integer.parseInt(temp);
            }
            String desc = null;
            System.out.println("Do you want to edit description? [y/n]");
            if(scanner.nextLine().equalsIgnoreCase("y")){
                System.out.println("Enter a show description: ");
                desc = scanner.nextLine();
            }
            editShowRequestController.editShowRequest(VAT, Integer.parseInt(showRequestId), dateTime, duration, place, numberOfDrones, desc);
            System.out.println("✅ Show request edited successfully");
        } catch (Exception e){
            e.printStackTrace();
            System.out.println("❌ An unexpected error occurred");
        }
    }

    private void createShowProposal(Scanner scanner) {
        try {
            System.out.println("Enter customer VAT:");
            String customerVat = scanner.nextLine();

            List<ShowRequest> showRequests = listShowRequestsController.listShowRequestsOfCustomer(customerVat);
            if (showRequests.isEmpty()) {
                System.out.println("⚠️ No show requests found for this customer.");
                return;
            }

            System.out.println("Available show requests:");
            for (ShowRequest request : showRequests) {
                String dt = request.getDatetime().getDateTime().toString().replace("T", " ");
                System.out.printf("%d->\tDescription: %s\tPlace: %s\tDate & Time: %s\tDuration: %d\tNumber of Drones: %d\tStatus: %s\n", 
                    request.getId(), request.getDescription().getDescription(), request.getPlace().getPlace(), 
                    dt, request.getDuration().getDuration(), request.getNumberOfDrones().getNumber(), 
                    request.getStatus().toString());
            }

            System.out.println("Enter show request ID:");
            int showRequestId = Integer.parseInt(scanner.nextLine());

            var proposal = createShowProposalController.create(showRequestId);

            System.out.println("✅ Show proposal created successfully with ID: " + proposal.getId());

        } catch (Exception e) {
            System.out.println("❌ Error creating proposal: " + e.getMessage());
        }
    }

    private void addMultipleFiguresToProposal(Scanner scanner) {
        try {
            System.out.println("Enter the ID of the show proposal:");
            Long proposalId = Long.parseLong(scanner.nextLine());

            List<Figure> addedFigures = new ArrayList<>();

            while (true) {
                System.out.println("Enter the code of the figure to add (or 'done' to finish):");
                String input = scanner.nextLine();
                if ("done".equalsIgnoreCase(input)) break;

                while (true) {
                    System.out.println("Enter the position in the proposal:");
                    String positionInput = scanner.nextLine();

                    if ("cancel".equalsIgnoreCase(positionInput)) break;

                    int position;
                    try {
                        position = Integer.parseInt(positionInput);
                    } catch (NumberFormatException e) {
                        System.out.println("⚠️ Invalid position. Try again or type 'cancel' to skip:");
                        continue;
                    }

                    try {
                        var updatedProposal = addFiguresShowProposalController.addFigureWithoutDroneModel(proposalId, input, position);

                        Figure lastAdded = updatedProposal.getFigures()
                                .stream()
                                .filter(f -> f.getFigure().code().value() == Long.parseLong(input))
                                .findFirst()
                                .orElseThrow(() -> new RuntimeException("Figure just added not found"))
                                .getFigure();

                        addedFigures.add(lastAdded);
                        System.out.println("✅ Figure " + input + " added successfully.");
                        break;

                    } catch (IllegalArgumentException | IllegalStateException e) {
                        System.out.println("⚠️ Error: " + e.getMessage());
                        System.out.println("Try a different position or type 'cancel' to skip this figure:");
                    }
                }
            }

            for (Figure figure : addedFigures) {
                while (true) {
                    System.out.println("Enter a Drone Model to associate with Figure [" + figure.code().value() + "] (or 'done'):");
                    String modelInput = scanner.nextLine();
                    if ("done".equalsIgnoreCase(modelInput)) break;

                    try {
                        addFiguresShowProposalController.associateDroneModelWithFigure(figure.code().value(), modelInput);
                        System.out.println("✅ Associated model " + modelInput + " with figure " + figure.code().value());
                    } catch (Exception e) {
                        System.out.println("⚠️ Could not associate: " + e.getMessage());
                    }
                }
            }

        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }

    private void addSimulationVideoToProposal(Scanner scanner) {
        try {
            System.out.println("Enter the ID of the show proposal:");
            Long proposalId = Long.parseLong(scanner.nextLine());

            System.out.println("Enter the link to the video:");
            String videoLink = scanner.nextLine();

            addVideoToShowProposalController.addSimulationVideoLink(proposalId, videoLink);

            System.out.println("✅ Video link added successfully to Show Proposal " + proposalId);
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }

    private void sendShowProposal(Scanner scanner) {
        try {
            System.out.println("List of unsent show proposals:");
            List<ShowProposal> list = sendShowProposalController.listOfUnsentShowProposals();
            for(int i=0; i<list.size(); i++){
                System.out.println((i+1) + ". "+list.get(i).toString());
            }
            Integer choice = Integer.parseInt(scanner.nextLine()) -1;
            while(choice<0||choice>list.size()){
                System.out.print("Choose again: ");
                choice = Integer.parseInt(scanner.nextLine());
            }
            if(sendShowProposalController.sendShowProposal(list.get(choice))==1) {
                System.out.println("✅ Show proposal sent successfully.");
            }
            else {
                System.out.println("❌ Error sending show proposal");
            }
        }
        catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }
    private void markShowProposal(Scanner scanner){
        System.out.println("Accepted (by the customer) show proposals: ");
        for(ShowProposal v :
             markShowProposalController.seeShowProposalsAcceptedByCustomer()){
            System.out.println(v.toString());
        }
        System.out.println("The ID of the proposal to mark as accepted");
        String idStr = scanner.nextLine();
        Long id = Long.parseLong(idStr);
        boolean success = markShowProposalController.markShowProposal(id);
        if(success){
            System.out.println("✅ Show proposal marked successfully.");
            return;
        }
        System.out.println("❌ Error marking show proposal");
    }
}
