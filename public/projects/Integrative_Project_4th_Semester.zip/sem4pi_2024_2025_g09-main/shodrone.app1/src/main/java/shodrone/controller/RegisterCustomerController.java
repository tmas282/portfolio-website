package shodrone.controller;

import org.springframework.stereotype.Controller;
import shodrone.services.CustomerService;

@Controller
public class RegisterCustomerController {

    private final CustomerService customerService;

    public RegisterCustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    public void registerCustomerAndRepresentative(
            String vat,
            String customerName,
            String customerEmail,
            String customerAddress,
            String customerPhone,
            String repName,
            String repEmail,
            String repPosition,
            String repPhone,
            String customerType
    ) {
        customerService.registerCustomerAndRepresentative(
                vat, customerName, customerEmail, customerAddress, customerPhone,
                repName, repEmail, repPosition, repPhone, customerType
        );
    }
}
