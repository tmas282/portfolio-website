package shodrone.dronelanguage;

import org.antlr.v4.runtime.*;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
@Component
public class DroneLanguageValidator {

    public boolean validate(String filePath) {
        try {
            String code = Files.readString(Paths.get(filePath));

            CharStream input = CharStreams.fromString(code);
            DroneLanguageLexer lexer = new DroneLanguageLexer(input);
            CommonTokenStream tokens = new CommonTokenStream(lexer);
            DroneLanguageParser parser = new DroneLanguageParser(tokens);

            parser.removeErrorListeners();
            SyntaxErrorListener errorListener = new SyntaxErrorListener();
            parser.addErrorListener(errorListener);

            parser.program();

            if (errorListener.hasErrors()) {
                System.err.println("Syntax errors detected:");
                Arrays.asList(errorListener.getErrors()).forEach(System.err::println);
                return false;
            }

            System.out.println("The drone program is valid.");
            return true;

        } catch (IOException e) {
            System.err.println("Failed to read file: " + filePath);
            return false;
        }
    }

    private static class SyntaxErrorListener extends BaseErrorListener {
        private final StringBuilder errorLog = new StringBuilder();
        private boolean hasErrors = false;

        @Override
        public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol,
                                int line, int charPositionInLine, String msg, RecognitionException e) {
            hasErrors = true;
            errorLog.append("line ").append(line).append(":").append(charPositionInLine)
                    .append(" ").append(msg).append("\n");
        }

        public boolean hasErrors() {
            return hasErrors;
        }

        public String[] getErrors() {
            return errorLog.toString().split("\n");
        }
    }
}
