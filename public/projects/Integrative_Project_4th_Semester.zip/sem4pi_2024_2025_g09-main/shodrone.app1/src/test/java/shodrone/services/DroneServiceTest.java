package shodrone.services;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import shodrone.dronemanagement.Drone;
import shodrone.dronemanagement.DroneStatus;
import shodrone.dronemodelmanagement.ModelID;
import shodrone.repositories.DroneModelRepository;
import shodrone.repositories.DroneRepository;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class DroneServiceTest {

    private DroneRepository droneRepo;
    private DroneModelRepository modelRepo;
    private DroneService droneService;

    @BeforeEach
    void setUp() {
        droneRepo = mock(DroneRepository.class);
        modelRepo = mock(DroneModelRepository.class);
        droneService = new DroneService(droneRepo, modelRepo);
    }

    @Test
    void testGetDronesAvailable() {
        ModelID modelId = new ModelID("M1");
        Drone d1 = mock(Drone.class);
        Drone d2 = mock(Drone.class);
        when(droneRepo.findByModel_ModelIDAndStatus(modelId, DroneStatus.ACTIVE))
                .thenReturn(Arrays.asList(d1, d2));

        Map<ModelID, Integer> req = new HashMap<>();
        req.put(modelId, 2);

        List<Drone> result = droneService.getDronesAvailable(req);
        assertEquals(2, result.size());
        assertTrue(result.containsAll(Arrays.asList(d1, d2)));
    }

    @Test
    void testGetDronesAvailableValidationError() {
        ModelID modelId = new ModelID("M1");
        when(droneRepo.findByModel_ModelIDAndStatus(modelId, DroneStatus.ACTIVE))
                .thenReturn(Collections.singletonList(mock(Drone.class)));

        Map<ModelID, Integer> req = new HashMap<>();
        req.put(modelId, 2);

        assertThrows(IllegalArgumentException.class, () -> droneService.getDronesAvailable(req));
    }
}