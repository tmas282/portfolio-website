package shodrone.controller;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import shodrone.customermanagement.*;
import shodrone.customerrepresentativemanagement.CustomerRepresentative;
import shodrone.repositories.ShowProposalRepository;
import shodrone.showproposalmanagement.*;
import shodrone.showrequestmanagement.*;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class MarkShowProposalControllerTest {

    private static ShowProposalRepository showProposalRepository;

    @BeforeAll
    static void setup(){
        showProposalRepository = mock(ShowProposalRepository.class);
        when(showProposalRepository.save(any(ShowProposal.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));
        when(showProposalRepository.save(any(ShowProposal.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));
    }
    @Test
    void testMarkShowProposal() {
        Customer customer = new Customer(new VAT("PT123456789"),
                new Name("example"),
                new Email("123@showdrone.com"),
                new Address("example"),
                new PhoneNumber("932961514"),
                new CustomerRepresentative(),
                CustomerType.REGULAR);
        ShowRequest showRequest = new ShowRequest(customer,
                new ShowRequestStatus(ShowRequestStatus.ShowRequestStatusOptions.ACCEPTED),
                new ShowRequestDateTime(LocalDateTime.MAX),
                new ShowRequestDuration(60),
                new ShowRequestPlace("example"),
                new NumberOfDrones(10),
                new ShowDescription("example"));
        ShowProposal showProposal = new ShowProposal(showRequest,
                ShowProposalStatus.ACCEPTED,
                new NumberOfDrones(10),
                new ShowDescription("example"),
                new ShowProposalDate(LocalDate.MAX),
                new ShowProposalTime(LocalTime.MAX),
                new ShowProposalDuration(Duration.ofMinutes(30)),
                new ShowProposalPlace("example"));
        showProposal = showProposalRepository.save(showProposal);
        when(showProposalRepository.findById(showProposal.getId()))
                .thenReturn(java.util.Optional.of(showProposal));
        MarkShowProposalController controller = new MarkShowProposalController(showProposalRepository);
        assertTrue(controller.markShowProposal(showProposal.getId()));
    }
}