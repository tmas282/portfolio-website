package shodrone.controller;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import shodrone.repositories.CustomerRepository;
import shodrone.services.CustomerService;
import shodrone.services.ShowRequestService;

import static org.junit.jupiter.api.Assertions.*;

class RegisterShowRequestControllerTest {
    private static CustomerService customerService;
    private static ShowRequestService showRequestService;
    private static RegisterShowRequestController c;
    @BeforeAll
    static void setup(){
        customerService = Mockito.mock(CustomerService.class);
        showRequestService = Mockito.mock(ShowRequestService.class);
        c = new RegisterShowRequestController(customerService, showRequestService);
    }
    @Test
    void checkClientIsRegistered() {
        boolean real = c.checkClientIsRegistered("PT123456789");
        assertTrue(real);
    }

    @Test
    void addShowRequest() {
        boolean real = c.addShowRequest("PT123456789", "2000-01-01 10:10:10", 60, "espinho", 1, "blabla");
        assertTrue(real);
    }
}