package shodrone.services;

import shodrone.figurecategorymanagement.CategoryName;
import shodrone.figurecategorymanagement.Description;
import shodrone.figurecategorymanagement.FigureCategory;
import shodrone.repositories.FigureCategoryRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class EditFigureCategoryServiceTest {

    private FigureCategoryService service;
    private FigureCategoryRepository repository;

    @BeforeEach
    void setUp() {
        repository = mock(FigureCategoryRepository.class);
        service = new FigureCategoryService(repository);
    }

    @Test
    void editCategory_Success() {
        FigureCategory category = new FigureCategory(new CategoryName("original"), new Description("old desc"));

        when(repository.findByName_ValueIgnoreCase("original")).thenReturn(Optional.of(category));
        when(repository.findByName_ValueIgnoreCase("new")).thenReturn(Optional.empty());
        when(repository.findByDescription_TextIgnoreCase("new desc")).thenReturn(Optional.empty());

        service.editFigureCategory("original", "new", "new desc");

        assertEquals("new", category.name().value());
        assertEquals("new desc", category.description().value());
        verify(repository).save(category);
    }

    @Test
    void editCategory_NotFound() {
        when(repository.findByName_ValueIgnoreCase("missing")).thenReturn(Optional.empty());

        var ex = assertThrows(IllegalArgumentException.class, () ->
                service.editFigureCategory("missing", "new", "desc")
        );
        assertEquals("Category not found: missing", ex.getMessage());
    }

    @Test
    void editCategory_DuplicateNewName() {
        FigureCategory current = new FigureCategory(new CategoryName("current"), new Description("old"));
        FigureCategory duplicate = new FigureCategory(new CategoryName("new"), new Description("other"));

        when(repository.findByName_ValueIgnoreCase("current")).thenReturn(Optional.of(current));
        when(repository.findByName_ValueIgnoreCase("new")).thenReturn(Optional.of(duplicate));

        var ex = assertThrows(IllegalArgumentException.class, () ->
                service.editFigureCategory("current", "new", "updated desc")
        );
        assertEquals("Another category with the new name already exists.", ex.getMessage());
    }

    @Test
    void editCategory_DescriptionAlreadyExists() {
        FigureCategory current = new FigureCategory(new CategoryName("X"), new Description("desc1"));
        FigureCategory conflicting = new FigureCategory(new CategoryName("Other"), new Description("desc2"));

        when(repository.findByName_ValueIgnoreCase("X")).thenReturn(Optional.of(current));
        when(repository.findByName_ValueIgnoreCase("New")).thenReturn(Optional.empty());
        when(repository.findByDescription_TextIgnoreCase("desc2")).thenReturn(Optional.of(conflicting));

        var ex = assertThrows(IllegalArgumentException.class, () ->
                service.editFigureCategory("X", "New", "desc2")
        );
        assertEquals("Another category with the same description already exists.", ex.getMessage());
    }

    @Test
    void editCategory_BlankInputs() {
        assertThrows(IllegalArgumentException.class, () ->
                service.editFigureCategory(" ", "   ", " ")
        );
    }
}
