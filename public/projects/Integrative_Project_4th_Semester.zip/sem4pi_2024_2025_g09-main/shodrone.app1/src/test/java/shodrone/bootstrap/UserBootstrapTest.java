package shodrone.bootstrap;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.util.ReflectionTestUtils;
import shodrone.customermanagement.Name;
import shodrone.customermanagement.PhoneNumber;
import shodrone.repositories.RoleRepository;
import shodrone.repositories.UserRepository;
import shodrone.usermanagement.Role;
import shodrone.usermanagement.RoleName;
import shodrone.usermanagement.User;

import java.util.Optional;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

class UserBootstrapTest {

    private UserRepository userRepository;
    private RoleRepository roleRepository;
    private PasswordEncoder passwordEncoder;
    private UserBootstrap bootstrap;

    @BeforeEach
    void setUp() {
        userRepository = mock(UserRepository.class);
        roleRepository = mock(RoleRepository.class);
        passwordEncoder = mock(PasswordEncoder.class);
        bootstrap = new UserBootstrap(userRepository, passwordEncoder, roleRepository);

        for (RoleName roleName : RoleName.values()) {
            Role mockRole = new Role();
            mockRole.setRoleName(roleName);
            when(roleRepository.findByRoleName(roleName)).thenReturn(Optional.of(mockRole));
        }

        when(passwordEncoder.encode(anyString())).thenAnswer(inv -> "encoded_" + inv.getArgument(0));
    }

    @Test
    void testCreateAdminIfNotExistCreatesAdmin() {
        String email = "admin@showdrone.com";
        String password = "adminpwd";
        Role adminRole = new Role();
        adminRole.setRoleName(RoleName.ADMIN);

        when(userRepository.findByEmail(email)).thenReturn(Optional.empty());
        when(roleRepository.findByRoleName(RoleName.ADMIN)).thenReturn(Optional.of(adminRole));
        when(passwordEncoder.encode(password)).thenReturn("encoded");

        setPrivateField(bootstrap, "adminEmail", email);
        setPrivateField(bootstrap, "adminPassword", password);
        setPrivateField(bootstrap, "adminUsername", "admin");

        assertDoesNotThrow(() -> bootstrap.run());

        verify(userRepository, atLeastOnce()).save(any(User.class));
    }

    @Test
    void testCreateAdminIfAlreadyExistsSkipsCreation() {
        when(userRepository.findByEmail("admin@showdrone.com"))
                .thenReturn(Optional.of(mock(User.class)));

        ReflectionTestUtils.setField(bootstrap, "adminEmail", "admin@showdrone.com");
        ReflectionTestUtils.setField(bootstrap, "adminUsername", "admin");
        ReflectionTestUtils.setField(bootstrap, "adminPassword", "admin");

        when(roleRepository.findByRoleName(any())).thenReturn(Optional.of(mock(Role.class)));

        assertDoesNotThrow(() -> bootstrap.run());

        verify(userRepository, never()).save(argThat(user ->
                "admin@showdrone.com".equals(user.email())
        ));
    }

    @Test
    void testRunDoesNotThrowAndCreatesAllRoles() {
        for (RoleName roleName : RoleName.values()) {
            when(roleRepository.findByRoleName(roleName)).thenReturn(Optional.of(new Role()));
        }

        setPrivateField(bootstrap, "adminEmail", "admin@showdrone.com");
        setPrivateField(bootstrap, "adminPassword", "admin");
        setPrivateField(bootstrap, "adminUsername", "admin");

        when(userRepository.findByEmail(anyString())).thenReturn(Optional.empty());
        when(roleRepository.findByRoleName(any())).thenReturn(Optional.of(new Role()));
        when(passwordEncoder.encode(anyString())).thenReturn("encoded");

        assertDoesNotThrow(() -> bootstrap.run());
    }

    @Test
    void testCreateUserIfNotExistSkipsNonBackofficeRole() {
        setPrivateField(bootstrap, "adminEmail", "admin@showdrone.com");
        setPrivateField(bootstrap, "adminPassword", "admin");
        setPrivateField(bootstrap, "adminUsername", "admin");

        // Adiciona argumentos fictícios para nome e telefone
        assertDoesNotThrow(() ->
                bootstrap.createUserIfNotExist("someone@x.com", "pwd", RoleName.CUSTOMER, "Fake Name", "911111111")
        );

        verify(userRepository, never()).save(any());
    }

    @Test
    void testCreateUserFailsWhenRoleMissing() {
        setPrivateField(bootstrap, "adminEmail", "admin@showdrone.com");
        setPrivateField(bootstrap, "adminPassword", "admin");
        setPrivateField(bootstrap, "adminUsername", "admin");

        when(roleRepository.findByRoleName(RoleName.DRONE_TECH)).thenReturn(Optional.empty());

        assertThrows(IllegalStateException.class, () ->
                bootstrap.createUserIfNotExist("tech@showdrone.com", "pwd", RoleName.DRONE_TECH, "Tech Name", "922222222")
        );
    }

    @Test
    void testCreateUserIfUserAlreadyExists() {
        Role mockRole = mock(Role.class);
        when(mockRole.getRoleName()).thenReturn(RoleName.CRM_MANAGER);

        // Cria um User válido com nome e telefone
        User existingUser = new User("crm_manager@showdrone.com", "pwd", mockRole, true, new Name("CRM Manager"), new PhoneNumber("933333333"));

        when(userRepository.findByEmail("crm_manager@showdrone.com"))
                .thenReturn(Optional.of(existingUser));

        setPrivateField(bootstrap, "adminEmail", "admin@showdrone.com");
        setPrivateField(bootstrap, "adminPassword", "admin");
        setPrivateField(bootstrap, "adminUsername", "admin");

        assertDoesNotThrow(() -> bootstrap.run());
    }

    @Test
    void testCreateRolesIfNotExistCreatesNewRole() {
        RoleName testRole = RoleName.CRM_MANAGER;
        when(roleRepository.findByRoleName(testRole)).thenReturn(Optional.empty());
        when(roleRepository.findByRoleName(any())).thenAnswer(inv -> Optional.of(new Role()));

        setPrivateField(bootstrap, "adminEmail", "admin@showdrone.com");
        setPrivateField(bootstrap, "adminPassword", "admin");
        setPrivateField(bootstrap, "adminUsername", "admin");

        assertDoesNotThrow(() -> bootstrap.run());
    }

    @Test
    void testCreateUserFailsWithInvalidEmailDomain() {
        setPrivateField(bootstrap, "adminEmail", "admin@shodrone.com");
        setPrivateField(bootstrap, "adminPassword", "admin");
        setPrivateField(bootstrap, "adminUsername", "admin");

        // Só roles backoffice aceitam apenas @showdrone.com
        assertThrows(IllegalArgumentException.class, () ->
                bootstrap.createUserIfNotExist("user@gmail.com", "pwd", RoleName.CRM_MANAGER, "Nome", "911111111")
        );
    }

    @Test
    void testCreateUserFailsWithNullNameOrPhone() {
        setPrivateField(bootstrap, "adminEmail", "admin@shodrone.com");
        setPrivateField(bootstrap, "adminPassword", "admin");
        setPrivateField(bootstrap, "adminUsername", "admin");

        // Nome nulo
        assertThrows(IllegalArgumentException.class, () ->
                new User("crm_manager@showdrone.com", "pwd", new Role(), true, null, new PhoneNumber("911111111"))
        );

        // Telefone nulo
        assertThrows(IllegalArgumentException.class, () ->
                new User("crm_manager@showdrone.com", "pwd", new Role(), true, new Name("Nome"), null)
        );
    }

    @Test
    void testCreateUserWithCustomerRoleAcceptsAnyEmailDomain() {
        setPrivateField(bootstrap, "adminEmail", "admin@shodrone.com");
        setPrivateField(bootstrap, "adminPassword", "admin");
        setPrivateField(bootstrap, "adminUsername", "admin");

        // CUSTOMER pode ter qualquer domínio
        assertDoesNotThrow(() ->
                bootstrap.createUserIfNotExist("user@gmail.com", "pwd", RoleName.CUSTOMER, "Nome", "911111111")
        );
    }

    /**
     * Helper para definir campos privados simulando o comportamento do Spring @Value.
     */
    private void setPrivateField(Object target, String fieldName, Object value) {
        try {
            var field = target.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(target, value);
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException("Falha ao injetar campo: " + fieldName, e);
        }
    }
}