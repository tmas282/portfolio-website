package shodrone.domain;

import org.junit.jupiter.api.Test;
import shodrone.dronemaintenancemanagement.MaintenanceType;
import shodrone.dronemaintenancemanagement.MaintenanceTypeDescription;
import shodrone.dronemaintenancemanagement.MaintenanceTypeStatus;

import static org.junit.jupiter.api.Assertions.*;

class MaintenanceTypeTest {

    @Test
    void testConstructor_ValidDescription() {
        MaintenanceTypeDescription description = new MaintenanceTypeDescription("Fix helix");
        MaintenanceType maintenanceType = new MaintenanceType(description);

        assertEquals(description, maintenanceType.getDescription(), "Description should match the input");
        assertEquals(MaintenanceTypeStatus.EDITABLE, maintenanceType.getStatus(), "Status should be EDITABLE by default");
    }

    @Test
    void testConstructor_NullDescription() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new MaintenanceType(null);
        });

        assertEquals("Description must not be null.", exception.getMessage(), "Exception message should match");
    }

    @Test
    void testGetters() {
        MaintenanceTypeDescription description = new MaintenanceTypeDescription("Fix helix");
        MaintenanceType maintenanceType = new MaintenanceType(description);

        assertEquals(description, maintenanceType.getDescription(), "Description should match the input");
        assertEquals(MaintenanceTypeStatus.EDITABLE, maintenanceType.getStatus(), "Status should be EDITABLE by default");
    }
}