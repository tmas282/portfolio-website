package shodrone.services;

import shodrone.figurecategorymanagement.CategoryName;
import shodrone.figurecategorymanagement.Description;
import shodrone.figurecategorymanagement.FigureCategory;
import shodrone.repositories.FigureCategoryRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ListFigureCategoriesServiceTest {

    private FigureCategoryService service;
    private FigureCategoryRepository repository;

    @BeforeEach
    void setUp() {
        repository = mock(FigureCategoryRepository.class);
        service = new FigureCategoryService(repository);
    }

    @Test
    void listCategories_NotNull() {
        when(repository.findAllByOrderByName_ValueAsc()).thenReturn(Collections.emptyList());

        var result = service.listAllCategories();
        assertNotNull(result);
    }

    @Test
    void listCategories_ReturnsCorrectIterable() {
        var cat1 = new FigureCategory(new CategoryName("a"), new Description("..."));
        var cat2 = new FigureCategory(new CategoryName("b"), new Description("..."));

        when(repository.findAllByOrderByName_ValueAsc()).thenReturn(List.of(cat1, cat2));

        Iterable<FigureCategory> result = service.listAllCategories();
        assertTrue(result.iterator().hasNext());
    }
}
