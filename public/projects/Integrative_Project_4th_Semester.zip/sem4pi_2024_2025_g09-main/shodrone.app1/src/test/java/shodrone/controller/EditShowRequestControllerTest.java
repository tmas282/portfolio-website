package shodrone.controller;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.mockito.Mockito;
import shodrone.customermanagement.*;
import shodrone.customerrepresentativemanagement.CustomerRepresentative;
import shodrone.customerrepresentativemanagement.Position;
import shodrone.services.CustomerService;
import shodrone.services.ShowRequestService;
import shodrone.showrequestmanagement.*;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class EditShowRequestControllerTest {
    private static CustomerService customerService;
    private static ShowRequestService showRequestService;
    private static EditShowRequestController c;
    @BeforeAll
    static void setup(){
        customerService = Mockito.mock(CustomerService.class);
        showRequestService = Mockito.mock(ShowRequestService.class);
        c = new EditShowRequestController(customerService, showRequestService);
    }
    @Test
    void editShowRequestNotAvailable() {
        Executable func = () -> c.editShowRequest("PT123456789", 1, "2000-01-01 10:10:10", 60, "espinho", 1, "blabla");
        assertThrows(AssertionError.class, func);
    }
}