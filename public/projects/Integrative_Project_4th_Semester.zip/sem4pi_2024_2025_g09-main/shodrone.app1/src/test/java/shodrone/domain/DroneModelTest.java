package shodrone.domain;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import shodrone.dronemodelmanagement.DroneModel;
import shodrone.dronemodelmanagement.ModelID;
import shodrone.dronemodelmanagement.ProgrammingLanguage;
import shodrone.dronemodelmanagement.WindTolerance;
import shodrone.dronemodelmanagement.MaintenanceThreshold;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import static org.junit.jupiter.api.Assertions.*;

class DroneModelTest {

    private ModelID mockModelID;
    private ProgrammingLanguage mockLanguage;
    private WindTolerance mockWindTolerance;
    private MaintenanceThreshold mockMaintenanceThreshold;

    @BeforeEach
    void setUp() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        mockModelID = new ModelID("DM001");
        mockLanguage = new ProgrammingLanguage("Java");

        Constructor<WindTolerance> windToleranceConstructor = WindTolerance.class.getDeclaredConstructor();
        windToleranceConstructor.setAccessible(true);
        mockWindTolerance = windToleranceConstructor.newInstance();

        Constructor<MaintenanceThreshold> maintenanceThresholdConstructor = MaintenanceThreshold.class.getDeclaredConstructor();
        maintenanceThresholdConstructor.setAccessible(true);
        mockMaintenanceThreshold = maintenanceThresholdConstructor.newInstance();
    }

    @Test
    void testDroneModelCreation() {
        DroneModel droneModel = new DroneModel(mockModelID, mockLanguage, mockWindTolerance, mockMaintenanceThreshold);

        assertNotNull(droneModel);
        assertEquals(mockModelID, droneModel.getModelID());
        assertEquals(mockLanguage, droneModel.getProgrammingLanguage());
        assertEquals(mockWindTolerance, droneModel.getWindTolerance());
    }

    @Test
    void testEquals() {
        DroneModel droneModel1 = new DroneModel(mockModelID, mockLanguage, mockWindTolerance, mockMaintenanceThreshold);
        DroneModel droneModel2 = new DroneModel(mockModelID, mockLanguage, mockWindTolerance, mockMaintenanceThreshold);

        assertEquals(droneModel1, droneModel2);
    }

    @Test
    void testHashCode() {
        DroneModel droneModel1 = new DroneModel(mockModelID, mockLanguage, mockWindTolerance, mockMaintenanceThreshold);
        DroneModel droneModel2 = new DroneModel(mockModelID, mockLanguage, mockWindTolerance, mockMaintenanceThreshold);

        assertEquals(droneModel1.hashCode(), droneModel2.hashCode());
    }
}