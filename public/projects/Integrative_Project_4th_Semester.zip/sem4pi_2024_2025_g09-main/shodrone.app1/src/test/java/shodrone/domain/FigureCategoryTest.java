package shodrone.domain;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import shodrone.figurecategorymanagement.CategoryName;
import shodrone.figurecategorymanagement.CategoryStatus;
import shodrone.figurecategorymanagement.Description;
import shodrone.figurecategorymanagement.FigureCategory;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class FigureCategoryTest {

    @Test
    void shouldCreateValidFigureCategory() {
        CategoryName name = new CategoryName("Acrobatics");
        Description description = new Description("Figures that involve aerial maneuvers");

        FigureCategory category = new FigureCategory(name, description);

        assertEquals(name, category.name());
        assertEquals(description, category.description());
        Assertions.assertEquals(CategoryStatus.active(), category.status());
        assertNotNull(category.creationDate());
    }

    @Test
    void shouldNotAllowNullNameOrDescriptionInConstructor() {
        Description description = new Description("Figures with balance");
        CategoryName name = new CategoryName("Balance");

        assertThrows(IllegalArgumentException.class, () -> new FigureCategory(null, description));
        assertThrows(IllegalArgumentException.class, () -> new FigureCategory(name, null));
    }

    @Test
    void renameTo_shouldUpdateCategoryName() {
        FigureCategory category = new FigureCategory(
                new CategoryName("Old Name"),
                new Description("Some description"));

        CategoryName newName = new CategoryName("New Name");
        category.renameTo(newName);

        assertEquals(newName, category.name());
    }

    @Test
    void changeDescription_shouldUpdateDescription() {
        FigureCategory category = new FigureCategory(
                new CategoryName("Balance"),
                new Description("Initial description"));

        Description newDescription = new Description("Updated description");
        category.changeDescription(newDescription);

        assertEquals(newDescription, category.description());
    }

    @Test
    void deactivate_shouldSetStatusToInactive() {
        FigureCategory category = new FigureCategory(
                new CategoryName("Acrobatics"),
                new Description("Aerial maneuvers"));

        category.deactivate();
        assertEquals(CategoryStatus.inactive(), category.status());
    }

    @Test
    void activate_shouldSetStatusToActive() {
        FigureCategory category = new FigureCategory(
                new CategoryName("Acrobatics"),
                new Description("Aerial maneuvers"));

        category.deactivate();
        assertEquals(CategoryStatus.inactive(), category.status());

        category.activate();
        assertEquals(CategoryStatus.active(), category.status());
    }

    @Test
    void creationDate_shouldBeToday() {
        FigureCategory category = new FigureCategory(
                new CategoryName("Balance"),
                new Description("Stable positions"));

        assertEquals(LocalDate.now(), category.creationDate().value());
    }

    @Test
    void testEqualsAndHashCode_shouldUseId() {
        FigureCategory cat1 = new FigureCategory(
                new CategoryName("Acrobatics"),
                new Description("Aerial maneuvers"));
        FigureCategory cat2 = new FigureCategory(
                new CategoryName("Balance"),
                new Description("Stable positions"));


        assertEquals(cat1, cat1);
        assertNotEquals(cat1, cat2);

        var field = assertDoesNotThrow(() -> FigureCategory.class.getDeclaredField("id"));
        field.setAccessible(true);
        assertDoesNotThrow(() -> field.set(cat2, 1L));
        assertDoesNotThrow(() -> field.set(cat1, 1L));

        assertEquals(cat1, cat2);
        assertEquals(cat1.hashCode(), cat2.hashCode());
    }

    @Test
    void testNotEqualsIfDifferentTypeOrNull() {
        FigureCategory category = new FigureCategory(
                new CategoryName("Balance"),
                new Description("Stable positions"));

        assertNotEquals(category, null);
        assertNotEquals(category, "Some string");
    }
}
