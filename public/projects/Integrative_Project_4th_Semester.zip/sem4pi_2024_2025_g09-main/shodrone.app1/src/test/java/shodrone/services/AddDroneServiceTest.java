package shodrone.services;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import shodrone.dronemanagement.*;
import shodrone.dronemodelmanagement.DroneModel;
import shodrone.dronemodelmanagement.ModelID;
import shodrone.repositories.DroneModelRepository;
import shodrone.repositories.DroneRepository;

import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class AddDroneServiceTest {

    private DroneRepository droneRepo;
    private DroneModelRepository modelRepo;
    private DroneService service;

    @BeforeEach
    void setup() {
        droneRepo = mock(DroneRepository.class);
        modelRepo = mock(DroneModelRepository.class);
        service = new DroneService(droneRepo, modelRepo);
    }

    @Test
    void verifyAddDroneSuccess() {
        String serial = "D001";
        String modelId = "DM001";
        String routine = "Circle";

        ModelID modelID = new ModelID(modelId);
        DroneModel droneModel = mock(DroneModel.class);

        when(droneRepo.existsBySerialNumber(any())).thenReturn(false);
        when(modelRepo.findById(modelID)).thenReturn(Optional.of(droneModel));
        when(droneRepo.save(any())).thenAnswer(i -> i.getArgument(0));

        Drone result = service.addDrone(serial, modelId, routine);

        assertNotNull(result);
        verify(droneRepo).save(any(Drone.class));
    }

    @Test
    void verifyDroneAlreadyExistsThrows() {
        when(droneRepo.existsBySerialNumber(any())).thenReturn(true);

        IllegalStateException ex = assertThrows(IllegalStateException.class,
                () -> service.addDrone("D001", "DM001", "Circle"));
        assertEquals("Drone with this serial number already exists.", ex.getMessage());
    }

    @Test
    void verifyDroneModelExists() {
        when(droneRepo.existsBySerialNumber(any())).thenReturn(false);
        when(modelRepo.findById(any())).thenReturn(Optional.empty());

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> service.addDrone("D001", "DM001", "Circle"));
        assertTrue(ex.getMessage().contains("No such drone model"));
    }
}
