package shodrone.services;

import shodrone.figuremanagement.*;
import shodrone.figurecategorymanagement.CategoryName;
import shodrone.figurecategorymanagement.FigureCategory;
import shodrone.figurecategorymanagement.Description;
import shodrone.repositories.CustomerRepository;
import shodrone.repositories.FigureCategoryRepository;
import shodrone.repositories.FigureRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AddFigureServiceTest {

    private FigureService service;
    private FigureRepository figureRepository;
    private FigureCategoryRepository figureCategoryRepository;
    private CustomerRepository customerRepository;

    @BeforeEach
    void setUp() {
        figureRepository = mock(FigureRepository.class);
        figureCategoryRepository = mock(FigureCategoryRepository.class);
        customerRepository = mock(CustomerRepository.class);
        service = new FigureService(figureRepository, figureCategoryRepository, customerRepository);
    }

    @Test
    void addFigure_Success() {
        // Arrange
        long codeId = 12345L;
        Code code = new Code(codeId);
        String categoryName = "TestCategory";
        List<Keyword> keywords = new ArrayList<>();
        keywords.add(new Keyword("test"));
        keywords.add(new Keyword("figure"));

        CategoryName catName = new CategoryName(categoryName);
        Description description = new Description("Test Category Description");
        FigureCategory category = new FigureCategory(catName, description);

        when(figureRepository.findByCode(code)).thenReturn(Optional.empty());
        when(figureCategoryRepository.findByName_ValueIgnoreCase(categoryName)).thenReturn(Optional.of(category));

        // Act
        int result = service.addFigure(codeId, keywords, categoryName);

        // Assert
        assertEquals(0, result); // 0 means success
        verify(figureRepository).save(any(Figure.class));
    }

    @Test
    void addFigure_CodeAlreadyExists() {
        // Arrange
        long codeId = 12345L;
        Code code = new Code(codeId);
        String categoryName = "TestCategory";
        List<Keyword> keywords = new ArrayList<>();
        keywords.add(new Keyword("test"));

        // Create a real category for the existing figure
        CategoryName catName = new CategoryName(categoryName);
        Description description = new Description("Test Category Description");
        FigureCategory category = new FigureCategory(catName, description);

        // Create a real existing figure
        List<Keyword> existingKeywords = new ArrayList<>();
        existingKeywords.add(new Keyword("existing"));
        Figure existingFigure = new Figure(code, existingKeywords, category);

        when(figureRepository.findByCode(code)).thenReturn(Optional.of(existingFigure));

        // Act
        int result = service.addFigure(codeId, keywords, categoryName);

        // Assert
        assertEquals(1, result); // 1 means code already exists
        verify(figureRepository, never()).save(any(Figure.class));
    }

    @Test
    void addFigure_CategoryDoesNotExist() {
        // Arrange
        long codeId = 12345L;
        Code code = new Code(codeId);
        String categoryName = "NonExistentCategory";
        List<Keyword> keywords = new ArrayList<>();
        keywords.add(new Keyword("test"));

        when(figureRepository.findByCode(code)).thenReturn(Optional.empty());
        when(figureCategoryRepository.findByName_ValueIgnoreCase(categoryName)).thenReturn(Optional.empty());

        // Act
        int result = service.addFigure(codeId, keywords, categoryName);

        // Assert
        assertEquals(2, result); // 2 means category doesn't exist
        verify(figureRepository, never()).save(any(Figure.class));
    }

    @Test
    void addFigure_InvalidCategoryName() {
        // Arrange
        long codeId = 12345L;
        String invalidCategoryName = null; // This will cause CategoryName constructor to throw exception
        List<Keyword> keywords = new ArrayList<>();
        keywords.add(new Keyword("test"));

        // Act
        int result = service.addFigure(codeId, keywords, invalidCategoryName);

        // Assert
        assertEquals(2, result); // 2 means invalid category
        verify(figureRepository, never()).save(any(Figure.class));
    }
}
