package shodrone.bootstrap;

        import org.junit.jupiter.api.BeforeEach;
        import org.junit.jupiter.api.Test;
        import shodrone.services.CustomerService;

        import static org.mockito.Mockito.*;

        class CustomerBootstrapTest {

            private CustomerService customerService;
            private CustomerBootstrap customerBootstrap;

            @BeforeEach
            void setUp() {
                customerService = mock(CustomerService.class);
                customerBootstrap = new CustomerBootstrap(customerService);
            }

            @Test
            void testBootstrapRegistersCustomers() {
                customerBootstrap.run();

                verify(customerService, times(1)).registerCustomerAndRepresentative(
                        "PT123456789", "CustomerName", "customer@example.com",
                        "Main Street 1", "912345678",
                        "Alice Customer", "representative1@example.com", "Manager", "936584758",
                        "VIP"
                );

                verify(customerService, times(1)).registerCustomerAndRepresentative(
                        "PT987654321", "Another Customer", "another@example.com",
                        "Avenida Central", "923456789",
                        "Bob Client", "representative2@example.com", "CTO", "926584759",
                        "REGULAR"
                );
            }
        }