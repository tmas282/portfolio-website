package shodrone.services;

import shodrone.figurecategorymanagement.FigureCategory;
import shodrone.repositories.FigureCategoryRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AddFigureCategoryServiceTest {

    private FigureCategoryService service;
    private FigureCategoryRepository repository;

    @BeforeEach
    void setUp() {
        repository = mock(FigureCategoryRepository.class);
        service = new FigureCategoryService(repository);
    }

    @Test
    void addCategory_Success() {
        when(repository.findByName_ValueIgnoreCase("design")).thenReturn(Optional.empty());

        service.addFigureCategory("design", "Base category for shapes");

        verify(repository).save(any(FigureCategory.class));
    }

    @Test
    void addCategory_AlreadyExists() {
        when(repository.findByName_ValueIgnoreCase("duplicate")).thenReturn(Optional.of(mock(FigureCategory.class)));

        var ex = assertThrows(IllegalArgumentException.class, () ->
                service.addFigureCategory("duplicate", "ignored")
        );
        assertEquals("A category with this name already exists.", ex.getMessage());
    }

    @Test
    void addCategory_BlankName() {
        var ex = assertThrows(IllegalArgumentException.class, () ->
                service.addFigureCategory("  ", "Valid")
        );
        assertTrue(ex.getMessage().toLowerCase().contains("name"));
    }

    @Test
    void addCategory_NullDescription() {
        var ex = assertThrows(IllegalArgumentException.class, () ->
                service.addFigureCategory("unique", null)
        );
        assertTrue(ex.getMessage().toLowerCase().contains("description"));
    }

    @Test
    void addCategory_DuplicateDescription() {
        when(repository.findByName_ValueIgnoreCase("new")).thenReturn(Optional.empty());
        when(repository.findByDescription_TextIgnoreCase("same desc"))
                .thenReturn(Optional.of(mock(FigureCategory.class)));

        var ex = assertThrows(IllegalArgumentException.class, () ->
                service.addFigureCategory("new", "same desc")
        );
        assertEquals("A category with this description already exists.", ex.getMessage());
    }

}
