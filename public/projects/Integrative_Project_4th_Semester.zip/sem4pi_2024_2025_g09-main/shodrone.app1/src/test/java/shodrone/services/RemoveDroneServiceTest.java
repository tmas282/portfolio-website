package shodrone.services;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import shodrone.dronemanagement.*;
import shodrone.repositories.DroneModelRepository;
import shodrone.repositories.DroneRepository;

import java.time.LocalDate;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RemoveDroneServiceTest {

    private DroneRepository droneRepo;
    private DroneModelRepository modelRepo;
    private DroneService service;

    @BeforeEach
    void setup() {
        droneRepo = mock(DroneRepository.class);
        modelRepo = mock(DroneModelRepository.class);
        service = new DroneService(droneRepo, modelRepo);
    }

    @Test
    void verifyRemoveDroneSuccess() {
        String serial = "SN001";
        String reason = "Broken";
        LocalDate date = LocalDate.now();
        DroneStatus newStatus = DroneStatus.INACTIVE;

        Drone drone = mock(Drone.class);

        when(droneRepo.findById(any())).thenReturn(Optional.of(drone));
        when(droneRepo.save(any())).thenReturn(drone);

        service.removeDrone(serial, reason, date, newStatus);

        verify(drone).markAsRemoved(any(), any(), eq(newStatus));
        verify(droneRepo).save(drone);
    }

    @Test
    void verifyDroneNotFoundThrows() {
        when(droneRepo.findById(any())).thenReturn(Optional.empty());

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> service.removeDrone("SN001", "Broken", LocalDate.now(), DroneStatus.INACTIVE));
        assertTrue(ex.getMessage().contains("not found"));
    }
}
