package shodrone.controller;

            import org.junit.jupiter.api.*;
            import org.mockito.ArgumentCaptor;
            import org.springframework.security.crypto.password.PasswordEncoder;
            import shodrone.customermanagement.Name;
            import shodrone.customermanagement.PhoneNumber;
            import shodrone.services.UserService;
            import shodrone.repositories.RoleRepository;
            import shodrone.repositories.UserRepository;
            import shodrone.usermanagement.Role;
            import shodrone.usermanagement.RoleName;
            import shodrone.usermanagement.User;

            import java.util.Optional;

            import static org.junit.jupiter.api.Assertions.*;
            import static org.mockito.Mockito.*;

            class RegisterUserTest {

                private UserRepository userRepository;
                private RoleRepository roleRepository;
                private PasswordEncoder passwordEncoder;
                private UserService registerUserService;

                @BeforeEach
                void setUp() {
                    userRepository = mock(UserRepository.class);
                    roleRepository = mock(RoleRepository.class);
                    passwordEncoder = mock(PasswordEncoder.class);
                    registerUserService = new UserService(userRepository, roleRepository, passwordEncoder);
                }

                @Test
                void testRegisterUserWithValidData() {
                    String email = "newuser@showdrone.com";
                    String password = "secure123";
                    RoleName roleName = RoleName.CRM_MANAGER;
                    Role role = new Role();
                    role.setRoleName(roleName);
                    Name name = new Name("Nome Teste");
                    PhoneNumber phone = new PhoneNumber("911111111");

                    when(userRepository.findByEmail(email)).thenReturn(Optional.empty());
                    when(roleRepository.findByRoleName(roleName)).thenReturn(Optional.of(role));
                    when(passwordEncoder.encode(password)).thenReturn("encoded");

                    registerUserService.registerUser(email, password, roleName, name, phone);

                    ArgumentCaptor<User> userCaptor = ArgumentCaptor.forClass(User.class);
                    verify(userRepository).save(userCaptor.capture());
                    assertEquals(email, userCaptor.getValue().email());
                    assertEquals(role, userCaptor.getValue().role());
                    assertEquals("Nome Teste", userCaptor.getValue().getName().value());
                    assertEquals("911111111", userCaptor.getValue().getPhone().value());
                }

                @Test
                void testRegisterUserWithDuplicateEmail() {
                    String email = "duplicate@showdrone.com";
                    Name name = new Name("Nome");
                    PhoneNumber phone = new PhoneNumber("911111111");
                    when(userRepository.findByEmail(email)).thenReturn(Optional.of(mock(User.class)));

                    assertThrows(IllegalStateException.class, () ->
                            registerUserService.registerUser(email, "pwd", RoleName.ADMIN, name, phone)
                    );
                    verify(userRepository, never()).save(any());
                }

                @Test
                void testRegisterUserWithInvalidRole() {
                    String email = "user@showdrone.com";
                    Name name = new Name("Nome");
                    PhoneNumber phone = new PhoneNumber("911111111");
                    when(userRepository.findByEmail(email)).thenReturn(Optional.empty());
                    when(roleRepository.findByRoleName(RoleName.SHOW_DESIGNER)).thenReturn(Optional.empty());

                    assertThrows(IllegalStateException.class, () ->
                            registerUserService.registerUser(email, "pwd", RoleName.SHOW_DESIGNER, name, phone)
                    );
                    verify(userRepository, never()).save(any());
                }

                @Test
                void testRegisterUserWithNullEmail() {
                    Name name = new Name("Nome");
                    PhoneNumber phone = new PhoneNumber("911111111");
                    when(roleRepository.findByRoleName(RoleName.ADMIN)).thenReturn(Optional.of(new Role()));

                    assertThrows(IllegalArgumentException.class, () ->
                            registerUserService.registerUser(null, "pwd", RoleName.ADMIN, name, phone)
                    );
                }

                @Test
                void testRegisterUserWithEmptyEmail() {
                    Name name = new Name("Nome");
                    PhoneNumber phone = new PhoneNumber("911111111");
                    when(roleRepository.findByRoleName(RoleName.ADMIN)).thenReturn(Optional.of(new Role()));

                    assertThrows(IllegalArgumentException.class, () ->
                            registerUserService.registerUser("", "pwd", RoleName.ADMIN, name, phone)
                    );
                }

                @Test
                void testRegisterUserWithEmptyPassword() {
                    Name name = new Name("Nome");
                    PhoneNumber phone = new PhoneNumber("911111111");
                    when(roleRepository.findByRoleName(RoleName.ADMIN)).thenReturn(Optional.of(new Role()));

                    assertThrows(IllegalArgumentException.class, () ->
                            registerUserService.registerUser("user@showdrone.com", "", RoleName.ADMIN, name, phone)
                    );
                }

                @Test
                void testPasswordIsEncodedBeforeSaving() {
                    String email = "secure@showdrone.com";
                    String password = "plain";
                    String encoded = "encoded";
                    Role role = new Role();
                    role.setRoleName(RoleName.ADMIN);
                    Name name = new Name("Nome");
                    PhoneNumber phone = new PhoneNumber("911111111");

                    when(userRepository.findByEmail(email)).thenReturn(Optional.empty());
                    when(roleRepository.findByRoleName(RoleName.ADMIN)).thenReturn(Optional.of(role));
                    when(passwordEncoder.encode(password)).thenReturn(encoded);

                    registerUserService.registerUser(email, password, RoleName.ADMIN, name, phone);

                    verify(passwordEncoder).encode(password);
                    verify(userRepository).save(any());
                }

                @Test
                void testUserIsEnabledByDefault() {
                    String email = "enabled@showdrone.com";
                    String password = "1234";
                    Role role = new Role();
                    role.setRoleName(RoleName.ADMIN);
                    Name name = new Name("Nome");
                    PhoneNumber phone = new PhoneNumber("911111111");

                    when(userRepository.findByEmail(email)).thenReturn(Optional.empty());
                    when(roleRepository.findByRoleName(RoleName.ADMIN)).thenReturn(Optional.of(role));
                    when(passwordEncoder.encode(password)).thenReturn("encoded");

                    registerUserService.registerUser(email, password, RoleName.ADMIN, name, phone);

                    ArgumentCaptor<User> userCaptor = ArgumentCaptor.forClass(User.class);
                    verify(userRepository).save(userCaptor.capture());

                    assertTrue(userCaptor.getValue().isEnabled(), "User should be enabled by default");
                }
            }