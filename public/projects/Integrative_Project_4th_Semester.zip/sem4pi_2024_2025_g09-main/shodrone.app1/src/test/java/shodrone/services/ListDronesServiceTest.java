package shodrone.services;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import shodrone.dronemanagement.DroneStatus;
import shodrone.dronemodelmanagement.ModelID;
import shodrone.repositories.DroneModelRepository;
import shodrone.repositories.DroneRepository;

import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ListDronesServiceTest {

    private DroneRepository droneRepo;
    private DroneModelRepository modelRepo;
    private DroneService service;

    @BeforeEach
    void setup() {
        droneRepo = mock(DroneRepository.class);
        modelRepo = mock(DroneModelRepository.class);
        service = new DroneService(droneRepo, modelRepo);
    }

    @Test
    void verifyListActiveDronesReturnsDrones() {
        String modelId = "DM001";
        ModelID modelID = new ModelID(modelId);
        List drones = Collections.emptyList();

        when(droneRepo.findByModel_ModelIDAndStatus(modelID, DroneStatus.ACTIVE)).thenReturn(drones);

        List result = service.listActiveDronesByModel(modelId);

        assertNotNull(result);
        assertEquals(drones, result);
        verify(droneRepo).findByModel_ModelIDAndStatus(modelID, DroneStatus.ACTIVE);
    }
}
