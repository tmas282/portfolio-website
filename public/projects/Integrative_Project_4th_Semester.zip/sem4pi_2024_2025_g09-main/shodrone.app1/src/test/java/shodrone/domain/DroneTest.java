package shodrone.domain;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import shodrone.dronemanagement.*;
import shodrone.dronemodelmanagement.DroneModel;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DroneTest {

    private DroneModel mockModel;
    private SerialNumber mockSerialNumber;

    @BeforeEach
    void setUp() {
        mockModel = mock(DroneModel.class);
        mockSerialNumber = mock(SerialNumber.class);
    }

    @Test
    void testDroneCreation() {
        SpecificRoutine routine = new SpecificRoutine("Circlw");
        Drone drone = new Drone(mockSerialNumber, mockModel, DroneStatus.ACTIVE, routine);

        assertNotNull(drone);
        assertEquals(mockSerialNumber, drone.serialNumber());
        assertEquals(mockModel, drone.model());
        assertEquals(DroneStatus.ACTIVE, drone.status());
        assertEquals(routine, drone.routine());
    }

    @Test
    void testIsActive() {
        SpecificRoutine routine = new SpecificRoutine("Circle");
        Drone drone = new Drone(mockSerialNumber, mockModel, DroneStatus.ACTIVE, routine);

        assertTrue(drone.isActive());
    }

    @Test
    void testMarkAsRemoved() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        SpecificRoutine routine = new SpecificRoutine("Circle");
        Drone drone = new Drone(mockSerialNumber, mockModel, DroneStatus.ACTIVE, routine);


        Constructor<RemovalDate> constructor = RemovalDate.class.getDeclaredConstructor(LocalDate.class);
        constructor.setAccessible(true);

        RemovalDate removalDate = constructor.newInstance(LocalDate.now());

        drone.markAsRemoved(new RemovalReason("Broken"), removalDate, DroneStatus.INACTIVE);

        assertEquals(DroneStatus.INACTIVE, drone.status());
        assertNotNull(drone.removalReason());
        assertNotNull(drone.removalDate());
    }

    @Test
    void testEquals() {
        SpecificRoutine routine = new SpecificRoutine("Circle");
        Drone drone1 = new Drone(mockSerialNumber, mockModel, DroneStatus.ACTIVE, routine);
        Drone drone2 = new Drone(mockSerialNumber, mockModel, DroneStatus.ACTIVE, routine);

        assertEquals(drone1, drone2);
    }

    @Test
    void testHashCode() {
        SpecificRoutine routine = new SpecificRoutine("Circle");
        Drone drone1 = new Drone(mockSerialNumber, mockModel, DroneStatus.ACTIVE, routine);
        Drone drone2 = new Drone(mockSerialNumber, mockModel, DroneStatus.ACTIVE, routine);

        assertEquals(drone1.hashCode(), drone2.hashCode());
    }
}
