package server;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import shodrone.repositories.UserRepository;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class SecurityTest {
    private static UserRepository userRepository;

    @BeforeAll
    static void setUp() {
        userRepository = mock(UserRepository.class);
    }

    @Test
    void testUserDetailsService() {
        assertThrows(UsernameNotFoundException.class, () ->
                new Security().userDetailsService(userRepository).loadUserByUsername("customer@showdrone.com"));
        assertThrows(UsernameNotFoundException.class, () ->
                new Security().userDetailsService(userRepository).loadUserByUsername("representative@showdrone.com"));
    }
}