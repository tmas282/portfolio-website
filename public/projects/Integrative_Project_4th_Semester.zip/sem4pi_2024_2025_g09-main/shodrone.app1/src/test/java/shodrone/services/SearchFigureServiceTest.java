package shodrone.services;

import shodrone.figuremanagement.*;
import shodrone.figurecategorymanagement.CategoryName;
import shodrone.figurecategorymanagement.FigureCategory;
import shodrone.figurecategorymanagement.Description;
import shodrone.repositories.CustomerRepository;
import shodrone.repositories.FigureCategoryRepository;
import shodrone.repositories.FigureRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SearchFigureServiceTest {

    private FigureService service;
    private FigureRepository figureRepository;
    private FigureCategoryRepository figureCategoryRepository;
    private CustomerRepository customerRepository;

    private Figure figure1; // Category: Design, Keywords: modern, minimalist
    private Figure figure2; // Category: Design, Keywords: classic, elegant
    private Figure figure3; // Category: Architecture, Keywords: modern, urban
    private Figure figure4; // Category: Sculpture, Keywords: abstract, artistic

    @BeforeEach
    void setUp() {
        figureRepository = mock(FigureRepository.class);
        figureCategoryRepository = mock(FigureCategoryRepository.class);
        customerRepository = mock(CustomerRepository.class);
        service = new FigureService(figureRepository, figureCategoryRepository, customerRepository);

        // Create test data
        setupTestFigures();
    }

    private void setupTestFigures() {
        // Create categories
        CategoryName designName = new CategoryName("Design");
        Description designDesc = new Description("Design category description");
        FigureCategory designCategory = new FigureCategory(designName, designDesc);

        CategoryName architectureName = new CategoryName("Architecture");
        Description architectureDesc = new Description("Architecture category description");
        FigureCategory architectureCategory = new FigureCategory(architectureName, architectureDesc);

        CategoryName sculptureName = new CategoryName("Sculpture");
        Description sculptureDesc = new Description("Sculpture category description");
        FigureCategory sculptureCategory = new FigureCategory(sculptureName, sculptureDesc);

        // Create figures with different categories and keywords
        // Figure 1: Design category with "modern" and "minimalist" keywords
        List<Keyword> keywords1 = new ArrayList<>();
        keywords1.add(new Keyword("modern"));
        keywords1.add(new Keyword("minimalist"));
        figure1 = new Figure(new Code(1001), keywords1, designCategory);

        // Figure 2: Design category with "classic" and "elegant" keywords
        List<Keyword> keywords2 = new ArrayList<>();
        keywords2.add(new Keyword("classic"));
        keywords2.add(new Keyword("elegant"));
        figure2 = new Figure(new Code(1002), keywords2, designCategory);

        // Figure 3: Architecture category with "modern" and "urban" keywords
        List<Keyword> keywords3 = new ArrayList<>();
        keywords3.add(new Keyword("modern"));
        keywords3.add(new Keyword("urban"));
        figure3 = new Figure(new Code(1003), keywords3, architectureCategory);

        // Figure 4: Sculpture category with "abstract" and "artistic" keywords
        List<Keyword> keywords4 = new ArrayList<>();
        keywords4.add(new Keyword("abstract"));
        keywords4.add(new Keyword("artistic"));
        figure4 = new Figure(new Code(1004), keywords4, sculptureCategory);
    }

    @Test
    void searchByCategory_FindsFigures() {
        // Arrange
        when(figureRepository.findAll()).thenReturn(Arrays.asList(figure1, figure2, figure3, figure4));

        // Act
        List<Figure> result = service.searchByCategory("Design");

        // Assert
        assertEquals(2, result.size());
        assertTrue(result.contains(figure1));
        assertTrue(result.contains(figure2));
        assertFalse(result.contains(figure3));
        assertFalse(result.contains(figure4));

        // Verify that the repository's findAll method was called
        verify(figureRepository).findAll();
    }

    @Test
    void searchByCategory_CaseInsensitive() {
        // Arrange
        when(figureRepository.findAll()).thenReturn(Arrays.asList(figure1, figure2, figure3, figure4));

        // Act - using lowercase
        List<Figure> result = service.searchByCategory("design");

        // Assert
        assertEquals(2, result.size());
        assertTrue(result.contains(figure1));
        assertTrue(result.contains(figure2));

        // Verify that the repository's findAll method was called
        verify(figureRepository).findAll();
    }

    @Test
    void searchByCategory_NoFiguresFound() {
        // Arrange
        when(figureRepository.findAll()).thenReturn(Arrays.asList(figure1, figure2, figure3, figure4));

        // Act
        List<Figure> result = service.searchByCategory("NonExistentCategory");

        // Assert
        assertTrue(result.isEmpty());

        // Verify that the repository's findAll method was called
        verify(figureRepository).findAll();
    }

    @Test
    void searchByKeyword_FindsFigures() {
        // Arrange
        when(figureRepository.findAll()).thenReturn(Arrays.asList(figure1, figure2, figure3, figure4));

        // Act
        List<Figure> result = service.searchByKeyword("modern");

        // Assert
        assertEquals(2, result.size());
        assertTrue(result.contains(figure1));
        assertTrue(result.contains(figure3));
        assertFalse(result.contains(figure2));
        assertFalse(result.contains(figure4));

        // Verify that the repository's findAll method was called
        verify(figureRepository).findAll();
    }

    @Test
    void searchByKeyword_CaseInsensitive() {
        // Arrange
        when(figureRepository.findAll()).thenReturn(Arrays.asList(figure1, figure2, figure3, figure4));

        // Act - using uppercase
        List<Figure> result = service.searchByKeyword("MODERN");

        // Assert
        assertEquals(2, result.size());
        assertTrue(result.contains(figure1));
        assertTrue(result.contains(figure3));

        // Verify that the repository's findAll method was called
        verify(figureRepository).findAll();
    }

    @Test
    void searchByKeyword_NoFiguresFound() {
        // Arrange
        when(figureRepository.findAll()).thenReturn(Arrays.asList(figure1, figure2, figure3, figure4));

        // Act
        List<Figure> result = service.searchByKeyword("NonExistentKeyword");

        // Assert
        assertTrue(result.isEmpty());

        // Verify that the repository's findAll method was called
        verify(figureRepository).findAll();
    }

    @Test
    void searchByCategoryAndKeyword_FindsFigures() {
        // Arrange
        when(figureRepository.findAll()).thenReturn(Arrays.asList(figure1, figure2, figure3, figure4));

        // Act
        List<Figure> result = service.searchByCategoryAndKeyword("Design", "modern");

        // Assert
        assertEquals(1, result.size());
        assertTrue(result.contains(figure1));
        assertFalse(result.contains(figure2));
        assertFalse(result.contains(figure3));
        assertFalse(result.contains(figure4));

        // Verify that the repository's findAll method was called at least once
        verify(figureRepository, atLeast(1)).findAll();
    }

    @Test
    void searchByCategoryAndKeyword_CaseInsensitive() {
        // Arrange
        when(figureRepository.findAll()).thenReturn(Arrays.asList(figure1, figure2, figure3, figure4));

        // Act - using mixed case
        List<Figure> result = service.searchByCategoryAndKeyword("DeSiGn", "MoDerN");

        // Assert
        assertEquals(1, result.size());
        assertTrue(result.contains(figure1));

        // Verify that the repository's findAll method was called at least once
        verify(figureRepository, atLeast(1)).findAll();
    }

    @Test
    void searchByCategoryAndKeyword_NoFiguresFound_CategoryExists_KeywordDoesNot() {
        // Arrange
        when(figureRepository.findAll()).thenReturn(Arrays.asList(figure1, figure2, figure3, figure4));

        // Act
        List<Figure> result = service.searchByCategoryAndKeyword("Design", "NonExistentKeyword");

        // Assert
        assertTrue(result.isEmpty());

        // Verify that the repository's findAll method was called at least once
        verify(figureRepository, atLeast(1)).findAll();
    }

    @Test
    void searchByCategoryAndKeyword_NoFiguresFound_CategoryDoesNotExist() {
        // Arrange
        when(figureRepository.findAll()).thenReturn(Arrays.asList(figure1, figure2, figure3, figure4));

        // Act
        List<Figure> result = service.searchByCategoryAndKeyword("NonExistentCategory", "modern");

        // Assert
        assertTrue(result.isEmpty());

        // Verify that the repository's findAll method was called at least once
        verify(figureRepository, atLeast(1)).findAll();
    }
}
