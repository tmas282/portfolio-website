package shodrone.services;

import shodrone.figuremanagement.*;
import shodrone.figurecategorymanagement.CategoryName;
import shodrone.figurecategorymanagement.FigureCategory;
import shodrone.figurecategorymanagement.Description;
import shodrone.customermanagement.VAT;
import shodrone.repositories.CustomerRepository;
import shodrone.repositories.FigureCategoryRepository;
import shodrone.repositories.FigureRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ListActivePublicFiguresServiceTest {

    private FigureService service;
    private FigureRepository figureRepository;
    private FigureCategoryRepository figureCategoryRepository;
    private CustomerRepository customerRepository;

    private Figure activePublicFigure1;
    private Figure activePublicFigure2;
    private Figure inactiveFigure;
    private Figure exclusiveFigure;

    @BeforeEach
    void setUp() {
        figureRepository = mock(FigureRepository.class);
        figureCategoryRepository = mock(FigureCategoryRepository.class);
        customerRepository = mock(CustomerRepository.class);
        service = new FigureService(figureRepository, figureCategoryRepository, customerRepository);
        
        // Create test data
        setupTestFigures();
    }
    
    private void setupTestFigures() {
        // Create a category for test figures
        CategoryName catName = new CategoryName("TestCategory");
        Description description = new Description("Test Category Description");
        FigureCategory category = new FigureCategory(catName, description);
        
        // Create active public figures
        List<Keyword> keywords1 = new ArrayList<>();
        keywords1.add(new Keyword("test1"));
        activePublicFigure1 = new Figure(new Code(1001), keywords1, category);
        
        List<Keyword> keywords2 = new ArrayList<>();
        keywords2.add(new Keyword("test2"));
        activePublicFigure2 = new Figure(new Code(1002), keywords2, category);
        
        // Create an inactive figure
        List<Keyword> keywords3 = new ArrayList<>();
        keywords3.add(new Keyword("test3"));
        inactiveFigure = new Figure(new Code(1003), keywords3, category);
        inactiveFigure.deactivate(); // This makes the figure inactive
        
        // Create an exclusive figure
        List<Keyword> keywords4 = new ArrayList<>();
        keywords4.add(new Keyword("test4"));
        exclusiveFigure = new Figure(new Code(1004), keywords4, category);
        exclusiveFigure.addExclusivity(new Exclusivity(new VAT("PT123456789"))); // This makes the figure exclusive
    }

    @Test
    void listAllActivePublicFigures_ReturnsOnlyActivePublicFigures() {
        // Arrange
        // The repository's findAll method is already filtering for active and public figures
        // So we only need to return the active public figures in our mock
        when(figureRepository.findAll()).thenReturn(Arrays.asList(activePublicFigure1, activePublicFigure2));
        
        // Act
        List<Figure> result = service.listAllActivePublicFigures();
        
        // Assert
        assertEquals(2, result.size());
        assertTrue(result.contains(activePublicFigure1));
        assertTrue(result.contains(activePublicFigure2));
        assertFalse(result.contains(inactiveFigure));
        assertFalse(result.contains(exclusiveFigure));
        
        // Verify that the repository's findAll method was called
        verify(figureRepository).findAll();
    }
    
    @Test
    void listAllActivePublicFigures_NoFiguresExist_ReturnsEmptyList() {
        // Arrange
        when(figureRepository.findAll()).thenReturn(new ArrayList<>());
        
        // Act
        List<Figure> result = service.listAllActivePublicFigures();
        
        // Assert
        assertTrue(result.isEmpty());
        
        // Verify that the repository's findAll method was called
        verify(figureRepository).findAll();
    }
}