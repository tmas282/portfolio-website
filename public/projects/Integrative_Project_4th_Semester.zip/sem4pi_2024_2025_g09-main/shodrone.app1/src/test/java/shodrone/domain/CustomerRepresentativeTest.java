package shodrone.domain;

import org.junit.jupiter.api.Test;
import shodrone.customermanagement.Email;
import shodrone.customermanagement.Name;
import shodrone.customermanagement.PhoneNumber;
import shodrone.customerrepresentativemanagement.CustomerRepresentative;
import shodrone.customerrepresentativemanagement.Position;
import shodrone.usermanagement.Role;
import shodrone.usermanagement.RoleName;
import shodrone.usermanagement.User;

import static org.junit.jupiter.api.Assertions.*;

class CustomerRepresentativeTest {

    @Test
    void shouldCreateValidCustomerRepresentative() {
        Name name = new Name("Alice Johnson");
        Email email = new Email("alice.johnson@example.com");
        Position position = new Position("Show Designer");

        CustomerRepresentative representative = new CustomerRepresentative(email, name, position);

        assertEquals(name, representative.getName());
        assertEquals(email, representative.getEmail());
        assertEquals(position, representative.getPosition());
    }

    @Test
    void shouldNotAllowNullValuesInConstructor() {
        Email email = new Email("alice.johnson@example.com");
        Name name = new Name("Alice Johnson");
        Position position = new Position("Show Designer");

        assertThrows(IllegalArgumentException.class, () -> new CustomerRepresentative(null, name, position));
        assertThrows(IllegalArgumentException.class, () -> new CustomerRepresentative(email, null, position));
        assertThrows(IllegalArgumentException.class, () -> new CustomerRepresentative(email, name, null));
    }

    @Test
    void shouldSetValidPhoneNumber() {
        Name name = new Name("Alice Johnson");
        Email email = new Email("alice.johnson@example.com");
        Position position = new Position("Show Designer");
        PhoneNumber phoneNumber = new PhoneNumber("912345678");

        CustomerRepresentative representative = new CustomerRepresentative(email, name, position);
        representative.setPhoneNumber(phoneNumber);

        assertEquals(phoneNumber, representative.getPhoneNumber());
    }



    @Test
    void shouldSetValidUser() {
        Name name = new Name("Alice Johnson");
        Email email = new Email("alice.johnson@example.com");
        Position position = new Position("Show Designer");
        PhoneNumber phone = new PhoneNumber("912345678");

        // Cria uma instância de Role
        Role role = new Role(RoleName.CUSTOMER_REPRESENTATIVE);

        // Passa o Role para o construtor de User
        User user = new User("alice.johnson@example.com", "securePassword123", role, true, name, phone);

        CustomerRepresentative representative = new CustomerRepresentative(email, name, position);
        representative.setUser(user);

        assertEquals(user, representative.user());
    }


    @Test
    void shouldTestEqualityBasedOnEmail() {
        Email email1 = new Email("alice.johnson@example.com");
        Email email2 = new Email("bob.smith@example.com");
        Name name = new Name("Alice Johnson");
        Position position = new Position("Show Designer");

        CustomerRepresentative rep1 = new CustomerRepresentative(email1, name, position);
        CustomerRepresentative rep2 = new CustomerRepresentative(email1, name, position);
        CustomerRepresentative rep3 = new CustomerRepresentative(email2, name, position);

        assertEquals(rep1, rep2);
        assertNotEquals(rep1, rep3);
    }

    @Test
    void shouldTestHashCodeBasedOnEmail() {
        Email email = new Email("alice.johnson@example.com");
        Name name = new Name("Alice Johnson");
        Position position = new Position("Show Designer");

        CustomerRepresentative rep1 = new CustomerRepresentative(email, name, position);
        CustomerRepresentative rep2 = new CustomerRepresentative(email, name, position);

        assertEquals(rep1.hashCode(), rep2.hashCode());
    }


}