package shodrone.domain;

                import org.junit.jupiter.api.Test;
                import shodrone.customermanagement.*;
                import shodrone.customerrepresentativemanagement.CustomerRepresentative;

                import java.util.List;

                import static org.junit.jupiter.api.Assertions.*;
                import static org.mockito.Mockito.*;

                class CustomerTest {

                    @Test
                    void shouldCreateValidCustomer() {
                        VAT vat = new VAT("PT123456789");
                        Name name = new Name("Empresa Exemplo");
                        Email email = new Email("empresa@exemplo.com");
                        Address address = new Address("Rua Exemplo, 123");
                        PhoneNumber phone = new PhoneNumber("912345678");
                        CustomerRepresentative rep = mock(CustomerRepresentative.class);

                        Customer customer = new Customer(vat, name, email, address, phone, rep, CustomerType.REGULAR);

                        assertEquals(vat, customer.identity());
                        assertEquals(CustomerStatus.CREATED, customer.status());
                        assertTrue(customer.representatives().contains(rep));
                    }

                    @Test
                    void shouldNotAllowNullValuesInConstructor() {
                        VAT vat = new VAT("PT123456789");
                        Name name = new Name("Empresa Exemplo");
                        Email email = new Email("empresa@exemplo.com");
                        Address address = new Address("Rua Exemplo, 123");
                        PhoneNumber phone = new PhoneNumber("912345678");
                        CustomerRepresentative rep = mock(CustomerRepresentative.class);

                        assertThrows(IllegalArgumentException.class, () -> new Customer(null, name, email, address, phone, rep, CustomerType.REGULAR));
                        assertThrows(IllegalArgumentException.class, () -> new Customer(vat, null, email, address, phone, rep, CustomerType.REGULAR));
                        assertThrows(IllegalArgumentException.class, () -> new Customer(vat, name, null, address, phone, rep, CustomerType.REGULAR));
                        assertThrows(IllegalArgumentException.class, () -> new Customer(vat, name, email, null, phone, rep, CustomerType.REGULAR));
                        assertThrows(IllegalArgumentException.class, () -> new Customer(vat, name, email, address, null, rep, CustomerType.REGULAR));
                        assertThrows(IllegalArgumentException.class, () -> new Customer(vat, name, email, address, phone, null, CustomerType.REGULAR));
                    }

                    @Test
                    void shouldAddRepresentative() {
                        VAT vat = new VAT("PT123456789");
                        Name name = new Name("Empresa Exemplo");
                        Email email = new Email("empresa@exemplo.com");
                        Address address = new Address("Rua Exemplo, 123");
                        PhoneNumber phone = new PhoneNumber("912345678");
                        CustomerRepresentative rep1 = mock(CustomerRepresentative.class);
                        CustomerRepresentative rep2 = mock(CustomerRepresentative.class);

                        Customer customer = new Customer(vat, name, email, address, phone, rep1, CustomerType.REGULAR);
                        customer.addRepresentative(rep2);

                        List<CustomerRepresentative> reps = customer.representatives();
                        assertTrue(reps.contains(rep1));
                        assertTrue(reps.contains(rep2));
                    }

                    @Test
                    void shouldReturnRepresentativeEmails() {
                        VAT vat = new VAT("PT123456789");
                        Name name = new Name("Empresa Exemplo");
                        Email email = new Email("empresa@exemplo.com");
                        Address address = new Address("Rua Exemplo, 123");
                        PhoneNumber phone = new PhoneNumber("912345678");

                        CustomerRepresentative rep1 = mock(CustomerRepresentative.class);
                        CustomerRepresentative rep2 = mock(CustomerRepresentative.class);

                        when(rep1.getEmail()).thenReturn(new Email("rep1@exemplo.com"));
                        when(rep2.getEmail()).thenReturn(new Email("rep2@exemplo.com"));

                        Customer customer = new Customer(vat, name, email, address, phone, rep1, CustomerType.REGULAR);
                        customer.addRepresentative(rep2);

                        List<String> emails = customer.representativeEmails();
                        assertTrue(emails.contains("rep1@exemplo.com"));
                        assertTrue(emails.contains("rep2@exemplo.com"));
                    }

                    @Test
                    void shouldTestEqualityBasedOnVAT() {
                        VAT vat1 = new VAT("PT123456789");
                        VAT vat2 = new VAT("PT987654321");
                        Name name = new Name("Empresa Exemplo");
                        Email email = new Email("empresa@exemplo.com");
                        Address address = new Address("Rua Exemplo, 123");
                        PhoneNumber phone = new PhoneNumber("912345678");
                        CustomerRepresentative rep = mock(CustomerRepresentative.class);

                        Customer customer1 = new Customer(vat1, name, email, address, phone, rep, CustomerType.REGULAR);
                        Customer customer2 = new Customer(vat1, name, email, address, phone, rep, CustomerType.REGULAR);
                        Customer customer3 = new Customer(vat2, name, email, address, phone, rep, CustomerType.REGULAR);

                        assertEquals(customer1, customer2);
                        assertNotEquals(customer1, customer3);
                    }

                    @Test
                    void shouldTestHashCodeBasedOnVAT() {
                        VAT vat = new VAT("PT123456789");
                        Name name = new Name("Empresa Exemplo");
                        Email email = new Email("empresa@exemplo.com");
                        Address address = new Address("Rua Exemplo, 123");
                        PhoneNumber phone = new PhoneNumber("912345678");
                        CustomerRepresentative rep = mock(CustomerRepresentative.class);

                        Customer customer1 = new Customer(vat, name, email, address, phone, rep, CustomerType.REGULAR);
                        Customer customer2 = new Customer(vat, name, email, address, phone, rep, CustomerType.REGULAR);

                        assertEquals(customer1.hashCode(), customer2.hashCode());
                    }
                }