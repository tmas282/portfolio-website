package shodrone.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import shodrone.dronemanagement.Drone;
import shodrone.dronemodelmanagement.ModelID;
import shodrone.repositories.DroneModelRepository;
import shodrone.repositories.ShowProposalRepository;
import shodrone.services.DroneService;
import shodrone.services.ShowProposalService;
import shodrone.showproposalmanagement.ShowProposal;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AddDronesProposalControllerTest {
    private DroneService droneService;
    private ShowProposalService showProposalService;
    private ShowProposalRepository showProposalRepository;
    private DroneModelRepository droneModelRepository;
    private AddDronesProposalController controller;
    @BeforeEach
    void setUp() {
        this.droneService = mock(DroneService.class);
        this.showProposalService = mock(ShowProposalService.class);
        this.showProposalRepository = mock(ShowProposalRepository.class);
        this.droneModelRepository = mock(DroneModelRepository.class);
        this.controller = new AddDronesProposalController(
                droneService, showProposalService, showProposalRepository, droneModelRepository
        );
    }
    @Test
    void addDronesToShowProposal() {
        Long proposalId = 1L;
        Map<ModelID, Integer> req = new HashMap<>();
        List<Drone> drones = Arrays.asList(mock(Drone.class));
        ShowProposal proposal = mock(ShowProposal.class);

        when(droneService.getDronesAvailable(req)).thenReturn(drones);
        when(showProposalRepository.findById(proposalId)).thenReturn(Optional.of(proposal));

        boolean result = controller.addDronesToShowProposal(proposalId, req);

        assertTrue(result);
        verify(showProposalService).addDronesToShowProposal(proposal, drones);
    }
}