package shodrone.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.security.crypto.password.PasswordEncoder;
import shodrone.repositories.UserRepository;
import shodrone.usermanagement.*;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class Authentication_AuthorizationTest {

    private UserRepository userRepository;
    private PasswordEncoder passwordEncoder;
    private AuthController authController;

    @BeforeEach
    void setUp() {
        userRepository = mock(UserRepository.class);
        passwordEncoder = mock(PasswordEncoder.class);
        authController = new AuthController(userRepository, passwordEncoder);
    }

    @Test
    void testAuthenticateSuccess() {
        User user = mock(User.class);
        when(user.isEnabled()).thenReturn(true);
        when(user.password()).thenReturn("encodedPass");
        when(user.email()).thenReturn("user@showdrone.com");

        when(userRepository.findByEmail("user@showdrone.com")).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("plainPass", "encodedPass")).thenReturn(true);

        User result = authController.authenticate("user@showdrone.com", "plainPass");
        assertNotNull(result);
        assertEquals(user, result);
    }

    @Test
    void testAuthenticateWrongPassword() {
        User user = mock(User.class);
        when(user.isEnabled()).thenReturn(true);
        when(user.password()).thenReturn("encodedPass");

        when(userRepository.findByEmail("user@showdrone.com")).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("wrongPass", "encodedPass")).thenReturn(false);

        User result = authController.authenticate("user@showdrone.com", "wrongPass");
        assertNull(result);
    }

    @Test
    void testAuthenticateUserDisabled() {
        User user = mock(User.class);
        when(user.isEnabled()).thenReturn(false);

        when(userRepository.findByEmail("user@showdrone.com")).thenReturn(Optional.of(user));

        User result = authController.authenticate("user@showdrone.com", "anyPass");
        assertNull(result);
    }

    @Test
    void testAuthenticateUserNotFound() {
        when(userRepository.findByEmail("notfound@showdrone.com")).thenReturn(Optional.empty());

        User result = authController.authenticate("notfound@showdrone.com", "anyPass");
        assertNull(result);
    }
}