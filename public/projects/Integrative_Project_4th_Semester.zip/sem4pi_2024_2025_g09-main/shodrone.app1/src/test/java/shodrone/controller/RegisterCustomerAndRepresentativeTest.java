package shodrone.controller;

    import org.junit.jupiter.api.BeforeEach;
    import org.junit.jupiter.api.Test;
    import org.mockito.ArgumentCaptor;
    import org.springframework.security.crypto.password.PasswordEncoder;
    import shodrone.customermanagement.*;
    import shodrone.customerrepresentativemanagement.CustomerRepresentative;
    import shodrone.repositories.*;
    import shodrone.services.CustomerService;
    import shodrone.usermanagement.Role;
    import shodrone.usermanagement.RoleName;
    import shodrone.usermanagement.User;

    import java.util.Optional;

    import static org.junit.jupiter.api.Assertions.*;
    import static org.mockito.ArgumentMatchers.*;
    import static org.mockito.Mockito.*;

    class RegisterCustomerAndRepresentativeTest {

        private CustomerRepository customerRepository;
        private UserRepository userRepository;
        private RoleRepository roleRepository;
        private CustomerRepresentativeRepository customerRepresentativeRepository;
        private CustomerService customerService;
        private PasswordEncoder passwordEncoder;

        @BeforeEach
        void setUp() {
            customerRepository = mock(CustomerRepository.class);
            userRepository = mock(UserRepository.class);
            roleRepository = mock(RoleRepository.class);
            customerRepresentativeRepository = mock(CustomerRepresentativeRepository.class);
            passwordEncoder = mock(PasswordEncoder.class);
            customerService = new CustomerService(customerRepository, userRepository, roleRepository, passwordEncoder, customerRepresentativeRepository);

            when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");

            // Simula que qualquer save devolve a própria entidade
            when(customerRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
            when(userRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
            when(customerRepresentativeRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

            // Configura os mocks para os papéis
            Role customerRole = new Role();
            customerRole.setRoleName(RoleName.CUSTOMER);
            Role repRole = new Role();
            repRole.setRoleName(RoleName.CUSTOMER_REPRESENTATIVE);

            when(roleRepository.findByRoleName(RoleName.CUSTOMER)).thenReturn(Optional.of(customerRole));
            when(roleRepository.findByRoleName(RoleName.CUSTOMER_REPRESENTATIVE)).thenReturn(Optional.of(repRole));
        }

        @Test
        void testRegisterCustomerAndRepresentativeSuccessfully() {
            String vat = "PT123456789";
            String customerName = "Customer Name";
            String customerEmail = "customer@example.com";
            String customerAddress = "Main Street 1";
            String customerPhone = "912345678";
            String repName = "Representative Name";
            String repEmail = "rep@example.com";
            String repPosition = "Manager";
            String repPhone = "923456789";

            when(customerRepository.findByVat(any(VAT.class))).thenReturn(Optional.empty());
            when(userRepository.findByEmail(anyString())).thenReturn(Optional.empty());
            when(customerRepresentativeRepository.findByEmail(any(Email.class))).thenReturn(Optional.empty());

            customerService.registerCustomerAndRepresentative(
                    vat, customerName, customerEmail, customerAddress, customerPhone,
                    repName, repEmail, repPosition, repPhone, "REGULAR"
            );

            ArgumentCaptor<Customer> customerCaptor = ArgumentCaptor.forClass(Customer.class);
            verify(customerRepository).save(customerCaptor.capture());
            assertEquals(vat, customerCaptor.getValue().identity().value());

            ArgumentCaptor<CustomerRepresentative> representativeCaptor = ArgumentCaptor.forClass(CustomerRepresentative.class);
            verify(customerRepresentativeRepository).save(representativeCaptor.capture());
            assertEquals(repEmail, representativeCaptor.getValue().getEmail().value());
            assertEquals(repName, representativeCaptor.getValue().getName().value());
        }

        @Test
        void testRegisterCustomerFailsIfVATExists() {
            String vat = "PT123456789";

            when(customerRepository.findByVat(any(VAT.class))).thenReturn(Optional.of(mock(Customer.class)));

            Exception ex = assertThrows(IllegalArgumentException.class, () ->
                    customerService.registerCustomerAndRepresentative(
                            vat, "Name", "email@example.com", "Address", "912345678",
                            "Rep Name", "rep@example.com", "Manager", "923456789", "REGULAR"
                    )
            );

            assertTrue(ex.getMessage().contains("already exists"));
            verify(customerRepository, never()).save(any());
            verify(customerRepresentativeRepository, never()).save(any());
        }

        @Test
        void testRegisterCustomerFailsIfRepresentativeEmailExists() {
            String vat = "PT123456789";
            String repEmail = "rep@example.com";
            String customerEmail = "customer@shodrone.com";

            when(customerRepository.findByVat(any(VAT.class))).thenReturn(Optional.empty());
            when(userRepository.findByEmail(anyString())).thenReturn(Optional.empty());
            when(customerRepresentativeRepository.findByEmail(any(Email.class)))
                    .thenReturn(Optional.of(mock(CustomerRepresentative.class)));

            Exception ex = assertThrows(IllegalArgumentException.class, () ->
                    customerService.registerCustomerAndRepresentative(
                            vat, "Name", customerEmail, "Address", "912345678",
                            "Rep Name", repEmail, "Manager", "923456789", "REGULAR"
                    )
            );

            assertTrue(ex.getMessage().contains("already exists"));
            verify(customerRepository, never()).save(any());
            verify(customerRepresentativeRepository, never()).save(any());
            verify(userRepository, never()).save(any());
        }

        @Test
        void testRegisterCustomerFailsIfCustomerRoleMissing() {
            String vat = "PT111222333";

            when(customerRepository.findByVat(any(VAT.class))).thenReturn(Optional.empty());
            when(userRepository.findByEmail(anyString())).thenReturn(Optional.empty());
            when(roleRepository.findByRoleName(RoleName.CUSTOMER_REPRESENTATIVE)).thenReturn(Optional.empty());

            assertThrows(IllegalStateException.class, () ->
                    customerService.registerCustomerAndRepresentative(
                            vat, "Name", "email@example.com", "Address", "912345678",
                            "Rep Name", "rep@example.com", "Manager", "923456789", "REGULAR"
                    )
            );
        }

        @Test
        void testBothUsersAreEnabledAfterRegistration() {
            when(customerRepository.findByVat(any(VAT.class))).thenReturn(Optional.empty());
            when(userRepository.findByEmail(anyString())).thenReturn(Optional.empty());
            when(customerRepresentativeRepository.findByEmail(any(Email.class))).thenReturn(Optional.empty());

            customerService.registerCustomerAndRepresentative(
                    "PT123456789", "Test", "cust@x.com", "Addr", "912345678",
                    "Rep", "rep@x.com", "Position", "933456789", "REGULAR"
            );

            ArgumentCaptor<User> userCaptor = ArgumentCaptor.forClass(User.class);
            verify(userRepository, times(2)).save(userCaptor.capture());

            for (User user : userCaptor.getAllValues()) {
                assertTrue(user.isEnabled());
            }
        }
    }