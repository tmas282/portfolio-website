package shodrone.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import shodrone.customermanagement.Name;
import shodrone.customermanagement.PhoneNumber;
import shodrone.services.UserService;
import shodrone.repositories.UserRepository;
import shodrone.usermanagement.Role;
import shodrone.usermanagement.RoleName;
import shodrone.usermanagement.User;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ManageUsersTest {

    private UserRepository userRepository;
    private UserService userService;

    @BeforeEach
    void setUp() {
        userRepository = mock(UserRepository.class);
        userService = new UserService(userRepository, null, null); // Apenas o UserRepository é necessário aqui
    }

    @Test
    void testDisableUserSuccessfully() {
        String email = "user@example.com";
        User user = mock(User.class);
        when(userRepository.findByEmail(email)).thenReturn(Optional.of(user));

        boolean result = userService.disableUser(email);

        assertTrue(result, "User should be disabled successfully");
        verify(user).deactivate();
        verify(userRepository).save(user);
    }

    @Test
    void testDisableUserNotFound() {
        String email = "nonexistent@example.com";
        when(userRepository.findByEmail(email)).thenReturn(Optional.empty());

        boolean result = userService.disableUser(email);

        assertFalse(result, "Disabling a non-existent user should return false");
        verify(userRepository, never()).save(any());
    }

    @Test
    void testEnableUserSuccessfully() {
        String email = "user@example.com";
        User user = mock(User.class);
        when(userRepository.findByEmail(email)).thenReturn(Optional.of(user));

        boolean result = userService.enableUser(email);

        assertTrue(result, "User should be enabled successfully");
        verify(user).activate();
        verify(userRepository).save(user);
    }

    @Test
    void testEnableUserNotFound() {
        String email = "nonexistent@example.com";
        when(userRepository.findByEmail(email)).thenReturn(Optional.empty());

        boolean result = userService.enableUser(email);

        assertFalse(result, "Enabling a non-existent user should return false");
        verify(userRepository, never()).save(any());
    }

    @Test
    void testDisableUserDoesNotThrowException() {
        String email = "user@example.com";
        User user = mock(User.class);
        when(userRepository.findByEmail(email)).thenReturn(Optional.of(user));

        assertDoesNotThrow(() -> userService.disableUser(email));
    }

    @Test
    void testEnableUserDoesNotThrowException() {
        String email = "user@example.com";
        User user = mock(User.class);
        when(userRepository.findByEmail(email)).thenReturn(Optional.of(user));

        assertDoesNotThrow(() -> userService.enableUser(email));
    }

    @Test
    void testListAllUsersReturnsCorrectData() {
        Role adminRole = new Role();
        adminRole.setRoleName(RoleName.ADMIN);

        Role managerRole = new Role();
        managerRole.setRoleName(RoleName.CRM_MANAGER);

        User user1 = new User("admin@showdrone.com", "pwd", adminRole, true, new Name("Admin"), new PhoneNumber("911111111"));
        User user2 = new User("manager@showdrone.com", "pwd", managerRole, false, new Name("Manager"), new PhoneNumber("922222222"));

        when(userRepository.findAll()).thenReturn(List.of(user1, user2));

        List<User> users = userService.listAllUsers();

        assertEquals(2, users.size(), "Should return all users");
        assertEquals("admin@showdrone.com", users.get(0).email());
        assertTrue(users.get(0).isEnabled(), "Admin user should be enabled");
        assertEquals("manager@showdrone.com", users.get(1).email());
        assertFalse(users.get(1).isEnabled(), "Manager user should be disabled");
    }

    @Test
    void testListAllUsersReturnsEmptyListWhenNoUsersExist() {
        when(userRepository.findAll()).thenReturn(List.of());

        List<User> users = userService.listAllUsers();

        assertTrue(users.isEmpty(), "Should return an empty list when no users exist");
    }

    @Test
    void testListAllUsersIsImmutable() {
        Role role = new Role();
        role.setRoleName(RoleName.ADMIN);

        User user = new User("admin@showdrone.com", "pwd", role, true, new Name("Admin"), new PhoneNumber("911111111"));

        when(userRepository.findAll()).thenReturn(List.of(user));

        List<User> result = userService.listAllUsers();

        assertThrows(UnsupportedOperationException.class, () -> {
            result.add(new User("new@showdrone.com", "pwd", role, true, new Name("Novo"), new PhoneNumber("933333333")));
        }, "Should not allow modification of returned user list");
    }

}