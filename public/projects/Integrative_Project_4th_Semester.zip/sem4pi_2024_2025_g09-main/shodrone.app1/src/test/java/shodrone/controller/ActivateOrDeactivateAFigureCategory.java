package shodrone.controller;

import static org.mockito.Mockito.mock;
import shodrone.figurecategorymanagement.CategoryName;
import shodrone.figurecategorymanagement.Description;
import shodrone.figurecategorymanagement.FigureCategory;
import shodrone.repositories.FigureCategoryRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import shodrone.services.FigureCategoryService;


import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ActivateOrDeactivateAFigureCategory {

    private FigureCategoryService service;
    private FigureCategoryRepository repository;

    @BeforeEach
    void setUp() {
        repository = mock(FigureCategoryRepository.class);
        service = new FigureCategoryService(repository);
    }

    @Test
    void activateCategory_Success() {
        FigureCategory cat = new FigureCategory(new CategoryName("test"), new Description("..."));
        cat.deactivate();

        when(repository.findByName_ValueIgnoreCase("test")).thenReturn(Optional.of(cat));

        service.activateCategory("test");

        assertTrue(cat.status().isActive());
        verify(repository).save(cat);
    }

    @Test
    void activateCategory_AlreadyActive() {
        FigureCategory cat = new FigureCategory(new CategoryName("x"), new Description("..."));
        when(repository.findByName_ValueIgnoreCase("x")).thenReturn(Optional.of(cat));

        var ex = assertThrows(IllegalArgumentException.class, () ->
                service.activateCategory("x")
        );
        assertEquals("Category is already active.", ex.getMessage());
    }

    @Test
    void deactivateCategory_Success() {
        FigureCategory cat = new FigureCategory(new CategoryName("test"), new Description("..."));

        when(repository.findByName_ValueIgnoreCase("test")).thenReturn(Optional.of(cat));

        service.deactivateCategory("test");

        assertFalse(cat.status().isActive());
        verify(repository).save(cat);
    }

    @Test
    void deactivateCategory_AlreadyInactive() {
        FigureCategory cat = new FigureCategory(new CategoryName("x"), new Description("..."));
        cat.deactivate();

        when(repository.findByName_ValueIgnoreCase("x")).thenReturn(Optional.of(cat));

        var ex = assertThrows(IllegalArgumentException.class, () ->
                service.deactivateCategory("x")
        );
        assertEquals("Category is already inactive.", ex.getMessage());
    }

    @Test
    void toggleCategory_NotFound() {
        when(repository.findByName_ValueIgnoreCase("invalid")).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class, () ->
                service.activateCategory("invalid")
        );
        assertThrows(IllegalArgumentException.class, () ->
                service.deactivateCategory("invalid")
        );
    }
}
