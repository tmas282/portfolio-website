package shodrone.services;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import shodrone.dronemodelmanagement.DroneModel;
import shodrone.dronemodelmanagement.ModelID;
import shodrone.dronemodelmanagement.WindTolerance;
import shodrone.dronemodelmanagement.MaintenanceThreshold;
import shodrone.repositories.DroneModelRepository;

import java.util.NavigableMap;
import java.util.Optional;
import java.util.TreeMap;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class CreateDroneModelServiceTest {

    private DroneModelRepository repository;
    private DroneModelService service;
    private MaintenanceThreshold maintenanceThreshold;

    @BeforeEach
    void setUp() {
        repository = mock(DroneModelRepository.class);
        service = new DroneModelService(repository);
        maintenanceThreshold = new MaintenanceThreshold(10);
    }

    @Test
    void verifyDroneModelAlreadyExistsThrowsException() {

        when(repository.findByModelID(any(ModelID.class))).thenReturn(Optional.of(mock(DroneModel.class)));

        NavigableMap<Double, Double> map = new TreeMap<>();
        map.put(5.0, 0.0);
        WindTolerance tolerance = new WindTolerance(map);

        // Act & Assert
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            service.createDroneModel("DM100", "Java", tolerance, maintenanceThreshold);
        });

        assertEquals("A drone model with ID 'DM100' already exists.", exception.getMessage());
        verify(repository, never()).save(any(DroneModel.class));
    }

    @Test
    void verifyDroneModelNullInputsThrowsException() {
        NavigableMap<Double, Double> map = new TreeMap<>();
        map.put(5.0, 0.0);
        WindTolerance tolerance = new WindTolerance(map);

        assertThrows(IllegalArgumentException.class, () -> service.createDroneModel(null, "Java", tolerance, maintenanceThreshold));
        assertThrows(IllegalArgumentException.class, () -> service.createDroneModel("DM100", null, tolerance, maintenanceThreshold));
        assertThrows(IllegalArgumentException.class, () -> service.createDroneModel("DM100", "Java", null, maintenanceThreshold));
        assertThrows(IllegalArgumentException.class, () -> service.createDroneModel("DM100", "Java", tolerance, null));
    }
}