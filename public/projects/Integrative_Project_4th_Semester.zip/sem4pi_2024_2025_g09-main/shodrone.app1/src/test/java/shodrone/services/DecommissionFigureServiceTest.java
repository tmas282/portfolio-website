package shodrone.services;

import shodrone.figuremanagement.*;
import shodrone.figurecategorymanagement.CategoryName;
import shodrone.figurecategorymanagement.FigureCategory;
import shodrone.figurecategorymanagement.Description;
import shodrone.repositories.CustomerRepository;
import shodrone.repositories.FigureCategoryRepository;
import shodrone.repositories.FigureRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DecommissionFigureServiceTest {

    private FigureService service;
    private FigureRepository figureRepository;
    private FigureCategoryRepository figureCategoryRepository;
    private CustomerRepository customerRepository;

    @BeforeEach
    void setUp() {
        figureRepository = mock(FigureRepository.class);
        figureCategoryRepository = mock(FigureCategoryRepository.class);
        customerRepository = mock(CustomerRepository.class);
        service = new FigureService(figureRepository, figureCategoryRepository, customerRepository);
    }

    @Test
    void decommissionFigure_Success() {
        // Arrange
        long codeId = 12345L;
        Code code = new Code(codeId);

        // Create a category for the figure
        CategoryName catName = new CategoryName("TestCategory");
        Description description = new Description("Test Category Description");
        FigureCategory category = new FigureCategory(catName, description);

        // Create a figure that will be decommissioned
        List<Keyword> keywords = new ArrayList<>();
        keywords.add(new Keyword("test"));
        Figure figure = new Figure(code, keywords, category);

        // Mock repository behavior
        when(figureRepository.findByCode(code)).thenReturn(Optional.of(figure));
        when(figureRepository.findAll()).thenReturn(List.of(figure));

        // Act
        int result = service.decommissionFigure(code);

        // Assert
        assertEquals(0, result); // 0 means success
        verify(figureRepository).save(figure); // Figure should be saved
    }

    @Test
    void decommissionFigure_FigureNotFound() {
        // Arrange
        long codeId = 12345L;
        Code code = new Code(codeId);

        // Mock repository behavior - figure not found
        when(figureRepository.findByCode(code)).thenReturn(Optional.empty());

        // Act
        int result = service.decommissionFigure(code);

        // Assert
        assertEquals(1, result); // 1 means figure not found
        verify(figureRepository, never()).save(any(Figure.class)); // Figure should not be saved
    }

    @Test
    void decommissionFigure_FigureNotInFindAll() {
        // Arrange
        long codeId = 12345L;
        Code code = new Code(codeId);

        // Create a category for the figure
        CategoryName catName = new CategoryName("TestCategory");
        Description description = new Description("Test Category Description");
        FigureCategory category = new FigureCategory(catName, description);

        // Create a figure that will be decommissioned
        List<Keyword> keywords = new ArrayList<>();
        keywords.add(new Keyword("test"));
        Figure figure = new Figure(code, keywords, category);

        // Mock repository behavior - figure found by code but not in findAll
        when(figureRepository.findByCode(code)).thenReturn(Optional.of(figure));
        when(figureRepository.findAll()).thenReturn(new ArrayList<>()); // Empty list

        // Act
        int result = service.decommissionFigure(code);

        // Assert
        assertEquals(2, result); // 2 means other error
        verify(figureRepository, never()).save(any(Figure.class)); // Figure should not be saved
    }
}
