package shodrone.domain;

import org.junit.jupiter.api.Test;
import shodrone.figuremanagement.Code;
import shodrone.figuremanagement.Figure;
import shodrone.showproposalmanagement.*;
import shodrone.showrequestmanagement.*;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ShowProposalTest {

    @Test
    void shouldCreateValidShowProposal() {
        ShowRequest showRequest = mock(ShowRequest.class);
        ShowRequestStatus acceptedStatus = mock(ShowRequestStatus.class);
        when(acceptedStatus.toString()).thenReturn("ACCEPTED");
        when(showRequest.getStatus()).thenReturn(acceptedStatus);

        NumberOfDrones drones = new NumberOfDrones(10);
        ShowDescription desc = new ShowDescription("Unique Description");
        ShowProposalDate date = new ShowProposalDate(LocalDate.of(2024, 6, 1));
        ShowProposalTime time = new ShowProposalTime(LocalTime.of(21, 0));
        ShowProposalDuration duration = new ShowProposalDuration(Duration.ofMinutes(60));
        ShowProposalPlace place = new ShowProposalPlace("Lisbon");

        ShowProposal proposal = new ShowProposal(showRequest, ShowProposalStatus.DRAFT, drones, desc, date, time, duration, place);

        assertEquals(showRequest, proposal.getShowRequest());
        assertEquals(ShowProposalStatus.DRAFT, proposal.getStatus());
        assertEquals(drones, proposal.getNumberOfDrones());
        assertEquals(desc, proposal.getDescription());
        assertEquals(date, proposal.getDate());
        assertEquals(time, proposal.getTime());
        assertEquals(duration, proposal.getDuration());
        assertEquals(place, proposal.getPlace());
        assertNull(proposal.getSimulationVideoLink());
    }

    @Test
    void shouldNotAllowNullArguments() {
        ShowRequest showRequest = mock(ShowRequest.class);
        ShowRequestStatus acceptedStatus = mock(ShowRequestStatus.class);
        when(acceptedStatus.toString()).thenReturn("ACCEPTED");
        when(showRequest.getStatus()).thenReturn(acceptedStatus);

        NumberOfDrones drones = new NumberOfDrones(10);
        ShowDescription desc = new ShowDescription("desc");
        ShowProposalDate date = new ShowProposalDate(LocalDate.of(2024, 6, 1));
        ShowProposalTime time = new ShowProposalTime(LocalTime.of(21, 0));
        ShowProposalDuration duration = new ShowProposalDuration(Duration.ofMinutes(60));
        ShowProposalPlace place = new ShowProposalPlace("Lisbon");

        assertThrows(IllegalArgumentException.class, () -> new ShowProposal(null, ShowProposalStatus.DRAFT, drones, desc, date, time, duration, place));
        assertThrows(IllegalArgumentException.class, () -> new ShowProposal(showRequest, null, drones, desc, date, time, duration, place));
        assertThrows(IllegalArgumentException.class, () -> new ShowProposal(showRequest, ShowProposalStatus.DRAFT, null, desc, date, time, duration, place));
        assertThrows(IllegalArgumentException.class, () -> new ShowProposal(showRequest, ShowProposalStatus.DRAFT, drones, null, date, time, duration, place));
        assertThrows(IllegalArgumentException.class, () -> new ShowProposal(showRequest, ShowProposalStatus.DRAFT, drones, desc, null, time, duration, place));
        assertThrows(IllegalArgumentException.class, () -> new ShowProposal(showRequest, ShowProposalStatus.DRAFT, drones, desc, date, null, duration, place));
        assertThrows(IllegalArgumentException.class, () -> new ShowProposal(showRequest, ShowProposalStatus.DRAFT, drones, desc, date, time, null, place));
        assertThrows(IllegalArgumentException.class, () -> new ShowProposal(showRequest, ShowProposalStatus.DRAFT, drones, desc, date, time, duration, null));
    }

    @Test
    void shouldOnlyAllowAcceptedOrPendingShowRequestStatus() {
        ShowRequest showRequest = mock(ShowRequest.class);
        ShowRequestStatus rejectedStatus = mock(ShowRequestStatus.class);
        when(rejectedStatus.toString()).thenReturn("REJECTED");
        when(showRequest.getStatus()).thenReturn(rejectedStatus);

        NumberOfDrones drones = new NumberOfDrones(10);
        ShowDescription desc = new ShowDescription("desc");
        ShowProposalDate date = new ShowProposalDate(LocalDate.of(2024, 6, 1));
        ShowProposalTime time = new ShowProposalTime(LocalTime.of(21, 0));
        ShowProposalDuration duration = new ShowProposalDuration(Duration.ofMinutes(60));
        ShowProposalPlace place = new ShowProposalPlace("Lisbon");

        assertThrows(IllegalStateException.class, () -> new ShowProposal(showRequest, ShowProposalStatus.DRAFT, drones, desc, date, time, duration, place));
    }

    @Test
    void shouldSetSimulationVideoLink() {
        ShowRequest showRequest = mock(ShowRequest.class);
        ShowRequestStatus acceptedStatus = mock(ShowRequestStatus.class);
        when(acceptedStatus.toString()).thenReturn("ACCEPTED");
        when(showRequest.getStatus()).thenReturn(acceptedStatus);

        ShowProposal proposal = new ShowProposal(
                showRequest,
                ShowProposalStatus.DRAFT,
                new NumberOfDrones(10),
                new ShowDescription("desc"),
                new ShowProposalDate(LocalDate.of(2024, 6, 1)),
                new ShowProposalTime(LocalTime.of(21, 0)),
                new ShowProposalDuration(Duration.ofMinutes(60)),
                new ShowProposalPlace("Lisbon")
        );

        proposal.setSimulationVideoLink(new ShowProposalSimulationVideo("http://video.com/v1"));
        assertEquals("http://video.com/v1", proposal.getSimulationVideoLink().value());
    }

    @Test
    void shouldTestEqualityBasedOnId() {
        ShowRequest showRequest = mock(ShowRequest.class);
        ShowRequestStatus acceptedStatus = mock(ShowRequestStatus.class);
        when(acceptedStatus.toString()).thenReturn("ACCEPTED");
        when(showRequest.getStatus()).thenReturn(acceptedStatus);
        ShowProposal proposal1 = new ShowProposal(
                showRequest,
                ShowProposalStatus.DRAFT,
                new NumberOfDrones(10),
                new ShowDescription("desc1"),
                new ShowProposalDate(LocalDate.of(2024, 6, 1)),
                new ShowProposalTime(LocalTime.of(21, 0)),
                new ShowProposalDuration(Duration.ofMinutes(60)),
                new ShowProposalPlace("Lisbon")
        );
        ShowProposal proposal2 = new ShowProposal(
                showRequest,
                ShowProposalStatus.DRAFT,
                new NumberOfDrones(10),
                new ShowDescription("desc2"),
                new ShowProposalDate(LocalDate.of(2024, 6, 1)),
                new ShowProposalTime(LocalTime.of(21, 0)),
                new ShowProposalDuration(Duration.ofMinutes(60)),
                new ShowProposalPlace("Lisbon")
        );

        var idField = assertDoesNotThrow(() -> ShowProposal.class.getDeclaredField("id"));
        idField.setAccessible(true);
        assertDoesNotThrow(() -> idField.set(proposal1, 1L));
        assertDoesNotThrow(() -> idField.set(proposal2, 1L));

        assertEquals(proposal1, proposal2);
        assertEquals(proposal1.hashCode(), proposal2.hashCode());
    }

    @Test
    void shouldNotBeEqualIfIdIsDifferent() {
        ShowRequest showRequest = mock(ShowRequest.class);
        ShowRequestStatus acceptedStatus = mock(ShowRequestStatus.class);
        when(acceptedStatus.toString()).thenReturn("ACCEPTED");
        when(showRequest.getStatus()).thenReturn(acceptedStatus);

        ShowProposal proposal1 = new ShowProposal(
                showRequest,
                ShowProposalStatus.DRAFT,
                new NumberOfDrones(10),
                new ShowDescription("desc1"),
                new ShowProposalDate(LocalDate.of(2024, 6, 1)),
                new ShowProposalTime(LocalTime.of(21, 0)),
                new ShowProposalDuration(Duration.ofMinutes(60)),
                new ShowProposalPlace("Lisbon")
        );
        ShowProposal proposal2 = new ShowProposal(
                showRequest,
                ShowProposalStatus.DRAFT,
                new NumberOfDrones(10),
                new ShowDescription("desc2"),
                new ShowProposalDate(LocalDate.of(2024, 6, 1)),
                new ShowProposalTime(LocalTime.of(21, 0)),
                new ShowProposalDuration(Duration.ofMinutes(60)),
                new ShowProposalPlace("Lisbon")
        );

        var idField = assertDoesNotThrow(() -> ShowProposal.class.getDeclaredField("id"));
        idField.setAccessible(true);
        assertDoesNotThrow(() -> idField.set(proposal1, 1L));
        assertDoesNotThrow(() -> idField.set(proposal2, 2L));

        assertNotEquals(proposal1, proposal2);
    }

    @Test
    void shouldAddFigureToProposalSuccessfully() {
        ShowProposal proposal = createValidProposal();

        Figure figure = mock(Figure.class);
        when(figure.code()).thenReturn(new Code(1L));

        ShowProposalFigure spf = new ShowProposalFigure(figure, 0);
        spf.setShowProposal(proposal);
        proposal.getFigures().add(spf);

        assertEquals(1, proposal.getFigures().size());
        assertEquals(figure, proposal.getFigures().get(0).getFigure());
        assertEquals(0, proposal.getFigures().get(0).getPosition());
    }

    @Test
    void shouldNotAllowSameFigureInConsecutivePositions() {
        ShowProposal proposal = createValidProposal();

        Figure figure = mock(Figure.class);
        when(figure.code()).thenReturn(new Code(1L));

        ShowProposalFigure first = new ShowProposalFigure(figure, 0);
        first.setShowProposal(proposal);
        proposal.getFigures().add(first);

        ShowProposalFigure second = new ShowProposalFigure(figure, 1);
        second.setShowProposal(proposal);

        boolean violatesConsecutiveRule = false;
        List<ShowProposalFigure> sorted = new ArrayList<>(proposal.getFigures());
        sorted.add(second);
        sorted.sort(Comparator.comparingInt(ShowProposalFigure::getPosition));

        for (int i = 1; i < sorted.size(); i++) {
            if (sorted.get(i).getFigure().equals(sorted.get(i - 1).getFigure())) {
                violatesConsecutiveRule = true;
                break;
            }
        }

        assertTrue(violatesConsecutiveRule, "Should not allow the same figure in consecutive positions");
    }

    @Test
    void shouldNotAllowDuplicatePositions() {
        ShowProposal proposal = createValidProposal();

        Figure figure1 = mock(Figure.class);
        when(figure1.code()).thenReturn(new Code(1L));
        Figure figure2 = mock(Figure.class);
        when(figure2.code()).thenReturn(new Code(2L));

        ShowProposalFigure f1 = new ShowProposalFigure(figure1, 0);
        ShowProposalFigure f2 = new ShowProposalFigure(figure2, 0); // same position

        f1.setShowProposal(proposal);
        f2.setShowProposal(proposal);

        proposal.getFigures().add(f1);
        boolean throwsConflict = proposal.getFigures().stream()
                .anyMatch(f -> f.getPosition() == f2.getPosition());

        assertTrue(throwsConflict, "Should not allow two figures at the same position");
    }

    private ShowProposal createValidProposal() {
        ShowRequest showRequest = mock(ShowRequest.class);
        ShowRequestStatus acceptedStatus = mock(ShowRequestStatus.class);
        when(acceptedStatus.toString()).thenReturn("ACCEPTED");
        when(showRequest.getStatus()).thenReturn(acceptedStatus);

        return new ShowProposal(
                showRequest,
                ShowProposalStatus.DRAFT,
                new NumberOfDrones(5),
                new ShowDescription("Desc"),
                new ShowProposalDate(LocalDate.now()),
                new ShowProposalTime(LocalTime.NOON),
                new ShowProposalDuration(Duration.ofMinutes(60)),
                new ShowProposalPlace("Place")
        );
    }




}