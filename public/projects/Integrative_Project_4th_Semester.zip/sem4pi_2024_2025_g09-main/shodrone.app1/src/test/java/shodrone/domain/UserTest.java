package shodrone.domain;

        import org.junit.jupiter.api.Test;
        import shodrone.customermanagement.Name;
        import shodrone.customermanagement.PhoneNumber;
        import shodrone.usermanagement.Role;
        import shodrone.usermanagement.User;

        import static org.junit.jupiter.api.Assertions.*;
        import static org.mockito.Mockito.*;

        class UserTest {

            private static final Name VALID_NAME = new Name("Test User");
            private static final PhoneNumber VALID_PHONE = new PhoneNumber("911111111");

            @Test
            void shouldCreateValidUser() {
                Role role = mock(Role.class);
                User user = new User("user@showdrone.com", "encrypted", role, true, VALID_NAME, VALID_PHONE);

                assertEquals("user@showdrone.com", user.email());
                assertEquals("encrypted", user.password());
                assertEquals(role, user.role());
                assertTrue(user.isEnabled());
                assertEquals(VALID_NAME, user.getName());
                assertEquals(VALID_PHONE, user.getPhone());
            }

            @Test
            void shouldThrowIfEmailIsNullOrBlank() {
                Role role = mock(Role.class);
                assertThrows(IllegalArgumentException.class, () -> new User(null, "pwd", role, true, VALID_NAME, VALID_PHONE));
                assertThrows(IllegalArgumentException.class, () -> new User("   ", "pwd", role, true, VALID_NAME, VALID_PHONE));
            }

            @Test
            void shouldThrowIfPasswordIsNullOrBlank() {
                Role role = mock(Role.class);
                assertThrows(IllegalArgumentException.class, () -> new User("user@showdrone.com", null, role, true, VALID_NAME, VALID_PHONE));
                assertThrows(IllegalArgumentException.class, () -> new User("user@showdrone.com", "   ", role, true, VALID_NAME, VALID_PHONE));
            }

            @Test
            void shouldThrowIfRoleIsNull() {
                assertThrows(IllegalArgumentException.class, () -> new User("user@showdrone.com", "pwd", null, true, VALID_NAME, VALID_PHONE));
            }

            @Test
            void shouldThrowIfNameIsNull() {
                Role role = mock(Role.class);
                assertThrows(IllegalArgumentException.class, () -> new User("user@showdrone.com", "pwd", role, true, null, VALID_PHONE));
            }

            @Test
            void shouldThrowIfPhoneIsNull() {
                Role role = mock(Role.class);
                assertThrows(IllegalArgumentException.class, () -> new User("user@showdrone.com", "pwd", role, true, VALID_NAME, null));
            }

            @Test
            void shouldActivateAndDeactivateUser() {
                Role role = mock(Role.class);
                User user = new User("user@showdrone.com", "pwd", role, false, VALID_NAME, VALID_PHONE);

                assertFalse(user.isEnabled());
                user.activate();
                assertTrue(user.isEnabled());
                user.deactivate();
                assertFalse(user.isEnabled());
            }

            @Test
            void shouldSetValidEmail() {
                Role role = mock(Role.class);
                User user = new User("user@showdrone.com", "pwd", role, true, VALID_NAME, VALID_PHONE);

                user.setEmail("new@showdrone.com");
                assertEquals("new@showdrone.com", user.email());
            }

            @Test
            void shouldThrowOnInvalidEmailFormat() {
                Role role = mock(Role.class);
                User user = new User("user@showdrone.com", "pwd", role, true, VALID_NAME, VALID_PHONE);

                assertThrows(IllegalArgumentException.class, () -> user.setEmail("invalid-email"));
                assertThrows(IllegalArgumentException.class, () -> user.setEmail(null));
            }

            @Test
            void shouldTestEqualsAndHashCode() {
                Role role = mock(Role.class);
                User user1 = new User("a@showdrone.com", "pwd", role, true, VALID_NAME, VALID_PHONE);
                User user2 = new User("a@showdrone.com", "pwd", role, true, VALID_NAME, VALID_PHONE);

                // Simular mesmo id
                var idField = getIdField();
                setId(user1, 1L);
                setId(user2, 1L);

                assertEquals(user1, user2);
                assertEquals(user1.hashCode(), user2.hashCode());

                setId(user2, 2L);
                assertNotEquals(user1, user2);
            }

            // Helpers para definir o id privado
            private void setId(User user, Long id) {
                try {
                    var field = getIdField();
                    field.setAccessible(true);
                    field.set(user, id);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

            private java.lang.reflect.Field getIdField() {
                try {
                    return User.class.getDeclaredField("id");
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        }