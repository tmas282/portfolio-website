package shodrone.services;

                import org.junit.jupiter.api.Test;
                import static org.junit.jupiter.api.Assertions.*;
                import org.junit.jupiter.api.BeforeAll;
                import org.junit.jupiter.api.function.Executable;
                import org.mockito.Mockito;
                import shodrone.customermanagement.*;
                import shodrone.customerrepresentativemanagement.CustomerRepresentative;
                import shodrone.customerrepresentativemanagement.Position;
                import shodrone.showrequestmanagement.*;

                import java.time.LocalDateTime;

                class ShowRequestServiceTest {
                    private static ShowRequestService showRequestService;

                    @BeforeAll
                    static void setup(){
                        showRequestService = Mockito.mock(ShowRequestService.class);
                    }

                    @Test
                    void createShowRequest() {
                        CustomerRepresentative representative = new CustomerRepresentative(
                                new Email("rep@customer.com"),
                                new Name("João Representante"),
                                new Position("Manager")
                        );
                        Customer c = new Customer(
                                new VAT("PT123124121"),
                                new Name("Tomás"),
                                new Email("tom@s.org"),
                                new Address("espinho"),
                                new PhoneNumber("932941511"),
                                representative,
                                CustomerType.REGULAR
                        );
                        ShowRequestStatus status = new ShowRequestStatus(ShowRequestStatus.ShowRequestStatusOptions.ACCEPTED);
                        ShowRequestDateTime dateTime = new ShowRequestDateTime(LocalDateTime.now());
                        ShowRequestDuration duration = new ShowRequestDuration(25);
                        ShowRequestPlace place = new ShowRequestPlace("spinho");
                        NumberOfDrones numberOfDrones = new NumberOfDrones(1);
                        ShowDescription description = new ShowDescription("BLA BLA");

                        Executable func = () -> showRequestService.createShowRequest(c, status, dateTime, duration, place, numberOfDrones, description);
                        assertDoesNotThrow(func);
                    }

                    @Test
                    void editShowRequest() {
                        CustomerRepresentative representative = new CustomerRepresentative(
                                new Email("rep@customer.com"),
                                new Name("João Representante"),
                                new Position("Manager")
                        );
                        Customer c = new Customer(
                                new VAT("PT123124121"),
                                new Name("Tomás"),
                                new Email("tom@s.org"),
                                new Address("espinho"),
                                new PhoneNumber("932941511"),
                                representative,
                                CustomerType.REGULAR
                        );
                        ShowRequestStatus status = new ShowRequestStatus(ShowRequestStatus.ShowRequestStatusOptions.ACCEPTED);
                        ShowRequestDateTime dateTime = new ShowRequestDateTime(LocalDateTime.now());
                        ShowRequestDuration duration = new ShowRequestDuration(25);
                        ShowRequestPlace place = new ShowRequestPlace("spinho");
                        NumberOfDrones numberOfDrones = new NumberOfDrones(1);
                        ShowDescription description = new ShowDescription("BLA BLA");
                        ShowRequest showRequest = new ShowRequest(c, status, dateTime, duration, place,numberOfDrones, description);
                        showRequestService.editShowRequest(showRequest);
                    }
                }