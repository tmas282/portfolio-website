package shodrone.domain;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import shodrone.dronemaintenancemanagement.*;
import shodrone.dronemanagement.Drone;
import java.time.LocalDate;

import static org.mockito.Mockito.*;

class MaintenanceRecordTest {

    @Test
    void validMaintenanceRecordShouldBeCreated() {
        MaintenanceDate date = new MaintenanceDate(LocalDate.of(2024, 6, 1));
        MaintenanceDescription desc = new MaintenanceDescription("Routine check");
        MaintenanceType type = new MaintenanceType(new MaintenanceTypeDescription("Battery replacement"));
        Drone drone = mock(Drone.class);

        MaintenanceRecord record = new MaintenanceRecord(date, desc, type, drone);

        assertEquals(date, record.getMaintenanceDate());
        assertEquals(desc, record.getMaintenanceDescription());
        assertEquals(type, record.getMaintenanceType());
        // Reflection to check private drone field
        try {
            var field = MaintenanceRecord.class.getDeclaredField("drone");
            field.setAccessible(true);
            assertEquals(drone, field.get(record));
        } catch (Exception e) {
            fail("Drone field not accessible or not set correctly");
        }
    }

    @Test
    void nullFieldsShouldThrow() {
        MaintenanceDate date = new MaintenanceDate(LocalDate.now());
        MaintenanceDescription desc = new MaintenanceDescription("Desc");
        MaintenanceType type = new MaintenanceType(new MaintenanceTypeDescription("Type"));
        Drone drone = mock(Drone.class);

        assertThrows(IllegalArgumentException.class, () -> new MaintenanceRecord(null, desc, type, drone));
        assertThrows(IllegalArgumentException.class, () -> new MaintenanceRecord(date, null, type, drone));
        assertThrows(IllegalArgumentException.class, () -> new MaintenanceRecord(date, desc, null, drone));
        assertThrows(IllegalArgumentException.class, () -> new MaintenanceRecord(date, desc, type, null));
    }

    @Test
    void equalsAndHashCodeContract() {
        MaintenanceDate date = new MaintenanceDate(LocalDate.now());
        MaintenanceDescription desc = new MaintenanceDescription("Desc");
        MaintenanceType type = new MaintenanceType(new MaintenanceTypeDescription("Type"));
        Drone drone = mock(Drone.class);

        MaintenanceRecord record1 = new MaintenanceRecord(date, desc, type, drone);

        // Test reflexivity and hashCode consistency
        assertEquals(record1, record1);
        assertEquals(record1.hashCode(), record1.hashCode());
    }
}