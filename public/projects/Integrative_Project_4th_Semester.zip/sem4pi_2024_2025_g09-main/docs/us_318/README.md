# US318 - Templates for show proposals

## 1. Context

This feature will allow CRM Managers to configure the templates used for documenting a show proposal.

### 1.1 List of issues

- **Analysis**: Understanding the requirements for producing a fine implementation for this use-case.
- **Design**: Defining the architecture and sequence of operations for sending a configuring a template.
- **Implementation**: Implementing the functionality for configuring the templates for show proposals.
- **Tests**: Testing the functionality to ensure proper implementation.

## 2. Requirements

**US316** As a **CRM Manager**, I want to be able to configure the template that formats the document to be sent to the customer.

**Acceptance Criteria:**

- **US316.1** The plugin used to validate the proposal document template must be previously registered in the system.

**Dependencies/References:**

- The plugin used to validate the template

## 3. Analysis

The CRM Manager must indicate a path do the template he/she wants to configur. 
It shall then be validated by the plugin in order for it to be updated in the system.

- 1.Write the path where the template is.
- 2.Validate the configuration using the plugin.
- 3.Register the template in the system.

### 3.1 Refference to artifacts

- **Domain Model**: This use-case is centered around the Show Proposal Management aggregate of the domain model.

## 4. Design

### 4.1 Sequence Diagram

![Sequence Diagram](US318-SD.svg)