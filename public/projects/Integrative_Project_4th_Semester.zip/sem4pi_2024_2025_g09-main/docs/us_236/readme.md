# US236 - Edit show requests

## Context

This feature is part of Shodrone's customer management system. It allows a CRM Collaborator to edit a show requests of a client.

A customer contacts a Shodrone's CRM Collaborator to submit a request for a show. The CRM Collaborator creates the show request into the system. If it is a new customer, it must be created in the system first.
A show request includes the customer, place, time, number of drones requested (tentative) and duration. It also should include the show's description, i.e. a document with the sequence of figures from the Shodrone's catalogue and/or request of new figures, as well as customer's exclusivity requirements. As usual, basic workflow information should also be kept (author of the request, history, etc.)
Whenever new figures have to be created, the CRM Manager assigns each request to a Show Designer that, based on the show request, designs the new figures and add them to the system. The CRM Collaborator is then able to generate a show proposal with the figures the customer desires. If the customer accepts the proposal, the CRM Collaborator updates the status of the request and the proposal, and it goes into production.
Upon acceptance of the show proposal by the customer, the show is scheduled by the CRM team. This probably involves some negotiation with the customer. The date and time are stored in the system.
## Requirements

### User Story

- **As CRM Collaborator**, I want to edit a show requests of a client.


### Acceptance Criteria

- **AC1:** Only show requests without a proposal can be edited.
- **AC2:** The client VAT should be provided.

### Dependencies

- This feature depends on US230 - Register Show request, because is mandatory to exist, at least, one show request.
- This feature depends on US220 - Register customer, as there must be, at least, one customer.

## Design

### Realization

- **Sequence Diagram**:


![sd.svg](sd.svg)