# US325: List maintenance history of a drone

## Context

This feature is part of Shodrone's drone management system. It allows Drone Technicians to view the maintenance history of a specific drone between two dates, providing essential information for tracking and managing drone maintenance.

This feature will be implemented in **Sprint 3**.

## Requirements

### User Story

- **As a Drone Tech**, I want to list a drone's maintenance history between two dates so that I can track and review past maintenance operations.

### Acceptance Criteria

- **US325.1** The system must allow Drone Technicians to view the maintenance history of a specific drone.
- **US325.2** The maintenance history must be filterable by a date range (start date and end date).
- **US325.3** The list must include all maintenance records within the specified date range.
- **US325.4** Each maintenance record in the list must display the date, maintenance type, and description.
- **US325.5** The system must validate that the drone exists before attempting to retrieve its maintenance history.

### Dependencies

- This user story depends on US326 (Add maintenance record to a drone), as maintenance records must be previously registered in the system.

## Analysis

This feature enables Drone Technicians to access and review the maintenance history of drones, which is crucial for ensuring proper maintenance tracking and compliance with safety standards.

**Key Considerations:**
- **Date Range Filtering**: The system must allow filtering maintenance records between two specific dates.
- **Data Validation**: The system must validate that the drone exists and that the date range is valid.
- **Displayed Information**: Each maintenance record should show relevant details such as date, type, and description.

## Design

### Realization

- **Sequence Diagram**: See diagram `ListMaintenanceHistory.puml`, which shows the interactions between UI, Controller, DroneService, repositories, and domain entities.

![ListMaintenanceHistory.svg](ListMaintenanceHistory.svg)

### Applied Design Patterns

- **Layered Architecture**: A separation between presentation, application, domain, and persistence layers was used to organize the code.
- **Repository Pattern**: Used to abstract access to maintenance record data.

### Acceptance Tests

- List maintenance history of a drone with existing maintenance records.
- List maintenance history with a valid date range containing records.
- List maintenance history with a valid date range containing no records.
- Attempt to list maintenance history for a non-existent drone (should fail).
- Attempt to list maintenance history with an invalid date range (end date before start date) (should fail).

## Implementation

### Overview

The feature adds the ability to retrieve and display maintenance records for a specific drone within a given date range. The Drone Technician accesses this functionality through the back-office interface.

- **Key Components**:
  - **MaintenanceRecord Class**: Contains details such as date, maintenance type, description, and association with a **Drone**.
  - **DroneService**: Responsible for retrieving maintenance records based on the drone and date range.
  - **MaintenanceRecordRepository**: Used to fetch maintenance records filtered by drone and date range.
  - **Validation Logic**: Ensures that the drone exists and that the date range is valid.

## Integration / Demonstration

To demonstrate the feature:

1. **Log in** as a Drone Technician.
2. Navigate to the **Drone Management** section.
3. Select a drone and click **View Maintenance History**.
4. Enter the start and end dates for the desired period.
5. View the list of maintenance records within the specified date range.

## Observations

- **Future Improvements**: Add additional filters, such as filtering by maintenance type or sorting options.
- **Alternative Solutions Considered**: Displaying all maintenance records without date filtering was considered but rejected to avoid information overload.

## How to Use the Feature

1. **Log in** to the system with valid Drone Technician credentials.
2. Navigate to the **Drone Management** section.
3. Select a drone from the list.
4. Click on **View Maintenance History**.
5. Enter the start and end dates for the desired period.
6. Click **Search** to view the maintenance records within the specified date range.