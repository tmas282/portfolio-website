# US103 – Project Structure

## 1. Context

This user story aims to ensure that the development team configures the **base project structure** to support an efficient and scalable development process.
The objective is to **facilitate and accelerate** the implementation of upcoming user stories, complying with the architectural and technological decisions defined in the project requirements.

This task is part of **Sprint 1** and is crucial for establishing a solid foundation for the development activities.

### 1.1 List of Tasks

- **Analysis**: Review the project requirements and technical constraints to identify the essential elements of the project structure.
- **Implementation**: Create the base project structure in the repository, including the configuration of the build system and basic dependencies.
- **Testing**: Verify that the structure supports building and executing a simple “Greeter” prototype for both the domain and Customer App modules.
- **Documentation**: Document the structure and guidelines for its use in the docs folder.

---

## 2. Requirements

**US103** – As Project Manager, I want the team to configure the project structure to facilitate/accelerate the
development of upcoming user stories.

### Acceptance Criteria

- **US103.1** – The repository must contain the root folder with subfolders for domain Server and Customer App.
- **US103.2** – A common docs folder must exist for documentation purposes.
- **US103.3** – The project must include a basic Maven configuration (pom.xml) to manage dependencies.
- **US103.4** – The project structure must include support for ANTLR integration.
- **US103.5** – The project must include placeholders for the DSL parser, domain model, and application services.
- **US103.6** – The project must include a working java file implementation that can be built and executed.
- **US103.7** – A README.md file must describe the structure and how to execute the base project.

### Dependencies/References

- Section 5 – Non-Functional Requirements of Sem4PI_Project_Requirements_v01c.pdf
- Figure 4 – System components in Sprint 2 of the same document
- Apache Maven Documentation
- ANTLR Documentation

---

## 3. Analysis

The setup of the project structure requires:

1. Defining a modular architecture that clearly separates domain and Customer App components.
2. Creating a multi-module Maven project with parent pom.xml and child modules for domain and Customer App.
3. Including a docs folder to centralize technical documentation, diagrams, and reports.
4. Configuring ANTLR support in the domain Server module to handle DSL parsing.
5. Adding placeholder packages following DDD principles:
- **5.1** shodrone.src.main.java.application
- **5.2** shodrone.src.main.java.domain
- **5.3** shodrone.src.main.java.persistence
- **5.4** shodrone.src.main.java.presentation
6. Including scripts to build and run a simple prototype, ensuring that the structure works.

---

## 4. Implementation

### 4.1 Project Structure Overview

The project is organized as follows:

- **backoffice/**: Contains all the code related to the domain Server, including domain, application, infrastructure, and presentation layers.
- **customer-app/**: Contains the code for the customer application.
- **docs/**: Directory reserved for documentation, including UML diagrams and reports.
- **pom.xml**: Maven configuration files. There is a main file in the root and a specific file in each module.
- **README.md**: Contains usage, configuration, and execution instructions for the project.


### 4.2 Acceptance Tests


| Test Objective                                      | Acceptance Criteria |
|-----------------------------------------------------|--------------------:|
| Verify project folder structure exists              |             US103.1 |
| Verify docs folder and documentation exists         |             US103.2 |
| Verify Maven build works                            |             US103.3 |
| Verify ANTLR dependency is configured               |             US103.4 |
| Verify domain structure packages exist              |             US103.5 |
| Verify execution of "Greeter" in both modules       |             US103.6 |
| Verify existence of usage instructions in README.md |             US103.7 |



