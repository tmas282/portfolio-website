# US101 – Technical Constraints

## 1. Context

This user story aims to ensure that the team understands and complies with the technical constraints of the project, as defined in Section 5 of the Sem4PI Project Requirements Document.

This is the first time this task is implemented and it must be completed in Sprint 1.

### 1.1 List of issues

Analysis: Interpreting non-functional requirements (NFRs) from the project document.  
Design: Mapping constraints to project architecture, processes, and tooling.  
Implementation: Repository organization, CI setup, documentation tooling.  
Testing: Verifying build scripts, CI pipeline, test coverage feasibility, and documentation generation.

---

## 2. Requirements

**US101** – As Project Manager, I want the team to follow the technical constraints and concerns of the project.

### Acceptance Criteria

- US101.1 – Project must adopt Scrum methodology with documented tasks.
- US101.2 – Documentation must be in Markdown format and include PlantUML diagrams.
- US101.3 – The codebase must support Test-Driven Development (TDD).
- US101.4 – The repository must include CI configuration and support cross-platform scripts.
- US101.5 – Database persistence must be configurable (in-memory or RDBMS).
- US101.6 – Java must be the primary programming language.
- US101.7 – The system must support authentication and authorization mechanisms.
- US101.8 – DSL support must follow LPROG guidelines (ANTLR recommended).
- US101.9 – Simulation system must include multi-threading and process synchronization.

### Dependencies/References

- Section 5 of `Sem4PI_Project_Requirements_v01a.pdf`

---

## 3. Analysis

The analysis of the non-functional requirements reveals their impact across various aspects of the project:

| NFR      | Impact                                                                                |
|----------|---------------------------------------------------------------------------------------|
| NFR01    | The team must organize development in Sprints and hold weekly Scrum meetings.         |
| NFR02    | Requires structured documentation in Markdown and PlantUML.                           |
| NFR03    | Encourages Test-Driven Development approach.                                          |
| NFR04    | Repository and source code management via GitHub.                                     |
| NFR05    | Requires Continuous Integration using GitHub Actions.                                 |
| NFR06    | Necessitates multi-platform build scripts and clear documentation.                    |
| NFR07    | Database configuration must allow switching between in-memory and RDBMS.              |
| NFR08    | Authentication and authorization must be integrated.                                  |
| NFR09    | Java is the primary language; C will be used for simulation.                          |
| NFR10-12 | Future simulation modules will require concurrency, synchronization, and scalability. |

These constraints have direct implications on how the project is structured, how the team works, and how the solution is implemented and tested.

---

## 4. Implementation


### 4.1 Repository Organization

    - `backoffice/`
    - `customer-app/`
    - `docs/`
    - `pom.xml`
    - `README.md


### 4.2 Project Overview


* Document the project structure based on the repository organization.

The project is organized as follows:

- **`backoffice/`**: Contains all the code related to the domain Server, including domain, application, infrastructure, and presentation layers.
- **`customer-app/`**: Contains the code for the customer application.
- **`docs/`**: Directory reserved for documentation, including UML diagrams and reports.
- **`pom.xml`**: Maven configuration files. There is a main file in the root and a specific file in each module.
- **`README.md`**: Contains usage, configuration, and execution instructions for the project.


### 4.2 Continuous Integration Setup

**Create a GitHub Actions workflow file:**

```yaml
# .github/workflows/ci.yml
name: CI

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Set up JDK 11
        uses: actions/setup-java@v4
        with:
          java-version: '11'
          distribution: 'adopt'

      - name: Build with Maven
        run: mvn clean install

      - name: Run tests
        run: mvn test

      - name: Guardar artefacto JAR
        uses: actions/upload-artifact@v4
        with:
          name: shodrone-build
          path: "**/target/*.jar"
```

### 4.3 Documentation Tooling

#### Generate UML diagrams using PlantUML:
```bash
# generate-plantuml-diagrams.sh
#!/bin/bash
plantuml docs/*.puml
```


### 4.4 Acceptance Tests

| Test Objective                                               | Acceptance Criteria |
|--------------------------------------------------------------|---------------------|
| Verify CI Pipeline executes on push                          | US101.4             |
| Validate PlantUML diagram generation                         | US101.2             |
| Test build scripts on Windows and Linux                      | US101.4             |
| Confirm database can be switched between in-memory and RDBMS | US101.5             |

Example test validation:

```bash
# Generate UML diagrams
./generate-plantuml-diagrams.sh

# Verify CI workflow (GitHub Actions)
git push origin main
