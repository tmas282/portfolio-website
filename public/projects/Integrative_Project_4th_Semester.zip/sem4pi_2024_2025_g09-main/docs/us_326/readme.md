# US326: Add maintenance record to a drone

## Context

This feature is part of Shodrone's drone management system. It allows Drone Technicians to add maintenance records to drones, documenting the maintenance operations performed and potentially resetting the usage time counter when appropriate.

This feature will be implemented in **Sprint 3**.

## Requirements

### User Story

- **As a Drone Tech**, I want to add a maintenance record to a given drone so that I can document maintenance operations performed.

### Acceptance Criteria

- **US326.1** The system must allow Drone Technicians to add maintenance records to a specific drone.
- **US326.2** A maintenance record must be associated with an existing maintenance type.
- **US326.3** Some maintenance operations must reset the usage time counter of the drone.
- **US326.4** The system must validate that the drone exists before adding a maintenance record.
- **US326.5** The system must validate that the maintenance type exists before adding a maintenance record.
- **US326.6** The maintenance record must include the date, maintenance type, and description.

### Dependencies

- This user story depends on US327 (Register drone usage time), as the maintenance operations may reset the usage time counter.

## Analysis

This feature enables Drone Technicians to document maintenance operations performed on drones, which is essential for tracking maintenance history and ensuring proper drone maintenance.

**Key Considerations:**
- **Maintenance Types**: The system must support different types of maintenance operations, some of which reset the usage time counter.
- **Usage Time Reset**: When certain maintenance operations are performed, the drone's usage time counter should be reset to zero.
- **Data Validation**: The system must validate that both the drone and maintenance type exist before adding a record.

## Design

### Realization

- **Sequence Diagram**: See diagram `AddMaintenanceRecord.puml`, which shows the interactions between UI, Controller, DroneService, repositories, and domain entities.

![AddMaintenanceRecord.svg](AddMaintenanceRecord.svg)

### Applied Design Patterns

- **Layered Architecture**: A separation between presentation, application, domain, and persistence layers was used to organize the code.
- **Factory Pattern**: Used to create maintenance records with the appropriate attributes.
- **Repository Pattern**: Used to abstract access to drone and maintenance type data.

### Acceptance Tests

- Add a maintenance record with valid data for a maintenance type that does not reset usage time.
- Add a maintenance record with valid data for a maintenance type that resets usage time.
- Verify that the usage time counter is reset when appropriate.
- Attempt to add a maintenance record for a non-existent drone (should fail).
- Attempt to add a maintenance record with a non-existent maintenance type (should fail).
- Verify that the maintenance record includes all required information.

## Implementation

### Overview

The feature adds the ability to create and store maintenance records for drones. The Drone Technician accesses this functionality through the back-office interface.

- **Key Components**:
  - **MaintenanceRecord Class**: Contains details such as date, maintenance type, description, and association with a **Drone**.
  - **MaintenanceType Class**: Defines different types of maintenance operations, including whether they reset the usage time counter.
  - **DroneService**: Responsible for creating maintenance records and resetting the usage time counter when appropriate.
  - **Validation Logic**: Ensures that both the drone and maintenance type exist before adding a record.

## Integration / Demonstration

To demonstrate the feature:

1. **Log in** as a Drone Technician.
2. Navigate to the **Drone Management** section.
3. Select a drone and click **Add Maintenance Record**.
4. Select a maintenance type from the list.
5. Enter a description of the maintenance operation.
6. Submit the form and verify that the maintenance record was added.
7. If the maintenance type resets usage time, verify that the drone's usage time counter has been reset to zero.

## Observations

- **Future Improvements**: Add support for attaching files (e.g., photos, documents) to maintenance records.
- **Alternative Solutions Considered**: Automatically scheduling maintenance based on usage time was considered but deferred to a future release.

## How to Use the Feature

1. **Log in** to the system with valid Drone Technician credentials.
2. Navigate to the **Drone Management** section.
3. Select a drone from the list.
4. Click on **Add Maintenance Record**.
5. Select a maintenance type from the dropdown list.
6. Enter a description of the maintenance operation.
7. Click **Submit** to add the maintenance record.
8. If the maintenance type resets usage time, the drone's usage time counter will be automatically reset to zero.