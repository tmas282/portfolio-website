# US110 - Domain Model

## 1. Context

*This task involves elaborating a Domain Model using Domain-Driven Design (DDD). It is the first time this task is assigned to be developed.*

### 1.1 List of Tasks

- **Analysis**: Understand the business requirements and identify the core domains.
- **Design**: Create the domain model using DDD principles.
- **Implementation**: Implement the domain model in the codebase.
- **Testing**: Verify the domain model aligns with the business requirements.

---

## 2. Requirements

**US110** – As Project Manager, I want the team to elaborate a Domain Model using DDD.

### Acceptance Criteria

- **US110.1** – The domain model must be documented using UML diagrams.
- **US110.2** – The domain model must include entities, value objects, aggregates, and repositories.
- **US110.3** – The domain model must be implemented in the codebase.

### Dependencies/References

- Section 3 – Business Requirements of `Sem4PI_Project_Requirements_v01c.pdf`

---

## 3. Analysis

*The team should analyze the business requirements to identify the core domains and subdomains. The domain model should be designed using DDD principles, ensuring it accurately represents the business logic.*

---

## 4. Implementation

*The implementation involves creating the domain model and documenting it using UML diagrams.*

### 4.1 Domain Model Design

1. **Identify Core Domains and Subdomains:**
    - Analyze the business requirements to identify the core domains and subdomains.

2. **Create UML Diagrams:**
    - Use PlantUML to create UML diagrams representing the domain model.

3. **Implement the Domain Model:**
    - Implement entities, value objects, aggregates, and repositories in the codebase.

### 4.2 Acceptance Tests

| Test Objective                                      | Acceptance Criteria |
|-----------------------------------------------------|--------------------:|
| Verify UML diagrams creation                        |             US110.1 |
| Verify domain model implementation                  |             US110.2 |
| Verify alignment with business requirements         |             US110.3 |

**Example test validation:**

- **Create UML diagrams:**
    - Use PlantUML to create diagrams representing entities, value objects, aggregates, and repositories.

- **Implement domain model:**
    - Implement the identified components in the codebase.

- **Verify alignment:**
    - Ensure the domain model aligns with the business requirements.