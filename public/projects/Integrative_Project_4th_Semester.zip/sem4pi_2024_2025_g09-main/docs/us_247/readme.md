# US247 — List Figure Categories

## 1. Contexto

Permite ao Show Designer listar todas as categorias de figura disponíveis, exibindo nome e status.

### 1.1 Lista de questões

- **Análise**: Exibir categorias ordenadas.
- **Design**: Recuperar dados do repositório.
- **Implementação**: Método simples para buscar todas as categorias.
- **Teste**: Validar que a lista é retornada corretamente.

## 2. Requisitos

**US247** Como **Show Designer**, quero listar todas as categorias de figura ordenadas por nome para facilitar consulta.

**Critérios de Aceitação:**

- US247.1 O sistema deve retornar todas as categorias ordenadas alfabeticamente.
- US247.2 Deve incluir nome e status na exibição.

## 3. Análise

- Método de busca ordenada no repositório.
- Exibir resultado no UI.

### Artefatos de Suporte

- **Diagrama de Caso de Uso**: O Show Designer interage com o sistema para listar todas as categorias de figura.

![Use Case Diagram](svg/UseCaseDiagramExtract-Use_Case_Diagram.svg)

- **Modelo de Domínio**: O modelo de domínio para esta funcionalidade está centrado no **Figure Category Management** e **Figure Management**.

![Domain Model](svg/DomainModelExtract.svg)


## 4. Design

### 4.1 Realização

- UI chama controller que chama service.
- Service invoca repositório para listar ordenado.
- UI mostra lista.

![Sequence Diagram](svg/ListFigureCategories.svg)

### 4.2 Padrões Aplicados

- Separação clara de responsabilidades.

### 4.3 Testes de Aceitação

- Testar retorno da lista com várias categorias.
- Testar retorno vazio.

```java
@Test
void listCategories_NotNull() {
when(repository.findAllByOrderByName_ValueAsc()).thenReturn(Collections.emptyList());

        var result = service.listAllCategories();
        assertNotNull(result);
    }
    
```

```java
    @Test
    void listCategories_ReturnsCorrectIterable() {
        var cat1 = new FigureCategory(new CategoryName("a"), new Description("..."));
        var cat2 = new FigureCategory(new CategoryName("b"), new Description("..."));

        when(repository.findAllByOrderByName_ValueAsc()).thenReturn(List.of(cat1, cat2));

        Iterable<FigureCategory> result = service.listAllCategories();
        assertTrue(result.iterator().hasNext());
    }
```

## 5. Implementação

A implementação inclui:
- **ShowDesignerUI**: Fornece uma interface para o Show Designer listar as categorias.
- **FigureCategoryController**: Lida com pedidos para listar as categorias.
- **FigureCategoryService**: Implementa a lógica de negócio para listar as categorias.

### Principais Commits
- **Commit 1**: `7ca4807c9a524b56b15cfef8339d4c3abda7351d`
- **Commit 2**: `d77f7c19f86db8b478ac51ab4e57dc38a796ad8f`
- **Commit 3**: `5ee3792defefb22c1ebad794416a14b916e32273`


## 6. Integração/Demonstração

Para demonstrar a funcionalidade:

1. Inicie sessão como Show Designer.
2. Utilize o menu para registar uma ou mais categorias.
3. Utilize o menu para listar as categorias.

## 7. Observações

N/A