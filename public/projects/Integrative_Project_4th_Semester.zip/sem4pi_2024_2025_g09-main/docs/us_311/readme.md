# US311 - Add drones to a proposal

## Context

This feature is part of Shodrone's back office app. It allows a CRM Collaborator to configure the list of drone models (number of drones and model) of a show proposal.

A customer contacts a Shodrone’s CRM Collaborator to submit a request for a show. The CRM
Collaborator creates the show request into the system. If it is a new customer, it must be created in
the system first.
A show request includes the customer, place, Ɵme, number of drones requested (tentaƟve) and
duraƟon. It also should include the show’s description, i.e. a document with the sequence of figures
from the Shodrone’s catalogue and/or request of new figures, as well as customer’s exclusivity
requirements. As usual, basic workflow informaƟon should also be kept (author of the request, history,
etc.)
Whenever new figures have to be created, the CRM Manager assigns each request to a Show Designer
that, based on the show request, designs the new figures and add them to the system. The CRM
Collaborator is then able to generate a show proposal with the figures the customer desires. If the
customer accepts the proposal, the CRM Collaborator updates the status of the request and the
proposal, and it goes into production.
Upon acceptance of the show proposal by the customer, the show is scheduled by the CRM team. This
probably involves some negoƟaƟon with the customer. The date and Ɵme are stored in the system.


## Requirements

### User Story

- **As a CRM Collaborator,** I want to configure the list of drone models (number of drones and model) of a show proposal.
The drones in the proposal must be compatible with the drones in the Shodrone’s inventory. 
As such, the number of drones of a given type in a proposal cannot exceed the total number of active drones of that type in the inventory. 
There is no need to verify if these drones are used in another show on the same date.

### Acceptance Criteria

- **AC1:** The drones in the proposal must be compatible with the drones in the Shodrone’s inventory;
- **AC2:** The number of drones of a given type in a proposal cannot exceed the total number of active drones of that type in the inventory.;

### Dependencies

- US310 - Create Show Proposal: As there must exist a show proposal to download.

## Design

### Realization

- **Sequence Diagram**:


![sd.svg](sd.svg)