# US246 — Edit Figure Category

## 1. Contexto

Esta funcionalidade permite ao Show Designer editar uma categoria existente, alterando seu nome e descrição, garantindo que as novas informações também sejam únicas.

### 1.1 Lista de questões

- **Análise**: Permitir atualização sem quebrar unicidade.
- **Design**: Atualizar atributos e validar conflitos.
- **Implementação**: Desenvolver serviço e UI para edição.
- **Teste**: Validar erros e sucesso na edição.

## 2. Requisitos

**US246** Como **Show Designer**, quero editar o nome e a descrição de uma categoria de figura, respeitando a unicidade.

**Critérios de Aceitação:**

- US246.1 O sistema deve permitir alterar o nome e descrição de uma categoria.
- US246.2 O sistema deve validar que o novo nome e descrição são únicos.
- US246.3 O sistema deve persistir a categoria atualizada.
- US246.4 Deve retornar erro caso a categoria original não exista.

## 3. Análise

- Buscar a categoria pelo nome atual.
- Verificar se novo nome e descrição já existem em outras categorias.
- Atualizar atributos via métodos do domínio.
- Salvar no repositório.

### Artefatos de Suporte

- **Diagrama de Caso de Uso**: O Show Designer interage com o sistema para editar uma categoria de figura.

![Use Case Diagram](svg/UseCaseDiagramExtract-Use_Case_Diagram.svg)

- **Modelo de Domínio**: O modelo de domínio para esta funcionalidade está centrado no **Figure Category Management** e **Figure Management**.

![Domain Model](svg/DomainModelExtract.svg)

## 4. Design

### 4.1 Realização

- UI solicita nome atual, novo nome e nova descrição.
- Controller e Service processam a edição.
- Validações de unicidade são feitas no Service.
- Salva no repositório.

![Sequence Diagram](svg/EditFigureCategory.svg)

### 4.2 Padrões Aplicados

- Mesmos padrões da US245, com ênfase em validação de estado existente.
- Uso do Aggregate Root para manter consistência.

### 4.3 Testes de Aceitação

- Teste de sucesso na edição.
- Teste de erro se categoria não existir.
- Teste de erro se novo nome ou descrição já existirem.

```java
@Test
void editCategory_Success() {
FigureCategory category = new FigureCategory(new CategoryName("original"), new Description("old desc"));

        when(repository.findByName_ValueIgnoreCase("original")).thenReturn(Optional.of(category));
        when(repository.findByName_ValueIgnoreCase("new")).thenReturn(Optional.empty());
        when(repository.findByDescription_TextIgnoreCase("new desc")).thenReturn(Optional.empty());

        service.editFigureCategory("original", "new", "new desc");

        assertEquals("new", category.name().value());
        assertEquals("new desc", category.description().value());
        verify(repository).save(category);
    }
```
```java
    @Test
    void editCategory_NotFound() {
        when(repository.findByName_ValueIgnoreCase("missing")).thenReturn(Optional.empty());

        var ex = assertThrows(IllegalArgumentException.class, () ->
                service.editFigureCategory("missing", "new", "desc")
        );
        assertEquals("Category not found: missing", ex.getMessage());
    }
```
```java
    @Test
    void editCategory_DuplicateNewName() {
        FigureCategory current = new FigureCategory(new CategoryName("current"), new Description("old"));
        FigureCategory duplicate = new FigureCategory(new CategoryName("new"), new Description("other"));

        when(repository.findByName_ValueIgnoreCase("current")).thenReturn(Optional.of(current));
        when(repository.findByName_ValueIgnoreCase("new")).thenReturn(Optional.of(duplicate));

        var ex = assertThrows(IllegalArgumentException.class, () ->
                service.editFigureCategory("current", "new", "updated desc")
        );
        assertEquals("Another category with the new name already exists.", ex.getMessage());
    }
```
```java
    @Test
    void editCategory_DescriptionAlreadyExists() {
        FigureCategory current = new FigureCategory(new CategoryName("X"), new Description("desc1"));
        FigureCategory conflicting = new FigureCategory(new CategoryName("Other"), new Description("desc2"));

        when(repository.findByName_ValueIgnoreCase("X")).thenReturn(Optional.of(current));
        when(repository.findByName_ValueIgnoreCase("New")).thenReturn(Optional.empty());
        when(repository.findByDescription_TextIgnoreCase("desc2")).thenReturn(Optional.of(conflicting));

        var ex = assertThrows(IllegalArgumentException.class, () ->
                service.editFigureCategory("X", "New", "desc2")
        );
        assertEquals("Another category with the same description already exists.", ex.getMessage());
    }

```
```java
    @Test
    void editCategory_BlankInputs() {
        assertThrows(IllegalArgumentException.class, () ->
                service.editFigureCategory(" ", "   ", " ")
        );
    }
```

## 5. Implementação

A implementação inclui:
- **ShowDesignerUI**: Fornece uma interface para o Show Designer editar as categorias.
- **FigureCategoryController**: Lida com pedidos para editar as categorias.
- **FigureCategoryService**: Implementa a lógica de negócio para editar as categorias.

### Principais Commits
- **Commit 1**: `0e06ff9cfb5abf073b0376930bee20356c160ba7`
- **Commit 2**: `77bf9ab698cdf5c2c2463a48d860f23e0987dd9d`
- **Commit 3**: `f86117e84c8ae5415b39cb1790088a926ec3ba49`


## 6. Integração/Demonstração

Para demonstrar a funcionalidade:

1. Inicie sessão como Show Designer.
2. Utilize o menu para registar uma ou mais categoria.
3. Utilize o menu para editar uma categoria.
4. Verifique que a categoria foi atualizada corretamente fora do sistema.

## 7. Observações

N/A