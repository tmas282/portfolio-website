# US371 - Accept/reject proposal

## 1. Context

This feature will allow customers to accept or reject a show proposal that was previously sent to them by a CRM Collaborator. 
After a customer has gone through the process of requesting a show, a show proposal will be sent to them via the Customer App using TCP. 
After that, the customer will need to analyze the proposal and then choose whether to accept or reject that proposal.

### 1.1 List of issues

- **Analysis**: Understanding the requirements involving the production of a fine implementation for this use-case.
- **Design**: Defining the architecture and sequence of operations for making it possible for a customer to respond to a proposal.
- **Implementation**: Implementing the functionalities involving this use-case.
- **Tests**: Testing the functionality to ensure proper implementation.

## 2. Requirements

**US371** As a **Customer**, I want to accept/reject a proposal using the Customer App. I may provide feedback.

**Acceptance Criteria:**

- **US371.1** It has to be made possible for the customers to send feedback if they want to.

**Dependencies/References:**

- US310 - As there must be ShowProposals
- US316 - As the "Send ShowProposal" functionality must exist for one to reach the customers.
- US370 - As the customers need to see the proposal so that they can respond to it.

## 3. Analysis

A server-client TCP connection will allow the customer to respond to the proposal. First the customer will enter the Customer app. 
Then he/she will check his/her ShowProposals and then respond to it, when the server receives the response, it will update the status of the proposal 
according to the response. If the customer opts to send feedback, the feedback will be sent via TCP, when the feedback reaches the server, 
it will be saved in an appropriate location, the name of the file will follow the template: proposal_feedback_<proposal_id>_<date>.txt

### 3.1 Refference to artifacts

- **Domain Model**: This use-case is centered around the Show Proposal Management aggregate of the domain model.

