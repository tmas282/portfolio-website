# US233 - Add Figure to the catalogue

## 1. Context

This functionality is crucial for the design of show request proposals because figures are one of the vital parts of a show.

### 1.1 List of issues

- **Analysis:** This feature will support the registration of a new figure in the figure catalogue.
- **Design:** It is necessary to implement a functionality that lets Show designers add figures to the public catalogue.
- **Implementation:** A new Figure java class will be made to represent a figure.
- **Test:** Unit tests will be created in-order to the insertion of figures in the catalogue.

## 2. Requirements

**US233:** As Show designer I want to add a figure to the public catalogue.

### 2.1 Acceptence Criteria

- **AC1:** Figures are classified with a category and a set of keywords.
- **AC2:** If a figure is custom-made to a customer’s request it is not public and can only be used in shows for that customer.

## 3. Analysis

This feature will enable Show Designers to add new public figures to the public figures catalogue, which will then be used in show request proposals.

### 3.1 Reference to global artifacts

#### Domain model

This user story will be mainly represented by the Figure Management aggregate of the domain model

#### Use case diagram

This user story will encompass the create figure use case, carried out by the Show Designer


## 4. Design

### Sequence Diagram

![Sequence Diagram - Full](US233-SD.svg)