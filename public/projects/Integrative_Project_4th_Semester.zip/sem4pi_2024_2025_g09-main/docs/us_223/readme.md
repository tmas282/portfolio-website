# US223: Edit a Customer Representative

## Context

This feature is part of Shodrone's customer management system. It allows a CRM Collaborator to edit the information of a customer representative, ensuring that only the email and phone number can be updated. Other information, such as name and position, remains unchanged.

## Requirements

### User Story

- **As a CRM Collaborator**, I want to edit the information (email and phone number) of a customer representative to keep the data up to date.

### Acceptance Criteria

- **US223.1** The system must allow editing the email and phone number of a customer representative.
- **US223.2** The system must not allow editing other information, such as name and position.
- **US223.3** The edited email must be unique in the system.
- **US223.4** Disabled representatives cannot be edited.

### Dependencies

- This feature depends on US221 (Add Customer Representative), as representatives must be previously registered in the system.

## Analysis

This feature ensures that the contact details of customer representatives can be efficiently updated while maintaining data integrity in the system.

**Key Considerations:**
- **Email uniqueness validation**: The system must ensure that the edited email is not associated with another user.
- **Disabled representatives**: Cannot be edited, ensuring that only active representatives are kept up to date.

## Design

### Realization

- **Sequence Diagram**:
![EditCustomerRepresentative.svg](EditCustomerRepresentative.svg)

### Applied Design Patterns

- **Factory Pattern**: Used to create repositories, ensuring consistency in object creation.
- **Repository Pattern**: Used to abstract access to customer representative data.

## Implementation Details

- If the email is updated, a new representative is created with the updated email, and the old representative is removed.
- The phone number can be updated directly without creating a new representative.
- The system validates that the new email is unique before proceeding with the update.
- Disabled representatives cannot be edited, and an exception is thrown if an attempt is made.

## Acceptance Tests

- Edit the email and phone number of an active representative with valid data.
- Attempt to edit the email to one that already exists in the system.
- Ensure that disabled representatives cannot be edited.
- Verify that only the email and phone number can be updated.
- Confirm that a new representative is created when the email is updated, and the old one is removed.

## Observations

- **Future Improvements**: A feature to notify the representative about the changes made could be implemented.
- **Alternative Solutions Considered**: Allowing the editing of other information, such as name and position, was discarded to avoid inconsistencies.

## How to Use the Feature

1. **Log in** to the system with valid CRM Collaborator credentials.
2. Navigate to the **Customer Representative Management** section.
3. Select the representative to be edited.
4. Update the email and/or phone number and submit the changes.
5. The system will confirm the successful update.