# US104 – Continuous Integration Server Setup

## 1. Context

This user story aims to ensure that the development team configures a **Continuous Integration (CI)** environment using **GitHub Actions/Workflows**.  
The goal is to automatically build and test the project at every code change, ensuring software stability and early detection of integration problems.

This task is part of **Sprint 1** and is fundamental to establishing the project's development workflow.

### 1.1 List of Tasks

- **Analysis**: Identify the continuous integration needs defined in the project requirements.
- **Implementation**: Create and configure the CI workflow in `.github/workflows/ci.yml`.
- **Testing**: Verify that the CI workflow is correctly triggered and that build and test steps execute successfully.
- **Documentation**: Record the workflow configuration in the project documentation.

---

## 2. Requirements

**US104** – As Project Manager, I want the team to set up a continuous integration server.

### Acceptance Criteria

- **US104.1** – The CI workflow must be triggered on each `push` or `pull_request` to the `main` branch.
- **US104.2** – The workflow must check out the repository code.
- **US104.3** – The workflow must set up **JDK 11**.
- **US104.4** – The workflow must build the project using **Maven**.
- **US104.5** – The workflow must run all project tests.
- **US104.6** – The workflow execution status must be visible in the repository's **Actions** tab.

### Dependencies/References

- Section 5 – Non-Functional Requirements of `Sem4PI_Project_Requirements_v01a.pdf`
- [GitHub Actions Documentation](https://docs.github.com/en/actions)

---

## 3. Analysis

Setting up the Continuous Integration server involves automating key development processes to ensure consistent software quality.

The GitHub Actions/Workflows configuration requires:

1. Defining triggers on `push` and `pull_request` events to the `main` branch.
2. Checking out the project repository to access the source code.
3. Installing **JDK 11** (Temurin distribution).
4. Building the project with **Maven**.
5. Running all defined tests.
6. Making the workflow status available to all contributors.

This setup guarantees that any integration issues are detected early and increases project reliability.

---

## 4. Implementation

### 4.1 Workflow Configuration

The workflow configuration file is located at `.github/workflows/ci.yml`.  

### 4.2 Acceptance Tests


| Test Objective                                           | Acceptance Criteria |
|----------------------------------------------------------|--------------------:|
| Verify CI workflow triggers on `push` and `pull_request` |             US104.1 |
| Verify repository checkout in workflow                   |             US104.2 |
| Verify JDK 11 setup                                      |             US104.3 |
| Verify Maven build execution                             |             US104.4 |
| Verify test execution                                    |             US104.5 |
| Verify workflow status in Actions tab                    |             US104.6 |


Example test validation:

```bash
# Trigger CI by pushing a commit
git commit -m "Test CI pipeline"
git push origin main

# Verify in GitHub > Actions tab
