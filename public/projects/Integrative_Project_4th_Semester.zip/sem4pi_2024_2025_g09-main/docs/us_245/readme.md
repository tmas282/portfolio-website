# US245 — Add Figure Category

## 1. Contexto

Esta funcionalidade permite ao Show Designer adicionar uma nova categoria de figura no sistema, definindo o nome e a descrição. O sistema garante que o nome e a descrição sejam únicos.

### 1.1 Lista de questões

- **Análise**: Garantir a unicidade do nome e descrição da categoria.
- **Design**: Definir o fluxo para validação e persistência da nova categoria.
- **Implementação**: Desenvolver o serviço, controlador e UI para adicionar categorias.
- **Teste**: Garantir a validação e persistência correta através de testes unitários.

## 2. Requisitos

**US245** Como **Show Designer**, quero adicionar uma categoria de figura com nome e descrição únicos para organizar figuras no sistema.

**Critérios de Aceitação:**

- US245.1 O sistema deve validar que o nome da categoria é único.
- US245.2 O sistema deve validar que a descrição da categoria é única.
- US245.3 O sistema deve persistir a categoria com estado ativo e data de criação atual.
- US245.4 A categoria deve poder ser visualizada após a criação.

## 3. Análise

- Verificar se já existe categoria com nome ou descrição iguais.
- Criar uma nova entidade FigureCategory com nome, descrição, status ativo e data atual.
- Persistir a nova entidade via repositório.
- Validar entrada para não permitir valores vazios.

### Artefatos de Suporte

- **Diagrama de Caso de Uso**: O Show Designer interage com o sistema para registar uma categoria de figura.

![Use Case Diagram](svg/UseCaseDiagramExtract-Use_Case_Diagram.svg)

- **Modelo de Domínio**: O modelo de domínio para esta funcionalidade está centrado no **Figure Category Management** e **Figure Management**.

![Domain Model](svg/DomainModelExtract.svg)

## 4. Design

### 4.1 Realização

- ShowDesignerUI coleta nome e descrição.
- Chama FigureCategoryController.addCategory(nome, descrição).
- Controller chama FigureCategoryService.addFigureCategory(nome, descrição).
- Service valida unicidade via FigureCategoryRepository.
- Cria FigureCategory e salva.
- UI confirma sucesso ou exibe erro.

![Sequence Diagram](svg/AddFigureCategory.svg)

### 4.2 Padrões Aplicados

- **Controller**: Separação da camada de apresentação da lógica.
- **Information Expert**: Service contém a lógica de negócio para validar e criar.
- **Transactional Service**: Método `addFigureCategory` é transacional.
- **Validation**: Garantia de unicidade e dados válidos.

### 4.3 Testes de Aceitação

- Teste de sucesso adicionando categoria com nome e descrição únicos.
- Teste de falha se nome já existir.
- Teste de falha se descrição já existir.
- Teste de falha se nome ou descrição vazios.


```java
@Test
void addCategory_Success() {
    when(repository.findByName_ValueIgnoreCase("design")).thenReturn(Optional.empty());

    service.addFigureCategory("design", "Base category for shapes");

    verify(repository).save(any(FigureCategory.class));
}
```

```java
@Test
void addCategory_AlreadyExists() {
    when(repository.findByName_ValueIgnoreCase("duplicate")).thenReturn(Optional.of(mock(FigureCategory.class)));

    var ex = assertThrows(IllegalArgumentException.class, () ->
            service.addFigureCategory("duplicate", "ignored")
    );
    assertEquals("A category with this name already exists.", ex.getMessage());
}
```

```java
@Test
    void addCategory_BlankName() {
        var ex = assertThrows(IllegalArgumentException.class, () ->
                service.addFigureCategory("  ", "Valid")
        );
        assertTrue(ex.getMessage().toLowerCase().contains("name"));
    }
```

```java
    @Test
    void addCategory_NullDescription() {
        var ex = assertThrows(IllegalArgumentException.class, () ->
                service.addFigureCategory("unique", null)
        );
        assertTrue(ex.getMessage().toLowerCase().contains("description"));
    }
```

```java
    @Test
    void addCategory_DuplicateDescription() {
        when(repository.findByName_ValueIgnoreCase("new")).thenReturn(Optional.empty());
        when(repository.findByDescription_TextIgnoreCase("same desc"))
                .thenReturn(Optional.of(mock(FigureCategory.class)));

        var ex = assertThrows(IllegalArgumentException.class, () ->
                service.addFigureCategory("new", "same desc")
        );
        assertEquals("A category with this description already exists.", ex.getMessage());
    }
```

## 5. Implementação

A implementação inclui:
- **ShowDesignerUI**: Fornece uma interface para o Show Designer registar as categorias.
- **FigureCategoryController**: Lida com pedidos para registar as categorias.
- **FigureCategoryService**: Implementa a lógica de negócio para registar as categorias.

### Principais Commits
- **Commit 1**: `d8f76636e2c761b2b7374cf176b56e5d1e2deedc`
- **Commit 2**: `b585c7472f3d7a8a864911a27ce675a09db5c0b7`
- **Commit 3**: `fb05d88eb1ceaadb6310a4888d797deb4a3bcbf3`


## 6. Integração/Demonstração

Para demonstrar a funcionalidade:

1. Inicie sessão como Show Designer.
2. Utilize o menu para registar uma ou mais categoria. .
3. Verifique que a categoria foi registada corretamente fora do sistema.

## 7. Observações

N/A