# US102 - Project Repository

## 1. Context

*This task involves setting up a GitHub project board for project management. It is the first time this task is assigned to be developed.*

### 1.1 List of Tasks

- **Analysis**: Identify the tools that best suit the team's needs for project management.
- **Implementation**: Create the repository and configure the project management tool.
- **Testing**: Verify that the tool works for everyone's needs.

---

## 2. Requirements

**US102** – As Project Manager, I want the team to use the defined project repository in GitHub and set up a GitHub tool for project management.

### Acceptance Criteria

- **US102.1** – The GitHub tool must be a GitHub Project with a board.

### Dependencies/References

- Section 4 – Non-Functional Requirements of `Sem4PI_Project_Requirements_v01c.pdf`

---

## 3. Analysis

*The team should analyze the best practices for setting up a GitHub project board and how it can be integrated with the existing workflow.*

---

## 4. Implementation

*The implementation involves creating the project board in the GitHub repository and setting up the columns.*

### 4.1 Project Board Setup

1. **Create a new GitHub Project:**
    - Navigate to the repository on GitHub.
    - Go to the "Projects" tab.
    - Click "New Project" and select "Board".

2. **Configure the project board:**
    - Add columns such as "To Do", "In Progress", and "Done".
    - Add cards for tasks and user stories.

### 4.2 Acceptance Tests

| Test Objective                                      | Acceptance Criteria |
|-----------------------------------------------------|--------------------:|
| Verify project board creation                       |             US102.1 |
| Verify columns setup                                |             US102.1 |
| Verify task cards creation                          |             US102.1 |

**Example test validation:**

- **Create a new project board:**
    - Navigate to the repository on GitHub.
    - Go to the "Projects" tab.
    - Click "New Project" and select "Board".

- **Set up columns:**
    - Add columns such as "To Do", "In Progress", and "Done".

- **Add task cards:**
    - Create cards for tasks and user stories.