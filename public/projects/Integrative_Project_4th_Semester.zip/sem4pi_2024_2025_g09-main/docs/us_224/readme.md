# US224: Disable a Customer Representative

## Context

This feature is part of Shodrone's customer management system. It allows a CRM Collaborator to disable a customer representative, ensuring they are no longer contacted or associated with new interactions in the system.

## Requirements

### User Story

- **As a CRM Collaborator**, I want to disable a customer representative to ensure they are no longer contacted or associated with new interactions.

### Acceptance Criteria

- **US224.1** The system must allow disabling a customer representative.
- **US224.2** Disabled representatives must not be listed in future interactions.

### Dependencies

- This feature depends on US221 (Add Customer Representative), as representatives must be previously registered in the system.

## Analysis

This feature ensures that customer representatives can be efficiently disabled, maintaining data integrity and preventing future interactions with disabled representatives.

**Key Considerations:**
- **Logical deletion**: Disabled representatives are not removed from the system but are marked as inactive.

## Design

### Realization

- **Sequence Diagram**:


![DisableCustomerRepresentative.svg](DisableCustomerRepresentative.svg)


### Applied Design Patterns

- **Repository Pattern**: Used to abstract access to customer representative and user data.
- **Domain-Driven Design (DDD)**: Applied to encapsulate the deactivation logic in the domain.

## Acceptance Tests

- Disable an active representative with valid data.
- Ensure disabled representatives do not appear in future listings.

## How to Use the Feature

1. **Log in** to the system with valid CRM Collaborator credentials.
2. Navigate to the **Customer Representative Management** section.
3. Select the representative to be disabled.
4. Confirm the action.
5. The system will confirm the successful deactivation.