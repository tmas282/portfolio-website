# US232 - Search Figure catalogue

## 1. Context

This functionality will help the CRM Collaborator search the figure catalogue in an organized way.

### 1.1 List of issues

- **Analysis:** The system needs to have the figures organized in a way that will let the CRM Collaborator search for them
- **Design:** It is necessary to implement a functionality that lets CRM Collaborators search for a figure 
- **Implementation:** The search will be made to the FigureRepository and the figures matching the criteria will be retrieved
- **Test:** Unit tests will be created in-order to validate that the criteria matches

## 2. Requirements

**US233:** As Show designer I want to add a figure to the public catalogue.

### 2.1 Acceptence Criteria

- **AC1:** The search should ignore accents and shouldn’t be case-sensitive.

### 2.2 Dependencies

- **US233:** As it doesn't make sense for a search to be made on an empty catalogue

## 3. Analysis

This feature will help the CRM Collaborators keep track of the figures in existence in an organized way.

### 3.1 Reference to global artifacts

#### Domain model

This user story will be mainly represented by the Figure Management aggregate of the domain model

#### Use case diagram

This user story will encompass the browse catalogue use case, carried out by the CRM Collaborator


## 4. Design

### Sequence Diagram

![Sequence Diagram - Full](US232-SD.svg)

