# US328: List drones needing preventive maintenance

## Context

This feature is part of Shodrone's drone management system. It allows Drone Technicians to identify drones that require preventive maintenance based on their usage time exceeding the maintenance threshold defined for their model.

This feature will be implemented in **Sprint 3**.

## Requirements

### User Story

- **As a Drone Tech**, I want to list all drones requiring preventive maintenance on a given date so that I can plan and schedule maintenance operations.

### Acceptance Criteria

- **US328.1** The system must allow Drone Technicians to list all drones requiring preventive maintenance on a specific date.
- **US328.2** A drone requires preventive maintenance when its usage time exceeds the maintenance threshold defined for its model.
- **US328.3** The list must include the drone's serial number, model, current usage time, and maintenance threshold.
- **US328.4** The system must validate that the date is valid.

### Dependencies

- This user story depends on US327 (Register drone usage time), as the usage time is used to determine when preventive maintenance is required.
- This user story is also related to US326 (Add maintenance record to a drone), as preventive maintenance operations are recorded as maintenance records.

## Analysis

This feature enables Drone Technicians to proactively identify drones that require preventive maintenance, which is essential for ensuring drone reliability and safety.

**Key Considerations:**
- **Maintenance Threshold**: Each drone model has a defined maintenance threshold (in hours) that determines when preventive maintenance is required.
- **Usage Time Comparison**: The system compares the current usage time of each drone with the maintenance threshold of its model.
- **Date Filtering**: The system allows filtering drones requiring maintenance on a specific date, which helps in planning maintenance operations.

## Design

### Realization

- **Sequence Diagram**: See diagram `ListDronesNeedingMaintenance.puml`, which shows the interactions between UI, Controller, DroneService, repositories, and domain entities.

![ListDronesNeedingMaintenance.svg](ListDronesNeedingMaintenance.svg)

### Applied Design Patterns

- **Layered Architecture**: A separation between presentation, application, domain, and persistence layers was used to organize the code.
- **Repository Pattern**: Used to abstract access to drone and drone model data.
- **Strategy Pattern**: Used to implement the logic for determining which drones require maintenance.

### Acceptance Tests

- List drones requiring maintenance on a valid date.
- Verify that only drones with usage time exceeding the maintenance threshold are included in the list.
- Verify that the list includes all required information (serial number, model, usage time, threshold).
- Attempt to list drones requiring maintenance with an invalid date (should fail).
- Verify that drones with usage time below the maintenance threshold are not included in the list.

## Implementation

### Overview

The feature adds the ability to identify and list drones that require preventive maintenance. The Drone Technician accesses this functionality through the back-office interface.

- **Key Components**:
  - **Drone Class**: Contains the usage time counter that is compared with the maintenance threshold.
  - **DroneModel Class**: Defines the maintenance threshold for each drone model.
  - **DroneService**: Responsible for identifying drones that require preventive maintenance.
  - **Validation Logic**: Ensures that the date is valid and that the comparison between usage time and maintenance threshold is accurate.

## Integration / Demonstration

To demonstrate the feature:

1. **Log in** as a Drone Technician.
2. Navigate to the **Drone Management** section.
3. Click on **List Drones Needing Maintenance**.
4. Enter the date for which to check maintenance requirements.
5. View the list of drones requiring preventive maintenance, including their serial number, model, usage time, and maintenance threshold.

## Observations

- **Future Improvements**: Add support for automatically scheduling maintenance operations for drones requiring preventive maintenance.
- **Alternative Solutions Considered**: Implementing a notification system to alert Drone Technicians when drones approach their maintenance threshold was considered but deferred to a future release.

## How to Use the Feature

1. **Log in** to the system with valid Drone Technician credentials.
2. Navigate to the **Drone Management** section.
3. Click on **List Drones Needing Maintenance**.
4. Enter the date for which to check maintenance requirements.
5. Click **Search** to view the list of drones requiring preventive maintenance.
6. The list will display each drone's serial number, model, current usage time, and maintenance threshold.
7. Use this information to plan and schedule maintenance operations for the identified drones.