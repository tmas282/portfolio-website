# US248 — Activate/Deactivate Figure Category

## 1. Contexto

Permite ao Show Designer ativar ou desativar categorias de figura, alterando seu status.

### 1.1 Lista de questões

- **Análise**: Alterar status da categoria.
- **Design**: Método toggle com validação do estado atual.
- **Implementação**: Serviços para ativar e desativar.
- **Teste**: Validar estados válidos e erros.

## 2. Requisitos

**US248** Como **Show Designer**, quero ativar ou desativar categorias para controlar sua disponibilidade.

**Critérios de Aceitação:**

- US248.1 O sistema deve permitir ativar categorias inativas.
- US248.2 O sistema deve permitir desativar categorias ativas.
- US248.3 Deve impedir ativar categorias já ativas e vice-versa.
- US248.4 Persistir alteração de status.

## 3. Análise

- Buscar categoria pelo nome.
- Verificar status atual.
- Alterar status e salvar.

### Artefatos de Suporte

- **Diagrama de Caso de Uso**: O Show Designer interage com o sistema para ativar/desativar uma categoria de figura.

![Use Case Diagram](svg/UseCaseDiagramExtract-Use_Case_Diagram.svg)

- **Modelo de Domínio**: O modelo de domínio para esta funcionalidade está centrado no **Figure Category Management** e **Figure Management**.

![Domain Model](svg/DomainModelExtract.svg)


## 4. Design

### 4.1 Realização

- UI coleta nome e ação (ativar/desativar).
- Controller chama service.
- Service executa validação e atualização.
- Salva estado.

![Sequence Diagram](svg/InactivateOrActivateAFigureCategory.svg)

### 4.2 Padrões Aplicados

- Uso de enum para status.
- Validação no domínio.

### 4.3 Testes de Aceitação

- Testar ativar categoria inativa com sucesso.
- Testar erro ao ativar categoria já ativa.
- Testar desativar categoria ativa com sucesso.
- Testar erro ao desativar categoria já inativa.

```java
@Test
void activateCategory_Success() {
FigureCategory cat = new FigureCategory(new CategoryName("test"), new Description("..."));
cat.deactivate();

        when(repository.findByName_ValueIgnoreCase("test")).thenReturn(Optional.of(cat));

        service.activateCategory("test");

        assertTrue(cat.status().isActive());
        verify(repository).save(cat);
    }
```

```java
    @Test
    void activateCategory_AlreadyActive() {
        FigureCategory cat = new FigureCategory(new CategoryName("x"), new Description("..."));
        when(repository.findByName_ValueIgnoreCase("x")).thenReturn(Optional.of(cat));

        var ex = assertThrows(IllegalArgumentException.class, () ->
                service.activateCategory("x")
        );
        assertEquals("Category is already active.", ex.getMessage());
    }
```

```java
    @Test
    void deactivateCategory_Success() {
        FigureCategory cat = new FigureCategory(new CategoryName("test"), new Description("..."));

        when(repository.findByName_ValueIgnoreCase("test")).thenReturn(Optional.of(cat));

        service.deactivateCategory("test");

        assertFalse(cat.status().isActive());
        verify(repository).save(cat);
    }
```

```java
    @Test
    void deactivateCategory_AlreadyInactive() {
        FigureCategory cat = new FigureCategory(new CategoryName("x"), new Description("..."));
        cat.deactivate();

        when(repository.findByName_ValueIgnoreCase("x")).thenReturn(Optional.of(cat));

        var ex = assertThrows(IllegalArgumentException.class, () ->
                service.deactivateCategory("x")
        );
        assertEquals("Category is already inactive.", ex.getMessage());
    }
```

```java
    @Test
    void toggleCategory_NotFound() {
        when(repository.findByName_ValueIgnoreCase("invalid")).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class, () ->
                service.activateCategory("invalid")
        );
        assertThrows(IllegalArgumentException.class, () ->
                service.deactivateCategory("invalid")
        );
    }
```


## 5. Implementação

A implementação inclui:
- **ShowDesignerUI**: Fornece uma interface para o Show Designer alterar o estado das categorias.
- **FigureCategoryController**: Lida com pedidos de alteração de estado das categorias.
- **FigureCategoryService**: Implementa a lógica de negócio para ativar e desativar categorias.

### Principais Commits
- **Commit 1**: `7ca4807c9a524b56b15cfef8339d4c3abda7351d`
- **Commit 2**: `8df8c09f2a00f14aa28fd8957faa1d633e21ba5a`
- **Commit 3**: `5ee3792defefb22c1ebad794416a14b916e32273`


## 6. Integração/Demonstração

Para demonstrar a funcionalidade:

1. Inicie sessão como Show Designer.
2. Utilize o menu para registar uma categoria.
3. Utilize o menu para desativar/ativar uma categoria
4. Verifique que a categoria foi ativada ou desativada corretamente fora do sistema.

## 7. Observações

N/A