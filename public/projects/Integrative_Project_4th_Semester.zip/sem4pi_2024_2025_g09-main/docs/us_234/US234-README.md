# US234 - Decommission figure

## 1. Context

This functionality is important to keep the cohesion between the catalogue and the actual figures that are available.

### 1.1 List of issues

- **Analysis:** This feature will support the elimination of a figure from the catalogue so that it will no longer be available.
- **Design:** It is necessary to implement a functionality that lets CRM Managers remove a figure from the catalogue.
- **Implementation:** The system will support the deletion of a Figure object from the catalogue.
- **Test:** Unit tests will be created in-order to validate this elimination.

## 2. Requirements

**US234:** As CRM Manager, I want to decommission a figure from the catalogue so that it will not be used anymore.

### 2.1 Dependencies

- **US233:** As there must be a figure to remove.

## 3. Analysis

This feature will enable CRM Managers to keep a life-cycle of figures in an easy and organized way.

### 3.1 Reference to global artifacts

#### Domain model

This user story will be mainly represented by the Figure Management aggregate of the domain model

## 4. Design

### Sequence Diagram

![Sequence Diagram](US234-SD.svg)