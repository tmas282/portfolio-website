# US230 - Register Show Request

## Context

This feature is part of Shodrone's customer management system. It allows a CRM Collaborator to register a show request.

A customer contacts a Shodrone's CRM Collaborator to submit a request for a show. The CRM Collaborator creates the show request into the system. If it is a new customer, it must be created in the system first.
A show request includes the customer, place, time, number of drones requested (tentative) and duration. It also should include the show's description, i.e. a document with the sequence of figures from the Shodrone's catalogue and/or request of new figures, as well as customer's exclusivity requirements. As usual, basic workflow information should also be kept (author of the request, history, etc.)
Whenever new figures have to be created, the CRM Manager assigns each request to a Show Designer that, based on the show request, designs the new figures and add them to the system. The CRM Collaborator is then able to generate a show proposal with the figures the customer desires. If the customer accepts the proposal, the CRM Collaborator updates the status of the request and the proposal, and it goes into production.
Upon acceptance of the show proposal by the customer, the show is scheduled by the CRM team. This probably involves some negotiation with the customer. The date and time are stored in the system.
## Requirements

### User Story

- **As a CRM Collaborator,** I want to register (create) a show request.

### Acceptance Criteria

- **AC1:** The customer must be in the system first;
- **AC2:** There must be at least a document with figures from Shodrone catalogue or a new figures request. 

### Dependencies

- This feature depends on US220 - Register customer, because is mandatory to exist a customer.

## Design

### Realization

- **Sequence Diagram**:


![sd.svg](sd.svg)