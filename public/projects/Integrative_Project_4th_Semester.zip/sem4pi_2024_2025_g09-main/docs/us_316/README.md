# US316 - Send show proposal to the customer

## 1. Context

This feature will allow CRM Collaborators to respond to a customer's show request by sending a show proposal.

### 1.1 List of issues

- **Analysis**: Understanding the requirements for producing a fine implementation for this use-case
- **Design**: Defining the architecture and sequence of operations for sending a show proposal to a customer.
- **Implementation**: Implementing the functionality for sending a show proposal to a customer.
- **Tests**: Testing the functionality to ensure proper implementation.

## 2. Requirements

**US316** As a **CRM Collaborator**, I want to send the show proposal to the customer.

**Acceptance Criteria:**

- **US316.1** The proposal is to be sent as a properly formatted document.
- **US316.2** The document to be sent must include the show details and a link to the video.
- **US316.3** The format of the proposal must be supported by the system and has to be generated using the correct plugin.
- **US316.4** The proposal can't be sent without prior successful testing of its show.

**Dependencies/References:**

- US316 is dependent on "US310 - Create show proposal", as there must be a proposal for one to be sent to its customer.

## 3. Analysis

Each show proposal must be kept in the database. Access to show proposals must be exclusive to its recipients.
The "send" part of this use-case will be achieved by making it available on the Customer App.

### 3.1 Refference to artifacts

- **Domain Model**: This use-case is centered around the Show Proposal Management aggregate of the domain model.

## 4. Design

### 4.1 Sequence Diagram

![Sequence Diagram](US316-SD.svg)

