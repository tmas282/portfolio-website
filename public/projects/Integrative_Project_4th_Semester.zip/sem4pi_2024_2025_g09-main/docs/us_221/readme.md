# US221: Add a Customer Representative

## Context

This feature is part of the project to improve Shodrone's customer management system. It allows CRM Collaborators to add new customer representatives, who will be registered as distinct users in the system. Email domain verification has been excluded for this type of user, recognizing the practical difficulties in verifying email domains for all representatives.

This feature will be implemented in **Sprint 2**.

## Requirements

### User Story

- **As a CRM Collaborator**, I want to register a new customer representative so that each representative becomes a distinct user in the syste.
- The representative will only have access to functionalities related to customer management.

### Acceptance Criteria

- **US221.1** The system must allow CRM Collaborators to register new customer representatives.
- **US221.2** The system must create the representative as a user in the system, with restricted access to functionalities related to customer management.
- **US221.3** The representative's email does not require domain verification.
- **US221.4** The representative's email must be unique in the system.
- **US221.5** The system must validate that the representative's email is unique before saving.

### Dependencies

- This user story depends on US220 Register Customer, as a customer must be registered before a representative can be added. After registering a customer, representatives can be associated with that customer.

## Analysis

This feature supports the registration of customer representatives as system users, ensuring that each representative is assigned the correct role and permissions.

**Key Considerations:**
- **Email domain verification**: Omitted as it is impractical for the project's use cases.
- **Role-based permissions**: The representative will only have access to functionalities related to customer management and will not have access to administrative functionalities.
- **Email uniqueness**: The representative's email will be validated to ensure it is unique in the system, both in the user repository and in the representative repository.
- **Password assignment**: The representative is registered with a default static password defined in the service logic. No automatic password generation is applied in this version.

## Design

### Realization

- **Sequence Diagram**: See diagram `AddCustomerRepresentative.puml`, which shows the interactions between UI, Controller, CustomerService, repositories, and domain entities.

![AddCustomerRepresentative.svg](AddCustomerRepresentative.svg)

### Applied Design Patterns

- **Layered Architecture**: A separation between presentation, application, domain, and persistence layers was used to organize the code.
- **Information Expert**: `CustomerService` is responsible for coordinating the representative creation process and enforcing business rules.

### Acceptance Tests

- Add a representative with valid data.
- Attempt to add a representative with a duplicate email (should fail).
- Attempt to add a representative with a malformed VAT (e.g., missing country prefix).
- Attempt to add a representative with a name under 2 characters (should fail).
- Attempt to add a representative with a blank or malformed email (should fail).
- Attempt to add a representative with a blank position (should fail).
- Verify that the representative is correctly associated with the customer.
- Ensure the representative has limited permissions in the system.

## Implementation

### Overview

The feature adds a new **CustomerRepresentative** entity to the system and creates a user with limited access (restricted to customer-related functionalities). The CRM Collaborator adds representatives through the back-office interface, and each representative is stored in the database and also registered as a user.

- **Key Components**:
  - **CustomerRepresentative Class**: Contains details such as name, email, position, and association with a **Customer**.
  - **CustomerService**: Responsible for orchestrating the creation of the representative and the corresponding system user.
  - **UserRepository and RoleRepository**: Used to ensure the user is stored and linked with the appropriate system role (`CUSTOMER_REPRESENTATIVE`).
  - **Validation Logic**: Ensures that VAT is correctly formatted (e.g., PT123456789), the name and position have valid lengths, and the email is syntactically valid and unique.

## Integration / Demonstration

To demonstrate the feature:

1. **Log in** as a CRM Collaborator.
2. Use the **CRM Collaborator Menu** to select the option to add a representative.
3. Input the representative's details (Customer VAT, Name, Email, Position).
4. Submit the form and **verify** that the representative was created and registered as a system user with the correct role and access limitations.

## Observations

- **Improvement Considerations**: Future versions of the system may allow representatives to receive a temporary password or to set their own password through a self-registration flow.
- **Error Handling**: The UI provides detailed feedback for errors such as duplicate email, invalid input, or customer not found.
- **Security**: Password is currently hardcoded; future versions should support secure password generation and change mechanisms.

## How to Use the Feature

1. **Log in** to the system with valid CRM Collaborator credentials.
2. Navigate to the **Customer Management** section.
3. Select **Add Representative**.
4. Fill in the representative's details (VAT, name, email, position) and submit.
5. The representative will be registered as a system user with the appropriate role and limited access to customer management functionalities.

**Note**: Automated tests for this feature are pending implementation. Manual testing via console interaction is currently supported.
