# Technical Constraints

This document summarizes the non-functional requirements (NFRs) that must be followed by the team in the scope of the Shodrone domain System development.

These constraints are derived from Section 5 of the Project Requirements Document (Version 1.a, March 2025).

---

## NFR01 - Project Management

- The team must adopt the **Scrum** methodology.
- Weekly Scrum meetings must be conducted with the Scrum Master (LAPR4 PL teacher).
- Development must be organized in three Sprints, following an iterative and incremental process.

---

## NFR02 - Technical Documentation

- All project documentation must be stored in the repository under the `docs/` folder.
- Documentation must use **Markdown format** and include **UML diagrams**.
- Diagrams must be created using **PlantUML**.
- Both the `.puml` source files and the generated diagrams (vectorial format) must be included.

---

## NFR03 - Test-Driven Development

- The team should follow a **Test-Driven Development (TDD)** approach whenever possible.

---

## NFR04 - Source Control

- The entire source code and documentation must be versioned in the **GitHub repository** provided.
- Only the `main` branch will be used as a source for official releases.

---

## NFR05 - Continuous Integration

- The GitHub repository must include a **Continuous Integration (CI)** configuration using **GitHub Actions**.
- CI must run nightly builds and publish results and metrics.

---

## NFR06 - Deployment and Scripts

- The repository must include **scripts** to:
    - Build the solution
    - Deploy the solution
    - Execute the solution
- Scripts must be compatible with **Linux and Windows**.
- A detailed `README.md` must explain how to build, deploy, and execute the solution.

---

## NFR07 - Configurable Database

- The solution must support two persistence modes:
    - **In-memory database** (for development and testing)
    - **Relational Database (RDBMS)** (for production)
- Configuration must allow switching between both options.
- Default data initialization must be supported.

---

## NFR08 - Authentication and Authorization

- The system must implement **authentication** and **authorization** for all users and functionalities.

---

## NFR09 - Programming Language

- The solution must be implemented using **Java** as the main programming language.
- Other languages may be used according to specific needs (e.g., C for simulation).

---

## NFR10 - Network Communication

- Network socket APIs may use:
    - A custom application protocol
    - An existing standard protocol (e.g., HTTP)

---

## NFR11 - DSL and Drone Language Analysis

- The system must support the analysis and validation of:
    - A **high-level DSL** for figure descriptions
    - **Drone-specific programming languages**
- The **ANTLR** tool is recommended for this purpose.

---

## NFR12 - Simulation System (Sprint 3)

- The simulation system must:
    - Use a **multi-threaded parent process** and **child processes** for drones
    - Communicate through **shared memory**
    - Separate functionalities into dedicated threads (collision detection, report generation)
    - Synchronize simulation step-by-step using **semaphores**
    - Allow termination via **signals** when collision thresholds are exceeded
