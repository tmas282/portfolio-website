# Glossary
**Terms, Expressions and Acronyms (TEA) must be organized alphabetically.**

| **_TEA_** (EN)          | **_Description_** (EN)                                                                                                                     |
|:------------------------|:-------------------------------------------------------------------------------------------------------------------------------------------|
| Address                 | The place where a customer lives.                                                                                                          |
| Category                | A classification for a figure.                                                                                                             |
| Code                    | The set of instructions that allows a drone to perform a specific routine in a figure.                                                     |
| Collision Report        | A report detailing any collisions detected during a simulation.                                                                            |
| Customer                | An entity representing a client of Shodrone, including VAT, status, address, phone number, name, and email.                                |
| Customer Representative | An entity representing a person who acts on behalf of a customer, including name, email, and position.                                     |
| Customer Status         | A status that allows differentiating the hierarchy between customers.                                                                      |
| Description             | A detailed explanation of a figure.                                                                                                        |
| Drone                   | An unmanned aerial vehicle (UAV) that can fly autonomously or be remotely controlled, identified by serial number and status.              |
| Drone Figure            | An entity representing the relationship between a drone and a figure.                                                                      |
| Drone Model             | The specific type of drone used in the show, with unique capabilities and programming requirements.                                        |
| Drone Status            | Defines the status of a drone (e.g., «Active», «Broken», «In Maintenance», «Out of Inventory»).                                            |
| Email                   | A professional way to contact someone or something.                                                                                        |
| Exclusivity             | An attribute that determines whether a show description is unique to a customer.                                                           |
| Figure                  | A composition of a large set of drones, each one running a specific routine, including code, version, keywords, description, and category. |
| Keyword                 | A set of words that classify a figure.                                                                                                     |
| Name                    | The name of a customer or customer representative.                                                                                         |
| Number of Drones        | The amount of drones that compose a show.                                                                                                  |
| Phone Number            | A personal way to contact someone or something.                                                                                            |
| Place                   | The location where a simulation or show will be developed.                                                                                 |
| Position                | The job title or role of a customer representative.                                                                                        |
| Programming Language    | The language used to program a drone model.                                                                                                |
| Serial Number           | A unique number that identifies a drone.                                                                                                   |
| Show                    | A sequence of figures.                                                                                                                     |
| Show Description        | Details of how a show will happen, including exclusivity.                                                                                  |
| Show Proposal           | An entity representing a proposed show, including status, time, date, and associated figures.                                              |
| Show Proposal Date      | The date when a show proposal is created.                                                                                                  |
| Show Proposal Figure    | An entity representing a figure included in a show proposal.                                                                               |
| Show Proposal Status    | The status of a show proposal.                                                                                                             |
| Show Proposal Time      | The time when a show proposal is created.                                                                                                  |
| Show Request            | An entity representing a customer's request for a show, including status, date, time, duration, place, number of drones, and description.  |
| Show Request Date       | The date when a show request is created.                                                                                                   |
| Show Request Duration   | The duration of a show request.                                                                                                            |
| Show Request Place      | The location where a show request is to be held.                                                                                           |
| Show Request Status     | The status of a show request.                                                                                                              |
| Show Request Time       | The time when a show request is created.                                                                                                   |
| Simulation              | A test run to ensure that the drones' movements and the figures they perform do not lead to collisions or errors.                          |
| Simulation Status       | The status of a simulation.                                                                                                                |
| Specific Routine        | A specific set of instructions that a drone needs to perform a show.                                                                       |
| VAT                     | A unique number that identifies a customer for tax purposes.                                                                               |
| Version                 | The version of a figure.                                                                                                                   |