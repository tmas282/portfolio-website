# Use Case Diagram (UCD)

**In the scope of this project, there is a direct relationship of _1 to 1_ between Use Cases (UC) and User Stories (US).**

However, be aware, this is a pedagogical simplification. On further projects and course units there may also exist _1 to N **and/or** N to 1_ relationships between UC and US.

**Insert below the Use Case Diagram in a SVG format**

![Use Case Diagram](svg/UCD.svg)

**For each UC/US, it must be provided evidences of applying main activities of the software development process (requirements, analysis, design, tests and code). Gather those evidences on a separate file for each UC/US and set up a link as suggested below.**

# Use Cases / User Stories

| UC/US | Description                                                   |                   
|:------|:--------------------------------------------------------------|
| US101 | Technical Constraints                                         |
| US102 | Project Repository                                            |
| US103 | Project Structure                                             |
| US104 | Continuous Integration Server                                 |
| US105 | Automated Deployment                                          |
| US110 | Domain Model                                                  |
| US210 | Authentication and Authorization                              |
| US211 | Register Users                                                |
| US212 | Disable/Enable Users                                          |
| US213 | List Users                                                    |
| US220 | Register Customer                                             |
| US221 | Add a Customer Representative                                 |
| US222 | List Customer Representatives                                 |
| US223 | Edit a Customer Representative                                |
| US224 | Disable a Customer Representative                             |
| US230 | Show Request                                                  |
| US231 | Figure Catalogue                                              |
| US232 | Search Figure Catalogue                                       |
| US233 | Add Figure to Catalogue                                       |
| US234 | Decommission Figure                                           |
| US235 | List Show Requests of Client                                  |
| US236 | Edit Show Requests                                            |
| US240 | Drone Model Creation                                          |
| US241 | Add Drone to Inventory                                        |
| US242 | Remove Drone from Inventory                                   |
| US243 | List Drones in Inventory                                      |
| US245 | Add Figure Category                                           |
| US246 | Edit Figure Category                                          |
| US247 | List Figure Categories                                        |
| US248 | Inactivate/Activate a Figure Category                         |
| US251 | Specification of the Language for Figure and Show Description |
| US253 | Configuration of a Drone's Language                           |
| US255 | Configuration of Proposal Templates                           |
| US261 | Initiate Simulation for a Figure                              |
| US262 | Capture and Process Drone Movements                           |
| US263 | Detect Drone Collisions in Real-Time                          |
| US264 | Synchronize Drone Execution with a Time Step                  |
| US265 | Generate a Simulation Report                                  |
| US310 | Create Show Proposal                                          |
| US311 | Add Drones to Proposal                                        |
| US312 | Add Figures to Proposal                                       |
| US315 | Add Video of Simulation to Proposal                           |
| US316 | Send Show Proposal to Customer                                |
| US317 | Mark Show Proposal as Accepted                                |
| US318 | Templates for Show Proposals                                  |
| US321 | Add Maintenance Type                                          |
| US322 | List Maintenance Types                                        |
| US323 | Edit Maintenance Type                                         |
| US325 | List Maintenance History of a Drone                           |
| US326 | Add Maintenance Record to a Drone                             |
| US327 | Register Drone Usage Time                                     |
| US328 | List Drones Needing Preventive Maintenance                    |
| US340 | DSL Plugin                                                    |
| US341 | Validate Figure Description                                   |
| US344 | Generation of a Drone Program                                 |
| US345 | Drone Language Plugin                                         |
| US346 | Validation of a Drone Program                                 |
| US347 | Proposal Generation                                           |
| US348 | Show Generation                                               |
| US361 | Initialize Hybrid Simulation Environment                      |
| US362 | Function-specific Threads in Parent Process                   |
| US363 | Notify Report Thread via Condition Variables                  |
| US364 | Enforce Step-by-step Simulation Synchronization               |
| US365 | Generate and Store Final Simulation Report                    |
| US366 | Integrate Environmental Influences into Simulation            |
| US370 | Analyse a Proposal                                            |
| US371 | Accept/Reject Proposal                                        |
| US372 | Check Shows Dates                                             |
| US373 | Get Show Info                                                 |
| US376 | Show Testing                                                  |
| US378 | Running Test                                                  |