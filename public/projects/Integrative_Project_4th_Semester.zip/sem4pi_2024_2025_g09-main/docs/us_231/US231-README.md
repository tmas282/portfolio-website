# US231 - Figure catalogue

## 1. Context

This functionality is crucial for the development of this app as having a figure catalogue helps manage and organize the figures
to be used in shows.

### 1.1 List of issues

- **Analysis:** The system needs to have the figures organized in a way that will let the CRM Collaborator search for them
- **Design:** It is necessary to implement a functionality that lets CRM Collaborators search for a figure
- **Implementation:** The "Figure catalogue" will be retrieved from the FigureRepository
- **Test:** Unit tests will be created in-order to validate that only active and public figures are retrieved

## 2. Requirements

**US231:** As CRM Collaborator, I want to list all active public figures in the catalogue so that I can select them during the design of a show request proposal.

**Specifications from the document**

> When submiting a figure, the client may decide whether this will be exclusive

**Customer clarifications**

> **Question:** Na US 231, lê-se: "As CRM Collaborator, I want to list all public figures in the catalogue so that I can select them during a show request proposal", o que dá a entender que o catálogo inclui tanto figuras públicas como exclusivas. No entanto, na US 233, está escrito: "As Show designer I want to add a figure to the public catalogue", o que sugere que existem diferentes catálogos. Com base nestas duas User Stories, tenho as seguintes dúvidas: Quantos catálogos existem? Há apenas um catálogo que inclui tanto figuras públicas como exclusivas, ou existem catálogos separados (um para figuras públicas e outro para figuras exclusivas)? Todas as figuras precisam de estar no(s) catálogo(s)? Ou é possível que algumas figuras existam fora do(s) catálogo(s)?
>
> **Answer:** Quando uma figura é criada ela é acrescentada ao "catálogo" de figuras da ShowDrone. Não há figuras no éter.

## 3. Analysis

There's the need for a figure catalogue to exist so that it will then facilitate the design of a show request proposal.

### 3.1 Reference to global artifacts

#### Domain model

This user story will be mainly represented by the Figure Management aggregate of the domain model

#### Use case diagram

This user story will encompass the browse catalogue use case, carried out by the CRM Collaborator


## 4. Design

### Sequence Diagram

![Sequence Diagram - Full](US231-SD.svg)

