# US327: Register drone usage time

## Context

This feature is part of Shodrone's drone management system. It allows Drone Technicians to record the flying/usage time of drones, which is essential for tracking drone usage and determining when preventive maintenance is required.

This feature will be implemented in **Sprint 3**.

## Requirements

### User Story

- **As a Drone Tech**, I want to record the flying/usage time of a given drone so that I can track its operational hours.

### Acceptance Criteria

- **US327.1** The system must allow Drone Technicians to record the usage time of a specific drone.
- **US327.2** The usage time must be recorded in hours.
- **US327.3** The system must validate that the drone exists before recording usage time.
- **US327.4** The system must accumulate the usage time with the existing usage time of the drone.
- **US327.5** The usage time must be a positive number.

### Dependencies

- This user story is related to US326 (Add maintenance record to a drone), as some maintenance operations reset the usage time counter.
- This user story is also related to US328 (List drones needing preventive maintenance), as the usage time is used to determine when preventive maintenance is required.

## Analysis

This feature enables Drone Technicians to record and track the operational hours of drones, which is crucial for maintenance planning and ensuring drone reliability.

**Key Considerations:**
- **Usage Time Accumulation**: The system must add the recorded usage time to the existing usage time of the drone.
- **Data Validation**: The system must validate that the drone exists and that the usage time is a positive number.
- **Maintenance Relationship**: The usage time is used to determine when preventive maintenance is required and may be reset by certain maintenance operations.

## Design

### Realization

- **Sequence Diagram**: See diagram `RegisterDroneUsageTime.puml`, which shows the interactions between UI, Controller, DroneService, repositories, and domain entities.

![RegisterDroneUsageTime.svg](RegisterDroneUsageTime.svg)

### Applied Design Patterns

- **Layered Architecture**: A separation between presentation, application, domain, and persistence layers was used to organize the code.
- **Repository Pattern**: Used to abstract access to drone data.

### Acceptance Tests

- Record usage time for a drone with valid data.
- Verify that the usage time is accumulated with the existing usage time.
- Attempt to record usage time for a non-existent drone (should fail).
- Attempt to record a negative usage time (should fail).
- Verify that the usage time is correctly stored in the system.

## Implementation

### Overview

The feature adds the ability to record and track the usage time of drones. The Drone Technician accesses this functionality through the back-office interface.

- **Key Components**:
  - **Drone Class**: Contains the usage time counter that is updated when new usage time is recorded.
  - **DroneService**: Responsible for updating the usage time counter of the drone.
  - **Validation Logic**: Ensures that the drone exists and that the usage time is a positive number.

## Integration / Demonstration

To demonstrate the feature:

1. **Log in** as a Drone Technician.
2. Navigate to the **Drone Management** section.
3. Select a drone and click **Record Usage Time**.
4. Enter the usage time in hours.
5. Submit the form and verify that the usage time has been added to the existing usage time of the drone.

## Observations

- **Future Improvements**: Add support for automatic usage time tracking through integration with drone telemetry systems.
- **Alternative Solutions Considered**: Recording usage time in minutes or seconds was considered but rejected to simplify the user interface and data storage.

## How to Use the Feature

1. **Log in** to the system with valid Drone Technician credentials.
2. Navigate to the **Drone Management** section.
3. Select a drone from the list.
4. Click on **Record Usage Time**.
5. Enter the usage time in hours.
6. Click **Submit** to record the usage time.
7. The system will add the recorded usage time to the existing usage time of the drone.