# US105 – Automated deployment

## 1. Context

This user story aims to ensure that the development team configures the **necessary scripts** to support an efficient way of building/executing/deploying... effortlessly.
The objective is to **facilitate and accelerate** the implementation of upcoming user stories, complying with the architectural and technological decisions defined in the project requirements.

This task is part of **Sprint 1**.

### 1.1 List of Tasks

- **Analysis**: Review the requirements and technical constraints to identify the essential elements of this requirement.
- **Design**: Design the automated deployment based on maven.
- **Implementation**: Implement the automated deployment based on maven.
- **Testing**: Testing the functionality to ensure it works in the upcoming events.

---

## 2. Requirements

**US105** – As Project Manager, I want the team to add to the project the necessary scripts, so that build/executions/deployments... can be executed effortlessly.


### 2.1. Acceptance Criteria

- **AC1** – The repository must include scripts for all the major tasks and execution of applications.
- **AC2** – The repository should include the necessary scripts to build and deploy the solution in a variety of systems (at least Linux and Windows).

#### 2.1.1. Dependencies/References

- Section 4.1 - Sprint 1 of Sem4PI_Project_Requirements_v01c.pdf
- Section 5 – Non-Functional Requirements of Sem4PI_Project_Requirements_v01c.pdf

---

## 3. Analysis

Automate Deployment Scripts will, mainly, use maven. Maven is used to automate major tasks and execution of applications.
Running all defined tests with maven is also request.
Compilation of the system will use maven.
Deployment is going to be with maven also.

---

## 4. Implementation

According to maven:
- `mvn clean` -> Deletes the ./target/ folder, which contains all compiled .java files
- `mvn compile` -> Compiles all .java files  inside ./src/main/java to the ./target/ folder
- `mvn test` -> Runs all the unit tests in ./src/test/java folder using JUnit. This also generates reports to ./surefire-reports/.
- `mvn package` -> Compiles and deploys the project to a .jar file located ./target/ folder.
- `mvn jacoco:report` -> This generates in the ./target/site/jacoco a test coverage report in multiple formats (html, csv, xml). This reports displays code parts that got tested/not tested.

According to java:
- `java -jar ./path-to-jar` -> Runs the specified .jar file using Java Virtual Machine;

---


## 5. Testing

To test the scripts, we'll run them depending on the OS installed on the device:

### Linux/MacOs

1. Script to run unit tests: `./test.sh`
2. Script to run unit tests with coverage: `./test-with-coverage.sh`
3. Script to compile the project: `./build.sh`
4. Script to deploy in .jar file: `./deploy.sh`

### Windows

1. Script to run unit tests: `./test.bat`
2. Script to run unit tests with coverage: `./test-with-coverage.bat`
3. Script to compile the project: `./build.bat`
4. Script to deploy in .jar file: `./deploy.bat`
