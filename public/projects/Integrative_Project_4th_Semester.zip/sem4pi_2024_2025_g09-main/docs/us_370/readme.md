# US370 - Analyse a proposal

## Context

This feature is part of Shodrone's customer app and Shodrone's customer app server. It allows a Customer Representative to analyse and download the show proposal.

A customer contacts a Shodrone’s CRM Collaborator to submit a request for a show. The CRM
Collaborator creates the show request into the system. If it is a new customer, it must be created in
the system first.
A show request includes the customer, place, Ɵme, number of drones requested (tentaƟve) and
duraƟon. It also should include the show’s description, i.e. a document with the sequence of figures
from the Shodrone’s catalogue and/or request of new figures, as well as customer’s exclusivity
requirements. As usual, basic workflow informaƟon should also be kept (author of the request, history,
etc.)
Whenever new figures have to be created, the CRM Manager assigns each request to a Show Designer
that, based on the show request, designs the new figures and add them to the system. The CRM
Collaborator is then able to generate a show proposal with the figures the customer desires. If the
customer accepts the proposal, the CRM Collaborator updates the status of the request and the
proposal, and it goes into production.
Upon acceptance of the show proposal by the customer, the show is scheduled by the CRM team. This
probably involves some negoƟaƟon with the customer. The date and Ɵme are stored in the system.

User stories US370, US371, US372, and US373 are implemented in
the “Customer App” which communicates through the network with the “Customer App Server”, which in turn
accesses the Database. The “Customer App” is not allowed direct access to the Database.
The “Costumer App Server” must be able to cope with several instances of “Costumer App” running at the same
time, and the same goes for the “Simulator” application when it comes to several instances of the “Testing App”
and “Drone Runner”.
The communications between the applications must use TCP (Transmission Control Protocol) sockets in a
client-server architecture.
Teams may use a standard client-server TCP based application protocol, like for instance HTTP (Hyper Text
Transfer Protocol), or design their own client-server TCP based application protocol.
If the team chooses to design a new application protocol, then it must be formally described in the
project’s documentation. If the team chooses to use a standard application protocol, then the features of
that protocol that are going to be used must be described in detail.


## Requirements

### User Story

- **As a Customer Representative,** I want to have access to a show proposal of mine in the App. I received a link/code to download the file.

### Acceptance Criteria

- **AC1:** There should be a download link;
- **AC2:** It should be a TCP based protocol communication;

### Dependencies

- US316 - Send show proposal to the customer: As there the show proposal must be assigned to a customer representative. 
- US310 - Create Show Proposal: As there must exist a show proposal to download.

## Design

### Realization

- **Sequence Diagram**:


![sd.svg](sd.svg)