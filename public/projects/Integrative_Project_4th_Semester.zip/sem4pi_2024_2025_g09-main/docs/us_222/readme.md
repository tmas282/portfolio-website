# US222: List Customer Representatives

## Context

This feature is part of Shodrone's customer management system. It allows CRM Collaborators to list all active representatives of a specific customer, excluding those who are disabled.

This feature will be implemented in **Sprint 2**.

## Requirements

### User Story

- **As a CRM Collaborator**, I want to list all representatives of a specific customer so that I can view relevant information.

### Acceptance Criteria

- **US222.1** The system must allow listing all active representatives of a customer.
- **US222.2** Disabled representatives must not be displayed in the list.
- **US222.3** The list must include the name, email, and position of each representative.

### Dependencies

- This user story depends on US220 Register Customer, as a customer must be registered before their representatives can be listed.

## Analysis

This feature will enable CRM Collaborators to view active representatives of a customer, ensuring only relevant information is displayed.

**Key Considerations:**
- **Filtering Representatives**: Only active representatives should be displayed.
- **Displayed Information**: Name, email, and position of each representative.

## Design

### Realization

- **Sequence Diagram**:
    - A sequence diagram is provided to illustrate the flow of listing customer representatives.

![ListCustomerRepresentatives.svg](ListCustomerRepresentatives.svg)

- **Applied Design Patterns**:
    - **Repository Pattern**: Used to access customer representative data.

### Acceptance Tests

- List representatives of a customer with active representatives.
- Verify that disabled representatives are not displayed.
- Validate that the displayed information is correct.

## Implementation

### Overview
This feature adds the ability to list active representatives of a specific customer. The list will be accessed through the back-office interface.

- **Key Components**:
    - **CustomerRepresentativeRepository**: Responsible for fetching active representatives.
    - **ListCustomerRepresentativesController**: Manages the listing logic.

## Integration / Demonstration

To demonstrate the feature:

1. **Log in** as a CRM Collaborator.
2. Navigate to the **Customer Management** section.
3. Select a customer and click **List Representatives**.
4. Verify that only active representatives are displayed.

## Observations

- **Future Improvements**: Add additional filters, such as search by name or position.
- **Alternative Solutions Considered**: None at the moment.

## How to Use the Feature

1. **Log in** to the system with valid CRM Collaborator credentials.
2. Navigate to the **Customer Management** section.
3. Select a customer and click **List Representatives**.
4. View the list of active representatives for the customer.