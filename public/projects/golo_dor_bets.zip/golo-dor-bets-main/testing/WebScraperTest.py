from os import path
import sys
sys.path.append(path.join(path.dirname(__file__), '..'))

import unittest
from domain.WebScraper import WebScraper

class WebScraperTest(unittest.TestCase):
    def testDriverGettingValue(self): 
        real = WebScraper.getValuesFrom("https://www.flashscore.pt/jogo/Ek1RrmJ3/#/sumario-do-jogo", "/html/body/div[1]/div/div[4]/div[2]/div[3]/div[2]/a")
        self.assertEqual("Alemanha", real)
    def testDriverClickingAndGettingLink(self):
        expected = "https://www.flashscore.pt/jogo/Ek1RrmJ3/#/sumario-do-jogo/sumario-do-jogo"
        real = WebScraper.click(expected, "/html/body/div[3]/div[2]/div/div[1]/div/div[2]/div/button[1]")
        self.assertEqual(expected, real)
    def testValidation(self):
        with self.assertRaises(Exception):
            WebScraper.validate("https://www.livescore.com/en/football/uefa-nations-league/league-a-group-2/belgium-vs-france/1168457/")
if __name__ == "__main__":
    unittest.main()