from os import path
import sys
sys.path.append(path.join(path.dirname(__file__), '..'))

import unittest
from controller.GetOverUnderProbController import GetOverUnderProbController

class GetOverUnderProbControllerTest(unittest.TestCase):
    def testValuesAreCorrect(self):
        controller = GetOverUnderProbController()
        controller.setFileLocation("./testing/files/test.csv")
        valueUnder, valueOver = controller.calculateOverUnder(3.5)
        self.assertAlmostEqual(valueUnder, 0.5744, delta=0.0001)
if __name__ == "__main__":
    unittest.main()