from os import path
import sys
sys.path.append(path.join(path.dirname(__file__), '..'))

import unittest
from domain.Game import Game

class GameTest(unittest.TestCase):
    def testScrapingTitle(self):
        g = Game("https://www.flashscore.pt/jogo/vwbmU7aL/#/sumario-do-jogo")
        self.assertEqual(g.getTitle(), "Monaco - Lille".upper())
    def testScrapingChampionship(self):
        g = Game("https://www.flashscore.pt/jogo/vwbmU7aL/#/sumario-do-jogo")
        self.assertEqual(g.getChampionship(), "FRANÇA: Liga 1 - Ronda 8".upper())
    def testScrapingTeamStatsHome(self):
        g = Game("https://www.flashscore.pt/jogo/vwbmU7aL/#/sumario-do-jogo")
        self.assertCountEqual(g.getTeamHomeStats().getGoals(), [2, 2, 2, 3, 2])
    def testScrapingTeamStatsAway(self):
        g = Game("https://www.flashscore.pt/jogo/vwbmU7aL/#/sumario-do-jogo")
        self.assertCountEqual(g.getTeamAwayStats().getGoals(), [2, 1, 3, 3, 0])
if __name__ == "__main__":
    unittest.main()