from os import path
import sys
sys.path.append(path.join(path.dirname(__file__), '..'))

import unittest, numpy as np
from domain.MathOperations import MathOperations

class MathOperationsTest(unittest.TestCase):
    def testInsertValue(self):
        c = MathOperations()
        c.insertValue(5)
        self.assertEqual(c.values, [5])
    def testCalculateAverage(self):
        c = MathOperations()
        c.insertValue(3)
        c.insertValue(4)
        c.insertValue(5)
        c.insertValue(6)
        c.insertValue(7)
        self.assertEqual(c.calculateAverage(), 5)
    def testCalculateDeviation(self):
        c = MathOperations()
        c.insertValue(3)
        c.insertValue(4)
        c.insertValue(5)
        c.insertValue(6)
        c.insertValue(7)
        print(c.values)
        self.assertEqual(c.calculateDeviation(), np.sqrt(2))
if __name__ == "__main__":
    unittest.main()