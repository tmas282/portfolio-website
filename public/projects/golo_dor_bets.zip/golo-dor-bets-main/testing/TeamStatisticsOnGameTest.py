from os import path
import sys
sys.path.append(path.join(path.dirname(__file__), '..'))

import unittest
from domain.TeamStats import TeamStats

class TeamStatsTest(unittest.TestCase):
    def testGettingGoals(self):
        ts = TeamStats("https://www.flashscore.pt/jogo/0QRsVT4U/#/sumario-do-jogo", False)
        self.assertCountEqual(ts.getGoals(), [2, 3, 4, 2, 3])
if __name__ == "__main__":
    unittest.main()