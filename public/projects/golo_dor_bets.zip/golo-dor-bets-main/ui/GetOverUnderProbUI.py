def run():
    from os import path
    import sys
    sys.path.append(path.join(path.dirname(__file__), '..'))

    from controller.GetOverUnderProbController import GetOverUnderProbController

    controller = GetOverUnderProbController()
    controller.setFileLocation(input("Where is the file: "))
    while(True):
        x = float(input("What value you want to see Over/Under (-1 to leave): "))
        if x == -1:
            return
        valueUnder, valueOver = controller.calculateOverUnder(x)
        print(f"P(Goals<{x:.2f}) = {valueUnder:.2f}")
        print(f"P(Goals>{x:.2f}) = {valueOver:.2f}")
        
if __name__ == "__main__":
    run()