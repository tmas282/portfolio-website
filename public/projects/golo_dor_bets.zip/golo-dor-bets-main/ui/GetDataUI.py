def run():   
    from os import path
    import sys
    sys.path.append(path.join(path.dirname(__file__), '..'))

    from controller.GetDataController import GetDataController
    from matplotlib import pyplot as plt

    controller = GetDataController()
    link = input("Insert the game link: ")
    print("Hold on, this might take a while...")
    controller.keepData(str(link))
    print("Data saved.")    

if __name__ == "__main__":
    run()