def run():
    from os import path
    import sys
    sys.path.append(path.join(path.dirname(__file__), '..'))

    from controller.SeeNormalDistributionController import SeeNormalDistributionController
    from matplotlib import pyplot

    controller = SeeNormalDistributionController()
    print("Please tell us the five values: ")
    for i in range(5):
        n = int(input("Insert the value: "))
        if controller.insertValue(n) == False:
            print("Error.")
            i-=1
    print(controller.mathOperations.values)
    print("Calculating. This might take a while...")
    values = controller.requestValues()
    pyplot.plot(values[2][0], values[2][1])
    pyplot.title(f"Average = {values[0]}; Stardand Deviation = {values[1]}")
    pyplot.show()

if __name__ == "__main__":
    run()