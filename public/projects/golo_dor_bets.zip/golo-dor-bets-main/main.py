while True:
    print("[0] Calculate Normal Distribution")
    print("[1] Get Data from the website and store on file")
    print("[2] Get Over/Under probabilities based on files")
    print("[-1] Leave")
    n = int(input("Select an option: "))
    if n==0:
        import ui.SeeNormalDistributionUI as ui
        ui.run()
    elif n==1:
        import ui.GetDataUI as ui
        ui.run()
    elif n==1:
        import ui.GetDataUI as ui
        ui.run()
    elif n==2:
        import ui.GetOverUnderProbUI as ui
        ui.run()
    elif n==-1:
        exit()
    else:
        print("Not an option")
        continue