from .WebScraper import WebScraper as ws

class Team():
    NAME_HOME_CSS = "div.participant__participantName:nth-child(2) > a:nth-child(1)"
    NAME_AWAY_CSS = "div.participant__participantName:nth-child(1) > a:nth-child(1)"
    NAME_HOME_H2H_CSS = " > span:nth-child(3)"
    def __init__(self, link: str, home: bool):
        self.home = home
        if(home == True):
            self.name = ws.getValuesFrom(link, Team.NAME_HOME_CSS)
        else:
            self.name = ws.getValuesFrom(link, Team.NAME_AWAY_CSS)
    def getName(self):
        return self.name
    def checkIfHomeInGame(self, link: str, selector: str):
        homeTeamName = ws.getValuesFrom(link, selector + Team.NAME_HOME_H2H_CSS)
        return homeTeamName == self.name