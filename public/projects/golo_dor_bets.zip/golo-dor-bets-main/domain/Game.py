from os import path
import sys
sys.path.append(path.join(path.dirname(__file__), '..'))

from .WebScraper import WebScraper as wb
from domain.TeamStats import TeamStats

class Game():
    def __init__(self, link: str):
        self.link = link
        self.title = self.scrapeTitle()
        self.championship = self.scrapeChampionship()
    def getTitle(self):
        return self.title
    def getChampionship(self):
        return self.championship
    def getStats(self):
        self.stats = [TeamStats(self.link, True), TeamStats(self.link, False)]
        return self.stats
    def scrapeTitle(self):
        hTeamName = wb.getValuesFrom(self.link, "div.participant__participantName:nth-child(2) > a:nth-child(1)")
        aTeamName = wb.getValuesFrom(self.link, "div.participant__participantName:nth-child(1) > a:nth-child(1)")
        return hTeamName + " - " + aTeamName
    def scrapeChampionship(self):
        championship = wb.getValuesFrom(self.link, ".tournamentHeader__country")
        return championship