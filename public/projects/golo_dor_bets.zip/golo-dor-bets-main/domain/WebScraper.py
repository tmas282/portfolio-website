from os import path
import sys
sys.path.append(path.join(path.dirname(__file__), '..'))

from selenium import webdriver
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
import time
import atexit
from dotenv import load_dotenv
import os

class WebScraper():
    DRIVER = webdriver.Firefox()
    COOKIES_ACCEPTED = False
    COOKIES_CSS_SELECTOR = "#onetrust-accept-btn-handler"
    @staticmethod
    def acceptCookiesIfAvailable(link: str):
        if(WebScraper.COOKIES_ACCEPTED == False):
            load_dotenv()
            WebScraper.COOKIES_CSS_SELECTOR = os.getenv("COOKIES_CSS_SELECTOR")
            WebScraper.COOKIES_ACCEPTED = True
            WebScraper.click(link, WebScraper.COOKIES_CSS_SELECTOR)
    @staticmethod
    def getValuesFrom(link: str, cssSelector:str) -> str:
        WebScraper.validate(link)
        driver = WebScraper.DRIVER
        driver.maximize_window()
        WebScraper.goToLink(link)
        elem = driver.find_element(By.CSS_SELECTOR, cssSelector)
        return elem.text.upper()
    @staticmethod
    def clickElement(elem: WebElement):
        driver = WebScraper.DRIVER
        elem.location_once_scrolled_into_view
        driver.execute_script("arguments[0].scrollIntoView();", elem)
        try:
            elem.click()
        except:
            driver.execute_script("arguments[0].click();", elem)
        time.sleep(2)
        return driver.current_url
    @staticmethod
    def click(link: str, cssSelector:str) -> str:
        WebScraper.validate(link)
        driver = WebScraper.DRIVER
        driver.maximize_window()
        WebScraper.goToLink(link)
        elem = WebDriverWait(driver, 50).until(EC.element_to_be_clickable((By.CSS_SELECTOR, cssSelector)))
        return WebScraper.clickElement(elem)
    @staticmethod
    def clickXpath(link: str, xpath:str) -> str:
        WebScraper.validate(link)
        driver = WebScraper.DRIVER
        driver.maximize_window()
        WebScraper.goToLink(link)
        elem = WebDriverWait(driver, 50).until(EC.element_to_be_clickable((By.XPATH, xpath)))
        return WebScraper.clickElement(elem)
    @staticmethod
    def validate(link: str):
        if link.find("flashscore.pt") == -1:
            raise Exception("Not a valid link.")
    @staticmethod
    def goToLink(link: str):
        driver = WebScraper.DRIVER
        if not(driver.current_url == link):
            driver.get(link)
            WebScraper.acceptCookiesIfAvailable(link)
            time.sleep(5)
def close():
    WebScraper.DRIVER.close()
atexit.register(close)