import numpy as np, scipy.stats
class MathOperations:
    def __init__(self, values:list=[]):
        self.values = values
        self.average = 0.0
        self.standardDeviation = 0.0
        self.prob = 0.0
    def insertValue(self, n: float) -> bool:
        try:
            self.values.append(n)
        except:
            return False
        return True
    def calculateAverage(self) -> float:
        self.average = float(np.mean(self.values))
        return self.average
    def calculateDeviation(self) -> float:
        self.calculateAverage()
        denom = 0
        for i in self.values:
            denom += (i - self.average)**2
        self.standardDeviation =np.sqrt(denom / len(self.values))
        return self.standardDeviation
    def calculateNormalDistribution(self):
        self.calculateAverage()
        self.calculateDeviation()
        x = np.arange(self.average - 3 * self.standardDeviation, self.average + 3 * self.standardDeviation, 0.001)
        y = np.array([])
        for i in x:
            y = np.append(y, [scipy.stats.norm.pdf(i, self.average, self.standardDeviation)])
        return x, y