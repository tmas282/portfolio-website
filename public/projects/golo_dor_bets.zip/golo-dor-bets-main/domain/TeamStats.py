from .WebScraper import WebScraper as ws
from .Team import Team

class TeamStats():
    LAST_5_GAMES_HOME_SELECTOR = lambda self, x: f"div.h2h__section:nth-child(1) > div:nth-child(2) > div:nth-child({x})"
    LAST_5_GAMES_AWAY_SELECTOR = lambda self, x: f"div.h2h__section:nth-child(2) > div:nth-child(2) > div:nth-child({x})"
    STATS_GOALS_HOME_SELECTOR = " > span:nth-child(5) > span:nth-child(1)"
    STATS_GOALS_AWAY_SELECTOR = " > span:nth-child(5) > span:nth-child(2)"
    def __init__(self, link: str, homeTeam: bool):
        self.goals = []
        self.team = Team(link, homeTeam)
        self.loadStats(link, homeTeam)
    def loadStats(self, link: str, homeTeam: bool):
        for i in range(1, 6):
            if ws.getValuesFrom(link, f"._tabs_1v9r6_4 > a:nth-child({i}) > button:nth-child(1)") == "H2H":
                h2hLink = ws.click(link, f"._tabs_1v9r6_4 > a:nth-child({i}) > button:nth-child(1)")
                break
        for i in range(1,6):
            if(homeTeam):
                selector = self.LAST_5_GAMES_HOME_SELECTOR(i)
            else:
                selector = self.LAST_5_GAMES_AWAY_SELECTOR(i)
            if(self.team.checkIfHomeInGame(h2hLink, selector)):
                self.goals.append( int(ws.getValuesFrom(h2hLink, selector + self.STATS_GOALS_HOME_SELECTOR)))
            else:
                self.goals.append( int(ws.getValuesFrom(h2hLink, selector + self.STATS_GOALS_AWAY_SELECTOR)))
    def getGoals(self):
        return self.goals
    def getTeam(self):
        return self.team