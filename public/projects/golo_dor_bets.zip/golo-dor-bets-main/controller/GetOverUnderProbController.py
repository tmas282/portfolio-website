from os import path
import sys
sys.path.append(path.join(path.dirname(__file__), '..'))

import pandas as pd
import scipy.stats

from domain.MathOperations import MathOperations

class GetOverUnderProbController():
    def readFile(self):
        self.df = pd.read_csv(self.location)

    def setFileLocation(self, location: str):
        self.location = location
        self.readFile()
    
    def calculateOverUnder(self, value: float):
        goals = self.df["Goals"].to_list()
        math = MathOperations(goals)
        mu = math.calculateAverage()
        sigma = math.calculateDeviation()
        norm = scipy.stats.norm(mu, sigma)
        return norm.cdf(value), 1-norm.cdf(value)