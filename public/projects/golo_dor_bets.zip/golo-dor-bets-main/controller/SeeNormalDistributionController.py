from os import path
import sys
sys.path.append(path.join(path.dirname(__file__), '..'))

from domain.MathOperations import MathOperations

class SeeNormalDistributionController:
    def __init__(self):
        self.mathOperations = MathOperations()
    def insertValue(self, number: int) -> bool:
        return self.mathOperations.insertValue(number)
    def requestValues(self):
        average = self.mathOperations.calculateAverage()
        deviation = self.mathOperations.calculateDeviation()
        distribution = self.mathOperations.calculateNormalDistribution()
        return average, deviation, distribution