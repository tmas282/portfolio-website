from os import path
import sys
sys.path.append(path.join(path.dirname(__file__), '..'))

from domain.Game import Game
from domain.TeamStats import TeamStats
import pandas as pd

class GetDataController:
    def createCSV(self, stat: TeamStats):
            df = pd.DataFrame({"Goals": stat.getGoals()})
            df.to_csv(f"./out/{stat.getTeam().getName().replace(" ", "_")}.csv", index=False)
    def keepData(self, link: str):
        self.game = Game(link)
        self.stats = self.game.getStats()
        for stat in self.stats:
            self.createCSV(stat)
        