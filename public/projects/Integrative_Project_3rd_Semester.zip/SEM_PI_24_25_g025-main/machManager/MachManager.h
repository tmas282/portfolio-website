#ifndef MACHMANAGER_H
#define MACHMANAGER_H
typedef struct{
    int id;
    char name[100];
    float tempMin;
    float tempMax;
    float humMin;
    float humMax;
    int bufferLength;
    int medianLength;
} Machine;
extern Machine* machines;
extern int machinesLength;
Machine* getMachineById(int id);
Machine* addMachine(Machine machine);
#endif
