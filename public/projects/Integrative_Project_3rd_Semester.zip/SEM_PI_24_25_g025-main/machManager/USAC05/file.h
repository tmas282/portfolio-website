#ifndef FILE_H
#define FILE_H

int enqueue_value(int* buffer, int length, int* tail, int* head, int value);

#endif
