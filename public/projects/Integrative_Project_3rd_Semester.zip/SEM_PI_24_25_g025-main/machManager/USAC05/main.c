#include <stdio.h>
#include "file.h"

int main() {
    int buffer[] = {0,0,0,0,0};
    int length = 5;
    int* tail = buffer;
    int* head = buffer;
	int value = 100;
	
	printf("Initial state:\n");
    for(int i = 0; i < length; i++){
		printf("Elemento %d = %d\n", i, buffer[i]);
	}
	printf("\n");
	for(int j = 0; j < length * 2 - 1; j++){
		if(j == 5){
			head = buffer;
		}
		if (j >= 5){
			tail++;
		}
		int res = enqueue_value(buffer, length, tail, head, value);
		printf("%d : Buffer updated\n", res); // Expected output: 0

		printf("Buffer after update:\n");
		for(int i = 0; i < length; i++){
			printf("Elemento %d = %d\n", i, buffer[i]);
		}
		head++;
		value++;
    }
    return 0;
}
