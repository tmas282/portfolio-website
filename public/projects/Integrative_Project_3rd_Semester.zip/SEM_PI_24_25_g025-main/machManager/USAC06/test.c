#include <stdio.h>
#include <assert.h>
#include "asm.h"
void testRemovingValue(){
	int buffer[] = {5, 4, 3, 2, 1};
	int length = 5;
	int* tail = &buffer[0];
	int* head = &buffer[4];
	int value;
	int res = dequeue_value(&buffer, length, tail, head, &value);
	assert(res == 1);
	assert(value == 5);
	assert(buffer[0] == 4);
	assert(buffer[1] == 3);
	assert(buffer[2] == 2);
	assert(buffer[3] == 1);
	assert(buffer[4] == 0);
}
void testNegativeValue(){
	int buffer[] = {-5, -10, -2, -6, -100};
	int length = 5;
	int* tail = &buffer[0];
	int* head = &buffer[4];
	int value;
	int res = dequeue_value(&buffer, length, tail, head, &value);
	assert(res == 1);
	assert(value == -5);
	assert(buffer[0] == -10);
	assert(buffer[1] == -2);
	assert(buffer[2] == -6);
	assert(buffer[3] == -100);
	assert(buffer[4] == 0);
}
void testMixedValue(){
	int buffer[] = {-5, 10, 2, -6, 100, -1};
	int length = 6;
	int* tail = &buffer[0];
	int* head = &buffer[5];
	int value;
	int res = dequeue_value(&buffer, length, tail, head, &value);
	assert(res == 1);
	assert(value == -5);
	assert(buffer[0] == 10);
	assert(buffer[1] == 2);
	assert(buffer[2] == -6);
	assert(buffer[3] == 100);
	assert(buffer[4] == -1);
	assert(buffer[5] == 0);
}
int main(){
	printf("==== Test positive value ====\n");
	testRemovingValue();
	printf("==== PASSED ====\n");
	
	printf("==== Test negative value ====\n");
	testNegativeValue();
	printf("==== PASSED ====\n");
	
	printf("==== Test mixed values ====\n");
	testMixedValue();
	printf("==== PASSED ====\n");
}
