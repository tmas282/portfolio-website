#include <stdio.h>
#include "asm.h"
void print(int buffer[], int length){
	for(int i=0; i<length; i++){
		printf("%d, ", buffer[i]);
	}
	printf("\n");
}
int main(){
	int buffer[] = {5, 4, 3, 2, 1};
	int length = 5;
	int* tail = &buffer[0];
	int* head = &buffer[4];
	int value;
	print(buffer, length);
	int res = dequeue_value(&buffer, length, tail, head, &value);
	print(buffer, length);
	printf("Value removed: %d\n", value);
	printf("Return value: %d\n", res);
}
