#include <stdlib.h>
#include "MachManager.h"

Machine* machines;
int machinesLength;

Machine* addMachine(Machine machine){
    if(machinesLength == 0){
        machines = (Machine*) malloc(sizeof(Machine));
        *machines = machine;
    }
    else{
        machines = (Machine*) realloc(machines, (machinesLength+1) * sizeof(Machine));
        *(machines + machinesLength) = machine;
    }
    machinesLength++;
    return (machines + machinesLength - 1);
}
Machine* getMachineById(int id){
    for (int i = 0; i < machinesLength; i++)
    {
        if((machines + i)->id == id){
            return (machines + i);
        }
    }
    return NULL;
}
