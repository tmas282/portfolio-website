#include <stdio.h>

extern int get_n_element(int* buffer, int length, int* tail, int* head);

void test_get_n_element(int* buffer, int length, int* tail, int* head) {
	int n_elements = get_n_element(buffer, length, tail, head);
	printf("Buffer size: %d, Tail: %d, Head: %d, Elements: %d\n", length, *tail, *head, n_elements);
}

int main() {
	int buffer[10];

	int tail1 = 0, head1 = 0;
	test_get_n_element(buffer, 10, &tail1, &head1);

	int tail2 = 0, head2 = 3;
	test_get_n_element(buffer, 10, &tail2, &head2);

	int tail3 = 6, head3 = 5;
	test_get_n_element(buffer, 10, &tail3, &head3);

}
