// test_usac07.c
#include <assert.h>
#include <stdio.h>
#include "asm.h"

void test_get_n_element() {
    int buffer[10];
    int tail1 = 0, head1 = 0;
    int res1 = get_n_element(buffer, 10, &tail1, &head1);
    assert(res1 == 0);

    int tail2 = 0, head2 = 3;
    int res2 = get_n_element(buffer, 10, &tail2, &head2);
    assert(res2 == 10);

    int tail3 = 6, head3 = 5;
    int res3 = get_n_element(buffer, 10, &tail3, &head3);
    assert(res3 == 10);

    printf("All tests passed for get_n_element.\n");
}

int main() {
    test_get_n_element();
    return 0;
}