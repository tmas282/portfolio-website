#ifndef FILE_H
#define FILE_H

int extract_data(char* str, char* token, char* unit, int* value);

#endif
