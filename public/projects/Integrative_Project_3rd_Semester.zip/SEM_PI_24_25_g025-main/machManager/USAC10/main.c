#include <stdio.h>
#include "asm.h"
void print(int vec[], int n){
	for(int i=0; i<n; i++){
		printf("%d, ", vec[i]);
	}
	printf("\n");
}
int main(){
	int vec[] = {9, 4, 6, 1, 100, 1};
	int length = 6;
	int me;
	print(vec, length);
	int res = median(&vec, length, &me);
	printf("Return: %d\n", res);
	printf("Median: %d\n", me);
	print(vec, length);
}
