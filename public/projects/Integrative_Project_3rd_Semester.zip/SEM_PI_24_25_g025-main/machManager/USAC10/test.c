#include <stdio.h>
#include <assert.h>
#include "asm.h"
void testLengthZero(){
	int vec[] = {5, 4, 3, 2, 1};
	int length = 0;
	int me;
	int res = median(&vec, length, &me);
	assert(res == 0);
}
void testLengthNegative(){
	int vec[] = {5, 4, 3, 2, 1};
	int length = -1;
	int me;
	int res = median(&vec, length, &me);
	assert(res == 0);
}
void testOddLength(){
	int vec[] = {5, 4, 3, 2, 1};
	int length = 5;
	int me;
	int res = median(&vec, length, &me);
	assert(res == 1);
	assert(me == 3);
}
void testEvenLength(){
	int vec[] = {5, 4, 3, 3, 2, 1};
	int length = 6;
	int me;
	int res = median(&vec, length, &me);
	assert(res == 1);
	assert(me == 3);
}
void testEvenLengthDecimalMedian(){
	int vec[] = {5, 4, 3, 2, 2, 1};
	int length = 6;
	int me;
	int res = median(&vec, length, &me);
	assert(res == 1);
	assert(me == 3);
}
void testOneElement(){
	int vec[] = {1};
	int length = 1;
	int me;
	int res = median(&vec, length, &me);
	assert(res == 1);
	assert(me == 1);
}
int main(){
	printf("==== testLengthZero ====\n");
	testLengthZero();
	printf("==== PASSED ====\n");
	
	printf("==== testLengthNegative ====\n");
	testLengthNegative();
	printf("==== PASSED ====\n");
	
	printf("==== testOddLength ====\n");
	testOddLength();
	printf("==== PASSED ====\n");
	
	printf("==== testEvenLength ====\n");
	testEvenLength();
	printf("==== PASSED ====\n");
	
	printf("==== testEvenLengthDecimalMedian ====\n");
	testEvenLengthDecimalMedian();
	printf("==== PASSED ====\n");
	
	printf("==== testOneElement ====\n");
	testOneElement();
	printf("==== PASSED ====\n");
}
