#ifndef ASM_H
#define ASM_H
extern int median(int* vec, int length, int* me);
#endif
