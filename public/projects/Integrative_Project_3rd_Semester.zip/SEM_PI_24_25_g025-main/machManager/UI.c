#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "MachManager.h"

void initialSetupForEachMachine(){
    FILE* filep;
    char filename[100];
    printf("\nEnter filepath: ");
    scanf("%s", filename);
    filep = fopen(filename, "r");
    if(filep == NULL){
        printf("\nFile doesn't exist!");
        return;
    }
    char line[1000];
    while(fgets(line, 1000, filep)){
        short flag = 0;
        char *token = strtok(line, ";");
        int id = atoi(token);
        if(getMachineById(id) != NULL){
            printf("\nMachine with id %d already exists.", id);
            flag++;
        }
        char *machineName = strtok(NULL, ";");
        char *tempMinP = strtok(NULL, ";");
        float tempMin = (float) atof(tempMinP);
        char *tempMaxP = strtok(NULL, ";");
        float tempMax = (float) atof(tempMaxP);
        if(tempMin > tempMax){
            printf("\nTemperature maximum < Temperature minimum");
            flag++;
        }
        char *humMinP = strtok(NULL, ";");
        float humMin = (float) atof(humMinP);
        char *humMaxP = strtok(NULL, ";");
        float humMax = (float) atof(humMaxP);
        if(humMin > humMax){
            printf("\nHumidity maximum < Humidity minimum");
            flag++;
        }
        char *bufferLenP = strtok(NULL, ";");
        int bufferLen = atoi(bufferLenP);
        char *medianLenP = strtok(NULL, ";");
        int medianLen = atoi(medianLenP);
        if(medianLen > bufferLen){
            printf("\nMoving median window length > Circular Buffer length");
            flag++;
        }
        if(flag == 0){
            Machine m;
            m.id = id;
            strcpy(m.name, machineName);
            m.humMax = humMax;
            m.humMin = humMin;
            m.tempMax = tempMax;
            m.tempMin = tempMin;
            m.bufferLength = bufferLen;
            m.medianLength = medianLen;
            addMachine(m);
        }
        else{
            printf("Flags detected, not adding machine.");
        }
    }
    fclose(filep);
    return;
}
void showMachines(){
    Machine* m = machines;
    for(int i=0; i<machinesLength; i++){
        Machine* mach = (m + i);
        printf("Machine %d pointer: %p\n", i, mach);
        printf("\t Id: %d Name: %s\n", mach->id, mach->name);
        printf("\t Temp Min: %.2f Temp Max: %.2f\n", mach->tempMin, mach->tempMax);
        printf("\t Hum Min: %.2f Hum Max: %.2f\n", mach->humMin, mach->humMax);
        printf("\t Buffer Length: %d Median Length: %d\n\n", mach->bufferLength, mach->medianLength);
    }
}
void showMenu(){
    printf("[0] Leave Program\n");
    printf("[1] Perform the data structure initial setup for each machine using a text file (USAC12)\n");
    printf("[2] Show data structure of machines\n");
}
int main(){
    int option = 0;
    while(1){
        showMenu();
        printf("\nInsert Option: ");
        scanf("%d", &option);
        switch (option)
        {
            case 0:
                exit(0);
                break;
            case 1:
                initialSetupForEachMachine();break;
            case 2:
                showMachines();break;
            default:
                printf("\n");
        }
    }
    return 0;
}
