#include <stdio.h>
#include "asm.h"

#define LENGTH 5

int main() {
    int buffer[LENGTH] = {1, 2, 3, 4, 5};
    int array[5] = {0};
    int head = 0;
    int tail = 5;
    int n = 3;

    printf("Initial buffer: ");
    for (int i = 0; i < LENGTH; i++) {
        printf("%d ", buffer[i]);
    }
    printf("\n");

    int res = move_n_to_array(buffer, LENGTH, &tail, &head, n, array);

    if (res==1) {
        printf("Move succeeded!\n");
        printf("Array: ");
        for (int i = 0; i < n; i++) {
            printf("%d ", array[i]);
        }
        printf("\n");
        printf("Updated buffer: ");
        for (int i = 0; i < LENGTH; i++) {
            printf("%d ", buffer[i]);
        }
        printf("\n");
        printf("Updated head: %d\n", head);
        printf("Updated tail: %d\n", tail);
    } else {
        printf("Move failed: Not enough elements in the buffer.\n");
    }
//
    return 0;
}
