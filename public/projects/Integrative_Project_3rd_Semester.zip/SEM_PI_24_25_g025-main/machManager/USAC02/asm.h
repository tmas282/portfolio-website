#ifndef ASM_H
#define ASM_H
extern int get_number_binary(int value, char* bits);
#endif
