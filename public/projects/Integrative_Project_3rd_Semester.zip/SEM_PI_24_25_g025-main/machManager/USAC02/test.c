#include <stdio.h>
#include <assert.h>
#include "asm.h"
void testNegativeValue(){
	int value = -1;
	char bits[5];
	int res = get_number_binary(value, bits);
	assert (res == 0);
}
void testHigherThanMaxValue(){
	int value = 32;
	char bits[5];
	int res = get_number_binary(value, bits);
	assert (res == 0);
}
void testNullValue(){
	int value = 0; //0b00000
	char bits[5];
	int res = get_number_binary(value, bits);
	assert (res == 1);
	for(int i=0; i<5; i++){
		assert (bits[i] == 0);
	}
}
void testValueInsideInterval(){
	int value = 26; // 0b11010
	char bits[5];
	int res = get_number_binary(value, bits);
	assert (res == 1);
	assert (bits[4] == 1);
	assert (bits[3] == 1);
	assert (bits[2] == 0);
	assert (bits[1] == 1);
	assert (bits[0] == 0);
}
int main(){
	printf("==== Test negative value ====\n");
	testNegativeValue();
	printf("==== PASSED ====\n");
	
	printf("==== Test value higher than 31 ====\n");
	testHigherThanMaxValue();
	printf("==== PASSED ====\n");
	
	printf("==== Test for value 0 ====\n");
	testNullValue();
	printf("==== PASSED ====\n");
	
	printf("==== Test value inside [0, 31] ====\n");
	testValueInsideInterval();
	printf("==== PASSED ====\n");
}
