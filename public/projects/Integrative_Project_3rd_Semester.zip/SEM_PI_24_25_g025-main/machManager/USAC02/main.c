#include <stdio.h>
#include "asm.h"
int main(){
	int value = 26; // 0b11010
	char bits[5];
	int res = get_number_binary(value, bits);
	printf("Number %d (return: %d): %d, %d, %d, %d, %d\n", value, res, bits[4], bits[3], bits[2], bits[1], bits[0]);
}
