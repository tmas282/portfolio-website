#ifndef MACH_MANAGER_H
#define MACH_MANAGER_H
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_OPERATIONS 32
#define MAX_NAME_LEN 100
#define INITIAL_MACHINE_CAPACITY 10
#define STATUS_COUNT 3
#define MAX_BUFFER_LENGTH 100

typedef struct {
    char name[MAX_NAME_LEN];
    float tempMin;
    float tempMax;
    float humMin;
    float humMax;
    int bufferLength;
    int medianWindowLength;
    float currentTemp;
    float currentHum;
    int id;                 
    char state[4];
    int operations[MAX_OPERATIONS];    
    int operationCount;        
    time_t timestamp;    
    
    // Parâmetros de cálculo da mediana
    float tempBuffer[MAX_BUFFER_LENGTH];
    float humBuffer[MAX_BUFFER_LENGTH];
    int bufferIndex;
} Machine;

typedef struct {
    int id;
    char name[MAX_NAME_LEN];
} Operation;

extern Machine *machines;  
extern int machineTotal;  
extern int machineCapacity;      

int configureSerialPort(const char *portname);
int findOperationIndexById(int operation_id);
void sendCommandToMachine(int fd, const char *command);
void readSensorData(int fd, Machine* machine);
Machine* selectMachine(int id);
void checkAlerts(Machine* machine);
void freeMachines();

#endif
