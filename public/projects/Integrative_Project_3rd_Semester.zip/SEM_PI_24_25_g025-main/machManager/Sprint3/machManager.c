#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <time.h>
#include "machManager.h"
#include "file.h"

Machine* selectMachine(int id) {
    for (int i = 0; i < machineTotal; i++) {
        if (machines[i].id == id) {
            return &machines[i];
        }
    }
    return NULL;
}

int configureSerialPort(const char *port) {
    int pico = open(port, O_RDWR | O_NOCTTY | O_SYNC);
    if (pico < 0) {
        perror("Erro. Serial Port.");
        exit(1);
    }
    struct termios tty;
    if (tcgetattr(pico, &tty) != 0) {
        perror("Erro. Attributes.");
        exit(1);
    }
    cfsetospeed(&tty, B9600);
    cfsetispeed(&tty, B9600);

    tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8; 
    tty.c_cflag &= ~PARENB;                    
    tty.c_cflag &= ~CSTOPB;                    
    tty.c_cflag |= CREAD | CLOCAL;             

    tty.c_lflag &= ~ICANON;
    tty.c_lflag &= ~ECHO;   
    tty.c_lflag &= ~ECHOE;
    tty.c_lflag &= ~ISIG;   

    tty.c_iflag &= ~(IXON | IXOFF | IXANY);
    tty.c_oflag &= ~OPOST;

    if (tcsetattr(pico, TCSANOW, &tty) != 0) {
        perror("Erro. Setup serial port.");
        exit(1);
    }
    return pico;
}

void initializeBuffer(float* buffer, int length, float value) {
    for (int i = 0; i < length; i++) {
        buffer[i] = value;
    }
}

void sendCommandToMachine(int pico, const char *command) {
    write(pico, command, strlen(command));
    write(pico, "\n", 1);
}

void readSensorData(int pico, Machine* machine) {
    char buffer[200];
    int n = read(pico, buffer, sizeof(buffer) - 1);
    if (n > 0) {
        buffer[n] = '\0'; 
        char unit[20];      
        int value;
        if (extract_data(buffer, "TEMP", unit, &value)) {
            
            machine->currentTemp = value;
            machine->tempBuffer[machine->bufferIndex] = value;
        }
        else{
            printf("Error reading temperature\n");
        }
        if (extract_data(buffer, "HUM", unit, &value)) {
            machine->currentHum = value;
            machine->humBuffer[machine->bufferIndex] = value;
        }
        else{
            printf("Error reading humidity\n");
        }
        if (machine->bufferIndex == 0) {
            initializeBuffer(machine->tempBuffer, machine->bufferLength, machine->currentTemp);
            initializeBuffer(machine->humBuffer, machine->bufferLength, machine->currentHum);
        }
        machine->bufferIndex = (machine->bufferIndex + 1) % machine->bufferLength;
        int tempValues[MAX_BUFFER_LENGTH];
        int startIndex = (machine->bufferIndex - machine->medianWindowLength + machine->bufferLength) % machine->bufferLength;
        for (int i = 0; i < machine->medianWindowLength; i++) {
            tempValues[i] = (int)machine->tempBuffer[(startIndex + i) % machine->bufferLength];
        }
        int tempMedian = 0;
        median(tempValues, machine->medianWindowLength, &tempMedian);
        int humValues[MAX_BUFFER_LENGTH];
        for (int i = 0; i < machine->medianWindowLength; i++) {
            humValues[i] = (int)machine->humBuffer[(startIndex + i) % machine->bufferLength];
        }
        int humMedian = 0;
        median(humValues, machine->medianWindowLength, &humMedian);
        printf("%s (Id:%d), Actual Temperature(ºC): %.2f, Temperature Median(ºC): %d, Actual Humidity(%%): %.2f, Humidity Median(%%): %d\n", 
            machine->name,machine->id, machine->currentTemp, tempMedian, machine->currentHum, humMedian);
    }
    checkAlerts(machine);
}

void checkAlerts(Machine* machine) {
    if (machine->currentTemp < machine->tempMin) {
        printf("Actual Temperature below lower limit %.2f. Actual Temperature: %.2f\n", machine->tempMin, machine->currentTemp);
    } else if (machine->currentTemp > machine->tempMax) {
        printf("Actual Temperature above higher limit %.2f. Actual Temperature: %.2f\n", machine->tempMax, machine->currentTemp);
    }
    if (machine->currentHum < machine->humMin) {
        printf("Actual Humidity below lower limit %.2f. Actual Humidity: %.2f\n", machine->humMin, machine->currentHum);
    } else if (machine->currentHum > machine->humMax) {
        printf("Actual Humidity above higher limit %.2f. Actual Humidity: %.2f\n", machine->humMax, machine->currentHum);
    }
}
