#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <unistd.h>
#include "machManager.h"
#include "file.h"

const char *SERIAL_PORT_PATH = "/dev/ttyACM0";
Operation OPERATIONS[] = {
    {0, "CUT"},
    {1, "DRILL"},
    {2, "SCREW"},
    {3, "POLISH"},
    {4, "VARNISH"},
    {5, "PACK"},
    {6, "FIX"},
    {7, "ASSEMBLE"},
    {8, "PAINT"},
    {9, "LAMINATE"},
    {10, "DISASSEMBLE"},
    {11, "DRY"},
    {12, "COOL"},
    {13, "HEAT"},
    {14, "BOND"},
    {15, "STORE"},
    {16, "CALIBRATE"},
    {17, "GRIND"},
    {18, "MARK"},
    {19, "TEST"},
    {20, "FOLD"},
    {21, "BRUSH"},
    {22, "CHECK"},
    {23, "ADJUST"},
    {24, "LOAD"},
    {25, "UNLOAD"},
    {26, "ENGRAVE"},
    {27, "CRUSH"},
    {28, "TRANSFER"},
    {29, "SAW"},
    {30, "PRINT"},
    {31, "COMPRESS"}
};

Machine *machines = NULL;
int machineTotal = 0;
int machineCapacity = INITIAL_MACHINE_CAPACITY;

void reallocMachines() {
    machineCapacity *= 2;
    machines = (Machine *)realloc(machines, machineCapacity * sizeof(Machine));
    if (machines == NULL) {
        printf("Error. Machine memory reallocation failed.\n");
        exit(1);
    }
}

void showOperations() {
    printf("\nOperations:\n");
    for (int i = 0; i < MAX_OPERATIONS; i++) {
        if (strlen(OPERATIONS[i].name) > 0) {
            printf("Id: %d, Name: %s\n", OPERATIONS[i].id, OPERATIONS[i].name);
        }
    }
}

void showMachines() {
    printf("Machines:\n");
    for (int i = 0; i < machineTotal; i++) {
        char status[17];
        if (strcmp(machines[i].state, "ON") == 0) {
            strcpy(status, "ON: Ready");
        } else if (strcmp(machines[i].state, "OFF") == 0) {
            strcpy(status, "OFF: Turned Off");
        } else if (strcmp(machines[i].state, "OP") == 0) {
            strcpy(status, "OP: In Operation");
        } else {
            strcpy(status, "Error");
        }
        printf("Id: %d, Name: %s, Status: %s, ", machines[i].id, machines[i].name, status);
        if (machines[i].operationCount > 0) {
            printf("Operations: ");
            for (int j = 0; j < machines[i].operationCount; j++) {
                int operationId = machines[i].operations[j];
                int operationIndex = findOperationIndexById(operationId);
                if (operationIndex != -1) {
                    printf("%d - %s", operationId, OPERATIONS[operationIndex].name);
                    if (j < machines[i].operationCount - 1) {
                        printf(", ");
                    }
                }
            }
        } else {
            printf("No Operations");
        }
        printf("\n");
    }
}

int findMachineIndexById(int id) {
    for (int i = 0; i < machineTotal; i++) {
        if (machines[i].id == id) {
            return i;
        }
    }
    return -1;
}

int findOperationIndexById(int operationId) {
    for (int i = 0; i < MAX_OPERATIONS; i++) {
        if (OPERATIONS[i].id == operationId) {
            return i;
        }
    }
    return -1;
}

int doesMachineExist(int id) {
    for (int i = 0; i < machineTotal; i++) {
        if (machines[i].id == id) {
            return 1;
        }
    }
    return 0;
}

void addMachine() {
	printf("\n");
	if (machineTotal >= machineCapacity) {
        reallocMachines();
    }
    Machine newMachine;
    for (int i = 0; i < MAX_OPERATIONS; i++) {
        newMachine.operations[i] = -1;
    }
    newMachine.operationCount = 0;
    char input[100];
    int valid = 0;
    int id;
    printf("Machine id: ");
    while (1) {
        scanf("%d", &id);
        if (id < 0) {
            printf("Insert a positive number");
            while (getchar() != '\n');
        }
        else {
            int idExists = 0;
            for (int i = 0; i < machineTotal; i++) {
                if (machines[i].id == id) {
                    idExists = 1;
                    break;
                }
            }
            if (idExists) {
                printf("A machine with that id already exists.\n");
            } else {
                newMachine.id = id;
                while (getchar() != '\n');
                break;
            }
        }
    }
    printf("Name of machine: ");
    fgets(newMachine.name, sizeof(newMachine.name), stdin);
    newMachine.name[strcspn(newMachine.name, "\n")] = '\0';
    valid = 0;
    do {
        printf("Minimum temperature: ");
        fgets(input, sizeof(input), stdin);
        input[strcspn(input, "\n")] = '\0';
        newMachine.tempMin = strtof(input, NULL);
        printf("Maximum temperature: ");
        fgets(input, sizeof(input), stdin);
        input[strcspn(input, "\n")] = '\0';
        newMachine.tempMax = strtof(input, NULL);
        if (newMachine.tempMax < newMachine.tempMin) {
            printf("Maximum temperature can't be lower than minimum temperature.\n");
        } else {
            valid = 1;
        }
    } while (valid != 1);
    valid = 0;
    do {
        printf("Minimum humidity (0-100%%): ");
        fgets(input, sizeof(input), stdin);
        input[strcspn(input, "\n")] = 0;
        newMachine.humMin = strtof(input, NULL);

        printf("Maximum humidity (0-100%%): ");
        fgets(input, sizeof(input), stdin);
        input[strcspn(input, "\n")] = 0;
        newMachine.humMax = strtof(input, NULL);

        if (newMachine.humMax < newMachine.humMin || newMachine.humMax > 100 || newMachine.humMin < 0) {
            printf("Maximum humidity  is lower than minimum humidity or humidadities not inside the valid interval [0,100].\n");
        } else {
            valid = 1;
        }
    } while (!valid);
    valid = 0;
    do {
        printf("Circular Buffer Length: ");
        fgets(input, sizeof(input), stdin);
        input[strcspn(input, "\n")] = 0;
        newMachine.bufferLength = strtol(input, NULL, 10);
        if (newMachine.bufferLength <= 0) {
            printf("Can't be negative.\n");
        } else {
            valid = 1;
        }
    } while (!valid);
    valid = 0;
    do {
        printf("Moving Median Window Length: ");
        fgets(input, sizeof(input), stdin);
        input[strcspn(input, "\n")] = 0;
        newMachine.medianWindowLength = strtol(input, NULL, 10);
        if (newMachine.medianWindowLength <= 0) {
            printf("Can't be negative.\n");
        } else if (newMachine.medianWindowLength > newMachine.bufferLength) {
            printf("Moving Median Window Length is lower than Circular Buffer Length.\n");
        } else {
            valid = 1;
        }
    } while (!valid);
	strncpy(newMachine.state, "ON", sizeof(newMachine.state) - 1);
	newMachine.state[sizeof(newMachine.state) - 1] = '\0';
    newMachine.currentTemp = newMachine.tempMin;
    newMachine.currentHum = newMachine.humMin;
    newMachine.timestamp = time(NULL);
    machines[machineTotal] = newMachine;
    machineTotal++;
    printf("\nAdded Machine:\n");
    printf("Name: %s (Id: %d)\n", newMachine.name, newMachine.id);
    printf("Temperature (ºC): [%.2f; %.2f]\n", newMachine.tempMin, newMachine.tempMax);
    printf("Humidity (%%): [%.2f%%, %.2f%%]\n", newMachine.humMin, newMachine.humMax);
    printf("Circular Buffer Length: %d\n", newMachine.bufferLength);
    printf("Moving Median Window Length: %d\n", newMachine.medianWindowLength);
}

void removeMachine() {
	printf("\n");
    if (machineTotal == 0) {
        printf("Machines arent available.\n");
        return;
    }
    showMachines();
    printf("\n");
    int machineId;
    int machineIndex = -1;
    
	do {
		printf("Type machine id to remove, or 'X' to cancel: ");
		char input[100];
		scanf("%s", input);
		if (input[0] == 'X' || input[0] == 'x') {
			printf("Process canceled.\n");
			return;
		}
		if (sscanf(input, "%d", &machineId) == 0) {
			printf("It isn't a floating point number.\n");
		} else {
			machineIndex = findMachineIndexById(machineId);
			if (machineIndex == -1) {
				printf("That machine doesnt exist.\n");
			} else {
				break;
			}
		}
	} while (machineIndex == -1);
    if (machineIndex != -1) {
        printf("%s (Id: %d) selected. Do you wish to remove? (Y for yes, N to cancel):", machines[machineIndex].name, machines[machineIndex].id);
        while (getchar() != '\n');
        char cancelChoice;
        scanf("%c", &cancelChoice);
        if (cancelChoice == 'N' || cancelChoice == 'n') {
            printf("Canceled.\n");
            return;
        }
		if (strcmp(machines[machineIndex].state, "OP") == 0) {
			printf("That machine is operating and can't be removed.\n");
			return;	
		}
        printf("Machine %d removed.\n", machines[machineIndex].id);
        for (int i = machineIndex; i < machineTotal - 1; i++) {
            machines[i] = machines[i + 1];
        }
        machineTotal--;
    }
}

void assignOperation() {
    printf("\n");
    if (machineTotal == 0) {
        printf("Machines arent available.\n");
        return;
    }
    showMachines();
    printf("\n");
    int machineId;
    int machineIndex = -1;
    char input[100];
    do {
        printf("Type the machine id or 'X' to cancel: ");
        scanf("%s", input);
        if (input[0] == 'X' || input[0] == 'x') {
            printf("Canceled.\n");
            return;
        }
        if (sscanf(input, "%d", &machineId) == 0) {
            printf("It isn't a floating point number.\n");
        } else {
            machineIndex = findMachineIndexById(machineId);
            if (machineIndex == -1) {
                printf("Machine not found.\n");
            } else {
                break;
            }
        }
    } while (machineIndex == -1);
    printf("You selected %s (Id: %d)\n", machines[machineIndex].name, machines[machineIndex].id);
	showOperations();	
	printf("\n");
	int operationId;
	int operationIndex = -1;
	char *endptr;
	do {
		printf("Type the operation ID, or 'X' to cancel: ");
		scanf("%s", input);
		if (input[0] == 'X' || input[0] == 'x') {
			printf("Process canceled.\n");
			return;
		}
		operationId = strtol(input, &endptr, 10);

		if (*endptr != '\0') {
			printf("Invalid Entry.\n");
			continue;
		}
		operationIndex = findOperationIndexById(operationId);
		if (operationIndex == -1) {
			printf("Operation not found.\n");
		} else {
			break;
		}
	} while (operationIndex == -1);
	if (operationIndex != -1) {
		printf("Operacao selected: %s.\n", OPERATIONS[operationIndex].name);
	}
    if (machines[machineIndex].operationCount >= MAX_OPERATIONS) {
        printf("Error: This machine is on operation limit.\n");
        return;
    }
    machines[machineIndex].operations[machines[machineIndex].operationCount] = OPERATIONS[operationIndex].id;
    machines[machineIndex].operationCount++;
    printf("Operation %s -> machine %s.\n", OPERATIONS[operationIndex].name, machines[machineIndex].name);
}

void checkMachineStatus() {
	printf("\n");
    if (machineTotal == 0) {
        printf("Machines arent available.\n");
        return;
    }
    showMachines();
    printf("\n");
    int machineId;
    while (1) {
        printf("Type the Id of the machine to see the details or 'X' to cancel: ");
        char input[10];
        scanf("%s", input);
        if (input[0] == 'X' || input[0] == 'x') {
            printf("Process canceled.\n");
            return;
        }
        if (sscanf(input, "%d", &machineId) != 1) {
            printf("Invalid.\n");
        } else {
            int machineIndex = findMachineIndexById(machineId);
            if (machineIndex == -1) {
                printf("Machine not found.\n");
            } else {
                Machine *m = &machines[machineIndex];
                char status[17];
                if (strcmp(m->state, "ON") == 0) {
                    strcpy(status, "ON: Ready");
                } else if (strcmp(m->state, "OFF") == 0) {
                    strcpy(status, "OFF: Turned Off");
                } else if (strcmp(m->state, "OP") == 0) {
                    strcpy(status, "OP: In Operation");
                } else {
                    strcpy(status, "Error");
                }
                printf("\nMachine details:\n");
                printf("Name: %s (Id: %d)\n", m->name, m->id);
                printf("Actual Temperature (ºC): %.2f Interval (ºC): [%.2f, %.2f]\n", m->currentTemp, m->tempMin, m->tempMax);
                printf("Actual Humidity (%%): %.2f%% Interval (%%): [%.2f%%, %.2f%%]\n", m->currentHum, m->humMin, m->humMax);
                printf("Circular Buffer Length: %d\n", m->bufferLength);
                printf("Moving Median Window Length: %d\n", m->medianWindowLength);
				printf("Status: %s\n", status);
                if (m->operationCount == 0) {
                    printf("No Operations in the machine.\n");
                } else {
                    printf("Operation in the machine: ");
                    for (int i = 0; i < m->operationCount; i++) {
                        printf("%d - %s", m->operations[i], OPERATIONS[m->operations[i]].name);
                        if (i < m->operationCount - 1) {
                            printf(", ");
                        }
                    }
                    printf("\n");
                }
                printf("\n");
                return;
            }
        }
    }
}

void initialSetupForEachMachine() {
	printf("\n");
    FILE* filep;
    char filepath[100];
    printf("\nEnter filepath: ");
    scanf("%s", filepath);
    while (getchar() != '\n');
    filep = fopen(filepath, "r");
    if(filep == NULL){
        printf("\nFile doesn't exist");
        return;
    }
	printf("\n");
    char line[1000];
    while(fgets(line, 1000, filep)){
        if (line[0] == '\n') {
            continue;
        }
        Machine m;
        char *token = strtok(line, ";");
        if (token != NULL){
            m.id = atoi(token);
        }
        if (doesMachineExist(m.id) || m.id <=0) {
            printf("\nMachine with id %d already exists.", m.id);
            continue;
        }
        token = strtok(NULL, ";");
        if (token != NULL){
            strncpy(m.name, token, MAX_NAME_LEN);
        }
        token = strtok(NULL, ";");
        if (token != NULL){
            m.tempMin = atof(token);
        }
        token = strtok(NULL, ";");
        if (token != NULL){
            m.tempMax = atof(token);
        }
        if (m.tempMax <= m.tempMin) {
            printf("Temperature maximum < Temperature minimum\n");
            continue;
        }
        token = strtok(NULL, ";");
        if (token != NULL){
            m.humMin = atof(token);
        }
        token = strtok(NULL, ";");
        if (token != NULL){
            m.humMax = atof(token);
        }
        if (m.humMax <= m.humMin || m.humMin < 0 || m.humMax < 0 || m.humMax >100) {
            printf("Humidity maximum e menor que a humidade minimum ou humidades estao fora dos intervalos");
            continue;
        }
        token = strtok(NULL, ";");
        if (token != NULL){
            m.bufferLength = atoi(token);
        }
        token = strtok(NULL, ";");
        if (token != NULL){
            m.medianWindowLength = atoi(token);
        }
        if(m.medianWindowLength >= m.bufferLength){
            printf("\nMoving median window length bigger than Circular Buffer length");
        }
        strncpy(m.state, "ON", sizeof(m.state) - 1);
		m.state[sizeof(m.state) - 1] = '\0';
        m.currentTemp = m.tempMin;
        m.currentHum = m.humMin;
        m.operationCount = 0;
        for (int i = 0; i < MAX_OPERATIONS; i++) {
            m.operations[i] = -1;
        }
        token = strtok(NULL, ";");
        while (token != NULL && m.operationCount < MAX_OPERATIONS) {
            int operationId = atoi(token);
            if (operationId != 0) {
                m.operations[m.operationCount] = operationId;
                m.operationCount++;
            }
            token = strtok(NULL, ";");
        }
        machines[machineTotal] = m;
        machineTotal++;
        printf("Machine %s (Id: %d) loaded\n",m.name, m.id);
    }
    fclose(filep);
    printf("Setup done.\n");
    return;
    
}

void exportMachineOperations() {
	printf("\n");
    if (machineTotal == 0) {
        printf("Machines arent available.\n");
        return;
    }
    showMachines(machines, machineTotal);
    printf("\n");
    int machineId;
    printf("Type the machine id to export the operations (or 'X' to cancel): ");
    char input[10];
    scanf("%s", input);
    if (input[0] == 'X' || input[0] == 'x') {
        printf("Process canceled.\n");
        return;
    }
    if (sscanf(input, "%d", &machineId) != 1) {
        printf("Invalid ID.\n");
        return;
    }
    int machineIndex = -1;
    for (int i = 0; i < machineTotal; i++) {
        if (machines[i].id == machineId) {
            machineIndex = i;
            break;
        }
    }
    if (machineIndex == -1) {
        printf("Machine not found.\n");
        return;
    }
    Machine *m = &machines[machineIndex];
    char filepath[MAX_NAME_LEN + 18];
    snprintf(filepath, sizeof(filepath), "%s_operations.csv", m->name);
    FILE *file = fopen(filepath, "w");
    if (file == NULL) {
        printf("Error.\n");
        return;
    }
    fprintf(file, "machine_id;machine_Name;operacao_id;operacao_Name\n");
    for (int i = 0; i < m->operationCount; i++) {
        int operationIndex = findOperationIndexById(m->operations[i]);
        if (operationIndex != -1) {
            fprintf(file, "%d;%s;%d;%s\n", m->id, m->name, m->operations[i], OPERATIONS[operationIndex].name);
        }
    }
    fclose(file);
    printf("Operations exported to file '%s'.\n", filepath);
}

void showMachineMenu(Machine* machine) {
    printf("\nCommand to machine: %s (Id: %d)\n", machine->name, machine->id);
    printf("Insert ON,<op_num[0,31]> / OFF / OP,<op_num[0,31]> (or type 'X' to cancel):\n");
}

void controlMachine(int pico, Machine* machine) {
    while (1) {
        showMachineMenu(machine);
        char op[10];
        int n = -1;
        char cmd[20];
        char input[20];
        scanf("%s", input);
        input[strcspn(input, "\n")] = '\0';
        for (size_t i = 0; i < strlen(input); i++) {
            if (input[i] == ',') {
                input[i] = ' ';
            }
        }
		while (getchar() != '\n');
        if (input[0] == 'x' || input[0] == 'X') {
            return;
        }
		if (sscanf(input, "%s %d", op, &n) == 2) {
			if ((strcasecmp(op, "ON") == 0 || strcasecmp(op, "OP") == 0) && n >= 0 && n <= 31) {
				if (format_command((char*)op, n, cmd)) {
                    int found = 0;
                    for (int i = 0; i < machine->operationCount; i++) {
                        if (machine->operations[i] == n) {
                            found = 1;
                            break;
                        }
                    }
					if (!found) {
                        printf("Add that operation to the machine first.");
                        return;
					}
                    sendCommandToMachine(pico, cmd);
                    printf("\nCommand sent: %s\n", cmd);
                    strcpy(machine->state, op);
					time(&machine->timestamp);
					readSensorData(pico, machine);
                    return;
				}
			} else {
				printf("Invalid command or number outside interval [0, 31].\n");
			}
        
		} else if (sscanf(input, "%s", op) == 1) {
			if (strcasecmp(op, "OFF") == 0) {
				strcpy(cmd, "OFF");
				sendCommandToMachine(pico, cmd);
                printf("\nCommand sent: %s\n", cmd);
				strcpy(machine->state, "OFF");
				printf("\nMachine off.\n");
				
			} else {
				printf("Invalid Command.\n");
			}
		} else {
			printf("Invalid.\n");
		}
    }
}

void controlMachines(int pico) {
	while (getchar() != '\n');
    while (1) {
        printf("\n");
        if (machineTotal == 0) {
            printf("Machines arent available.\n");
            return;
        }
        showMachines();
        printf("\nType in machine ID (or 'X' to cancel): ");
        char input[10];
        if (fgets(input, sizeof(input), stdin) == NULL) {
            printf("Error.\n");
            continue;
        }
        input[strcspn(input, "\n")] = '\0';
        if (strcasecmp(input, "X") == 0) {
            return;
        }
        int selectedId;
        if (sscanf(input, "%d", &selectedId) == 1) {
            Machine* selectedMachine = selectMachine(selectedId);
            if (selectedMachine == NULL) {
                printf("Invalid ID.\n");
            } else {
                printf("%s(Id: %d) selected\n", selectedMachine->name, selectedMachine->id);
                controlMachine(pico, selectedMachine);
            }
        }
    }
}

void formatCommandForMachine(Machine* machine, const char* command, int pico) {
    char op[10];
    int n = -1;
    if (sscanf(command, "%[^,],%d", op, &n) == 2) {
        char cmd[20];
        if (format_command((char*)op, n, cmd)) {
            sendCommandToMachine(pico, cmd);
            printf("Command sent: %s\n", cmd);
            strcpy(machine->state, op);
            int found = 0;
            for (int i = 0; i < machine->operationCount; i++) {
				if (machine->operations[i] == n) {
					found = 1;
                    break;
                }
			}
			if (!found && machine->operationCount < MAX_OPERATIONS) {
				machine->operations[machine->operationCount++] = n;
				printf("Operation %d (%s) -> machine %s (Id: %d).\n", OPERATIONS[n].id, OPERATIONS[n].name, machine->name, machine->id);
			} else {
				if (!found) {
					printf("Operations maximum capacity reached in %s (Id: %d)\n", machine->name, machine->id);
				}
			}	   
            time(&machine->timestamp);
            readSensorData(pico, machine);
        }
    } else if (sscanf(command, "%s", op) == 1) {
        if (strcmp(op, "OFF") == 0) {
            char cmd[20] = "OFF";
            strcpy(cmd, "OFF");
            printf("Command sent: %s\n", cmd);
            sendCommandToMachine(pico, cmd);
            strcpy(machine->state, "OFF");
            printf("Machine off.\n");
        }
    } else {
        printf("Invalid.\n");
    }
}

void instructMachines(int pico) {
	printf("\n");
	if (machineTotal == 0) {
		printf("Machines arent available.\n");
		return;
	}
    char filepath[1000];
    printf("Insert file path or 'x' to cancel: ");
    scanf("%s", filepath);
    while (getchar() != '\n');
    if (strcasecmp(filepath, "X") == 0) {
        printf("Canceled.\n");
        return;
    }
    FILE *file = fopen(filepath, "r");
    if (file == NULL) {
        return;
    }
    char line[256];
    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\n")] = '\0';
        char* machineIdStr = strtok(line, ";");
        if (machineIdStr == NULL) {
            continue;
        }
        int machineId = atoi(machineIdStr);
        int machineIndex = findMachineIndexById(machineId);
        if (machineIndex == -1) {
            printf("\nMachine %d isn't registered.\n", machineId);
            continue;
        }
        Machine* machine = &machines[machineIndex];
        char* command = strtok(NULL, ";");
        int cmdCount = 0;
        for (cmdCount = 1; command != NULL; cmdCount++) {
            printf("\nInstruction %d: \n", cmdCount);
            if(strcmp(command, "") == 0 || strlen(command) < 3){
                printf("Not an instruction");
            }
            else{
                formatCommandForMachine(machine, command, pico);
            }
            command = strtok(NULL, ";");
        }
    }
    fclose(file);
}

void allocateMachines() {
    machines = (Machine *)malloc(machineCapacity * sizeof(Machine));
    if (machines == NULL) {
        printf("Error.\n");
        exit(1);
    }
}

void freeMachines() {
    free(machines);
}

void showMenu() {
    printf("\nMenu:\n");
    printf("[1] Initial Setup by archive (USAC12)\n");
    printf("[2] Export the Sequence of operations performed by a specific machine (USAC13)\n");
    printf("[3] Add machine (USAC14)\n");
    printf("[4] Remove machine (USAC14)\n");
    printf("[5] Current status of a machine (USAC14)\n");
    printf("[6] Assign an operation to a machine (USAC15)\n");
    printf("[7] Manage a specific machine and show its state in the Machine device for 2 seconds (USAC16)\n");
    printf("[8] Feed the system with a list of instructions (USAC17)\n");
    printf("[9] Leave\n");
}

int main() {
    int pico = configureSerialPort(SERIAL_PORT_PATH);
    allocateMachines();
    int option = 0;
    do {
        showMenu();
        printf("Choose an option: ");
        scanf("%d", &option);
        while(option < 1 || option > 9){
            printf("\nInvalid. Choose an option: ");
            scanf("%d", &option);
        }
        switch (option) {
            case 1:
                initialSetupForEachMachine();
                break;
            case 2:
                exportMachineOperations();
                break;
            case 3:
                addMachine();
                break;
            case 4:
                removeMachine();
                break;
            case 5:
                checkMachineStatus();
                break;
            case 6:
                assignOperation();
                break;
            case 7:
                controlMachines(pico);
                break;
            case 8:
                instructMachines(pico);
                break;
            case 9:
                break;
        }

    } while (option != 9);
    freeMachines();
    return 0;
}
