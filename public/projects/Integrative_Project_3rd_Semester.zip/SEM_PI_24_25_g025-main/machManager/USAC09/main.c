#include <stdio.h>
#include "file.h"

int main() {
    char order;
    char repeat;

    int n = 9;
    int array[] = {25, 32, 14, 1, 2, 87, 7, 8, 9};
    int* vec = array;

    do {
        
        do {
            printf("Do you want to sort in ascending order(1) or in descending order(0)? \n");
            scanf("%hhd", &order);

            if (order != 1 && order != 0) {
                printf("Invalid choice. Please choose 1 or 0.\n");
            }
        } while (order != 1 && order != 0);

        
        int res = sort_array(vec, n, order);

        printf("%d\n", res);
        printf("The Ordered Array is: \n{");
        for (int i = 0; i < n; i++) {
            printf("%d ", vec[i]);
        }
        printf("}\n");

        printf("\nDo you want to sort again with a different order? (Yes: y / No: n)\n");
        scanf(" %c", &repeat); //Ignorar caracteres de espaço em branco no buffer

    } while (repeat == 'y' || repeat == 'Y');

    return 0;
}
