// test_usac03.c
#include <assert.h>
#include <stdio.h>
#include "asm.h"

void test_get_number() {
    int value;
    char str1[] = "89";
    int res1 = get_number(str1, &value);
    assert(res1 == 1);
    assert(value == 89);

    char str2[] = "8--9";
    int res2 = get_number(str2, &value);
    assert(res2 == 0);
    assert(value == 0);

    char str3[] = "123";
    int res3 = get_number(str3, &value);
    assert(res3 == 1);
    assert(value == 123);

    char str4[] = "abc";
    int res4 = get_number(str4, &value);
    assert(res4 == 0);
    assert(value == 0);

    printf("All tests passed for get_number.\n");
}

int main() {
    test_get_number();
    return 0;
}