#include <stdio.h>
#include "asm.h"

int main() {

	int value;
	char str1[] = "89";

	int res  = get_number(str1, &value);

	printf("%d: %d\n", res, value);

	char str2[] = "8--9";

	int res2 = get_number(str2, &value);

	printf("%d: %d\n", res2, value);
}
