#ifndef ASM_H
#define ASM_H

int get_number(char* str, int* n);

#endif
