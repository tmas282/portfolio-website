#ifndef ASM_H
#define ASM_H
extern int format_command(char* op, int n, char *cmd);
#endif

