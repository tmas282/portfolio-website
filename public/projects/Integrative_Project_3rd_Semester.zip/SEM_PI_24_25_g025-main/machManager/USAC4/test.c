#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "asm.h"
void teste_Certo(){
    int value = 26;
    char str [] = "oN";
    char cmd [20];
    int res = format_command ( str , value , cmd ) ;
	assert (res == 1);
		assert (strcmp(cmd,"1: ON ,1 ,1 ,0 ,1 ,0"));
}
void teste_Errado(){
    int value = 15;
    char str [] = "aa";
    char cmd [20];
    int res = format_command ( str , value , cmd ) ;
	assert (res == 0);
		assert (strcmp(cmd,""));
}
int main(){
	printf("==== Test Certo ====\n");
	teste_Certo();
	printf("==== PASSED ====\n");

	printf("==== Test Errado ====\n");
	teste_Errado();
	printf("==== PASSED ====\n");

}
