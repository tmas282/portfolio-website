# USEI20 - Calculate Earliest and Latest Start and Finish Times

## 1. Requirements Engineering

### 1.1. User Story Description

As a user, I need the ability to calculate the earliest start (ES) and the latest finish (LF) times for each activity in a project. These calculations will consider activity dependencies, enabling identification of slack in non-critical activities and ensuring precise scheduling.

### 1.2. Customer Specifications and Clarifications

**From the specifications document:**

> The system should provide functionality for calculating ES, EF, LS, and LF times for each activity in a project graph. This will facilitate the identification of slack in non-critical activities and support efficient scheduling.

**From the client clarifications:**

> ------------------------------------------  

### 1.3. Acceptance Criteria

- **AC1:** The system must request the user to upload or input a project graph file.
- **AC2:** The system should compute the ES and LF times for all activities based on their dependencies.
- **AC3:** The system should present the calculated ES, EF, LS, and LF times clearly to the user.

### 1.4. Found Dependencies

This functionality relies on the following related user stories:

- **USEI17 - Build a PERT-CPM graph**: A properly constructed project graph is necessary for these calculations.
- **USEI18 - Detect Circular Dependencies**: Detecting and resolving circular dependencies is critical for valid scheduling.
- **USEI19 - Topological Sort of Project Activities**: Sorting activities in dependency order ensures accurate computation of start and finish times.

### 1.5 Input and Output Data

**Input Data:**

- A project graph in a supported format that defines activities and their dependencies.

**Output Data:**

- Calculated times:
    - Earliest Start (ES)
    - Latest Start (LS)
    - Earliest Finish (EF)
    - Latest Finish (LF)
### 1.6. System Sequence Diagram (SSD)

**_Other alternatives might exist._**

![System Sequence Diagram - USEI20](svg/US20-system-sequence-diagram.svg)

### 1.7 Other Relevant Remarks

* N/A