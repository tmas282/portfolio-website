# USEI20- Calculate Earliest and Latest Start and Finish Times

## 3. Design - User Story Realization

### 3.1. Rationale

_**Note that SSD - Alternative One is adopted.**_

| Interaction ID              | Question: Which class is responsible for... | Answer      | Justification (with patterns)                                                                                 |
|:----------------------------|:--------------------------------------------|:------------|:--------------------------------------------------------------------------------------------------------------|
| Step 1: ................... | ... interacting with the actor?             | FileGraphUI | Pure Fabrication: there is no reason to assign this responsibility to any existing class in the Domain Model. |
| Step 2: ................... | ... initializing the controller?            | FileGraphUI | Creator: FileGraphUI directly depends on the Controller.                                                                     |
| Step 3: ................... | ... reading the project graph file?         | ReadCSV     | Information Expert: ReadCSV has the knowledge to read the project graph file.                                 |
| Step 6: ................... | ... building the PERT/CPM graph?            | Controller  | Information Expert: Controller has the knowledge to build the PERT/CPM graph.                                 |
| Step 11: .................. | ... calculating ES and LF times?            | Algorithms  | Information Expert: Algorithms has the knowledge to calculate ES and LF times.                                |

## Systematization

According to the taken rationale, the conceptual classes promoted to software classes are:

* Activity
* Graph
* Edge

Other software classes (i.e. Pure Fabrication) identified:

* FileGraphUI
* Controller
* ReadCSV
* Algorithms

## 3.2. Sequence Diagram (SD)

### Full Diagram

This diagram shows the full sequence of interactions between the classes involved in the realization of this user story.

![Sequence Diagram - Full](svg/US20-sequence-diagram.svg)

## 3.3. Class Diagram (CD)

![Class Diagram](svg/US20-class-diagram.svg)