# USEI20- Calculate Earliest and Latest Start and Finish Times

## 2. Analysis

### 2.1. Relevant Domain Model Excerpt

![Domain Model](svg/US20-domain-model.svg)

### 2.2. Other Remarks

N/A