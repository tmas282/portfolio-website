# USEI21 -  Export Project Schedule to CSV

## 1. Requirements Engineering

### 1.1. User Story Description

As a user, I want to export the entire project schedule, including start times, finish times, and slack for each activity, to a CSV file for record-keeping and further analysis.

### 1.2. Customer Specifications and Clarifications 

**From the specifications document:**

Export: entire project schedule.
- start times
- finish times
- slack for each activity

**From the client clarifications:**

> Question:
> No questions yet.

> Answer:
> No answer yet.


### 1.3. Acceptance Criteria

- AC1 - CSV file format:

 " - schedule.csv with the format: <act_id,cost,duration,es,ls,ef,lf,prev_act_id1,...,prev_act_idN> "

### 1.4. Found out Dependencies

Dependency found on **USEI20: Calculate Earliest and Latest Start and Finish Times**.

### 1.5 Input and Output Data

**Input Data:**

* Has no input.
    

**Output Data:**

* CSV file.


### 1.6. System Sequence Diagram (SSD)

![System Sequence Diagram -](svg/USEI21-system-sequence-diagram.svg)

### 1.7 Other Relevant Remarks
Not yet defined.
