# USEI21 - Export Project Schedule to CSV

## 3. Design - User Story Realization 

### 3.1. Rationale

_**Note that SSD - Alternative One is adopted.**_


| Interaction ID | Question: Which class is responsible for...    | Answer       | Justification (with patterns)                                                                                                       |
|:---------------|:-----------------------------------------------|:-------------|:------------------------------------------------------------------------------------------------------------------------------------|
| Step 1  		     | 	... interacting with the actor?               | DisplayUI    | Pure Fabrication : This class serves as the interface between the user and the system; no existing domain class fulfills this role. |
| 			  		        | 	... updating the material quantity?           | UpdateBOO    | Creator: UpdateBOO encapsulates the logic for updating material quantities in the production tree.                      | 
| Step 2  		     | 	... identifying and retrieving the node?					 | Tree         | Information Expert: The DisplayUI gathers user inputs regarding tree creation parameters directly from the actor.                   |
| Step 3  		     | 	.. executing real-time updates?               | RealTimeUpdate | Pure Fabrication: RealTimeUpdate reflects changes in the system in real time.                               |
| Step 4  		     | 	... informing operation success?              | DisplayUI    | IE: is responsible for user interactions.                                                                                           | 

### Systematization ##

According to the taken rationale, the conceptual classes promoted to software classes are:
* Tree


Other software classes (i.e. Pure Fabrication) identified:
* RealTimeUpdate
* DisplayUI
* UpdateBOO



## 3.2. Sequence Diagram (SD)

_**Note that SSD - Alternative One is adopted.**_

### Full Diagram

This diagram shows the full sequence of interactions between the classes involved in the realization of this user story.

![Sequence Diagram - Full](svg/USEI12-sequence-diagram.svg)

### Split Diagrams

The following diagram shows the same sequence of interactions between the classes involved in the realization of this user story, but it is split in partial diagrams to better illustrate the interactions between the classes.

It uses Interaction Occurrence (a.k.a. Interaction Use).

## 3.3. Class Diagram (CD)

![Class Diagram](svg/USEI12-class-diagram.svg)