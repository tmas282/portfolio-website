# USEI12 - Update material quantities in the production tree

## 2. Analysis

### 2.1. Relevant Domain Model Excerpt 

![Domain Model](svg/USEI12-domain-model.svg)

### 2.2. Other Remarks

n/a