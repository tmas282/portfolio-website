# USEI24 - Simulate Project Delays and their Impact

## 2. Analysis

### 2.1. Relevant Domain Model Excerpt 

![Domain Model](svg/USEI24-domain-model-Domain_Model_USEI15.svg)

### 2.2. Other Remarks

n/a