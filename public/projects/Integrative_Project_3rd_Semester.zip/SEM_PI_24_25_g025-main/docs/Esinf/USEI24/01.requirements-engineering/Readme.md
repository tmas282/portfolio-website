# USEI24 - Simulate Project Delays and their Impact


## 1. Requirements Engineering

### 1.1. User Story Description
As a user, I want to simulate delays in specific activities by increasing their durations, and I want to automatically recalculate the critical path, total project duration, and slack times to assess
the potential impact of these delays on the overall project schedule.


### 1.2. Customer Specifications and Clarifications 

**From the specifications document:**

As a user, I want to simulate delays in specific activities by increasing their durations, and I want to automatically recalculate the critical path, total project duration, and slack times to assess
the potential impact of these delays on the overall project schedule.


**From the client clarifications:**

Yet to be defined.

### 1.3. Acceptance Criteria

* AC1 - Graph needs to exist in order to create delays.
* AC2 - Delays need to be treated by its respective duration unit.
* AC3 - No negative delays.


### 1.4. Found out Dependencies

* Depends on USEI17
* 
### 1.5 Input and Output Data

**Input Data:**

* Typed data:
    The Map of delays and respective relations to be changed in the graph.

**Output Data:**
    Graph with the respective changes.

### 1.6. System Sequence Diagram (SSD)

![System Sequence Diagram -](svg/USEI24-system-sequence-diagram-alternative-one-System_Sequence_Diagram__SSD____USEI15.svg)

### 1.7 Other Relevant Remarks

