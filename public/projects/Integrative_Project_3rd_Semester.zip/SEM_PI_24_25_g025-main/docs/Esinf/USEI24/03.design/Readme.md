# USEI24 - Simulate Project Delays and Their Impact.

## 3. Design - User Story Realization

### 3.1. Rationale

_**Note that the provided class diagram is adopted.**_

| Interaction ID | Question: Which class is responsible for...         | Answer              | Justification (with patterns)                                                                                                     |
|:---------------|:----------------------------------------------------|:--------------------|:----------------------------------------------------------------------------------------------------------------------------------|
| Step 1         | ... interacting with the user to load the CSV file? | `DisplayUI`         | **Pure Fabrication**: This class serves as the interface between the user and the system, managing all user interactions.         |
| Step 2         | ... reading and parsing the CSV file?               | `ReadCSV`           | **Information Expert**: Responsible for accessing and processing the CSV data necessary for creating the project graph.           |
| Step 3         | ... creating the project graph structure?           | `GraphCreation`     | **Creator (Rule 1)**: This class is responsible for generating the graph structure, encapsulating graph initialization logic.     |
| Step 4         | ... managing PERTCPM operations?                    | `PERTCPMGraph`      | **Controller**: This class manages activity dependencies, critical path calculation, and timing analysis.                         |
| Step 5         | ... simulating delays in specific activities?       | `DelaySimulation`   | **Information Expert**: Contains the logic to simulate delays by modifying durations and recalculating project outcomes.          |
| Step 6         | ... displaying simulation results to the user?      | `DisplayUI`         | **IE**: Handles user-facing operations, including showing results such as updated critical paths and project durations.           |

### Systematization

According to the adopted rationale, the conceptual classes promoted to software classes are:
* `GraphCreation`
* `PERTCPMGraph`
* `DelaySimulation`

Other software classes (i.e., Pure Fabrication) identified:
* `DisplayUI`
* `ReadCSV`

---

## 3.2. Sequence Diagram (SD)

_**Note that the provided class diagram is adopted.**_

### Full Diagram

The diagram below shows the full sequence of interactions required for simulating project delays and recalculating the schedule:

![Sequence Diagram - Full](svg/USEI24-sequence-diagram-full.svg)

### Split Diagrams

The following diagram shows the same sequence of interactions between the classes involved in the realization of this user story, but it is split in partial diagrams to better illustrate the interactions between the classes.

It uses Interaction Occurrence (a.k.a. Interaction Use).

## 3.3. Class Diagram (CD)

![Class Diagram](svg/USEI24-class-diagram.svg)
