# USEI18 - Detect Circular Dependencies

## 1. Requirements Engineering

### 1.1. User Story Description
As a user, I want to validate the project
graph to ensure there are no circular dependencies among activities, as this would
make the project unable to be scheduled.

### 1.2. Acceptance Criteria
Not yet defined.

### 1.3. System Sequence Diagram (SSD)

![System Sequence Diagram - USEI18](svg/USEI18-system-sequence-diagram-alternative-one-System_Sequence_Diagram__SSD____USEI18.svg)

### 1.4. Other Relevant Remarks
