# USEI18 - Detect Circular Dependencies

## 2. Analysis

### 2.1. Relevant Domain Model Excerpt 

![Domain Model](svg/USEI18-domain-model-Domain_Model_USEI18.svg)

### 2.2. Other Remarks

n/a