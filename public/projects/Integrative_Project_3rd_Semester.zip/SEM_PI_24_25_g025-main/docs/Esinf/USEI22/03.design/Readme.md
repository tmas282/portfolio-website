# USEI13 - Calculate the total quantity of materials and time needed for the production

## 3. Design - User Story Realization

### 3.1. Rationale

_**Note that SSD - Alternative One is adopted.**_

| Interaction ID | Question: Which class is responsible for...                                                                                                                                                                                            | Answer                               | Justification (with patterns)                                                                                                                                                                                                                 |
|:---------------|:---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:-------------------------------------|:----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Step 1  		     | 	... interacting with the actor?                                                                                                                                                                                                       | MenuUI                               | Pure Fabrication : This class serves as the interface between the user and the system; no existing domain class fulfills this role.                                                                                                           |
| 			  		        | 	... running the simulation?                                                                                                                                                                                                           | Simulator                            | Creator (Rule 1): The Simulator class is responsible for performing simulations based on the provided input data.                                                                                                                              |
| Step 2  		     | 	... receiving the simulation parameters?						                                                                                                                                                                                        | MenuUI                               | Information Expert: The MenuUI gathers user inputs regarding simulation parameters directly from the actor.                                                                                                                                   |
| Step 3  		     | 	.. executing the simulation logic?                                                                                                                                                                                                    | Simulator                            | Creator: The Simulator class contains the logic and state necessary to perform the simulation.                                                                                                                                                |
| Step 4  		     | 	... displays the total quantities per material and total time needed? | DisplayUI                               | IE: is responsible for user interactions.                                                                       |

### Systematization

According to the taken rationale, the conceptual classes promoted to software classes are:
* Simulator

Other software classes (i.e. Pure Fabrication) identified:
* MenuUI

## 3.2. Sequence Diagram (SD)

_**Note that SSD - Alternative Two is adopted.**_

### Full Diagram

This diagram shows the full sequence of interactions between the classes involved in the realization of this user story.

![Sequence Diagram - Full](svg/USEI13-sequence-diagram-full.svg)

### Split Diagrams

The following diagram shows the same sequence of interactions between the classes involved in the realization of this user story, but it is split in partial diagrams to better illustrate the interactions between the classes.

It uses Interaction Occurrence (a.k.a. Interaction Use).

## 3.3. Class Diagram (CD)

![Class Diagram](svg/USEI13-class-diagram.svg)