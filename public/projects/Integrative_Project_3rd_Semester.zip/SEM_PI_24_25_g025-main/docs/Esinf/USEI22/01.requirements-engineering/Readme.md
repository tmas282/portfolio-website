# USEI13 - Calculate the total quantity of materials and time needed for the production

## 1. Requirements Engineering

### 1.1. User Story Description

As a user, I want to calculate the quantity of materials and time needed for the production tree, using the quantity of each material and average time for the operation (average between all the machines able to perform an operation) to understand the overall production expense.

### 1.2. Customer Specifications and Clarifications

**From the specifications document:**
* Use a recursive traversal method to sum up the quantity of all materials and time needed to perform the operations in the production tree.
* The final output should display the totals per material and per operation.

**From the client clarifications:**
* Not yet defined.

### 1.3. Acceptance Criteria

* **AC1** - Use a recursive traversal method to sum up the quantity of all materials and time needed to perform the operations in the production tree.
* **AC2** - The final output should display the totals per material and per operation.

### 1.4. Found out Dependencies

* Dependency on the `Node` class for representing the production tree.
* Dependency on the `Tree` class for managing the production tree structure.
* Dependency on the `DisplayUI` class for displaying the results.

### 1.5 Input and Output Data

**Input Data:**
* Production tree structure (nodes and their quantities).

**Output Data:**
* Total quantities per material.
* Total time needed for production.

### 1.6. System Sequence Diagram (SSD)

![System Sequence Diagram - USEI13](svg/USEI13-system-sequence.svg)

### 1.7 Other Relevant Remarks

* None.