# USEI17 - Build a PERT-CPM graph

## 2. Analysis

### 2.1. Relevant Domain Model Excerpt 

![Domain Model](svg/USEI17-domain-model-Domain_Model_USEI17.svg)

### 2.2. Other Remarks

n/a