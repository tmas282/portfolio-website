# USEI17 - Build a PERT-CPM graph


## 1. Requirements Engineering

### 1.1. User Story Description
- USEI17 - Build a PERT-CPM graph - As a user, I want to import data from a
  CSV file structured as follows:

    activities.csv with the format:
    <act_id,act_descr,duration,duration_unit,cost,cost_unit,
    prev_act_id1,...,prev_act_idN>

  And build one PERT/CPM graph, considering the necessary validations for activity dependencies and data integrity.


### 1.2. Customer Specifications and Clarifications 

**From the specifications document:**



**From the client clarifications:**



### 1.3. Acceptance Criteria

Not yet defined.

### 1.4. Found out Dependencies

Not yet defined.

### 1.5 Input and Output Data

**Input Data:**
* activities.csv
    

**Output Data:**



### 1.6. System Sequence Diagram (SSD)

![System Sequence Diagram -](svg/USEI17-system-sequence-diagram-alternative-one-System_Sequence_Diagram__SSD____USEI17.svg)

### 1.7 Other Relevant Remarks

Not yet defined.
