# USEI19 - Topological sort of project activities

## 2. Analysis

### 2.1. Relevant Domain Model Excerpt

![Domain Model](svg/USEI19-domain-model.svg)

### 2.2. Other Remarks

n/a