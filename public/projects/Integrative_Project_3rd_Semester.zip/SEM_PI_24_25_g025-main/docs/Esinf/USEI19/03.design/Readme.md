# USEI19 - Topological sort of project activities

## 3. Design - User Story Realization

### 3.1. Rationale

_**Note that SSD - Alternative One is adopted.**_

| Interaction ID | Question: Which class is responsible for... | Answer                               | Justification (with patterns)                                                                                                                                                                                                                 |
|:---------------|:--------------------------------------------|:-------------------------------------|:----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Step 1         | ... interacting with the actor?             | MenuUI                              | Pure Fabrication : This class serves as the interface between the user and the system; no existing domain class fulfills this role.                                                                                                           |
|                | ... receiving the project activities?       | MenuUI                              | Information Expert: MenuUI collects the project activities from the actor to guide the topological sort logic.                                                                                                                                |
| Step 2         | ... creating the project graph?             | ProjectGraph                        | Creator: ProjectGraph is responsible for creating the graph based on the provided project activities.                                                                                                                                         |
| Step 3         | ... performing the topological sort?        | TopologicalSort                     | Information Expert: TopologicalSort contains the logic and state necessary to perform the topological sort.                                                                                                                                   |
| Step 4         | ... returning the sorted order of activities? | MenuUI                              | Information Expert: MenuUI is responsible for user interactions and returns the sorted order of activities to the actor.                                                                                                                      |

### Systematization

According to the taken rationale, the conceptual classes promoted to software classes are:
* ProjectGraph
* TopologicalSort

Other software classes (i.e. Pure Fabrication) identified:
* MenuUI

## 3.2. Sequence Diagram (SD)

_**Note that SSD - Alternative One is adopted.**_

### Full Diagram

This diagram shows the full sequence of interactions between the classes involved in the realization of this user story.

![Sequence Diagram - Full](svg/USEI19-sequence-diagram-full-Sequence_Diagram_Full_USEI19.svg)

### Split Diagrams

The following diagram shows the same sequence of interactions between the classes involved in the realization of this user story, but it is split in partial diagrams to better illustrate the interactions between the classes.

It uses Interaction Occurrence (a.k.a. Interaction Use).

## 3.3. Class Diagram (CD)

![Class Diagram](svg/USEI19-class-diagram.svg)