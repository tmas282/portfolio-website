# USEI19 - Topological sort of project activities

## 1. Requirements Engineering

### 1.1. User Story Description

As a user, I want to perform a topological sort of the project’s activities. This will provide a feasible sequence for executing the activities, respecting all dependency constraints, and help validate the graph’s structure.

### 1.2. Customer Specifications and Clarifications

**From the specifications document:**

As a user, I want to perform a topological sort of the project’s activities. This will provide a feasible sequence for executing the activities, respecting all dependency constraints, and help validate the graph’s structure.

**From the client clarifications:**

Not yet defined.

### 1.3. Acceptance Criteria

* AC1 - The system should perform a topological sort of the project activities.
* AC2 - The system should validate the graph’s structure to ensure there are no cycles.

### 1.4. Found out Dependencies

Not yet defined.

### 1.5 Input and Output Data

**Input Data:**

* Project activities and their dependencies.

**Output Data:**

* Sorted order of project activities.

### 1.6. System Sequence Diagram (SSD)

![System Sequence Diagram -](svg/USEI19-system-sequence-diagram-alternative-one.svg)

### 1.7 Other Relevant Remarks

Not yet defined.