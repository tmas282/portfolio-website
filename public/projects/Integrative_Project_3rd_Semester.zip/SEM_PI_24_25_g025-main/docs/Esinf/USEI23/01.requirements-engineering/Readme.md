# USEI23 - Identify Bottlenecks Activities in the Project Graph

## 1. Requirements Engineering

### 1.1. User Story Description
As a user, I want to identify bottleneck activities in the project graph, which are activities with the highest number of dependent activities or that appear on most paths, to better understand where delays are most likely to propagate.

### 1.2. Customer Specifications and Clarifications

**From the specifications document:**
- Identify activities with the highest number of dependent activities.
- Identify activities that appear on most paths.
- Present the bottleneck activities to the user.

**From the client clarifications:**
- The system should analyze the project graph to find bottleneck activities.
- The identified bottleneck activities should be presented in a user-friendly manner.

**Client Questions and Responses:**
> **QUESTION:** É suposto apresentarmos todas as atividades e o respetivo "grau" de dependência / número de sucessores, ou apenas apresentar algumas delas, as com maior "grau" de dependência / número de sucessores?
>
> **ANSWER:** Pode fazer uma abordagem equilibrada, identificando as Top 5 atividades com o maior grau de dependência e que apareçam em mais caminhos críticos, e opcionalmente se o cliente pretender, oferecer também a lista completa de todas as atividades com o maior grau.

> **QUESTION:**
>  1. Se a atividade A depender de B e a atividade B depender de C, então A vai ter grau de dependência 2 (porque depende de B e C) ou grau de dependência 1 (porque depende diretamente de B e só assumimos as dependências diretas)?
> 2. Se um grafo acabar com "End" e não uma atividade em si, faz sentido atribuir o grau de dependência para o "End"?
>
> **ANSWER:** O grau de dependência de uma atividade é baseado exclusivamente no número de atividades predecessoras imediatas das quais ela depende. Não precisa calcular o grau de dependência para "End".

### 1.3. Acceptance Criteria
- **AC1:** Analyze the project graph to identify activities with the highest number of dependent activities.
- **AC2:** Identify activities that appear on most paths.
- **AC3:** Present the identified bottleneck activities to the user.

### 1.4. Found out Dependencies
Depends on the data structures, simulation logic, and calculated metrics provided by other user stories in the project.

### 1.5 Input and Output Data

**Input Data:**
- Project graph data representing activities and their dependencies.

**Output Data:**
- List of identified bottleneck activities.

### 1.6. System Sequence Diagram (SSD)

![System Sequence Diagram -](svg/USEI23-system-sequence-diagram-alternative-one.svg)

### 1.7 Other Relevant Remarks
- Not defined yet.