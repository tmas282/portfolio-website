# USEI23 - Identify Bottlenecks Activities in the Project Graph

## 2. Analysis

### 2.1. Relevant Domain Model Excerpt 

![Domain Model](svg/USEI23-domain-model.svg)

### 2.2. Other Remarks

n/a