create PROCEDURE CheckOrderStock(p_OrderID IN NUMBER)
    IS
    v_OrderExists NUMBER := 0;
BEGIN
    -- Verificar se o OrderID existe na tabela ClientOrder
SELECT COUNT(*) INTO v_OrderExists
FROM ClientOrder
WHERE ID = p_OrderID;

IF v_OrderExists = 0 THEN
        -- Caso o OrderID não exista
        DBMS_OUTPUT.PUT_LINE('Order ID ' || p_OrderID || ' does not exist.');
ELSE
        -- Verificar o estoque para os itens da ordem
        FOR item IN (
            SELECT
                cop.PartCode,
                cop.Quantity AS RequiredQuantity,
                p.stock AS StockAvailable
            FROM
                ClientOrderProduct cop
                    JOIN
                Part p ON cop.PartCode = p.Code
            WHERE
                cop.CustomerOrderID = p_OrderID
            )
            LOOP
                IF item.StockAvailable >= item.RequiredQuantity THEN
                    DBMS_OUTPUT.PUT_LINE('Part ' || item.PartCode || ': Stock is sufficient (' ||
                                         item.StockAvailable || ' available, ' ||
                                         item.RequiredQuantity || ' required).');
ELSE
                    DBMS_OUTPUT.PUT_LINE('Part ' || item.PartCode || ': Stock is insufficient (' ||
                                         item.StockAvailable || ' available, ' ||
                                         item.RequiredQuantity || ' required).');
END IF;
END LOOP;
END IF;
END;
/