CREATE OR REPLACE PROCEDURE ListReservedMaterials
AS
BEGIN
    FOR reservations IN
    (SELECT sr.PARTCODE as partcode, sum(sr.QUANTITY) AS quantity
    FROM STOCKRESERVATION sr, OFFER o
    WHERE sr.PARTCODE = o.PARTCODE
    GROUP BY sr.PARTCODE) LOOP
        dbms_output.put('Reserved: ' || reservations.partcode || ' (Quantity: ' || reservations.quantity || ') and the ID of the supplier(s): ');
        FOR supplier IN
        (SELECT o.SUPPLIERID as supplier
        FROM OFFER o
        WHERE o.PARTCODE = reservations.PARTCODE) LOOP
            dbms_output.put(supplier.supplier);
        END LOOP;
        dbms_output.put_line('');
    END LOOP;
END;
--
SET serveroutput ON
EXEC ListReservedMaterials();
BEGIN
    ListReservedMaterials();
END;

CREATE OR REPLACE FUNCTION ValidateStockForOrder(
    p_order_ID IN NUMBER
) RETURN NUMBER AS
    insufficient_stock EXCEPTION;
    PRAGMA EXCEPTION_INIT(insufficient_stock, -20002);
    v_stock_sufficient NUMBER := 1; -- 1 para stock suficiente, 0 para insuficiente
BEGIN
    -- Iterar sobre os materiais necessários para o pedido
    FOR part_record IN (
        WITH RecursiveParts (parent_part_code, part_code, total_quantity, level_path) AS (
            -- Base case: Direct parts
            SELECT
                o.PartCode AS parent_part_code,
                bom.BOMPartCode AS part_code,
                bom.quantity * o.Quantity AS total_quantity,
                o.PartCode || '->' || bom.BOMPartCode AS level_path
            FROM
                ClientOrderProduct o
            INNER JOIN
                BOMPart bom ON o.PartCode = bom.PartCode
            WHERE
                o.CustomerOrderID = p_order_ID

            UNION ALL

            -- Recursive case: Sub-products
            SELECT
                rp.part_code AS parent_part_code,
                bom.BOMPartCode AS part_code,
                bom.quantity * rp.total_quantity AS total_quantity,
                rp.level_path || '->' || bom.BOMPartCode AS level_path
            FROM
                RecursiveParts rp
            INNER JOIN
                BOMPart bom ON rp.part_code = bom.PartCode
            WHERE
                INSTR(rp.level_path, bom.BOMPartCode) = 0 -- Evitar ciclos
        ),
        TotalRequiredParts AS (
            -- Agregar a quantidade total necessária para cada parte
            SELECT
                rp.part_code,
                SUM(rp.total_quantity) AS total_required_quantity
            FROM
                RecursiveParts rp
            GROUP BY
                rp.part_code
        )
        SELECT
            trp.part_code,
            trp.total_required_quantity,
            COALESCE(p.stock, 0) AS stock,
            COALESCE(p.minQuantity, 0) AS min_stock
        FROM
            TotalRequiredParts trp
        INNER JOIN
            Part p ON trp.part_code = p.Code
    ) LOOP
        -- Validar o stock de cada parte
        IF part_record.stock - part_record.total_required_quantity < part_record.min_stock THEN
            v_stock_sufficient := 0;
            RAISE insufficient_stock;
        END IF;
    END LOOP;

    RETURN v_stock_sufficient; -- Retorna 1 se o stock for suficiente

EXCEPTION
    WHEN insufficient_stock THEN
        RETURN 0; -- Retorna 0 se houver stock insuficiente
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20003, 'Erro ao validar o stock para o pedido: ' || SQLERRM);
END;
/


DECLARE
    result NUMBER;
BEGIN
    result := ValidateStockForOrder(123); -- Substitua 123 pelo ID de um pedido existente
    DBMS_OUTPUT.PUT_LINE('Resultado: ' || result);
END;