package esinf.domain.trees;

import esinf.domain.sprint2.TreeNode;
import esinf.domain.sprint2.NodeType;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class TreeNodeTest {

    @Test
    public void testTreeNodeCreation() {
        TreeNode node = new TreeNode("1", "Node1", NodeType.PRODUCT, BigDecimal.TEN, null); // Added 'parent' as null

        assertEquals("1", node.getId());
        assertEquals("Node1", node.getName());
        assertEquals(NodeType.PRODUCT, node.getType());
        assertEquals(BigDecimal.TEN, node.getQuantity());
        assertNotNull(node.getChildren());
        assertTrue(node.getChildren().isEmpty());
    }

    @Test
    public void testAddChild() {
        TreeNode parent = new TreeNode("1", "Parent", NodeType.PRODUCT, BigDecimal.TEN, null);
        TreeNode child = new TreeNode("2", "Child", NodeType.OPERATION, BigDecimal.ONE, parent);

        parent.addChild(child);

        List<TreeNode> children = parent.getChildren();
        assertNotNull(children);
        assertEquals(1, children.size());
        assertEquals(child, children.get(0));
        assertEquals(parent, child.getParent());
    }
}
