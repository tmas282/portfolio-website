package esinf.domain.sprint3;

import esinf.domain.sprint3.*;
import org.junit.jupiter.api.Test;
import java.util.LinkedList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class AlgorithmsTest {

    @Test
    void testCalculateTimes() {
        // Configurar o grafo de exemplo
        PertCpmGraph graph = new PertCpmGraph();
        Activity a = new Activity("A", "Start", 3, "days", 100);
        Activity b = new Activity("B", "Middle", 2, "days", 200);
        Activity c = new Activity("C", "End", 1, "days", 300);

        graph.addVertex(a);
        graph.addVertex(b);
        graph.addVertex(c);

        graph.addEdge(a, b, 0);
        graph.addEdge(b, c, 0);

        // Chamar o método calculateTimes
        Algorithms.calculateTimes(graph);

        // Verificar os valores de LS e LF
        assertEquals(0, a.getEarliestStart());
        assertEquals(3, a.getEarliestFinish());
        assertEquals(0, a.getLatestStart());
        assertEquals(3, a.getLatestFinish());

        assertEquals(3, b.getEarliestStart());
        assertEquals(5, b.getEarliestFinish());
        assertEquals(3, b.getLatestStart());
        assertEquals(5, b.getLatestFinish());

        assertEquals(5, c.getEarliestStart());
        assertEquals(6, c.getEarliestFinish());
        assertEquals(5, c.getLatestStart());
        assertEquals(6, c.getLatestFinish());
    }

    @Test
    void testTopologicalSort() {
        // Setup example graph
        PertCpmGraph graph = new PertCpmGraph();
        Activity a = new Activity("A", "Start", 3, "days", 100);
        Activity b = new Activity("B", "Middle", 2, "days", 200);
        Activity c = new Activity("C", "End", 1, "days", 300);

        graph.addVertex(a);
        graph.addVertex(b);
        graph.addVertex(c);

        graph.addEdge(a, b, 0);
        graph.addEdge(b, c, 0);

        // Perform topological sort
        List<Activity> sorted = Algorithms.DepthFirstSearch(graph);

        // Verify topological order
        assertNotNull(sorted, "Topological sort returned null, indicating a cycle");
        assertEquals(3, sorted.size(), "Incorrect number of activities in topological order");
        assertTrue(sorted.indexOf(a) < sorted.indexOf(b), "Activity A should come before Activity B");
        assertTrue(sorted.indexOf(b) < sorted.indexOf(c), "Activity B should come before Activity C");
    }

    @Test
    void testTopologicalSortWithCycle() {
        // Setup example graph with a cycle
        PertCpmGraph graph = new PertCpmGraph();
        Activity a = new Activity("A", "Start", 3, "days", 100);
        Activity b = new Activity("B", "Middle", 2, "days", 200);

        graph.addVertex(a);
        graph.addVertex(b);

        graph.addEdge(a, b, 0);
        graph.addEdge(b, a, 0); // Creates a cycle

        // Verify that DepthFirstSearch throws an exception
        Exception exception = assertThrows(UnsupportedOperationException.class, () -> {
            Algorithms.DepthFirstSearch(graph);
        });
        assertEquals("Graph contains circular dependencies.", exception.getMessage());
    }

    @Test
    void testHasCircularDependencies() {
        // Setup example graph
        PertCpmGraph graph = new PertCpmGraph();
        Activity a = new Activity("A", "Start", 3, "days", 100);
        Activity b = new Activity("B", "Middle", 2, "days", 200);

        graph.addVertex(a);
        graph.addVertex(b);

        // Add a cycle
        graph.addEdge(a, b, 0);
        graph.addEdge(b, a, 0);

        // Verify circular dependency detection
        assertTrue(Algorithms.hasCircularDependencies(graph), "Graph should have circular dependencies");

        // Remove the cycle
        graph.removeEdge(b, a);

        // Verify no circular dependency
        assertFalse(Algorithms.hasCircularDependencies(graph), "Graph should not have circular dependencies");
    }

    @Test
    void testTopologicalSortWithNullGraph() {
        // Setup a null graph
        PertCpmGraph graph = null;

        // Perform topological sort
        Exception exception = assertThrows(NullPointerException.class, () -> {
            Algorithms.DepthFirstSearch(graph);
        });

        // Verify exception message
        assertNotNull(exception.getMessage(), "Expected NullPointerException for a null graph");
    }
}