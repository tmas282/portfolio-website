package esinf.domain.trees;

import esinf.domain.trees.ComponentNode;
import esinf.domain.trees.OperationNode;
import esinf.domain.trees.ProductionTree;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ProductionTreeTest {
/*
    @Test
    public void testPrintTree() {
        ComponentNode root = new ComponentNode(1, "Car Assembly", 1, esinf.domain.trees.ProductionNodeType.OPERATION);
        ComponentNode chassis = new ComponentNode(2, "Chassis", 1, esinf.domain.trees.ProductionNodeType.COMPONENT);
        ComponentNode engine = new ComponentNode(3, "Engine", 1, esinf.domain.trees.ProductionNodeType.COMPONENT);

        root.addChild(chassis);
        root.addChild(engine);

        ProductionTree tree = new ProductionTree(root);

        // Capturar a saída do console
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        System.setOut(new PrintStream(output));

        tree.printTree();

        String expectedOutput = """
                Car Assembly
                  Chassis
                  Engine
                """;

        assertEquals(expectedOutput.trim(), output.toString().trim());
    }

 */
}
