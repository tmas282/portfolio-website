package esinf.domain.trees;

public class TestProductionTree {
    public static void main(String[] args) {
        // Criando nós de componentes e produtos
        ComponentNode root = new ComponentNode(1, "Car Assembly", 1, ProductionNodeType.OPERATION);
        ComponentNode chassis = new ComponentNode(2, "Chassis", 1, ProductionNodeType.COMPONENT);
        ComponentNode engine = new ComponentNode(3, "Engine", 1, ProductionNodeType.COMPONENT);
        ComponentNode wheel = new ComponentNode(4, "Wheel", 4, ProductionNodeType.COMPONENT);
        ComponentNode paint = new ComponentNode(5, "Paint", 5, ProductionNodeType.OPERATION);

        // Construindo a árvore de produção
        root.addChild(chassis);
        root.addChild(engine);
        root.addChild(wheel);
        root.addChild(paint);

        chassis.setParent(root);
        engine.setParent(root);
        wheel.setParent(root);
        paint.setParent(root);

        // Criando a árvore de produção
        ProductionTree productionTree = new ProductionTree(root);

        // Testando impressão da árvore
        System.out.println("Production Tree:");
        productionTree.printTree();
    }
}
