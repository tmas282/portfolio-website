package esinf.domain.sprint3;

import esinf.domain.sprint3.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ProjectExporterTest {

    private PertCpmGraph graph;

    @BeforeEach
    void setUp() {
        graph = new PertCpmGraph();
        Activity a = new Activity("A", "Start", 3, "days", 100);
        Activity b = new Activity("B", "Middle", 2, "days", 200);
        Activity c = new Activity("C", "End", 1, "days", 300);

        graph.addVertex(a);
        graph.addVertex(b);
        graph.addVertex(c);

        graph.addEdge(a, b, 0);
        graph.addEdge(b, c, 0);
    }

    @Test
    void testExportScheduleToCSV() throws IOException {
        String filePath = "test_schedule.csv";
        ProjectExporter.exportScheduleToCSV(graph, filePath);

        File file = new File(filePath);
        assertTrue(file.exists(), "File should exist after export.");

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String header = reader.readLine();
            assertEquals("Key,Cost,Duration,EarliestStart,LatestStart,EarliestFinish,LatestFinish,Predecessors", header, "Header should match expected format.");

            String lineA = reader.readLine();
            assertEquals("A,100.0,3.0,0.0,0.0,3.0,3.0", lineA, "Activity A should match expected format.");

            String lineB = reader.readLine();
            assertEquals("B,200.0,2.0,3.0,3.0,5.0,5.0,A", lineB, "Activity B should match expected format.");

            String lineC = reader.readLine();
            assertEquals("C,300.0,1.0,5.0,5.0,6.0,6.0,B", lineC, "Activity C should match expected format.");
        } finally {
            file.delete();
        }
    }
}