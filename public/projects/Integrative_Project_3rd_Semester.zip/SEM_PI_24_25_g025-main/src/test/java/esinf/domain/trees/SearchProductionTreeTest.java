package esinf.domain.trees;

import esinf.domain.trees.ComponentNode;
import esinf.domain.trees.ProductionNodeType;
import esinf.domain.trees.SearchProductionTree;
import org.junit.jupiter.api.Test;

import java.security.Key;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class SearchProductionTreeTest {

    @Test
    public void testAddProductionNode() {
        SearchProductionTree searchTree = new SearchProductionTree();
        Key key = new TestKey("key1");
        ComponentNode node = new ComponentNode(1, "Component1", 10, ProductionNodeType.COMPONENT);

        searchTree.addProductionNode(key, node);

        assertTrue(searchTree.getSearchMap().containsKey(key));
        assertEquals(node, searchTree.getSearchMap().get(key));
    }

    @Test
    public void testContainsNode() {
        SearchProductionTree searchTree = new SearchProductionTree();
        Key key = new TestKey("key1");
        ComponentNode node = new ComponentNode(1, "Component1", 10, ProductionNodeType.COMPONENT);

        searchTree.addProductionNode(key, node);

        assertTrue(searchTree.containsNode(key));
    }

    @Test
    public void testGetNodeDetails() {
        SearchProductionTree searchTree = new SearchProductionTree();
        Key key = new TestKey("key1");
        ComponentNode node = new ComponentNode(1, "Component1", 10, ProductionNodeType.COMPONENT);

        searchTree.addProductionNode(key, node);

        String details = searchTree.getNodeDetails(key);

        assertTrue(details.contains("Node Type: COMPONENT"));
        assertTrue(details.contains("Quantity: 10"));
    }

    @Test
    public void testSearchNodeByName() {
        SearchProductionTree searchTree = new SearchProductionTree();
        Key key = new TestKey("key1");
        ComponentNode node = new ComponentNode(1, "Component1", 10, ProductionNodeType.COMPONENT);

        searchTree.addProductionNode(key, node);

        assertEquals(node, searchTree.searchNodeByName("Component1"));
        assertNull(searchTree.searchNodeByName("Nonexistent"));
    }

    // Classe auxiliar para criar uma chave simulada
    private static class TestKey implements Key {
        private final String name;

        public TestKey(String name) {
            this.name = name;
        }

        @Override
        public String getAlgorithm() {
            return null;
        }

        @Override
        public String getFormat() {
            return null;
        }

        @Override
        public byte[] getEncoded() {
            return name.getBytes();
        }

        @Override
        public String toString() {
            return name;
        }
    }
}
