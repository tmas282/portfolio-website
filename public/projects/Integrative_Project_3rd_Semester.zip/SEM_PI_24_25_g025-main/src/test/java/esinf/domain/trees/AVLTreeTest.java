package esinf.domain.trees;

import esinf.domain.sprint2.AVLTree;
import esinf.domain.sprint2.NodeType;
import esinf.domain.sprint2.TreeNode;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class AVLTreeTest {

    @Test
    public void testAddOperation() {
        AVLTree tree = new AVLTree();
        TreeNode operation = new TreeNode("1", "Operation1", NodeType.OPERATION, BigDecimal.ONE, null);

        tree.add(1, operation);

        // Check tree root and structure
        assertNotNull(tree); // Check tree is not null
        // Additional methods to verify node structure would be needed
    }
}
