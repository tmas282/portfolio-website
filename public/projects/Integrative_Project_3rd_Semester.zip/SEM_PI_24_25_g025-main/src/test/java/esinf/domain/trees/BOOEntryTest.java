package esinf.domain.trees;

import esinf.domain.sprint2.BOOEntry;
import org.junit.jupiter.api.Test;

import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class BOOEntryTest {

    @Test
    public void testBOOEntryCreation() {
        HashMap<String, String> operationsDependencies = new HashMap<>();
        HashMap<String, String> productDependencies = new HashMap<>();
        operationsDependencies.put("Op1", "10");
        productDependencies.put("Prod1", "20");

        BOOEntry entry = new BOOEntry("Op1", "Prod1", "5", operationsDependencies, productDependencies);

        assertEquals("Op1", entry.operationId);
        assertEquals("Prod1", entry.resultProductId);
        assertEquals("5", entry.quantity);
        assertEquals(operationsDependencies, entry.operationsDependencies);
        assertEquals(productDependencies, entry.productDependencies);
    }
}
