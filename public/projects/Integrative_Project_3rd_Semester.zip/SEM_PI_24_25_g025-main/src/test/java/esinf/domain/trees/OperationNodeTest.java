package main.test;

import esinf.domain.trees.OperationNode;
import esinf.domain.trees.ProductionNodeType;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class OperationNodeTest {

    @Test
    public void testOperationNodeCreation() {
        OperationNode operation = new OperationNode(1, "Operation1", 10);

        assertEquals(1, operation.getId());
        assertEquals("Operation1", operation.getName());
        assertEquals(10, operation.getQuantity());
        assertEquals(ProductionNodeType.OPERATION, operation.getType());
        assertTrue(operation.getChildren().isEmpty());
    }

    @Test
    public void testAddChildToOperationNode() {
        OperationNode operation = new OperationNode(1, "Operation1", 10);
        OperationNode child = new OperationNode(2, "ChildOperation", 5);

        operation.addChild(child);

        assertEquals(1, operation.getChildren().size());
        assertEquals(child, operation.getChildren().get(0));
    }
}
