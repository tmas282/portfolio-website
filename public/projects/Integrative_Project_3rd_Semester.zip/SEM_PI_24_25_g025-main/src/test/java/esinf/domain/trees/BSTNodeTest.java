package esinf.domain.trees;

import esinf.domain.sprint2.BSTNode;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

public class BSTNodeTest {

    @Test
    public void testBSTNodeCreation() {
        BSTNode node = new BSTNode(BigDecimal.TEN, "Material1");

        assertEquals(BigDecimal.TEN, node.quantity);
        assertNotNull(node.materials);
        assertTrue(node.materials.contains("Material1"));
        assertNull(node.left);
        assertNull(node.right);
    }
}
