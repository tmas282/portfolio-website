package esinf.domain.trees;

import esinf.domain.sprint2.NodeType;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class NodeTypeTest {

    @Test
    public void testNodeTypeValues() {
        assertEquals("PRODUCT", NodeType.PRODUCT.name());
        assertEquals("OPERATION", NodeType.OPERATION.name());
    }
}
