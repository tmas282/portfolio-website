package esinf.domain.trees;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import esinf.domain.sprint2.AVLNode;
import esinf.domain.sprint2.NodeType;
import esinf.domain.sprint2.TreeNode;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

public class AVLNodeTest {

    @Test
    public void testAVLNodeCreation() {
        TreeNode operation = new TreeNode("1", "Operation1", NodeType.OPERATION, BigDecimal.ONE, null);
        AVLNode node = new AVLNode(1, operation);

        assertEquals(1, node.dependencyLevel);
        assertNotNull(node.operations);
        assertEquals(1, node.operations.size());
        assertEquals(operation, node.operations.get(0));
    }
}
