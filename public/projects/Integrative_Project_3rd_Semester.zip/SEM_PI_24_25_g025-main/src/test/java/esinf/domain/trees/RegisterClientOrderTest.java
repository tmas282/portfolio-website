package esinf.domain.trees;

import bddad.Functions.RegisterClientOrder;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class RegisterClientOrderTest {

    @Test
    public void testRegisterClientOrderInitialization() {
        RegisterClientOrder order = new RegisterClientOrder();
        assertNotNull(order);
    }
}
