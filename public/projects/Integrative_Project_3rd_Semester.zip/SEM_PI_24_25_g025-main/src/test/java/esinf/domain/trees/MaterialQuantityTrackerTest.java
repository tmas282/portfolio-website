package esinf.domain.trees;

import esinf.domain.sprint2.MaterialQuantityTracker;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class MaterialQuantityTrackerTest {

    @Test
    public void testAddMaterial() {
        MaterialQuantityTracker tracker = new MaterialQuantityTracker();
        tracker.addMaterial(BigDecimal.TEN, "Material1");

        // Assertions would require methods to verify internal state of tracker
        assertNotNull(tracker); // Tracker initialized successfully
    }
}
