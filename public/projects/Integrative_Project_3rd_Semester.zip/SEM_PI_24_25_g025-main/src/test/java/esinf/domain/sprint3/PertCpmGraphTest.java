package esinf.domain.sprint3;

import esinf.domain.sprint3.Activity;
import esinf.domain.sprint3.Algorithms;
import esinf.domain.sprint3.PertCpmGraph;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;

import static org.junit.jupiter.api.Assertions.*;

class PertCpmGraphTest {

    private PertCpmGraph graph;

    @BeforeEach
    void setUp() {
        graph = new PertCpmGraph();
    }

    @Test
    void testAddVertex() {
        Activity activity = new Activity("A", "High level analysis", 1, "week", 30);
        assertTrue(graph.addVertex(activity));
        assertTrue(graph.validVertex(activity));
        assertEquals(1, graph.numVertices());
    }

    @Test
    void testAddEdge() {
        Activity activity1 = new Activity("A", "High level analysis", 1, "week", 30);
        Activity activity2 = new Activity("B", "Order Hardware platform", 4, "week", 2500);
        graph.addVertex(activity1);
        graph.addVertex(activity2);
        assertTrue(graph.addEdge(activity1, activity2, 0));
        assertEquals(1, graph.numEdges());
        assertNotNull(graph.edge(activity1, activity2));
    }

    @Test
    void testCalculateTimes() {
        Activity activity1 = new Activity("A", "High level analysis", 1, "week", 30);
        Activity activity2 = new Activity("B", "Order Hardware platform", 4, "week", 2500);
        graph.addVertex(activity1);
        graph.addVertex(activity2);
        graph.addEdge(activity1, activity2, 0);

        Algorithms.calculateTimes(graph);

        assertEquals(0, activity1.getEarliestStart());
        assertEquals(1, activity1.getEarliestFinish());
        assertEquals(1, activity2.getEarliestStart());
        assertEquals(5, activity2.getEarliestFinish());
    }

    @Test
    void testFindCriticalPath() {
        Activity activity1 = new Activity("A", "High level analysis", 1, "week", 30);
        Activity activity2 = new Activity("B", "Order Hardware platform", 4, "week", 2500);
        graph.addVertex(activity1);
        graph.addVertex(activity2);
        graph.addEdge(activity1, activity2, 0);

        Algorithms.calculateTimes(graph);
        Collection<LinkedList<Activity>> criticalPaths = Algorithms.findCriticalPath(graph);

        assertEquals(1, criticalPaths.size());
        LinkedList<Activity> criticalPath = criticalPaths.iterator().next();
        assertEquals(2, criticalPath.size());
        assertTrue(criticalPath.contains(activity1));
        assertTrue(criticalPath.contains(activity2));
    }
}