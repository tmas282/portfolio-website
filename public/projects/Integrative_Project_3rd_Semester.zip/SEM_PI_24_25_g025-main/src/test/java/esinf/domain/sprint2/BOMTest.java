package esinf.domain.sprint2;

import esinf.domain.BOM;
import esinf.domain.Operation;
import esinf.domain.Product;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.LinkedList;

import static org.junit.jupiter.api.Assertions.*;

public class BOMTest {

    private BOM bom;
    private Product product;
    private Product product2;
    private Operation operation;

    @BeforeEach
    public void setUp() {
        // Inicializa o produto e a operação
        product = new Product("P001", "Product 1");
        product2 = new Product("P002", "Product 2");
        operation = new Operation("O001", "Operation 1");

        // Inicializa o BOM com a operação e produto associados
        bom = new BOM(operation, product);

        // Adiciona um produto à lista de produtos
        bom.getProducts().add(product2);
    }

    @Test
    public void testGetOperationId() {
        // Verifica se a operação associada ao BOM está correta
        assertEquals(operation, bom.getOperationId(), "A operação associada ao BOM não é a esperada.");
    }

    @Test
    public void testSetOperationId() {
        // Altera a operação associada ao BOM e verifica
        Operation newOperation = new Operation("O002", "Operation 2");
        bom.setOperationId(newOperation);
        assertEquals(newOperation, bom.getOperationId(), "A operação associada ao BOM não foi atualizada corretamente.");
    }

    @Test
    public void testGetProduct() {
        // Verifica se o produto associado ao BOM está correto
        assertEquals(product, bom.getProduct(), "O produto associado ao BOM não é o esperado.");
    }

    @Test
    public void testSetProduct() {
        // Altera o produto associado ao BOM e verifica
        Product newProduct = new Product("P003", "Product 3");
        bom.setProduct(newProduct);
        assertEquals(newProduct, bom.getProduct(), "O produto associado ao BOM não foi atualizado corretamente.");
    }

    @Test
    public void testGetProducts() {
        // Verifica se a lista de produtos está correta
        LinkedList<Product> products = bom.getProducts();
        assertNotNull(products, "A lista de produtos não pode ser nula.");
        assertEquals(1, products.size(), "A lista de produtos deve conter 1 elemento.");
        assertEquals(product2, products.getFirst(), "O produto na lista não é o esperado.");
    }

    @Test
    public void testSetProducts() {
        // Configura uma nova lista de produtos e verifica
        LinkedList<Product> newProducts = new LinkedList<>();
        Product product3 = new Product("P003", "Product 3");
        newProducts.add(product3);

        bom.setProducts(newProducts);

        LinkedList<Product> products = bom.getProducts();
        assertNotNull(products, "A lista de produtos não pode ser nula após o set.");
        assertEquals(1, products.size(), "A lista de produtos deve conter 1 elemento após o set.");
        assertEquals(product3, products.getFirst(), "O produto na lista não é o esperado após o set.");
    }

    @Test
    public void testAddProduct() {
        // Adiciona um novo produto à lista
        Product product3 = new Product("P003", "Product 3");
        bom.getProducts().add(product3);

        LinkedList<Product> products = bom.getProducts();
        assertEquals(2, products.size(), "A lista de produtos deve conter 2 elementos após a adição.");
        assertEquals(product3, products.getLast(), "O produto adicionado não está na posição esperada.");
    }

    @Test
    public void testRemoveProduct() {
        // Remove um produto da lista
        bom.getProducts().remove(product2);

        LinkedList<Product> products = bom.getProducts();
        assertEquals(0, products.size(), "A lista de produtos deve estar vazia após a remoção.");
    }
}
