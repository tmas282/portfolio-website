package esinf.domain.trees;

public class TreeProductionBuilderTest {
/*
    @Test
    public void testTreeProductionBuilderWithValidData() {
        // Prepare data
        Map<String, String> itemsMap = new HashMap<>();
        itemsMap.put("P1", "Product1");
        itemsMap.put("P2", "Product2");

        Map<String, String> operationsMap = new HashMap<>();
        operationsMap.put("O1", "Operation1");
        operationsMap.put("O2", "Operation2");

        List<BOOEntry> booEntries = new ArrayList<>();

        // Define operation O1 produces P1 and depends on P2
        Map<String, String> dependenciesO1 = new HashMap<>();
        dependenciesO1.put("P2", "5");
        BOOEntry entryO1 = new BOOEntry("O1", "P1", "1", new HashMap<>(), dependenciesO1);

        // Define operation O2 produces P2 with no dependencies
        BOOEntry entryO2 = new BOOEntry("O2", "P2", "5", new HashMap<>(), new HashMap<>());

        booEntries.add(entryO1);
        booEntries.add(entryO2);

        // Create TreeProductionBuilder
        TreeProductionBuilder builder = new TreeProductionBuilder(itemsMap, operationsMap);

        // Build tree starting from root product P1
        TreeNode root = builder.buildTree("P1", booEntries);

        // Validate the tree structure
        assertNotNull(root);
        assertEquals("P1", root.getId());
        assertEquals(NodeType.PRODUCT, root.getType());
        assertEquals(new BigDecimal("1"), root.getQuantity());

        // Validate root's children
        List<TreeNode> rootChildren = root.getChildren();
        assertNotNull(rootChildren);
        assertEquals(1, rootChildren.size());

        TreeNode operationNode = rootChildren.get(0);
        assertEquals("O1", operationNode.getId());
        assertEquals(NodeType.OPERATION, operationNode.getType());

        // Validate operation node's children
        List<TreeNode> operationChildren = operationNode.getChildren();
        assertNotNull(operationChildren);
        assertEquals(1, operationChildren.size());

        TreeNode productNode = operationChildren.get(0);
        assertEquals("P2", productNode.getId());
        assertEquals(NodeType.PRODUCT, productNode.getType());
        assertEquals(new BigDecimal("5"), productNode.getQuantity());

        // Ensure leaf node has no further children
        assertTrue(productNode.getChildren().isEmpty());
    }

 */
}
