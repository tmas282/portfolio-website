package esinf.domain.sprint3;

import controllers.GraphController;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.LinkedList;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class ProjectDelaySimulatorTest {

    private PertCpmGraph graph;
    private ProjectDelaySimulator simulator;

    @BeforeEach
    void setUp() {
        graph = new PertCpmGraph();
        Activity a = new Activity("A", "Start", 3, "days", 100);
        Activity b = new Activity("B", "Middle", 2, "days", 200);
        Activity c = new Activity("C", "End", 1, "days", 300);

        graph.addVertex(a);
        graph.addVertex(b);
        graph.addVertex(c);

        graph.addEdge(a, b, 0);
        graph.addEdge(b, c, 0);

        simulator = new ProjectDelaySimulator(graph);
    }
/*
    @Test
    void testSimulateDelay() {
        GraphController controller = new GraphController();

        // Simulate delay on activity B
        String delayedActivityKey = "B";
        float delay = 2;
        Map<String, Object> result = simulator.simulateDelay(delayedActivityKey, delay);

        // Verify the critical path and total duration
        @SuppressWarnings("unchecked")
        LinkedList<Activity> criticalPath = (LinkedList<Activity>) result.get("criticalPath");
        float totalDuration = (float) result.get("totalDuration");

        assertNotNull(criticalPath, "Critical path should not be null.");
        assertEquals(6, totalDuration, "Total duration should reflect the delay.");

        assertEquals(3, criticalPath.size(), "Critical path should contain 3 activities.");
        assertEquals("A", criticalPath.get(0).getKey(), "First activity should be A.");
        assertEquals("B", criticalPath.get(1).getKey(), "Second activity should be B.");
        assertEquals("C", criticalPath.get(2).getKey(), "Third activity should be C.");
    }


 */

/*
    @Test
    void testResetDelays() {
        // Simulate delay on activity B
        simulator.simulateDelay("B", 2);

        // Reset delays
        simulator.resetDelays();

        // Verify original durations
        Activity a = graph.vertex("A");
        Activity b = graph.vertex("B");
        Activity c = graph.vertex("C");

        assertEquals(3, a.getDuration(), "Activity A should have its original duration.");
        assertEquals(2, b.getDuration(), "Activity B should have its original duration.");
        assertEquals(1, c.getDuration(), "Activity C should have its original duration.");

        // Verify recalculated project duration
        Map<String, Object> result = simulator.simulateDelay("A", 0);
        float totalDuration = (float) result.get("totalDuration");
        assertEquals(6, totalDuration, "Total duration should reflect the original schedule.");
    }

 */
/*
    @Test
    void testPrintSchedule() {
        simulator.printSchedule();
        // Manual verification of printed schedule may be required
    }

 */
}
