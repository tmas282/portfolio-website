package esinf.domain.sprint2;

import esinf.domain.BOO;
import esinf.domain.Operation;
import esinf.domain.Product;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.LinkedList;

import static org.junit.jupiter.api.Assertions.*;

public class BOOTest {

    private BOO boo;
    private Product product;
    private Operation operation1;
    private Operation operation2;

    @BeforeEach
    public void setUp() {
        // Inicializa o produto e as operações
        product = new Product("P001", "Product 1");
        operation1 = new Operation("O001", "Operation 1");
        operation2 = new Operation("O002", "Operation 2");

        // Inicializa o BOO com o produto
        boo = new BOO(product);

        // Adiciona operações ao BOO
        boo.addOperation(operation1);
        boo.addOperation(operation2);
    }

    @Test
    public void testGetProduct() {
        // Verifica se o produto associado ao BOO está correto
        assertEquals(product, boo.getProduct(), "O produto associado ao BOO não é o esperado.");
    }

    @Test
    public void testSetProduct() {
        // Altera o produto associado ao BOO e verifica
        Product newProduct = new Product("P002", "Product 2");
        boo.setProduct(newProduct);
        assertEquals(newProduct, boo.getProduct(), "O produto associado ao BOO não foi atualizado corretamente.");
    }

    @Test
    public void testGetOperations() {
        // Verifica se a lista de operações contém os elementos adicionados
        LinkedList<Operation> operations = boo.getOperations();
        assertNotNull(operations, "A lista de operações não pode ser nula.");
        assertEquals(2, operations.size(), "A lista de operações deve conter 2 elementos.");
        assertTrue(operations.contains(operation1), "A lista de operações deve conter a operação 1.");
        assertTrue(operations.contains(operation2), "A lista de operações deve conter a operação 2.");
    }

    @Test
    public void testSetOperations() {
        // Configura uma nova lista de operações e verifica
        LinkedList<Operation> newOperations = new LinkedList<>();
        Operation operation3 = new Operation("O003", "Operation 3");
        newOperations.add(operation3);

        boo.setOperations(newOperations);

        LinkedList<Operation> operations = boo.getOperations();
        assertEquals(1, operations.size(), "A lista de operações deve conter 1 elemento.");
        assertEquals(operation3, operations.getFirst(), "A operação na lista não é a esperada.");
    }

    @Test
    public void testAddOperation() {
        // Adiciona uma nova operação e verifica
        Operation operation3 = new Operation("O003", "Operation 3");
        boo.addOperation(operation3);

        LinkedList<Operation> operations = boo.getOperations();
        assertEquals(3, operations.size(), "A lista de operações deve conter 3 elementos.");
        assertEquals(operation3, operations.getLast(), "A última operação na lista não é a esperada.");
    }

    @Test
    public void testAddOperationAt() {
        // Adiciona uma operação em uma posição específica
        Operation operation3 = new Operation("O003", "Operation 3");
        boo.addOperationAt(operation3, 1);

        LinkedList<Operation> operations = boo.getOperations();
        assertEquals(3, operations.size(), "A lista de operações deve conter 3 elementos.");
        assertEquals(operation3, operations.get(1), "A operação adicionada não está na posição esperada.");
    }

    @Test
    public void testRemoveOperation() {
        // Remove uma operação e verifica
        boo.removeOperation(operation1);

        LinkedList<Operation> operations = boo.getOperations();
        assertEquals(1, operations.size(), "A lista de operações deve conter 1 elemento após a remoção.");
        assertFalse(operations.contains(operation1), "A operação removida ainda está na lista.");
    }

    @Test
    public void testGetOperationAt() {
        // Verifica se a operação na posição específica é retornada corretamente
        assertEquals(operation1, boo.getOperationAt(0), "A operação na posição 0 não é a esperada.");
        assertEquals(operation2, boo.getOperationAt(1), "A operação na posição 1 não é a esperada.");
    }
/*
    @Test
    public void testGetBOODetails() {
        // Verifica os detalhes do BOO
        String details = boo.getBOODetails();
        assertTrue(details.contains("BOO OF PRODUCT ID: P001"), "Os detalhes do BOO devem conter o ID do produto.");
        assertTrue(details.contains("Operation Name: Operation 1"), "Os detalhes do BOO devem conter o nome da operação 1.");
        assertTrue(details.contains("Operation Name: Operation 2"), "Os detalhes do BOO devem conter o nome da operação 2.");
    }

 */

    @Test
    public void testSetters() {
        // Testa todos os setters
        LinkedList<Operation> newOperations = new LinkedList<>();
        Operation operation3 = new Operation("O003", "Operation 3");
        newOperations.add(operation3);

        boo.setOperations(newOperations);
        assertEquals(1, boo.getOperations().size(), "A lista de operações deve conter 1 elemento após o set.");
        assertEquals(operation3, boo.getOperations().getFirst(), "A operação na lista não é a esperada.");
    }
}
