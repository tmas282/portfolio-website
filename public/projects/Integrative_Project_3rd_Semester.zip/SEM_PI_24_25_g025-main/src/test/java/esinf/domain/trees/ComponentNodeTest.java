package main.test;

import esinf.domain.trees.ComponentNode;
import esinf.domain.trees.ProductionNodeType;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ComponentNodeTest {

    @Test
    public void testComponentNodeCreation() {
        ComponentNode component = new ComponentNode(1, "Component1", 20, ProductionNodeType.COMPONENT);

        assertEquals(1, component.getId());
        assertEquals("Component1", component.getName());
        assertEquals(20, component.getQuantity());
        assertEquals(ProductionNodeType.COMPONENT, component.getType());
        assertTrue(component.getChildren().isEmpty());
    }

    @Test
    public void testSetQuantity() {
        ComponentNode component = new ComponentNode(1, "Component1", 20, ProductionNodeType.COMPONENT);

        component.setQuantity(30);

        assertEquals(30, component.getQuantity());
    }

    @Test
    public void testAddChildToComponentNode() {
        ComponentNode parent = new ComponentNode(1, "ParentComponent", 10, ProductionNodeType.COMPONENT);
        ComponentNode child = new ComponentNode(2, "ChildComponent", 5, ProductionNodeType.COMPONENT);

        parent.addChild(child);

        assertEquals(1, parent.getChildren().size());
        assertEquals(child, parent.getChildren().get(0));
    }
}
