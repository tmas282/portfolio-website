package esinf.domain.sprint3;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ActivityTest {

    private Activity activity;

    @BeforeEach
    void setUp() {
        activity = new Activity("A1", "Description A1", 5.0f, "days", 100.0f);
    }

    @Test
    void testConstructor() {
        assertEquals("A1", activity.getKey());
        assertEquals("Description A1", activity.getDescription());
        assertEquals(5.0f, activity.getDuration());
        assertEquals("days", activity.getDurationUnit());
        assertEquals(100.0f, activity.getCost());
        assertEquals(0.0f, activity.getEarliestStart());
        assertEquals(0.0f, activity.getLatestFinish());
        assertEquals(5.0f, activity.getEarliestFinish());
        assertEquals(-5.0f, activity.getLatestStart());
        assertEquals(0.0f, activity.getSlack());
    }

    @Test
    void testGetters() {
        assertEquals("A1", activity.getKey());
        assertEquals("Description A1", activity.getDescription());
        assertEquals(5.0f, activity.getDuration());
        assertEquals("days", activity.getDurationUnit());
        assertEquals(100.0f, activity.getCost());
        assertEquals(0.0f, activity.getEarliestStart());
        assertEquals(0.0f, activity.getLatestFinish());
        assertEquals(5.0f, activity.getEarliestFinish());
        assertEquals(-5.0f, activity.getLatestStart());
        assertEquals(0.0f, activity.getSlack());
    }

    @Test
    void testSetters() {
        activity.setDuration(10.0f);
        assertEquals(10.0f, activity.getDuration());
        assertEquals(10.0f, activity.getEarliestFinish());
        assertEquals(-10.0f, activity.getLatestStart());

        activity.setEarliestStart(2.0f);
        assertEquals(2.0f, activity.getEarliestStart());
        assertEquals(12.0f, activity.getEarliestFinish());

        activity.setLatestFinish(15.0f);
        assertEquals(15.0f, activity.getLatestFinish());
        assertEquals(5.0f, activity.getLatestStart());

        activity.setSlack(3.0f);
        assertEquals(3.0f, activity.getSlack());
    }

    @Test
    void testEqualsAndHashCode() {
        Activity activity2 = new Activity("A1", "Description A1", 5.0f, "days", 100.0f);
        assertEquals(activity, activity2);
        assertEquals(activity.hashCode(), activity2.hashCode());

        Activity activity3 = new Activity("A2", "Description A2", 6.0f, "hours", 200.0f);
        assertNotEquals(activity, activity3);
        assertNotEquals(activity.hashCode(), activity3.hashCode());
    }
/*
    @Test
    void testToString() {
        String expected = "Description A1 (Key: A1) \n" +
                "Duration: 5.00 days \n" +
                "Cost: 100.00 \n" +
                "Earliest Start: 0.00 \n" +
                "Latest Finish: 0.00 \n" +
                "Slack: 0.00";
        assertEquals(expected, activity.toString());
    }

 */
}