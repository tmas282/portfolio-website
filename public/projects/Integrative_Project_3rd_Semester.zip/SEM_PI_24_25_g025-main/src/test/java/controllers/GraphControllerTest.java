package controllers;

import esinf.domain.sprint3.Activity;
import esinf.domain.sprint3.PertCpmGraph;
import org.junit.jupiter.api.Test;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;

import static org.junit.Assert.assertEquals;

class GraphControllerTest {

    @Test
    void readCSVandBuildGraph() throws FileNotFoundException {
        PertCpmGraph expected = new PertCpmGraph();
        expected.addVertex(new Activity("A", "High level analysis", 1, "week", 30));
        expected.addVertex(new Activity("B", "Order Hardware platform", 4, "week", 2500));
        expected.addVertex(new Activity("C", "Installation and commissioning of hardware", 2, "week", 1250));
        expected.addVertex(new Activity("D", "Detailed analysis of core modules", 3, "week", 30));
        expected.addVertex(new Activity("E", "Detailed analysis of supporting modules", 2, "week", 30));
        expected.addVertex(new Activity("F", "Programming of core modules", 4, "week", 20));
        expected.addVertex(new Activity("G", "Programming of supporting modules", 3, "week", 20));
        expected.addVertex(new Activity("H", "Quality assurance of core modules", 2, "week", 30));
        expected.addVertex(new Activity("I", "Quality assurance of supporting modules", 1, "week", 30));
        expected.addVertex(new Activity("J", "Application Manual", 1, "week", 550));
        expected.addVertex(new Activity("K", "User Manual", 1, "week", 750));
        expected.addVertex(new Activity("L", "Core and supporting module training", 2, "week", 1500));

        expected.addEdge(expected.vertex("B"), expected.vertex("C"), 0);
        expected.addEdge(expected.vertex("A"), expected.vertex("D"), 0);
        expected.addEdge(expected.vertex("D"), expected.vertex("E"), 0);
        expected.addEdge(expected.vertex("C"), expected.vertex("F"), 0);
        expected.addEdge(expected.vertex("D"), expected.vertex("F"), 0);
        expected.addEdge(expected.vertex("E"), expected.vertex("G"), 0);
        expected.addEdge(expected.vertex("F"), expected.vertex("G"), 0);
        expected.addEdge(expected.vertex("F"), expected.vertex("H"), 0);
        expected.addEdge(expected.vertex("G"), expected.vertex("I"), 0);
        expected.addEdge(expected.vertex("G"), expected.vertex("J"), 0);
        expected.addEdge(expected.vertex("G"), expected.vertex("K"), 0);
        expected.addEdge(expected.vertex("H"), expected.vertex("L"), 0);
        expected.addEdge(expected.vertex("I"), expected.vertex("L"), 0);
        expected.addEdge(expected.vertex("K"), expected.vertex("L"), 0);

        GraphController graphController = new GraphController();
        String csv = getClass().getClassLoader().getResource("small_project.csv").getFile();
        PertCpmGraph real = graphController.readCSVandBuildGraph(csv);
        assertEquals(expected, real);
    }

    @Test
    void getCriticalPaths() throws FileNotFoundException {
        GraphController graphController = new GraphController();
        String csv = getClass().getClassLoader().getResource("small_project.csv").getFile();
        graphController.readCSVandBuildGraph(csv);
        graphController.getActivityTimes();

        Collection<LinkedList<Activity>> expected = new ArrayList<>();
        LinkedList<Activity> criticalPath1 = new LinkedList<>();
        criticalPath1.add(graphController.getGraph().vertex("B"));
        criticalPath1.add(graphController.getGraph().vertex("C"));
        criticalPath1.add(graphController.getGraph().vertex("F"));
        criticalPath1.add(graphController.getGraph().vertex("G"));
        criticalPath1.add(graphController.getGraph().vertex("K"));
        criticalPath1.add(graphController.getGraph().vertex("L"));
        LinkedList<Activity> criticalPath2 = new LinkedList<>();
        criticalPath2.add(graphController.getGraph().vertex("B"));
        criticalPath2.add(graphController.getGraph().vertex("C"));
        criticalPath2.add(graphController.getGraph().vertex("F"));
        criticalPath2.add(graphController.getGraph().vertex("G"));
        criticalPath2.add(graphController.getGraph().vertex("I"));
        criticalPath2.add(graphController.getGraph().vertex("L"));
        expected.add(criticalPath1);
        expected.add(criticalPath2);

        Collection<LinkedList<Activity>> real = graphController.getCriticalPaths();
    }
}