package esinf.domain;

import java.util.*;
import java.util.Queue;

/**
 * Represents a product with details including ID, name, family, and associated BOM and BOO.
 */
public class Product {
    private final String productID;  // ID of the product
    private String name;  // Name of the product
    private String family;  // Family of the product
    private String description;  // Description of the product
    private BOO boo;  // BOO of the product
    private BOM bom;  // BOM of the product
    private static int counter = 0;  // Counter for product numbering
    private int number;  // Unique number for the product
    private float quantity;
    private List<Station> stationsPassed = new ArrayList<>();
    /**
     * Constructs a Product with specified details and initializes unique product number.
     *
     * @param productID   ID of the product.
     * @param name        Name of the product.
     * @param family      Product family.
     * @param description Description of the product.
     * @param boo         BOO associated with the product.
     * @param bom       BOM associated with the product.
     */
    public Product(String productID, String name, String family, String description, BOO boo, BOM bom) {
        this.productID = productID;
        this.name = name;
        this.family = family;
        this.description = description;
        this.bom = bom;
        this.boo = boo;
        this.number = counter++;
    }

    public Product (String productID, BOO boo){
        this.productID = productID;
        this.boo = boo;
    }
    public Product (String productID, String productName){
        this.productID = productID;
        this.name = productName;
    }

    public float getQuantity() {
        return quantity;
    }

    public void setQuantity(float quantity) {
        this.quantity = quantity;
    }

    /**
     * Retrieves the unique identifier of the product.
     *
     * @return Product ID.
     */
    public String getProductID() {
        return productID;
    }
    /**
     * Retrieves the name of the product.
     *
     * @return Product name.
     */
    public String getName() {
        return name;
    }
    /**
     * Retrieves the family category of the product.
     *
     * @return Product family.
     */
    public String getFamily() {
        return family;
    }
    /**
     * Retrieves the description of the product.
     *
     * @return Product description.
     */
    public String getDescription() {
        return description;
    }

/**
        * Retrieves the BOO (Bill of Operations) associated with the product.
            *
            * @return BOO associated with the product.
     */
    public BOO getBoo() {
        return boo;
    }
    /**
     * Retrieves the BOM (Bill of Materials) identifier of the product.
     *
     * @return BOM associated with the product.
     */
    public BOM getBom() {
        return bom;
    }
    /**
     * Compares this product to the specified object. The result is true if and only if
     * the argument is not null and is a Product object that has the same product ID.
     *
     * @param o The object to compare this Product against.
     * @return true if the given object represents a Product equivalent to this Product, false otherwise.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Product product = (Product) o;
        return productID.equals(product.productID);
    }
    /**
     * Returns a hash code value for the product, using the product ID.
     *
     * @return Hash code value for this product.
     */
    @Override
    public int hashCode() {
        return Objects.hash(productID);
    }
    /**
     * Returns a string representation of the Product, including ID, name, family, and description.
     *
     * @return String representation of the Product.
     */
    @Override
    public String toString() {
        return productID;
    }
    /**
     * Adds a station to the list of stations passed.
     *
     * @param station the station to add
     */
    public void addStation(Station station) {
        if (!stationsPassed.contains(station))
            stationsPassed.add(station);
    }

    /**
     * Gets the list of stations passed.
     *
     * @return the list of stations passed
     */
    public List<Station> getStationsPassed() {
        return stationsPassed;
    }
}