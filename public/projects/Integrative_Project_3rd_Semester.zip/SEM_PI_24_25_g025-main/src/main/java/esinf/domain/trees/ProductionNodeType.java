package esinf.domain.trees;

public enum ProductionNodeType {
    COMPONENT, OPERATION, RAW_MATERIAL;
}