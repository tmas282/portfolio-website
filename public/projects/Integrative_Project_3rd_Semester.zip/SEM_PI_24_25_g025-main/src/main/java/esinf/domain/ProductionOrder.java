package esinf.domain;

import java.util.Date;

/**
 * Represents a production order with associated product, priority, and scheduling details.
 */
public class ProductionOrder {
    private String costumerOrderID;  // ID of the associated customer order
    private Product product;  // Reference to the product
    private Priority priority;  // Priority of the production order
    private Date startDate;  // Start date of the production order
    private Date endDate;  // End date of the production order
    private int stage;  // Stage of the production order

    /**
     * Constructs a ProductionOrder with specified product and priority.
     *
     * @param product  The product associated with this order.
     * @param priority The priority level of this order.
     */
    public ProductionOrder(Product product, Priority priority) {
        this.costumerOrderID = costumerOrderID;
        this.product = product;
        this.priority = priority;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    // Getters and Setters

    /**
     * Gets the customer order ID.
     *
     * @return the customer order ID
     */
    public String getCostumerOrderID() {
        return costumerOrderID;
    }

    /**
     * Sets the customer order ID.
     *
     * @param costumerOrderID the customer order ID
     */
    public void setCostumerOrderID(String costumerOrderID) {
        this.costumerOrderID = costumerOrderID;
        this.stage = 0;
    }

    /**
     * Gets the product.
     *
     * @return the product
     */
    public Product getProduct() {
        return product;
    }

    /**
     * Sets the product.
     *
     * @param product the product
     */
    public void setProduct(Product product) {
        this.product = product;
    }

    /**
     * Gets the priority.
     *
     * @return the priority
     */
    public Priority getPriority() {
        return priority;
    }

    /**
     * Sets the priority.
     *
     * @param priority the priority
     */
    public void setPriority(Priority priority) {
        this.priority = priority;
    }

    /**
     * Gets the start date.
     *
     * @return the start date
     */
    public Date getStartDate() {
        return startDate;
    }

    /**
     * Sets the start date.
     *
     * @param startDate the start date
     */
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    /**
     * Gets the stage.
     *
     * @return the stage
     */
    public int getStage() {
        return stage;
    }

    /**
     * Resets the stage to 0.
     */
    public void resetStage() {
        stage = 0;
    }

    /**
     * Advances the stage by 1.
     */
    public void passStage() {
        this.stage += 1;
    }

    /**
     * Checks if the production order is completed.
     *
     * @return true if completed, false otherwise
     */
    public boolean isCompleted() {
        return product.getBoo().getOperations().size() - 1 < stage;
    }

    /**
     * Gets the end date.
     *
     * @return the end date
     */
    public Date getEndDate() {
        return endDate;
    }

    /**
     * Sets the end date.
     *
     * @param endDate the end date
     */
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }
}