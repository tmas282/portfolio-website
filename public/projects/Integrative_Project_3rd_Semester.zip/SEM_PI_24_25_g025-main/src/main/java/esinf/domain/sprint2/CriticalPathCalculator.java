package esinf.domain.sprint2;

import java.util.*;

public class CriticalPathCalculator {

    public static void identifyAndPrioritizeCriticalPath(TreeNode root) {
        PriorityQueue<OperationDepth> maxHeap = new PriorityQueue<>(Collections.reverseOrder());

        calculateDepth(root, 0, maxHeap);

        displayCriticalPath(maxHeap);
    }

    private static void calculateDepth(TreeNode node, int depth, PriorityQueue<OperationDepth> maxHeap) {
        if (node.getType() == NodeType.OPERATION) {
            maxHeap.add(new OperationDepth(node, depth));
        }

        for (TreeNode child : node.getChildren()) {
            calculateDepth(child, depth + 1, maxHeap);
        }
    }

    private static void displayCriticalPath(PriorityQueue<OperationDepth> maxHeap) {
        System.out.println("Critical Path Operations in Order of Importance:");
        while (!maxHeap.isEmpty()) {
            OperationDepth opDepth = maxHeap.poll();
            System.out.println("Operation: " + opDepth.node.getName() + ", Depth: " + opDepth.depth);
        }
    }

    private static class OperationDepth implements Comparable<OperationDepth> {
        TreeNode node;
        int depth;

        OperationDepth(TreeNode node, int depth) {
            this.node = node;
            this.depth = depth;
        }

        @Override
        public int compareTo(OperationDepth other) {
            return Integer.compare(this.depth, other.depth);
        }
    }
}