package esinf.domain.sprint3.algorithms;

import esinf.domain.sprint3.Algorithms;
import esinf.domain.sprint3.Graph;

import java.util.LinkedList;

public class TopologicalSort
{
    /**
     * Performs topological sort on the given graph based on the DepthFirstSearch algorithm.
     *
     * @param g Graph instance
     * @return a LinkedList with vertices in topological order
     */
    public static <V, E> LinkedList<V> topologicalSort(Graph<V, E> g) {
        return Algorithms.DepthFirstSearch(g);
    }
}
