package esinf.domain.sprint3;

import esinf.utils.GraphFileReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.function.BinaryOperator;
import java.util.ArrayList;
import java.util.LinkedList;

import static esinf.domain.sprint3.algorithms.AllPaths.allPaths;

/**
 *
 * @author DEI-ISEP
 *
 */
public class Algorithms {

    /**
     * Performs breadth-first search of a Graph starting in a vertex
     *
     * @param g    Graph instance
     * @param vert vertex that will be the source of the search
     * @return a LinkedList with the vertices of breadth-first search
     */
    public static <V, E> LinkedList<V> BreadthFirstSearch(Graph<V, E> g, V vert) {

        throw new UnsupportedOperationException("Not supported yet.");
    }

    /**
     * Performs depth-first search starting in a vertex
     *
     * @param g       Graph instance
     * @param vOrig   vertex of graph g that will be the source of the search
     * @param visited set of previously visited vertices
     * @param qdfs    return LinkedList with vertices of depth-first search
     */
    private static <V, E> void DepthFirstSearch(Graph<V, E> g, V vOrig, boolean[] visited, LinkedList<V> qdfs) {
        int key = g.key(vOrig);
        if (key == -1 || visited[key]) return;

        visited[key] = true;

        // Visit all adjacent vertices in a deterministic order
        g.adjVertices(vOrig).stream()
                .sorted((v1, v2) -> g.key(v1) - g.key(v2)) // Sort by vertex key for consistency
                .forEach(neighbor -> {
                    if (!visited[g.key(neighbor)]) {
                        DepthFirstSearch(g, neighbor, visited, qdfs);
                    }
                });

        // Add vertex to the topological order after processing all its neighbors
        qdfs.addFirst(vOrig);
    }

    public static <V, E> boolean hasCircularDependencies(Graph<V, E> g) {
        boolean[] visited = new boolean[g.numVertices()];
        boolean[] recStack = new boolean[g.numVertices()];

        for (V vertex : g.vertices()) {
            if (detectCycle(g, vertex, visited, recStack)) {
                return true; // Cycle found
            }
        }
        return false; // No cycle found
    }

    private static <V, E> boolean detectCycle(Graph<V, E> g, V vertex, boolean[] visited, boolean[] recStack) {
        int vertexKey = g.key(vertex);
        if (!visited[vertexKey]) {
            visited[vertexKey] = true;
            recStack[vertexKey] = true;

            for (V adj : g.adjVertices(vertex)) {
                int adjKey = g.key(adj);
                if (!visited[adjKey] && detectCycle(g, adj, visited, recStack)) {
                    return true;
                } else if (recStack[adjKey]) {
                    return true; // Cycle detected
                }
            }
        }
        recStack[vertexKey] = false;
        return false;
    }

    /**
     * Performs depth-first search starting in a vertex
     *
     * @param g Graph instance

     * @return a LinkedList with the vertices of depth-first search
     */
    public static <V, E> LinkedList<V> DepthFirstSearch(Graph<V, E> g) {

        if (hasCircularDependencies(g)) {
            throw new UnsupportedOperationException("Graph contains circular dependencies.");
        }
        LinkedList<V> topsort = new LinkedList<>();
        boolean[] visited = new boolean[g.numVertices()];

        // Iterate through all vertices in the graph
        g.vertices().stream()
                .sorted((v1, v2) -> g.inDegree(v1) - g.inDegree(v2)) // Sort by in-degree to prioritize independent nodes
                .forEach(vertex -> {
                    if (!visited[g.key(vertex)]) {
                        DepthFirstSearch(g, vertex, visited, topsort);
                    }
                });

        return topsort;
    }

    /**
     * Returns all paths from vOrig to vDest
     *
     * @param g       Graph instance
     * @param vOrig   Vertex that will be the source of the path
     * @param vDest   Vertex that will be the end of the path
     * @param visited set of discovered vertices
     * @param path    stack with vertices of the current path (the path is in reverse order)
     * @param paths   ArrayList with all the paths (in correct order)
     */
    public static <V, E> void allPaths(Graph<V, E> g, V vOrig, V vDest, boolean[] visited,
                                        LinkedList<V> path, ArrayList<LinkedList<V>> paths) {

        path.add(vOrig); // Adiciona o vértice atual ao caminho
        visited[g.key(vOrig)] = true; // Marca como visitado

        // Verifica se alcançou o destino
        if (vOrig.equals(vDest)) {
            paths.add(new LinkedList<>(path)); // Adiciona o caminho completo à lista de caminhos
        } else {
            // Explora os vértices adjacentes
            for (V vAdj : g.adjVertices(vOrig)) {
                // Se ainda não foi visitado
                if (!visited[g.key(vAdj)]) {
                    allPaths(g, vAdj, vDest, visited, path, paths); // Chamada recursiva
                }
            }
        }

        // Backtracking: remove o vértice atual do caminho e marca-o como não visitado
        path.removeLast();
        visited[g.key(vOrig)] = false;
    }

    /**
     * Returns all paths from vOrig to vDest
     *
     * @param g     Graph instance
     * @param vOrig information of the Vertex origin
     * @param vDest information of the Vertex destination
     * @return paths ArrayList with all paths from vOrig to vDest
     */
    public static <V, E> ArrayList<LinkedList<V>> allPaths(Graph<V, E> g, V vOrig, V vDest) {

        throw new UnsupportedOperationException("Not supported yet.");
    }

    /**
     * Computes shortest-path distance from a source vertex to all reachable
     * vertices of a graph g with non-negative edge weights
     * This implementation uses Dijkstra's algorithm
     *
     * @param g        Graph instance
     * @param vOrig    Vertex that will be the source of the path
     * @param visited  set of previously visited vertices
     * @param pathKeys minimum path vertices keys
     * @param dist     minimum distances
     */
    private static <V, E> void shortestPathDijkstra(Graph<V, E> g, V vOrig,
                                                    Comparator<E> ce, BinaryOperator<E> sum, E zero,
                                                    boolean[] visited, V[] pathKeys, E[] dist) {

        throw new UnsupportedOperationException("Not supported yet.");
    }


    /**
     * Shortest-path between two vertices
     *
     * @param g         graph
     * @param vOrig     origin vertex
     * @param vDest     destination vertex
     * @param ce        comparator between elements of type E
     * @param sum       sum two elements of type E
     * @param zero      neutral element of the sum in elements of type E
     * @param shortPath returns the vertices which make the shortest path
     * @return if vertices exist in the graph and are connected, true, false otherwise
     */
    public static <V, E> E shortestPath(Graph<V, E> g, V vOrig, V vDest,
                                        Comparator<E> ce, BinaryOperator<E> sum, E zero,
                                        LinkedList<V> shortPath) {

        throw new UnsupportedOperationException("Not supported yet.");
    }

    /**
     * Shortest-path between a vertex and all other vertices
     *
     * @param g     graph
     * @param vOrig start vertex
     * @param ce    comparator between elements of type E
     * @param sum   sum two elements of type E
     * @param zero  neutral element of the sum in elements of type E
     * @param paths returns all the minimum paths
     * @param dists returns the corresponding minimum distances
     * @return if vOrig exists in the graph true, false otherwise
     */
    public static <V, E> boolean shortestPaths(Graph<V, E> g, V vOrig,
                                               Comparator<E> ce, BinaryOperator<E> sum, E zero,
                                               ArrayList<LinkedList<V>> paths, ArrayList<E> dists) {

        throw new UnsupportedOperationException("Not supported yet.");
    }

    /**
     * Extracts from pathKeys the minimum path between voInf and vdInf
     * The path is constructed from the end to the beginning
     *
     * @param g        Graph instance
     * @param vOrig    information of the Vertex origin
     * @param vDest    information of the Vertex destination
     * @param pathKeys minimum path vertices keys
     * @param path     stack with the minimum path (correct order)
     */
    private static <V, E> void getPath(Graph<V, E> g, V vOrig, V vDest,
                                       V[] pathKeys, LinkedList<V> path) {

        throw new UnsupportedOperationException("Not supported yet.");
    }

    /**
     * Calculates the minimum distance graph using Floyd-Warshall
     *
     * @param g   initial graph
     * @param ce  comparator between elements of type E
     * @param sum sum two elements of type E
     * @return the minimum distance graph
     */
    public static <V, E> MatrixGraph<V, E> minDistGraph(Graph<V, E> g, Comparator<E> ce, BinaryOperator<E> sum) {

        throw new UnsupportedOperationException("Not supported yet.");
    }

    public static void calculateTimes(Graph<Activity, Integer> graph) {
        // Verificar se o grafo contém ciclos antes de calcular os tempos
        //TODO: Adicionar verificação de grafo ciclico (Bernardo)
        if (hasCircularDependencies(graph)) {
            throw new UnsupportedOperationException("Graph contains circular dependencies.");
        }
        // Continuar com o cálculo se o grafo for válido
        forwardPass(graph);
        backwardPass(graph);

        for (Activity activity : graph.vertices()) {
            double slack = activity.getLatestStart() - activity.getEarliestStart();
            activity.setSlack((float) slack);
        }
    }



    /*
     * Calcula os tempos de início mais cedo (ES) e término mais cedo (EF) para todas as atividades.
     *
     * @param graph O grafo de atividades (PERT/CPM).

    public static <V, E> List<V> topologicalSort(Graph<V, E> graph) {
        List<V> sortedList = new ArrayList<>();
        Queue<V> queue = new LinkedList<>();
        Map<V, Integer> inDegree = new HashMap<>();

        for (V vertex : graph.vertices()) {
            inDegree.put(vertex, graph.inDegree(vertex));
            if (inDegree.get(vertex) == 0) {
                queue.add(vertex);
            }
        }

        while (!queue.isEmpty()) {
            V vertex = queue.poll();
            sortedList.add(vertex);

            for (V adj : graph.adjVertices(vertex)) {
                int degree = inDegree.get(adj) - 1;
                inDegree.put(adj, degree);
                if (degree == 0) {
                    queue.add(adj);
                }
            }
        }

        if (sortedList.size() != graph.numVertices()) {
            return null; // Grafo contém ciclos
        }

        return sortedList;

    }
*/
    /**
     * Calcula os tempos de início mais tarde (LS) e término mais tarde (LF) para todas as atividades.
     *
     * @param graph O grafo de atividades (PERT/CPM).
     */
    public static void backwardPass(Graph<Activity, Integer> graph) {
        List<Activity> vertices = new ArrayList<>(graph.vertices());
        Collections.reverse(vertices); // Process in reverse order

        // Determine the maximum EF as the starting point
        double maxEF = vertices.stream()
                .mapToDouble(Activity::getEarliestFinish)
                .max()
                .orElse(0.0);

        // Initialize LF and LS for all activities
        for (Activity activity : vertices) {
            activity.setLatestFinish((float) maxEF);
        }

        for (Activity activity : vertices) {
            for (Activity successor : graph.adjVertices(activity)) {
                activity.setLatestFinish(Math.min(activity.getLatestFinish(), successor.getLatestStart()));
            }
            activity.setLatestStart(activity.getLatestFinish() - activity.getDuration());
        }
    }
    public static void forwardPass(Graph<Activity, Integer> graph) {
        Queue<Activity> queue = new LinkedList<>();

        for (Activity activity : graph.vertices()) {
            if (graph.inDegree(activity) == 0) {
                queue.add(activity);
            }
        }

        while (!queue.isEmpty()) {
            Activity current = queue.poll();
            for (Edge<Activity, Integer> edge : graph.outgoingEdges(current)) {
                Activity successor = edge.getVDest();
                successor.setEarliestStart(
                        Math.max(successor.getEarliestStart(), current.getEarliestFinish())
                );
                //successor.setEarliestFinish(successor.getEarliestStart() + successor.getDuration());
                queue.add(successor);
            }
        }
    }
    public static Collection<LinkedList<Activity>> findCriticalPath(PertCpmGraph graph, Activity orig, Collection<LinkedList<Activity>> criticalPaths, List<Activity> stack, List<LinkedList<Activity>> stackPaths){
        LinkedList<Activity> criticalPath;
        if(!stack.isEmpty()){
            criticalPath = new LinkedList<>(stackPaths.get(stackPaths.size() - 1));
            stackPaths.remove(stackPaths.get(stackPaths.size() - 1));
        }
        else{
            criticalPath = new LinkedList<>();
        }
        criticalPath.add(orig);
        stack.remove(orig);
        Collection<Activity> adjV = graph.adjVertices(orig);
        if(adjV.isEmpty()){
            criticalPaths.add(criticalPath);
            if(stack.isEmpty()){
                return criticalPaths;
            }
            return findCriticalPath(graph, stack.get(stack.size()-1), criticalPaths, stack, stackPaths);
        }
        for(Activity a : adjV){
            if(a.getSlack() == 0){
                stack.add(a);
                stackPaths.add(criticalPath);
            }
        }
        return findCriticalPath(graph, stack.get(stack.size()-1), criticalPaths, stack, stackPaths);
    }
    public static Collection<LinkedList<Activity>> findCriticalPath(PertCpmGraph graph, Activity orig){
        Collection<LinkedList<Activity>> criticalPaths = new ArrayList<>();
        return findCriticalPath(graph, orig, criticalPaths, new ArrayList<>(), new ArrayList<>());
    }
    public static Collection<LinkedList<Activity>> findCriticalPath(PertCpmGraph graph){
        Collection<LinkedList<Activity>> listCriticalPath = new ArrayList<>();
        for(Activity i : graph.vertices()){
            if(i.getSlack() == 0 && graph.incomingEdges(i).isEmpty()){
                listCriticalPath.addAll(findCriticalPath(graph, i));
            }
        }
        return listCriticalPath;
    }
    public static float calculateCriticalPathDuration(LinkedList<Activity> criticalPath){
        float duration =0;
        for(Activity i : criticalPath){
            duration += i.getDuration();
        }
        return duration;
    }

    public static void main(String[] args) throws FileNotFoundException {
        // Create a PertCpmGraph instance
        PertCpmGraph graph = new PertCpmGraph();

        GraphFileReader.buildGraphFromFile(graph, new File("./files/small_project.csv.csv"));

        // Perform Topological Sort
        LinkedList<Activity> sortedActivities = DepthFirstSearch(graph);

        // Print the result
        System.out.println("Topological Order of Activities:");
        int order = 1;
        for (Activity activity : sortedActivities) {
            System.out.printf("%d. [%s] -> %s%n", order++, activity.getKey(), activity.getDescription());
        }
    }

}