package esinf.utils;

import esinf.dataStructures.OperationStationMap;
import esinf.domain.Operation;
import esinf.domain.Station;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility class to read and process workstation data from a CSV file.
 */
public class WorkstationFileReader {
    private OperationStationMap operationStationMap;
    private List<Station> stations = new ArrayList<>();
    private List<Operation> operations = new ArrayList<>();

    /**
     * Constructs a WorkstationFileReader.
     */
    public WorkstationFileReader() {
        this.operationStationMap = new OperationStationMap();
    }

    /**
     * Reads and processes the CSV file containing workstation data.
     *
     * @param csvFilePath Path to the CSV file.
     */
    public void readCSV(String csvFilePath) {
        String line;
        String csvSplitBy = ";";

        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            // Skip the header
            br.readLine();

            // Read through each line in the CSV
            while ((line = br.readLine()) != null) {
                // Split the line into fields
                String[] row = line.split(csvSplitBy);

                // Extract data from the row
                String stationID = row[0].trim();
                String operationName = row[1].trim();
                int operationTime = Integer.parseInt(row[2].trim());

                // Create or get existing station
                Station station = new Station(stationID);
                if (!stations.contains(station)) {
                    stations.add(station);
                } else {
                    station = stations.get(stations.indexOf(station));
                }

                // Create the operation
                Operation operation = new Operation(operationName);
                if (!operations.contains(operation)) {
                    operations.add(operation);
                } else {
                    operation = operations.get(operations.indexOf(operation));
                }

                // Add the station-operation assignment to the map
                operationStationMap.addAssignment(operation, station, operationTime);
            }

            // Print success message
            System.out.println("CSV data loaded successfully!");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Prints all assignments of operations to stations.
     */
    public void printAssignments() {
        operationStationMap.printAllAssignments();
    }

    /**
     * Gets the operation station map.
     *
     * @return the operation station map
     */
    public OperationStationMap getOperationStationMap() {
        return operationStationMap;
    }

    /**
     * Gets the list of stations.
     *
     * @return the list of stations
     */
    public List<Station> getStations() {
        return stations;
    }

    /**
     * Gets the list of operations.
     *
     * @return the list of operations
     */
    public List<Operation> getOperations() {
        return operations;
    }
}