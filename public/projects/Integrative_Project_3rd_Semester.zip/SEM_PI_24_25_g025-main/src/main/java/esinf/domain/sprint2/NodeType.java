package esinf.domain.sprint2;

public enum NodeType {
    PRODUCT, OPERATION
}