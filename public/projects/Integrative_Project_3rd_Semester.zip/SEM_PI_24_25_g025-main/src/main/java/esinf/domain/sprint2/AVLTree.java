package esinf.domain.sprint2;

import esinf.domain.Operation;

import java.util.LinkedList;

public class AVLTree {
        private AVLNode root;

        // Add an operation to the AVL Tree
        public void add(int dependencyLevel, TreeNode operation) {
            root = add(root, dependencyLevel, operation);
        }

        private AVLNode add(AVLNode node, int dependencyLevel, TreeNode operation) {
            if (node == null) {
                return new AVLNode(dependencyLevel, operation);
            }

            if (dependencyLevel < node.dependencyLevel) {
                node.left = add(node.left, dependencyLevel, operation);
            } else if (dependencyLevel > node.dependencyLevel) {
                node.right = add(node.right, dependencyLevel, operation);
            } else {
                node.operations.add(operation); // Same level, add to list
            }

            // Update height and balance the node
            node.height = 1 + Math.max(height(node.left), height(node.right));
            return balance(node);
        }

        // Balance the AVL Tree
        private AVLNode balance(AVLNode node) {
            int balanceFactor = getBalanceFactor(node);

            if (balanceFactor > 1) { // Left-heavy
                if (getBalanceFactor(node.left) < 0) {
                    node.left = rotateLeft(node.left); // Left-Right case
                }
                return rotateRight(node); // Left-Left case
            }

            if (balanceFactor < -1) { // Right-heavy
                if (getBalanceFactor(node.right) > 0) {
                    node.right = rotateRight(node.right); // Right-Left case
                }
                return rotateLeft(node); // Right-Right case
            }

            return node; // Balanced
        }

        private AVLNode rotateRight(AVLNode y) {
            AVLNode x = y.left;
            AVLNode T = x.right;

            x.right = y;
            y.left = T;

            y.height = 1 + Math.max(height(y.left), height(y.right));
            x.height = 1 + Math.max(height(x.left), height(x.right));

            return x;
        }

        private AVLNode rotateLeft(AVLNode x) {
            AVLNode y = x.right;
            AVLNode T = y.left;

            y.left = x;
            x.right = T;

            x.height = 1 + Math.max(height(x.left), height(x.right));
            y.height = 1 + Math.max(height(y.left), height(y.right));

            return y;
        }

        private int height(AVLNode node) {
            return node == null ? 0 : node.height;
        }

        private int getBalanceFactor(AVLNode node) {
            return node == null ? 0 : height(node.left) - height(node.right);
        }

        // In-Order Traversal to print operations
        public void printOperations() {
            System.out.println("Operations sorted by dependency levels:");
            inOrderTraversal(root);
        }

        private void inOrderTraversal(AVLNode node) {
            if (node != null) {
                inOrderTraversal(node.left);
                System.out.println("Dependency Level " + node.dependencyLevel + ": " + node.operations);
                inOrderTraversal(node.right);
            }
        }
    // Method to export operation IDs sorted by dependency levels
    public LinkedList<String> exportOperationIdsByDependency() {
        LinkedList<String> sortedOperationIds = new LinkedList<>();
        exportInOrderTraversal(root, sortedOperationIds);
        return sortedOperationIds;
    }

    // Helper method for in-order traversal to export operation IDs
    private void exportInOrderTraversal(AVLNode node, LinkedList<String> sortedOperationIds) {
        if (node != null) {
            exportInOrderTraversal(node.left, sortedOperationIds); // Traverse left subtree

            // Add operation IDs from the current node if they are operations
            for (TreeNode operation : node.operations) {
                if (operation.getType() == NodeType.OPERATION) { // Check if the TreeNode is an operation
                    sortedOperationIds.add(operation.getId());
                }
            }

            exportInOrderTraversal(node.right, sortedOperationIds); // Traverse right subtree
        }
    }

}
