package esinf.utils;

import esinf.domain.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Utility class to read and parse articles from a CSV file.
 */
public class ArticleFileReader {
    private Map<String, Product> productMap = new HashMap<>();  // To store products by their productID
    private List<ProductionOrder> productionOrders = new ArrayList<>();  // List of ProductionOrders
    private List<Operation> allOperations;

    /**
     * Constructs an ArticleFileReader with a list of operations.
     *
     * @param operations List of all operations.
     */
    public ArticleFileReader(List<Operation> operations) {
        this.allOperations = operations;
    }

    /**
     * Reads and parses the articles from the specified CSV file.
     *
     * @param filePath Path to the CSV file.
     */
    public void readArticles(String filePath) {
        String line;
        String csvDelimiter = ";";

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            // Skip the header
            br.readLine();

            // Read through each line of the file
            while ((line = br.readLine()) != null) {
                // Split the line by the semicolon delimiter
                String[] values = line.split(csvDelimiter);

                // Extract articleID, priority, and operations
                String productID = values[0].trim();  // ArticleID corresponds to ProductID
                String priorityValue = values[1].trim();  // Priority

                // Extract the operations (some may be empty)
                List<String> operationNames = new ArrayList<>();
                List<Operation> operations = new ArrayList<>();
                for (int i = 2; i < values.length; i++) {
                    String operationStr = values[i].trim();
                    if (!operationStr.isEmpty()) {
                        for (Operation operation : allOperations) {
                            if (operation.getOperationID().equals(operationStr)) {
                                operations.add(operation);
                            }
                        }
                    }
                }

                // Create or retrieve the Product
                Product product = productMap.get(productID);
                if (product == null) {
                    // Create a new Product and associated BOO
                    BOO boo = new BOO(null);
                    product = new Product(productID, boo);
                    boo.setProduct(product);
                    productMap.put(productID, product);
                    for (Operation operation : operations) {
                        boo.addOperation(operation);
                    }
                }

                // Create a ProductionOrder for the product
                Priority priority = Priority.valueOf(priorityValue.toUpperCase());  // Convert string to enum
                ProductionOrder productionOrder = new ProductionOrder(product, priority);
                productionOrders.add(productionOrder);
            }

            System.out.println("Articles and operations loaded successfully!");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Prints the products and their associated BOO details.
     */
    public void printProductsAndBOOs() {
        for (Product product : productMap.values()) {
            System.out.println("Product ID: " + product.getProductID());
            System.out.println("BOO: " + product.getBoo().getBOODetails());
        }
    }

    /**
     * Prints the production orders.
     */
    public void printProductionOrders() {
        for (ProductionOrder order : productionOrders) {
            System.out.println("ProductionOrder for Product: " + order.getProduct().getProductID() +
                    ", Priority: " + order.getPriority());
        }
    }

    /**
     * Gets the product map.
     *
     * @return the product map
     */
    public Map<String, Product> getProducts() {
        return productMap;
    }

    /**
     * Gets the list of production orders.
     *
     * @return the list of production orders
     */
    public List<ProductionOrder> getProductionOrders() {
        resetProductionOrders();
        return productionOrders;
    }

    /**
     * Resets the stages of all production orders.
     */
    private void resetProductionOrders() {
        for (ProductionOrder order : productionOrders) {
            order.resetStage();
        }
    }
}