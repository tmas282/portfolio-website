package esinf.domain;

/**
 * Represents statistics for a station, including usage percentages.
 */
public class StationStatistics implements Comparable<StationStatistics> {
    private Station station;
    private double percentageRelativeToTotalTime;
    private double percentageRelativeToOperation;

    /**
     * Constructs a StationStatistics with specified station and usage percentages.
     *
     * @param station                      the station
     * @param percentageRelativeToTotalTime the percentage relative to total time
     * @param percentageRelativeToOperation the percentage relative to operation time
     */
    public StationStatistics(Station station, double percentageRelativeToTotalTime, double percentageRelativeToOperation) {
        this.station = station;
        this.percentageRelativeToTotalTime = percentageRelativeToTotalTime;
        this.percentageRelativeToOperation = percentageRelativeToOperation;
    }

    /**
     * Gets the station.
     *
     * @return the station
     */
    public Station getStation() {
        return station;
    }

    /**
     * Gets the percentage relative to total time.
     *
     * @return the percentage relative to total time
     */
    public double getPercentageRelativeToTotalTime() {
        return percentageRelativeToTotalTime;
    }

    /**
     * Gets the percentage relative to operation time.
     *
     * @return the percentage relative to operation time
     */
    public double getPercentageRelativeToOperation() {
        return percentageRelativeToOperation;
    }

    @Override
    public int compareTo(StationStatistics o) {
        return Double.compare(this.percentageRelativeToTotalTime, o.percentageRelativeToTotalTime);
    }
}