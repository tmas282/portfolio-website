package esinf.domain.sprint2;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class TreeNode {
    private String id; // Unique ID of the product or operation
    private String name; // Name or description
    private NodeType type; // Either PRODUCT or OPERATION
    private BigDecimal quantity; // Quantity associated with the node
    private List<TreeNode> children; // Child nodes
    private TreeNode parent; // Parent node

    public TreeNode(String id, String name, NodeType type, BigDecimal quantity, TreeNode parent) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.quantity = quantity;
        this.children = new ArrayList<>();
        this.parent = parent;
    }

    public void addChild(TreeNode child) {
        children.add(child);
    }

    public List<TreeNode> getChildren() {
        return children;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public NodeType getType() {
        return type;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    public void setQuantity(BigDecimal quantity) {
        this.quantity = quantity;
    }

    public TreeNode getParent() {
        return parent;
    }

    @Override
    public String toString() {
        return name + " (" + type + ", Quantity: " + quantity + ")";
    }
}