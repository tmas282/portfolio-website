package esinf.domain;

public enum Priority {
    LOW(1), NORMAL(2), HIGH(3);

    private final int level;

    Priority(int level) {
        this.level = level;
    }

    public int getLevel() {
        return level;
    }

    public static int compare(Priority p1, Priority p2) {
        return Integer.compare(p1.level, p2.level);
    }
}
