package esinf.domain.sprint3;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Activity {
    private String key; // Identificador único da atividade
    private String description; // Descrição da atividade
    private float duration; // Duração da atividade
    private String durationUnit; // Unidade de tempo da duração (ex.: dias, horas)
    private float cost; // Custo associado à atividade


    // Tempos para cálculo de agendamento
    private float earliestStart; // ES
    private float latestFinish; // LF
    private float earliestFinish; // EF
    private float latestStart; // LS
    private float slack; // Folga da atividade

    public void setEarliestFinish(float earliestFinish) {
        this.earliestFinish = earliestFinish;
    }

    public Activity(String key, String description, float duration, String durationUnit, float cost) {
        this.key = key;
        this.description = description;
        this.duration = duration;
        this.durationUnit = durationUnit;
        this.cost = cost;

        this.earliestStart = 0; // ES inicial como 0
        this.latestFinish = 0; // LF inicial como o maior valor possível
        this.earliestFinish = duration; // EF = ES + Duração
        this.latestStart = latestFinish - duration; // LS = LF - Duração
        this.slack = 0; // Inicializa a folga como 0
    }

    // Getters e Setters
    public String getKey() {
        return key;
    }

    public String getDescription() {
        return description;
    }

    public float getDuration() {
        return duration;
    }

    public String getDurationUnit() {
        return durationUnit;
    }

    public float getCost() {
        return cost;
    }



    public float getEarliestStart() {
        return earliestStart;
    }

    public float getLatestFinish() {
        return latestFinish;
    }

    public float getEarliestFinish() {
        return earliestFinish;
    }

    public float getLatestStart() {
       latestStart=latestFinish-duration;
        return latestStart;
    }

    public float getSlack() {
        return slack;
    }

    public void setDuration(float duration) {
        this.duration = duration;
        this.earliestFinish = earliestStart + duration; // Atualiza EF
        this.latestStart = latestFinish - duration; // Atualiza LS
    }

    public void setEarliestStart(float earliestStart) {
        this.earliestStart = earliestStart;
        this.earliestFinish = earliestStart + duration; // Atualiza EF
    }

    public void setLatestFinish(float latestFinish) {
        this.latestFinish = latestFinish;
        this.latestStart = latestFinish - duration; // Atualiza LS
    }

    public void setSlack(float slack) {
        this.slack = slack;
    }



    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Activity activity = (Activity) o;
        return Objects.equals(key, activity.key) && Objects.equals(description, activity.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(key, description, duration, durationUnit, cost);
    }
    public void setLatestStart(float latestStart) {
        this.latestStart = latestStart;
    }
    @Override
    public String toString() {
        return String.format("%s (Key: %s) \n" +
                "Duration: %.2f %s \n" +
                "Cost: %.2f \n" +
                "Earliest Start: %.2f \n" +
                "Latest Finish: %.2f \n" +
                "Slack: %.2f", description, key, duration, durationUnit, cost, earliestStart, latestFinish, slack);
    }

    public String toNotProcessedFile(boolean showDetails) {
        if(!showDetails){
            return String.format("%s (Key: %s) \\n" +
                    "Duration: %.2f %s \\n" +
                    "Cost: %.2f", description, key, duration, durationUnit, cost);
        }
        return String.format("%s (Key: %s) \\n" +
                "Duration: %.2f %s \\n" +
                "Cost: %.2f \\n" +
                "ES / LS: %.2f / %.2f \\n" +
                "EF / LF %.2f / %.2f \\n" +
                "Slack: %.2f", description, key, duration, durationUnit, cost, earliestStart, latestStart, earliestFinish, latestFinish, slack);
    }

}
