package esinf.domain.sprint3.lapr06;

import bddad.db.DatabaseConnection;
import esinf.domain.sprint3.OperationType;
import esinf.domain.sprint3.Workstation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class WorkstationsByOperationType {

    public static Map<OperationType, List<Workstation>> getWorkstationsByOperationType() throws SQLException {
        Map<OperationType, List<Workstation>> workstationsByOperationType = new LinkedHashMap<>();

        // SQL to fetch data from WorkstationTypeOperation table
        String operationTypeWorkstationQuery = "SELECT OperationTypeId, WorkstationTypeId FROM WorkstationTypeOperation";

        String operationTypeQuery = "SELECT Description FROM OperationType WHERE ID = ?";

        // SQL to fetch workstations by WorkstationTypeId
        String workstationQuery = "SELECT ID, Name, Description FROM Workstation WHERE WorkstationTypeId = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement opStmt = connection.prepareStatement(operationTypeWorkstationQuery);
             ResultSet opRs = opStmt.executeQuery()) {

            // Process each row in WorkstationTypeOperation
            while (opRs.next()) {
                String operationTypeId = opRs.getString("OperationTypeId");
                String workstationTypeId = opRs.getString("WorkstationTypeId");
                OperationType operationType = null;

                try (PreparedStatement opTypeStmt = connection.prepareStatement(operationTypeQuery)) {
                    opTypeStmt.setString(1, operationTypeId);
                    try (ResultSet opTypeRs = opTypeStmt.executeQuery()) {
                        if (opTypeRs.next()) {
                            String description = opTypeRs.getString("Description");
                            operationType = new OperationType(operationTypeId, description);
                        }
                    }
                }

                // Corrected check to use OperationType object
                if (!workstationsByOperationType.containsKey(operationType)) {
                    workstationsByOperationType.put(operationType, new ArrayList<>());
                }

                // Fetch workstations for the current WorkstationTypeId
                try (PreparedStatement wsStmt = connection.prepareStatement(workstationQuery)) {
                    wsStmt.setString(1, workstationTypeId);

                    try (ResultSet wsRs = wsStmt.executeQuery()) {
                        while (wsRs.next()) {
                            String workstationId = wsRs.getString("ID");
                            String name = wsRs.getString("Name");
                            String description = wsRs.getString("Description");

                            // Create Workstation object
                            Workstation workstation = new Workstation(workstationId, name, description);

                            // Add to the list for this OperationType
                            workstationsByOperationType.get(operationType).add(workstation);
                        }
                    }
                }
            }
        }

        return workstationsByOperationType;
    }


    public static void main(String[] args) {
        try {
            Map<OperationType, List<Workstation>> map = WorkstationsByOperationType.getWorkstationsByOperationType();
            map.forEach((operationType, workstations) -> {
                System.out.println("Operation Type: " + operationType);
                workstations.forEach(workstation -> System.out.println(" - " + workstation));
            });
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
