package esinf.utils;

import esinf.dataStructures.OperationStationMap;
import esinf.domain.*;

import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Iterator;

public class Simulator2 {
    private OperationStationMap operationStationMap;
    private List<Station> stations;
    private Map<Operation, Queue<ProductionOrderOperation>> operationQueues;
    private int currentTime;

    public Simulator2(List<Station> stations, OperationStationMap operationStationMap, Map<Operation, Queue<ProductionOrderOperation>> operationQueues) {
        this.stations = stations;
        this.operationStationMap = operationStationMap;
        this.operationQueues = operationQueues;
        this.currentTime = 0;
    }

    @SuppressWarnings("t")
    public void processQueues() {
        while (!allQueuesEmpty() || anyStationBusy()) {
            // Simultaneously assign tasks to all available stations
            for (Operation operation : operationQueues.keySet()) {
                Queue<ProductionOrderOperation> queue = operationQueues.get(operation);
                if (queue != null && !queue.isEmpty()) {
                    // Get the list of OperationStation objects that can perform this operation
                    List<OperationStation> operationStations = operationStationMap.getAssignmentsForOperation(operation);

                    // Iterate through all the ProductionOrderOperations in the queue to find those that can be completed
                    Iterator<ProductionOrderOperation> iterator = queue.iterator();
                    while (iterator.hasNext()) {
                        ProductionOrderOperation nextOperation = iterator.next();
                        if (canStart(nextOperation)) {
                            // Assign the task to an available station
                            for (OperationStation operationStation : operationStations) {
                                Station station = operationStation.getStation();
                                if (station.isAvailable(currentTime)) {
                                    int operationTime = operationStation.getOperationTime();
                                    station.processOperation(nextOperation.getOperation(), operationTime, currentTime);  // Start processing at this station
                                    nextOperation.addStation(station);  // Add the station to the production order operation
                                    nextOperation.setStatus(OrderStatus.IN_PRODUCTION); // Mark the operation as completed
                                    station.setCurrentOperation(nextOperation);
                                    break;  // Move to the next operation after assigning one to the station
                                }
                            }
                        }
                    }
                }
            }
            // Advance the time to the next station that finishes
            advanceTime();
        }
    }

    // Check if a ProductionOrderOperation can start
    private boolean canStart(ProductionOrderOperation productionOrderOperation) {
        ProductionOrder productionOrder = productionOrderOperation.getProductionOrder();
        int phase = productionOrderOperation.getPhaseOfProductBOO();  // Get the current phase of the operation

        // If phase is 0, it can start right away regardless of its status
        if (phase == 0 && productionOrderOperation.getStatus() != OrderStatus.IN_PRODUCTION) {
            return true;
        }

        // Operations with status READY can also be started
        return productionOrderOperation.getStatus() == OrderStatus.READY;
    }

    // Move the simulation time forward to the next time a station becomes available
    @SuppressWarnings("t")
    private void advanceTime() {
        int nextAvailableTime = Integer.MAX_VALUE;

        // Find the next time when any station becomes available
        for (Operation operation : operationQueues.keySet()) {
            List<OperationStation> operationStations = operationStationMap.getAssignmentsForOperation(operation);
            for (OperationStation opStation : operationStations) {
                Station station = opStation.getStation();
                if (station.getBusyUntil() > currentTime && station.getBusyUntil() < nextAvailableTime) {
                    nextAvailableTime = station.getBusyUntil();
                }
            }
        }
        currentTime = nextAvailableTime;  // Move time forward to the next station's availability
        System.out.println("Advancing simulation time to: " + currentTime);

        // After advancing time, check if any stations have finished their operations
        for (Operation operation : operationQueues.keySet()) {
            List<OperationStation> operationStations = operationStationMap.getAssignmentsForOperation(operation);
            for (OperationStation opStation : operationStations) {
                Station station = opStation.getStation();
                if (station.getBusyUntil() <= currentTime) {
                    ProductionOrderOperation currentOperation = station.getCurrentOperation();

                    // If a current operation exists and it is completed, mark the next phase as READY and remove the current one
                    if (currentOperation != null) {
                        completeOperation(currentOperation, station);  // Complete the current operation
                    }
                }
            }
        }
    }

    // Helper to complete the current operation and advance the next phase
    private void completeOperation(ProductionOrderOperation currentOperation, Station station) {
        currentOperation.setStatus(OrderStatus.COMPLETED);  // Mark the current operation as completed

        // Set the next operation in the same ProductionOrder to READY
        advanceNextPhase(currentOperation);

        // Remove the current operation from the queue
        Queue<ProductionOrderOperation> queue = operationQueues.get(currentOperation.getOperation());
        queue.remove(currentOperation);  // Remove the completed operation from the queue

        // Set the current operation of the station to null, as it's now completed
        station.setCurrentOperation(null);
        station.finishOperation();  // Mark the station as ready for new tasks
    }

    // Helper to advance the next phase of the same ProductionOrder
    private void advanceNextPhase(ProductionOrderOperation completedOperation) {
        ProductionOrder productionOrder = completedOperation.getProductionOrder();
        int nextPhase = completedOperation.getPhaseOfProductBOO() + 1;  // Next phase of the same ProductionOrder

        // Find the next operation for the same ProductionOrder and next phase
        for (Operation operation : operationQueues.keySet()) {
            Queue<ProductionOrderOperation> queue = operationQueues.get(operation);
            for (ProductionOrderOperation nextOperation : queue) {
                if (nextOperation.getProductionOrder().equals(productionOrder) && nextOperation.getPhaseOfProductBOO() == nextPhase) {
                    nextOperation.setStatus(OrderStatus.READY);  // Mark the next phase as READY
                    return;  // Exit once the next phase is found
                }
            }
        }
    }

    // Check if any station is still busy
    private boolean anyStationBusy() {
        for (Operation operation : operationQueues.keySet()) {
            List<OperationStation> operationStations = operationStationMap.getAssignmentsForOperation(operation);
            for (OperationStation opStation : operationStations) {
                Station station = opStation.getStation();
                if (station.getBusyUntil() > currentTime) {
                    return true;
                }
            }
        }
        return false;
    }

    // Check if all queues are empty
    private boolean allQueuesEmpty() {
        for (Queue<ProductionOrderOperation> queue : operationQueues.values()) {
            if (!queue.isEmpty()) {
                return false;
            }
        }
        return true;
    }
}
