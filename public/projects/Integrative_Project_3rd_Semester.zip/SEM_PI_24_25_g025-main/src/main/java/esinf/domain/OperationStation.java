package esinf.domain;
/**
 * Represents an association between an operation and a station, including the time required.
 */
public class OperationStation {
    private Station station;  // Reference to the station
    private Operation operation;  // Reference to the operation
    private int operationTime;  // Time required to perform the operation at this station
    /**
     * Constructs an OperationStation association with specified station, operation, and time.
     *
     * @param station       The associated station.
     * @param operation     The associated operation.
     * @param operationTime Time required to perform the operation.
     */
    public OperationStation(Station station, Operation operation, int operationTime) {
        this.station = station;
        this.operation = operation;
        this.operationTime = operationTime;
    }

    /**
     * Retrieves the associated station.
     * @return Associated station.
     */
    public Station getStation() {
        return station;
    }
    /**
     * Sets the associated station.
     * @param station New associated station.
     */
    public void setStation(Station station) {
        this.station = station;
    }
    /**
     * Retrieves the associated operation.
     * @return Associated operation.
     */
    public Operation getOperation() {
        return operation;
    }
    /**
     * Sets the associated operation.
     * @param operation New associated operation.
     */
    public void setOperation(Operation operation) {
        this.operation = operation;
    }

    /**
     * Retrieves the time required to perform the operation.
     * @return Operation time in seconds.
     */
    public int getOperationTime() {
        return operationTime;
    }
    /**
     * Sets the time required to perform the operation.
     * @param operationTime New operation time in seconds.
     */
    public void setOperationTime(int operationTime) {
        this.operationTime = operationTime;
    }
}
