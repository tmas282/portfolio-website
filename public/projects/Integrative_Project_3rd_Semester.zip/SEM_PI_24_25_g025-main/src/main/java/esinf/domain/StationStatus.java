package esinf.domain;

/**
 * Enum representing the status of a station.
 */
public enum StationStatus {
    READY, BUSY, INACTIVE
}