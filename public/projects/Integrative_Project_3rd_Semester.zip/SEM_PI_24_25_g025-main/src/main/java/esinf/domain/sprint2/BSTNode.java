package esinf.domain.sprint2;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class BSTNode {
    public BigDecimal quantity; // Key: Material quantity
    public List<String> materials; // Value: List of materials with this quantity
    public BSTNode left;
    public BSTNode right;

    public BSTNode(BigDecimal quantity, String material) {
        this.quantity = quantity;
        this.materials = new ArrayList<>();
        this.materials.add(material);
    }
}
