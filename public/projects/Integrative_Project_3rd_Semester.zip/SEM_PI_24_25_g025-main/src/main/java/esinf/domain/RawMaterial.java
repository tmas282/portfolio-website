package esinf.domain;

/**
 * Represents a raw material in the production system.
 */
public class RawMaterial {
}