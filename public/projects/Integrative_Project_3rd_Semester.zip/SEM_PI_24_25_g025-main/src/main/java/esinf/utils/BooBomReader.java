package esinf.utils;

import esinf.domain.BOM;
import esinf.domain.BOO;
import esinf.domain.Operation;
import esinf.domain.Product;

import java.io.*;
import java.util.*;

public class BooBomReader {
    public static void readCSVAndParse(String filePath, List<Operation> operations, List<Product> items, List<BOO> booList, List<BOM> bomList) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            br.readLine();
            while ((line = br.readLine()) != null) {
                String[] csvLine = line.split("\\(");
                String operationId = csvLine[0].split(";")[0];
                Operation operation = getOperationById(operationId, operations);
                String itemId = csvLine[0].split(";")[1];
                String itemQtd = csvLine[0].split(";")[2];
                Product product = getProductById(itemId, items);
                product.setQuantity(Integer.parseInt(itemQtd));
                BOO boo = new BOO(product);
                boo.setOperationId(operation);
                String operationsStr = csvLine[1].replace(");", "");
                operationsStr = operationsStr.replaceFirst(";", "");
                LinkedList<Operation> operationList = processOperationsString(operationsStr, operations);
                boo.setOperations(operationList);
                booList.add(boo);
                String materialsStr = csvLine[2].replace(")", "");
                materialsStr = materialsStr.replaceFirst(";", "");
                LinkedList<Product> itemsList = processMaterialsString(materialsStr, items);
                BOM bom = new BOM(operation, product);
                bom.setProducts(itemsList);
                bomList.add(bom);
            }
        }
    }
    private static LinkedList<Operation> processOperationsString(String operationsStr, List<Operation> operations){
        LinkedList<Operation> operationList = new LinkedList<>();
        String[] operationsCsv = operationsStr.split(";");
        for (int i = 0; i < operationsCsv.length; i+=2) {
            String operationId = operationsCsv[i];
            String operationQtd = operationsCsv[i+1];
            Operation op = getOperationById(operationId, operations);
            op.setQuantity(Float.parseFloat(operationQtd.replace(",", ".")));
            operationList.add(op);
        }
        return operationList;
    }

    private static LinkedList<Product> processMaterialsString(String materialsStr, List<Product> items){
        LinkedList<Product> products = new LinkedList<>();
        String[] materialsCsv = materialsStr.split(";");
        for (int i = 0; i < materialsCsv.length; i+=2) {
            String materialId = materialsCsv[i];
            String materialQtd = materialsCsv[i+1];
            Product prod = getProductById(materialId, items);
            prod.setQuantity(Float.parseFloat(materialQtd.replace(",", ".")));
            products.add(prod);
        }
        return products;
    }

    private static Operation getOperationById(String operationsId, List<Operation> operations){
        for (Operation op:
             operations) {
            if(Objects.equals(op.getOperationID(), operationsId)){
                return op;
            }
        }
        return null;
    }

    private static Product getProductById(String itemId, List<Product> items){
        for (Product product:
                items) {
            if (Objects.equals(product.getProductID(), itemId)){
                return product;
            }
        }
        return null;
    }
}