package esinf.utils;

import esinf.domain.sprint2.BOOEntry;

import java.io.*;
import java.util.*;

public class FileReaderUtility {

    // Map to store operation ID -> Description
    public Map<String, String> operationsMap = new HashMap<>();

    // Map to store item ID -> Description
    public Map<String, String> itemsMap = new HashMap<>();

    // List to store parsed BOO entries
    public List<BOOEntry> booEntries = new ArrayList<>();

    // Method to read operations.csv
    public void readOperationsFile(String filePath) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            boolean isFirstLine = true;
            while ((line = br.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue; // Skip the first line (header)
                }
                String[] parts = line.split(";");
                if (parts.length == 2) {
                    operationsMap.put(parts[0].trim(), parts[1].trim());
                }
            }
        }
    }

    // Method to read items.csv
    public void readItemsFile(String filePath) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            boolean isFirstLine = true;
            while ((line = br.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue; // Skip the first line (header)
                }
                String[] parts = line.split(";");
                if (parts.length == 2) {
                    itemsMap.put(parts[0].trim(), parts[1].trim());
                }
            }
        }
    }

    // Method to read and parse boo_v2.csv
    public void readBOOFile(String filePath) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            boolean isFirstLine = true;
            while ((line = br.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue; // Skip the first line (header)
                }
                String[] parts = line.split(";");
                if (parts.length >= 3) {
                    String operationId = parts[0].trim();
                    String resultProductId = parts[1].trim();
                    String quantity = parts[2].trim();

                    Map<String, String> operationsDependencies = new HashMap<>();
                    Map<String, String> productDependencies = new HashMap<>();

                    // Parse dependencies (operations and products)
                    boolean inOperations = false; // Track the current dependency type
                    boolean operationsParsed = false; // Ensure operations section is explicitly checked
                    for (int i = 3; i < parts.length; i++) {
                        String value = parts[i].trim();
                        if (value.equals("(")) {
                            if (!operationsParsed) {
                                inOperations = true; // Start parsing operations
                            } else {
                                inOperations = false; // Start parsing products
                            }
                        } else if (value.equals(")")) {
                            if (inOperations) {
                                operationsParsed = true; // Mark operations as parsed
                            }
                            inOperations = false; // Exit current dependency section
                        } else if (!value.isEmpty()) {
                            String id = value; // This is the ID (operation or product)
                            if (i + 1 < parts.length) {
                                String amount = parts[++i].trim(); // Next field is the quantity
                                if (inOperations) {
                                    operationsDependencies.put(id, amount);
                                } else {
                                    productDependencies.put(id, amount);
                                }
                            }
                        }
                    }

                    BOOEntry entry = new BOOEntry(operationId, resultProductId, quantity, operationsDependencies, productDependencies);
                    booEntries.add(entry);
                }
            }
        }
    }



    // Method to resolve operation dependencies and add to product dependencies
    public void resolveOperationDependenciesToProducts(List<BOOEntry> booEntries) {
        // Map operation ID to its result product ID for quick lookup
        Map<String, String> operationToProductMap = new HashMap<>();
        for (BOOEntry entry : booEntries) {
            operationToProductMap.put(entry.operationId, entry.resultProductId);
        }

        // Update each BOOEntry directly
        for (BOOEntry entry : booEntries) {
            for (Map.Entry<String, String> operationDependency : entry.operationsDependencies.entrySet()) {
                String operationId = operationDependency.getKey();
                String quantity = operationDependency.getValue();

                // Resolve the operation ID to its product ID
                String productId = operationToProductMap.get(operationId);
                if (productId != null) {
                    // Add the resolved product dependency directly to the BOOEntry
                    entry.productDependencies.put(productId, quantity);
                }
            }
        }
    }




    // Method to display parsed data
    public void displayParsedData() {
        System.out.println("Operations Map:");
        operationsMap.forEach((id, desc) -> System.out.println(id + " -> " + desc));

        System.out.println("\nItems Map:");
        itemsMap.forEach((id, desc) -> System.out.println(id + " -> " + desc));

        System.out.println("\nBOO Entries:");
        for (BOOEntry entry : booEntries) {
            System.out.println(entry);
        }
    }

    public static void main(String[] args) {
        FileReaderUtility reader = new FileReaderUtility();

        try {
            // Replace with your file paths
            reader.readOperationsFile("./files/operations.csv");
            reader.readItemsFile("./files/items.csv");
            reader.readBOOFile("./files/boo_v2.csv");

            // Display original parsed data
            System.out.println("Before resolving operation dependencies:");
            reader.displayParsedData();

            // Resolve operation dependencies to products
            reader.resolveOperationDependenciesToProducts(reader.booEntries);

            // Display updated data
            System.out.println("\nAfter resolving operation dependencies to products:");
            reader.displayParsedData();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
