package esinf.domain.sprint2;

import java.util.LinkedList;

public class BOOExtractor {

    private AVLTree avlTree;

    public BOOExtractor() {
        this.avlTree = new AVLTree();
    }

    /**
     * Extracts operations into an AVL tree based on reverse dependency levels.
     * The root (most dependent) starts with the highest dependency level.
     *
     * @param root the root of the production tree
     */
    public void extractBOO(TreeNode root) {
        int maxDepth = findMaxDepth(root); // Calculate the maximum depth of operations
        extractBOO(root, maxDepth);       // Start with the root at maxDepth
    }

    private void extractBOO(TreeNode node, int dependencyLevel) {
        if (node == null) return;

        // Add the operation to the AVL Tree with its calculated dependency level
        if (node.getType() == NodeType.OPERATION) {
            avlTree.add(dependencyLevel, node);
        }

        // Traverse children, decrementing the dependency level for operations
        for (TreeNode child : node.getChildren()) {
            if (child.getType() == NodeType.OPERATION) {
                extractBOO(child, dependencyLevel - 1);
            } else {
                extractBOO(child, dependencyLevel); // Products don't affect levels
            }
        }
    }

    /**
     * Finds the maximum depth of the production tree, considering only operations.
     * @param node the root node
     * @return the maximum depth
     */
    private int findMaxDepth(TreeNode node) {
        if (node == null) return 0;

        int maxDepth = 0;
        for (TreeNode child : node.getChildren()) {
            maxDepth = Math.max(maxDepth, findMaxDepth(child));
        }

        // Include the current node's level only if it's an operation
        return node.getType() == NodeType.OPERATION ? maxDepth + 1 : maxDepth;
    }

    public void printOperations() {
        avlTree.printOperations();
    }

    public LinkedList<String> getOperationsByDependencyLevel() {
        return avlTree.exportOperationIdsByDependency();
    }
}
