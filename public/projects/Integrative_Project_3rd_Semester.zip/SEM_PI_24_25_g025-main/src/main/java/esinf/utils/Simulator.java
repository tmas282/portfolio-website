                        package esinf.utils;

                        import esinf.dataStructures.OperationStationMap;
                        import esinf.domain.*;

                        import java.util.*;
                        import java.util.Queue;

                        public class Simulator {
                            private OperationStationMap operationStationMap;
                            private List<Station> stations;
                            private Map<Operation, Queue<ProductionOrderOperation>> operationQueues;
                            private int currentTime;
                            private Map<Product, Queue<Station>> stationsQueue = new HashMap<>();

                            // To store the flow dependency between workstations
                            private Map<Product, List<Station>> flowDependencies = new HashMap<>();

                            public Simulator(List<Station> stations, OperationStationMap operationStationMap, Map<Operation, Queue<ProductionOrderOperation>> operationQueues) {
                                this.stations = stations;
                                this.operationStationMap = operationStationMap;
                                this.operationQueues = operationQueues;
                                this.currentTime = 0;
                            }

                            @SuppressWarnings("t")
                            public void processQueues() {
                                while (!allQueuesEmpty() || anyStationBusy()) {
                                    // Simultaneously assign tasks to all available stations
                                    for (Operation operation : operationQueues.keySet()) {
                                        Queue<ProductionOrderOperation> queue = operationQueues.get(operation);
                                        if (queue != null && !queue.isEmpty()) {
                                            // Get the list of OperationStation objects that can perform this operation
                                            List<OperationStation> operationStations = operationStationMap.getAssignmentsForOperation(operation);

                    // Iterate through all the ProductionOrderOperations in the queue to find those that can be completed
                    Iterator<ProductionOrderOperation> iterator = queue.iterator();
                    while (iterator.hasNext()) {
                        ProductionOrderOperation nextOperation = iterator.next();
                        if (canStart(nextOperation)) {
                            // Find the best available station for this operation
                            OperationStation bestOperationStation = findBestAvailableOperationStation(operationStations);
                            if (bestOperationStation != null) {
                                Station station = bestOperationStation.getStation();
                                int operationTime = bestOperationStation.getOperationTime();
                                station.processOperation(nextOperation.getOperation(), operationTime, currentTime);  // Start processing at this station
                                trackFlowDependency(nextOperation.getProductionOrder().getProduct(), station);  // Track the flow between stations
                                nextOperation.addStation(station);  // Add the station to the production order operation
                                nextOperation.setStatus(OrderStatus.IN_PRODUCTION); // Mark the operation as completed
                                station.setCurrentOperation(nextOperation);
                                iterator.remove();  // Move to the next operation after assigning one to the station
                            }
                        }
                    }
                }
            }
            // Advance the time to the next station that finishes
            advanceTime();
        }
    }


    //TODO: Implement the trackFlowDependency method
    // Method to track flow dependency between stations



    // Check if a ProductionOrderOperation can start
    private boolean canStart(ProductionOrderOperation productionOrderOperation) {
        ProductionOrder productionOrder = productionOrderOperation.getProductionOrder();
        int phase = productionOrderOperation.getPhaseOfProductBOO();

        if (phase == 0 && productionOrderOperation.getStatus() != OrderStatus.IN_PRODUCTION) {
            return true;
        }

        return productionOrderOperation.getStatus() == OrderStatus.READY;
    }

    // Find the best available OperationStation for a given operation based on the fastest processing time
    private OperationStation findBestAvailableOperationStation(List<OperationStation> operationStations) {
        OperationStation bestOperationStation = null;
        int bestProcessingTime = Integer.MAX_VALUE;

        for (OperationStation opStation : operationStations) {
            Station station = opStation.getStation();
            if (station.isAvailable(currentTime)) {
                int operationTime = opStation.getOperationTime();
                if (bestOperationStation == null || operationTime < bestOperationStation.getOperationTime()) {
                    bestOperationStation = opStation;
                }
            }
        }
        return bestOperationStation;
    }

    // Move the simulation time forward to the next time a station becomes available
    @SuppressWarnings("t")
    private void advanceTime() {
        int nextAvailableTime = Integer.MAX_VALUE;

        for (Operation operation : operationQueues.keySet()) {
            List<OperationStation> operationStations = operationStationMap.getAssignmentsForOperation(operation);
            for (OperationStation opStation : operationStations) {
                Station station = opStation.getStation();
                if (station.getBusyUntil() > currentTime && station.getBusyUntil() < nextAvailableTime) {
                    nextAvailableTime = station.getBusyUntil();
                }
            }
        }
        currentTime = nextAvailableTime;
        System.out.println("Advancing simulation time to: " + currentTime);

        for (Operation operation : operationQueues.keySet()) {
            List<OperationStation> operationStations = operationStationMap.getAssignmentsForOperation(operation);
            for (OperationStation opStation : operationStations) {
                Station station = opStation.getStation();
                if (station.getBusyUntil() <= currentTime) {
                    ProductionOrderOperation currentOperation = station.getCurrentOperation();
                    if (currentOperation != null) {
                        completeOperation(currentOperation, station);
                    }
                }
            }
        }
    }

    private void completeOperation(ProductionOrderOperation currentOperation, Station station) {
        currentOperation.setStatus(OrderStatus.COMPLETED);
        advanceNextPhase(currentOperation);

        Queue<ProductionOrderOperation> queue = operationQueues.get(currentOperation.getOperation());
        queue.remove(currentOperation);

        station.setCurrentOperation(null);
        station.finishOperation();
    }

    private void advanceNextPhase(ProductionOrderOperation completedOperation) {
        ProductionOrder productionOrder = completedOperation.getProductionOrder();
        int nextPhase = completedOperation.getPhaseOfProductBOO() + 1;

        for (Operation operation : operationQueues.keySet()) {
            Queue<ProductionOrderOperation> queue = operationQueues.get(operation);
            for (ProductionOrderOperation nextOperation : queue) {
                if (nextOperation.getProductionOrder().equals(productionOrder) && nextOperation.getPhaseOfProductBOO() == nextPhase) {
                    nextOperation.setStatus(OrderStatus.READY);
                    return;
                }
            }
        }
    }

    private boolean anyStationBusy() {
        for (Operation operation : operationQueues.keySet()) {
            List<OperationStation> operationStations = operationStationMap.getAssignmentsForOperation(operation);
            for (OperationStation opStation : operationStations) {
                Station station = opStation.getStation();
                if (station.getBusyUntil() > currentTime) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean allQueuesEmpty() {
        for (Queue<ProductionOrderOperation> queue : operationQueues.values()) {
            if (!queue.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    public int getCurrentTime() {
        return currentTime;
    }

    public int getTotalTimeByOperation(Operation operationToCheck) {
        int totalTime = 0;
        for (Operation operation : operationStationMap.getOperations()) {
            if (operation.equals(operationToCheck)) {
                for (OperationStation operationStation : operationStationMap.getAssignmentsForOperation(operation)) {
                    totalTime += operationStation.getStation().getUsageTime();
                }
            }
        }
        return totalTime;
    }

    public Map<Operation, Integer> getTotalTimeByOperation() {
        Map<Operation, Integer> totalTimeByOperation = new HashMap<>();
        for (Operation operation : operationStationMap.getOperations()) {
            totalTimeByOperation.put(operation, getTotalTimeByOperation(operation));
        }
        return totalTimeByOperation;
    }

    public Map<Operation, Double> getAverageTimeByOperation(){
        Map<Operation, Double> averageTimeByOperation = new HashMap<>();
        for (Operation operation : operationStationMap.getOperations()) {
            int totalTime = 0;
            int count = 0;
            for (OperationStation operationStation : operationStationMap.getAssignmentsForOperation(operation)) {
                totalTime += operationStation.getStation().getUsageTime();
                count++;
            }
            averageTimeByOperation.put(operation, (double) Math.round((double) totalTime / count));
        }
        return averageTimeByOperation;
    }

    public List<StationStatistics> createStationStatistics() {
        List<StationStatistics> stationStatistics = new ArrayList<>();
        for (Station station : stations) {
            int totalTime = getCurrentTime();
            int getTotalTime = getTotalTimeByOperation(operationStationMap.getOperationOfStation(station));
            double prtt = ((double) station.getUsageTime() / getCurrentTime()) * 100;
            double prtop = ((double) station.getUsageTime() / getTotalTimeByOperation(operationStationMap.getOperationOfStation(station))) * 100;

            stationStatistics.add(new StationStatistics(station, prtt, prtop));
        }

        return stationStatistics;
    }

 // Método para rastrear a dependência de fluxo entre as estações
private void trackFlowDependency(Product product, Station newStation) {
 product.addStation(newStation);
 flowDependencies.putIfAbsent(product, product.getStationsPassed());
}
 public Map<Product, List<Station>> getFlowDependencies(){
     return flowDependencies;
 }
}
