package esinf.domain;

import esinf.domain.sprint3.OperationType;

import java.util.Objects;
/**
 * Represents an operation with details including ID, name, description, and duration.
 */
public class Operation {
    private Priority priority;
    private String operationID;  // ID of the operation
    private String description;  // Description of the operation
    private int duration;   // Duration of the operation in seconds
    private float quantity; //Quantity of the operation
    private String nextOperationID; //ID of the next operation
    private String operationTypeID; //Type of the operation

    /**
     * Constructs an Operation with the specified name.
     *
     * @param operationName Name of the operation.
     */
    public Operation(String operationName) {
        this.operationID = operationID;
        this.description = description;
        this.duration = duration;
    }
    /**
     * Constructs an Operation with the specified id and name.
     *
     * @param operationName Name of the operation.
     * @param operationID Id of the operation.
     */
    public Operation(String operationID, String operationName) {
        this.operationID = operationID;
    }
    public Operation(String operationID, String description, int duration) {
        this.operationID = operationID;
        this.description = description;
        this.duration = duration;
    }
    public Operation(String operationId,String description,int estimatedTime,String nextOperationId,String operationTypeId) {
        this.operationID = operationId;
        this.description = description;
        this.duration = estimatedTime;
        this.nextOperationID = nextOperationId;
        this.operationTypeID = operationTypeId;
        this.priority = Priority.NORMAL;
        this.quantity = 1;
    }
    public Operation(String operationID, String description, int duration, float quantity) {
        this.operationID = operationID;
        this.description = description;
        this.duration = duration;
        this.quantity = quantity;
    }
    public Operation(String operationId, String description, int estimatedTime, String nextOperationId, String operationTypeId, String priority, int quantity) {
        this.operationID = operationId;
        this.description = description;
        this.duration = estimatedTime;
        this.nextOperationID = nextOperationId;
        this.operationTypeID = operationTypeId;
        this.priority = Priority.valueOf(priority);
        this.quantity = (float) quantity;
    }

    public String getOperationTypeID() {
        return operationTypeID;
    }

    public void setOperationTypeID(String operationTypeID) {
        this.operationTypeID = operationTypeID;
    }

    public String getNextOperationID() {
        return nextOperationID;
    }

    public void setNextOperationID(String nextOperationID) {
        this.nextOperationID = nextOperationID;
    }

    public Priority getPriority() {
        return priority;
    }

    public void setPriority(Priority priority) {
        this.priority = priority;
    }

    public float getQuantity() {
        return quantity;
    }

    public void setQuantity(float quantity) {
        this.quantity = quantity;
    }
    /**
     * Retrieves the operation ID.
            * @return Operation ID.
            */
    public String getOperationID() {
        return operationID;
    }
    /**
     * Sets the operation ID.
     * @param operationID New operation ID.
     */
    public void setOperationID(String operationID) {
        this.operationID = operationID;
    }
    /**
     * Retrieves the description of the operation.
     * @return Operation description.
     */
    public String getDescription() {
        return description;
    }
    /**
     * Sets the description of the operation.
     * @param description New operation description.
     */
    public void setDescription(String description) {
        this.description = description;
    }
    /**
     * Retrieves the duration of the operation.
     * @return Operation duration in seconds.
     */
    public int getDuration() {
        return duration;
    }
    /**
     * Sets the duration of the operation.
     * @param duration New duration in seconds.
     */
    public void setDuration(int duration) {
        this.duration = duration;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Operation)) return false;
        Operation operation = (Operation) o;
        return operationID.equals(operation.operationID);
    }

    @Override
    public String toString() {
        return "Operation{" +
                "operationID='" + operationID + '\'' +
                ", description='" + description + '\'' +
                ", duration=" + duration +
                '}';
    }

    @Override
    public int hashCode() {
        return Objects.hash(operationID);
    }
}