package esinf.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Node<T> {
    private Node<T> parent;
    private T data;
    private List<Node<T>> children;

    public Node(Node<T> parent, T data) {
        this.parent = parent;
        this.data = data;
        this.children = new ArrayList<>();
    }

    public T getData() {
        return data;
    }

    public Node<T> getParent() {
        return parent;
    }

    public List<Node<T>> getChildren() {
        return children;
    }

    public void addChild(Node<T> child) {
        children.add(child);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Node<?> node = (Node<?>) o;
        return Objects.equals(parent, node.parent) && Objects.equals(data, node.data);
    }

    @Override
    public int hashCode() {
        return Objects.hash(parent, data);
    }
}
