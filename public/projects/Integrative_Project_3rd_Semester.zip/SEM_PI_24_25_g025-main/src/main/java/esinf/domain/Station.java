package esinf.domain;

import java.util.Objects;

/**
 * Represents a station in the production system.
 */
public class Station {
    private String stationID;  // ID of the station (e.g., ws11)
    private StationStatus stationStatus;  // Status of the station (e.g., READY, BUSY, INACTIVE)
    private int usageTime;
    private int busyUntil;
    private ProductionOrderOperation currentOperation;

    /**
     * Constructs a Station with the specified ID.
     *
     * @param stationID the ID of the station
     */
    public Station(String stationID) {
        this.stationID = stationID;
        this.stationStatus = StationStatus.READY;
        this.usageTime = 0;
        this.busyUntil = 0;
    }

    // Getters and Setters

    /**
     * Gets the station ID.
     *
     * @return the station ID
     */
    public String getStationID() {
        return stationID;
    }

    /**
     * Sets the station ID.
     *
     * @param stationID the station ID
     */
    public void setStationID(String stationID) {
        this.stationID = stationID;
    }

    /**
     * Gets the status of the station.
     *
     * @return the station status
     */
    public StationStatus getStatus() {
        return stationStatus;
    }

    /**
     * Sets the status of the station.
     *
     * @param stationStatus the station status
     */
    public void setStatus(StationStatus stationStatus) {
        this.stationStatus = stationStatus;
    }

    /**
     * Gets the current operation being processed by the station.
     *
     * @return the current operation
     */
    public ProductionOrderOperation getCurrentOperation() {
        return currentOperation;
    }

    /**
     * Sets the current operation being processed by the station.
     *
     * @param currentOperation the current operation
     */
    public void setCurrentOperation(ProductionOrderOperation currentOperation) {
        this.currentOperation = currentOperation;
    }

    /**
     * Gets the usage time of the station.
     *
     * @return the usage time
     */
    public int getUsageTime() {
        return usageTime;
    }

    /**
     * Adds usage time to the station.
     *
     * @param time the time to add
     */
    public void addUsageTime(int time) {
        if(this.usageTime + time < 0) throw new ArithmeticException("usageTime can't be negative");
        this.usageTime += time;
    }

    /**
     * Processes an operation at the station.
     *
     * @param operation   the operation to process
     * @param duration    the duration of the operation
     * @param currentTime the current time
     */
    public void processOperation(Operation operation, int duration, int currentTime) {
        this.stationStatus = StationStatus.BUSY;
        this.busyUntil = currentTime + duration;
        System.out.println("Station " + this.stationID + " is processing operation for " + duration + " seconds.");
        addUsageTime(duration);
        System.out.println("Station " + this.stationID + " processing for " + duration + " seconds. Busy until: " + this.busyUntil);
    }

    /**
     * Checks if the station is available.
     *
     * @param currentTime the current time
     * @return true if the station is available, false otherwise
     */
    public boolean isAvailable(int currentTime) {
        return currentTime >= this.busyUntil;
    }

    /**
     * Finishes the current operation at the station.
     */
    public void finishOperation() {
        this.stationStatus = StationStatus.READY;
        System.out.println("Station " + stationID + " has completed its operation and is now available.");
        if (currentOperation != null) {
            currentOperation.setStatus(OrderStatus.COMPLETED);
            currentOperation = null;
        }
    }

    /**
     * Gets the time until the station is busy.
     *
     * @return the busy until time
     */
    public int getBusyUntil() {
        return busyUntil;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Station station = (Station) o;
        return stationID.equals(station.getStationID());
    }

    @Override
    public int hashCode() {
        return Objects.hash(stationID, stationStatus);
    }

    @Override
    public String toString() {
        return stationID;
    }

    /**
     * Gets the status of the station.
     *
     * @return the station status
     */
    public StationStatus getStationStatus() {
        return stationStatus;
    }

    /**
     * Resets the station to its initial state.
     */
    public void reset() {
        this.stationStatus = StationStatus.READY;
        this.usageTime = 0;
        this.busyUntil = 0;
    }
}