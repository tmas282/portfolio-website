package esinf.domain.trees;

import java.security.Key;
import java.util.HashMap;
import java.util.Map;

public class SearchProductionTree {

    //Atributtes
    private Map<Key, ProductionNode> searchMap;

    //Constructor
    /**
     * Full constructor
     */
    public SearchProductionTree(){
        this.searchMap = new HashMap<>();
    }

    //Getter
    /**
     * Getter for search map
     * @return searchMap
     */
    public Map<Key, ProductionNode> getSearchMap(){return this.searchMap;}


    /**
     * Method to add operations or materials to search map
     */
    public void addProductionNode(Key key, ProductionNode node){
        if(!searchMap.containsKey(key)){
            searchMap.put(key, node);
        } else {
            System.out.println("Node with the given key already exists!");
        }
    }

    /**
     * Gets the details of a node based on its key
     * @param key the key of the node
     * @return a string with the details of the node
     */
    public String getNodeDetails(Key key) {
        //Vou buscar o node através da chave
        ProductionNode node = searchMap.get(key);

        //Se for nulo retorno que não existe
        if (node == null) {
            return "Node not found.";
        }

        //Vou buscar o tipo do node
        ProductionNodeType nodeType = node.getType();

        //Crio uma String Builder para retornar uma String com todas as informações caso sejam precisos noutro contexto
        StringBuilder details = new StringBuilder();

        details.append("Node Type: ").append(node.getType());
        //Verifico se o node type é um componente, se for coloco a quantidade do material usado
        if (ProductionNodeType.COMPONENT.equals(nodeType)) {
            ComponentNode componentNode = (ComponentNode) node;
            details.append(", Quantity: ").append(componentNode.getQuantity());
        }
        if (node.getParent() != null) {
            details.append(", Parent: ").append(node.getParent().getType());
        }

        return details.toString();
    }

    /**
     * Searches for a node by its name
     * @param name the name of the node
     * @return the ProductionNode if found
     */
    public ProductionNode searchNodeByName(String name) {
        for (ProductionNode node : searchMap.values()) {
            if (node.getName().equals(name)) {
                return node;
            }
        }
        return null; // Retorna null se não encontrar
    }

    /**
     * Searches for a node by its ID
     * @param id the ID of the node
     * @return the ProductionNode if found
     */
    public ProductionNode searchNodeById(String id) {
        for (ProductionNode node : searchMap.values()) {
            if (node.getId().equals(id)) {
                return node;
            }
        }
        return null; // Retorna null se não encontrar
    }

    /**
     * Checks if a node exists in the search map
     * @param key the key of the node
     * @return true if the node exists, false otherwise
     */
    public boolean containsNode(Key key){return searchMap.containsKey(key);}

    /**
     * Retrieves the key associated with a node by its name.
     *
     * @param name the name of the node
     * @return the Key associated with the node, or null if not found
     */
    public Key getKeyByName(String name) {
        for (Map.Entry<Key, ProductionNode> entry : searchMap.entrySet()) {
            ProductionNode node = entry.getValue();
            if (name != null && name.equals(node.getName())) {
                return entry.getKey();
            }
        }
        return null; // Retorna null se nenhum nó com o nome for encontrado
    }

    /**
     * Retrieves the key associated with a node by its ID.
     *
     * @param id the ID of the node
     * @return the Key associated with the node, or null if not found
     */
    public Key getKeyById(String id) {
        for (Map.Entry<Key, ProductionNode> entry : searchMap.entrySet()) {
            ProductionNode node = entry.getValue();
            if (id != null && id.equals(node.getId())) {
                return entry.getKey();
            }
        }
        return null; // Retorna null se nenhum nó com o ID for encontrado
        }
}