package esinf.domain.sprint2;

import java.math.BigDecimal;

public class ProductionTreeUpdater {

    public static void updateMaterialQuantity(TreeNode root, String materialId, BigDecimal newQuantity) {
        if (root == null) return;

        // Traverse the tree to find the node with the specified material
        if (root.getType() == NodeType.PRODUCT && root.getId().equals(materialId)) {
            BigDecimal originalQuantity = root.getQuantity();
            root.setQuantity(newQuantity);
            // Handle cascading updates based on proportional scaling
            BigDecimal scalingFactor = newQuantity.divide(originalQuantity, BigDecimal.ROUND_HALF_UP);
            updateDependentNodes(root, scalingFactor);
        }

        // Recursively traverse children
        for (TreeNode child : root.getChildren()) {
            updateMaterialQuantity(child, materialId, newQuantity);
        }
    }

    private static void updateDependentNodes(TreeNode node, BigDecimal scalingFactor) {
        for (TreeNode child : node.getChildren()) {
            BigDecimal updatedQuantity = child.getQuantity().multiply(scalingFactor);
            child.setQuantity(updatedQuantity);
            // Recursively update dependent nodes
            updateDependentNodes(child, scalingFactor);
        }
    }
}