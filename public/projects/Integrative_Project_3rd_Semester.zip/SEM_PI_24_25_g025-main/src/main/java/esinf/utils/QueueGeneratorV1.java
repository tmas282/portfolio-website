package esinf.utils;

import esinf.domain.Operation;
import esinf.domain.ProductionOrder;
import esinf.domain.ProductionOrderOperation;
import esinf.domain.BOO;
import esinf.domain.Product;

import java.util.*;

/**
 * Utility class to generate queues of ProductionOrderOperation instances.
 */
public class QueueGeneratorV1 {
    /**
     * Generates a map of operations to queues of ProductionOrderOperation instances.
     *
     * @param orders List of production orders.
     * @return Map of operations to queues of ProductionOrderOperation instances.
     */
    public Map<Operation, Queue<ProductionOrderOperation>> generate(List<ProductionOrder> orders) {
        Map<Operation, Queue<ProductionOrderOperation>> operationsMap = new HashMap<>();

        for (ProductionOrder order : orders) {
            Product product = order.getProduct();
            BOO boo = product.getBoo();
            List<Operation> operations = boo.getOperations();

            for (Operation operation : operations) {
                // Initialize queue if not present
                operationsMap.putIfAbsent(operation, new LinkedList<>());

                // Create ProductOrderOperation and add to the queue
                ProductionOrderOperation productOp = new ProductionOrderOperation(order.getPriority(), operation, order, order.getStage());
                operationsMap.get(operation).add(productOp);

                // Advance the stage in the order
                order.passStage();

                // Check if order is completed
                if (order.isCompleted()) {
                    break;
                }
            }
        }

        return operationsMap;
    }
}