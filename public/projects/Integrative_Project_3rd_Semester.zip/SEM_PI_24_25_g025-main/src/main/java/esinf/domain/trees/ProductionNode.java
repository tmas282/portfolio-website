package esinf.domain.trees;

import esinf.domain.trees.ProductionNodeType;

import java.util.List;

public interface ProductionNode {
    Integer getId();
    String getName();
    ProductionNode getParent();
    void setParent(ProductionNode parent);
    ProductionNodeType getType();
    List<ProductionNode> getChildren();
    void addChild(ProductionNode child);
    double getQuantity();
}