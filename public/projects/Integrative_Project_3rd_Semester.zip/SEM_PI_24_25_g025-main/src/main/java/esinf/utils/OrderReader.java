package esinf.utils;

import esinf.domain.Priority;
import esinf.domain.sprint3.lapr06.Order;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class OrderReader {
    public List<Order> readOrders(String filePath) throws IOException {
        List<Order> orders = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            // Skip the header line
            br.readLine();
            while ((line = br.readLine()) != null) {
                String[] values = line.split(";");
                int orderId = Integer.parseInt(values[0]);
                int itemId = Integer.parseInt(values[1]);
                Priority priority = Priority.valueOf(values[2]);
                int quantity = Integer.parseInt(values[3]);
                orders.add(new Order(orderId, itemId, priority, quantity));
            }
        }
        return orders;
    }
}