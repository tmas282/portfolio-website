package esinf.domain.sprint2;

public class QualityCheck implements Comparable<QualityCheck> {
    private String id;
    private String name;
    private int priority;
    private int stage;

    public QualityCheck(String id, String name, int priority, int stage) {
        this.id = id;
        this.name = name;
        this.priority = priority;
        this.stage = stage;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getPriority() {
        return priority;
    }

    public int getStage() {
        return stage;
    }

    @Override
    public int compareTo(QualityCheck other) {
        return Integer.compare(other.priority, this.priority); // Higher priority first
    }

    @Override
    public String toString() {
        return "QualityCheck{id='" + id + "', name='" + name + "', priority=" + priority + ", stage=" + stage + "}";
    }
}