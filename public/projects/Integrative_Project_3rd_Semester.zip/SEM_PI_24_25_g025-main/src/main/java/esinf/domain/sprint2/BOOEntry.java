package esinf.domain.sprint2;

import java.util.Map;

public class BOOEntry {
    public String operationId;
    public String resultProductId;
    public String quantity;
    public Map<String, String> operationsDependencies; // Operation ID -> Amount
    public Map<String, String> productDependencies;    // Product ID -> Amount

    public BOOEntry(String operationId, String resultProductId, String quantity,
                    Map<String, String> operationsDependencies, Map<String, String> productDependencies) {
        this.operationId = operationId;
        this.resultProductId = resultProductId;
        this.quantity = quantity;
        this.operationsDependencies = operationsDependencies;
        this.productDependencies = productDependencies;
    }

    private String formatDependencies(Map<String, String> dependencies) {
        StringBuilder formatted = new StringBuilder("[");
        for (Map.Entry<String, String> entry : dependencies.entrySet()) {
            formatted.append(entry.getKey()).append(": ").append(entry.getValue()).append(", ");
        }
        if (!dependencies.isEmpty()) {
            formatted.setLength(formatted.length() - 2); // Remove trailing ", "
        }
        formatted.append("]");
        return formatted.toString();
    }

    @Override
    public String toString() {
        return "Operation: " + operationId +
                ", Result Product: " + resultProductId +
                ", Quantity: " + quantity +
                ", Operations Dependencies: " + formatDependencies(operationsDependencies) +
                ", Product Dependencies: " + formatDependencies(productDependencies);
    }
}

