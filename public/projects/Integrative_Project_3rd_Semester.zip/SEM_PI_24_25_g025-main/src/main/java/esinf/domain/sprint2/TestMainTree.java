package esinf.domain.sprint2;

import esinf.utils.FileReaderUtility;

import java.math.BigDecimal;

public class TestMainTree {
    public static void main(String[] args) {
        try {
            // Initialize the reader to load data from the files
            FileReaderUtility reader = new FileReaderUtility();

            // Replace these file paths with your actual file paths
            String operationsFilePath = "./files/operations.csv";
            String itemsFilePath = "./files/items.csv";
            String booFilePath = "./files/boo_v2.csv";

            // Read the data
            reader.readOperationsFile(operationsFilePath);
            reader.readItemsFile(itemsFilePath);
            reader.readBOOFile(booFilePath);

            // Resolve operation dependencies into product dependencies
            reader.resolveOperationDependenciesToProducts(reader.booEntries);

            // Initialize the production tree builder
            TreeProductionBuilder builder = new TreeProductionBuilder(reader.itemsMap, reader.operationsMap);

            // Build the production tree using a root product ID
            String rootProductId = "1006"; // Replace with your desired root product ID
            TreeNode root = builder.buildTree(rootProductId, reader.booEntries);

            // Print the production tree structure
            System.out.println("Production Tree:");
            builder.printTree(root, "");

            // Calculate and display the total quantities and times
            ProductionTreeCalculator.calculateTotals(root);

            // Identify and prioritize critical path operations
            CriticalPathCalculator.identifyAndPrioritizeCriticalPath(root);

            // Update material quantity
            String materialId = "1014"; // Replace with the material ID you want to update
            BigDecimal newQuantity = new BigDecimal("1000000.0"); // Replace with the new quantity
            ProductionTreeUpdater.updateMaterialQuantity(root, materialId, newQuantity);

            // Print the updated production tree structure
            System.out.println("Updated Production Tree:");
            builder.printTree(root, "");

            // Initialize the QualityCheckManager
            QualityCheckManager qualityCheckManager = new QualityCheckManager();

            // Create and add quality checks
            qualityCheckManager.addQualityCheck(new QualityCheck("QC1", "Check Final Product", 10, 5));
            qualityCheckManager.addQualityCheck(new QualityCheck("QC2", "Check Raw Materials", 5, 1));
            qualityCheckManager.addQualityCheck(new QualityCheck("QC3", "Check Assembly", 8, 3));
            qualityCheckManager.addQualityCheck(new QualityCheck("QC4", "Check Packaging", 9, 4));

            // Print quality checks in order of priority
            System.out.println("------------------------USEI11-------------------------\n");
            System.out.println("Quality Checks in Order of Priority:");
            qualityCheckManager.printQualityChecks();

            // Perform quality checks one at a time
            System.out.println("\nPerforming Quality Checks:");
            while (qualityCheckManager.viewNextQualityCheck() != null) {
                System.out.println("Performing: " + qualityCheckManager.performNextQualityCheck());
            }

            // Initialize the SearchUtility
            SearchUtility searchUtility = new SearchUtility(builder);

            // Search for a node by ID
            String searchId = "1007"; // Replace with the ID you want to search
            System.out.println("\nSearch Result by ID:");
            System.out.println(searchUtility.searchNodeById(searchId));

            // Search for a node by name
            String searchName = "varnish"; // Replace with the name you want to search
            System.out.println("\nSearch Result by Name:");
            System.out.println(searchUtility.searchNodeByName(searchName));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}