package esinf.utils;

import esinf.domain.sprint3.lapr06.Order;
import esinf.domain.sprint3.lapr06.WorkstationOperationTime;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class ExportSimulatorResults {
    public void exportResults(String filePath, List<Order> orders, List<WorkstationOperationTime> operationTimes) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write("Order ID, Item ID, Priority, Quantity, Workstation ID, Operation ID, Operation Time\n");
            for (Order order : orders) {
                for (WorkstationOperationTime operationTime : operationTimes) {
                    writer.write(order.getOrderId() + ", " + order.getItemId() + ", " + order.getPriority() + ", " + order.getQuantity() + ", " +
                            operationTime.getWorkstationId() + ", " + operationTime.getOperationId() + ", " + operationTime.getOperationTime() + "\n");
                }
            }
        }
    }
}