package esinf.domain.sprint2;

import java.util.ArrayList;
import java.util.List;

public class AVLNode {
    public int dependencyLevel; // Key: Dependency level
    public List<TreeNode> operations; // Value: List of operations at this level
    AVLNode left, right;
    int height;

    public AVLNode(int dependencyLevel, TreeNode operation) {
        this.dependencyLevel = dependencyLevel;
        this.operations = new ArrayList<>();
        this.operations.add(operation);
        this.height = 1;
    }
}
