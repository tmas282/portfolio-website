package esinf.domain.sprint3;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;

public class ProjectExporter {

    public static void exportScheduleToCSV(PertCpmGraph graph, String filePath) throws IOException {
        try (FileWriter writer = new FileWriter(filePath)) {
            // Write the header
            writer.write("act_id,cost,duration,es,ls,ef,lf,prev_act_id1,...,prev_act_idN\n");

            // Write each activity's details
            for (Activity activity : graph.vertices()) {
                StringBuilder line = new StringBuilder();
                line.append(activity.getKey()).append(",");
                line.append(activity.getCost()).append(",");
                line.append(activity.getDuration()).append(",");
                line.append(activity.getEarliestStart()).append(",");
                line.append(activity.getLatestStart()).append(",");
                line.append(activity.getEarliestFinish()).append(",");
                line.append(activity.getLatestFinish());

                // Get predecessor activities
                Collection<Edge<Activity, Integer>> incomingEdges = graph.incomingEdges(activity);
                for (Edge<Activity, Integer> edge : incomingEdges) {
                    line.append(",").append(edge.getVOrig().getKey());
                }

                writer.write(line.toString());
                writer.write("\n");
            }
        }
    }
}