package esinf.utils;

import esinf.domain.sprint3.Activity;
import esinf.domain.sprint3.PertCpmGraph;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class GraphFileReader {
    private static void addVertex(PertCpmGraph graph, Scanner scanner){
        if(scanner.hasNextLine())
            scanner.nextLine();
        while (scanner.hasNextLine()){
            String line = scanner.nextLine();
            String[] col = line.split(",");
            Activity activity = new Activity(col[0], col[1], Float.parseFloat(col[2].replace(" ", "")), col[3], Float.parseFloat(col[4].replace(" ", "")));
            graph.addVertex(activity);
        }
    }
    private static void addEdges(PertCpmGraph graph, Scanner scanner){
        if(scanner.hasNextLine())
            scanner.nextLine();
        while (scanner.hasNextLine()){
            String line = scanner.nextLine();
            String[] col = line.split(",");
            Activity destiny = graph.vertex(col[0]);
            for (int i = 5; i < col.length; i++) {
                Activity origin = graph.vertex(col[i].replace("\"", ""));
                graph.addEdge(origin, destiny, 1);
            }
        }
    }
    public static void buildGraphFromFile(PertCpmGraph graph, File csv) throws FileNotFoundException {
        addVertex(graph, new Scanner(csv));
        addEdges(graph, new Scanner(csv));
    }
}
