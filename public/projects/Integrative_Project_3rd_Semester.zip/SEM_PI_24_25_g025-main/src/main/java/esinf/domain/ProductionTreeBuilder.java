package esinf.domain;

import esinf.repository.TreeRepository;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class ProductionTreeBuilder {
    public static void buildTrees(List<BOO> booList, List<BOM> bomList){
        buildOperationsTree(booList);
        buildMaterialsTree(bomList);
    }

    private static void buildMaterialsTree(List<BOM> bomList) {
        for (BOM bom : bomList) {
            Product product = bom.getProduct();
            List<Node<BOO>> operationNodes = TreeRepository.getRepository().getOperationsTree().get(product);
            if (operationNodes != null) {
                for (Node<BOO> node : operationNodes) {
                    if (node.getData().getOperationId().equals(bom.getOperationId())) {
                        for (Product material : bom.getProducts()) {
                            Node<BOO> materialNode = new Node<>(node, new BOO(material));
                            node.addChild(materialNode);
                        }
                    }
                }
            }
        }
    }

    private static void buildOperationsTree(List<BOO> booList) {
        for (BOO boo : booList) {
            Map<BOO, BOO> mapToNode = new HashMap<>(buildOperationTreeByBOO(boo, booList));
            mapToNode.replace(boo, null);
            List<Node<BOO>> nodesBOO = buildTreeOfNodes(mapToNode);
            TreeRepository.getRepository().addToOperationsTree(boo.getProduct(), nodesBOO);
        }
    }

    private static List<Node<BOO>> buildTreeOfNodes(Map<BOO, BOO> map) {
        List<Node<BOO>> nodes = new ArrayList<>();
        while (nodes.size() != map.size()) {
            for (var entry : map.entrySet()) {
                if (entry.getValue() == null) {
                    Node<BOO> node = new Node<>(null, entry.getKey());
                    if (!nodes.contains(node))
                        nodes.add(node);
                } else {
                    for (Node<BOO> node1 : nodes) {
                        if (node1.getData() == entry.getValue()) {
                            Node<BOO> node = new Node<>(node1, entry.getKey());
                            if (!nodes.contains(node)) {
                                nodes.add(node);
                            }
                            break;
                        }
                    }
                }
            }
        }
        return nodes;
    }

    private static Map<BOO, BOO> buildOperationTreeByBOO(BOO boo, List<BOO> booList) {
        Map<BOO, BOO> valueAndParent = new ConcurrentHashMap<>();
        List<BOO> flags = new ArrayList<>();
        valueAndParent.putIfAbsent(boo, new BOO());
        while (valueAndParent.size() != flags.size()) {
            for (Map.Entry<BOO, BOO> entry : valueAndParent.entrySet()) {
                BOO parent = entry.getKey();
                if (!flags.contains(parent)) {
                    flags.add(parent);
                    List<BOO> children = getChildren(parent, booList);
                    for (BOO child : children) {
                        valueAndParent.putIfAbsent(child, parent);
                    }
                }
            }
        }
        return valueAndParent;
    }

    private static BOO getBOOByOp(Operation op, List<BOO> booList) {
        for (BOO boo : booList) {
            if (boo.getOperationId().equals(op)) {
                return boo;
            }
        }
        return null;
    }

    private static List<BOO> getChildren(BOO boo, List<BOO> booList) {
        List<BOO> boos = new ArrayList<>();
        for (Operation op : boo.getOperations()) {
            boos.add(getBOOByOp(op, booList));
        }
        return boos;
    }
}