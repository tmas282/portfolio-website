package esinf.domain;

import java.util.List;
/**
 * Represents a customer in the system, containing information such as ID, name, NIF,
 * contact information, customer type, and a list of customer orders.
 */

public class Costumer {
    private String costumerID;  // ID of the customer
    private String name;  // Name of the customer
    private String nif;  // NIF of the customer
    private String contactInfo;  // Contact information of the customer
    private String costumerType;  // Type of the customer
    private List<CostumerOrder> orders;  // List of customer orders

    /**
     * Constructor to initialize the customer with specific data.
     *
     * @param costumerID   ID of the customer
     * @param name         Name of the customer
     * @param nif          NIF of the customer
     * @param contactInfo  Contact information of the customer
     * @param costumerType Type of the customer
     * @param orders       List of the customer's orders
     */
    public Costumer(String costumerID, String name, String nif, String contactInfo, String costumerType, List<CostumerOrder> orders) {
        this.costumerID = costumerID;
        this.name = name;
        this.nif = nif;
        this.contactInfo = contactInfo;
        this.costumerType = costumerType;
        this.orders = orders;
    }

    /**
     * Retrieves the customer order ID.
     * @return Customer order ID.
     */
    public String getCostumerID() {
        return costumerID;
    }
    /**
     * Sets the customer order ID.
     * @param costumerID New customer order ID.
     */
    public void setCostumerID(String costumerID) {
        this.costumerID = costumerID;
    }
    /**
     * Retrieves the customer's name.
     * @return Customer name.
     */
    public String getName() {
        return name;
    }
    /**
     * Sets the customer's name.
     * @param name New customer name.
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * Retrieves the customer's NIF.
     * @return Customer NIF.
     */
    public String getNif() {
        return nif;
    }
    /**
     * Sets the customer's NIF.
     * @param nif New customer NIF.
     */
    public void setNif(String nif) {
        this.nif = nif;
    }
    /**
     * Retrieves the customer's contact information.
     * @return Contact information.
     */
    public String getContactInfo() {
        return contactInfo;
    }
    /**
     * Sets the customer's contact information.
     * @param contactInfo New contact information.
     */
    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }
    /**
     * Retrieves the type of the customer.
     * @return Customer type.
     */
    public String getCostumerType() {
        return costumerType;
    }

    /**
     * Sets the type of the customer.
     * @param costumerType New customer type.
     */
    public void setCostumerType(String costumerType) {
        this.costumerType = costumerType;
    }
    /**
     * Retrieves the list of customer orders.
     * @return List of customer orders.
     */
    public List<CostumerOrder> getOrders() {
        return orders;
    }
    /**
     * Sets the list of customer orders.
     * @param orders New list of customer orders.
     */
    public void setOrders(List<CostumerOrder> orders) {
        this.orders = orders;
    }
}