package esinf.domain.sprint3.lapr06;

import bddad.db.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class WorkstationOperationTimeDAO {
    public List<WorkstationOperationTime> getOperationTimes() throws SQLException {
        List<WorkstationOperationTime> operationTimes = new ArrayList<>();
        String query = "SELECT workstation_id, operation_id, operation_time FROM workstation_operation_times";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                String workstationId = resultSet.getString("workstation_id");
                String operationId = resultSet.getString("operation_id");
                int operationTime = resultSet.getInt("operation_time");
                operationTimes.add(new WorkstationOperationTime(workstationId, operationId, operationTime));
            }
        }
        return operationTimes;
    }
}