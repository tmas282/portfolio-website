package esinf.domain.sprint2;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductionTreeCalculator {

    public static void calculateTotals(TreeNode root) {
        Map<String, BigDecimal> totalQuantities = new HashMap<>();
        Map<String, BigDecimal> totalTimes = new HashMap<>();

        traverseTree(root, totalQuantities, totalTimes);

        displayTotals(totalQuantities, totalTimes);
    }

    private static void traverseTree(TreeNode node, Map<String, BigDecimal> totalQuantities, Map<String, BigDecimal> totalTimes) {
        if (node.getType() == NodeType.PRODUCT) {
            totalQuantities.put(node.getId(), totalQuantities.getOrDefault(node.getId(), BigDecimal.ZERO).add(node.getQuantity()));
        } else if (node.getType() == NodeType.OPERATION) {
            totalTimes.put(node.getId(), totalTimes.getOrDefault(node.getId(), BigDecimal.ZERO).add(node.getQuantity()));
        }

        for (TreeNode child : node.getChildren()) {
            traverseTree(child, totalQuantities, totalTimes);
        }
    }

    private static void displayTotals(Map<String, BigDecimal> totalQuantities, Map<String, BigDecimal> totalTimes) {
        System.out.println("Total Quantities per Material:");
        for (Map.Entry<String, BigDecimal> entry : totalQuantities.entrySet()) {
            System.out.println("Material: " + entry.getKey() + ", Quantity: " + entry.getValue());
        }

        System.out.println("Total Times per Operation:");
        for (Map.Entry<String, BigDecimal> entry : totalTimes.entrySet()) {
            System.out.println("Operation: " + entry.getKey() + ", Time: " + entry.getValue());
        }
    }
}