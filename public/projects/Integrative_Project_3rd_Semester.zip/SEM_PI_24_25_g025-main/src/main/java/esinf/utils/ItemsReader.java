package esinf.utils;

import esinf.domain.Product;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ItemsReader {
    public static List<Product> readCSV(String filePath) throws IOException {
        List<Product> data = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                data.add(new Product(line.split(";")[0], line.split(";")[1]));
            }
        }
        data.remove(0);
        return data;
    }
}