package esinf.domain.sprint2;

import java.util.PriorityQueue;

public class QualityCheckManager {
    private PriorityQueue<QualityCheck> qualityCheckQueue;

    public QualityCheckManager() {
        this.qualityCheckQueue = new PriorityQueue<>();
    }

    public void addQualityCheck(QualityCheck qualityCheck) {
        qualityCheckQueue.add(qualityCheck);
    }

    public QualityCheck viewNextQualityCheck() {
        return qualityCheckQueue.peek();
    }

    public QualityCheck performNextQualityCheck() {
        return qualityCheckQueue.poll();
    }

    public void printQualityChecks() {
        PriorityQueue<QualityCheck> tempQueue = new PriorityQueue<>(qualityCheckQueue);
        while (!tempQueue.isEmpty()) {
            System.out.println(tempQueue.poll());
        }
    }
}