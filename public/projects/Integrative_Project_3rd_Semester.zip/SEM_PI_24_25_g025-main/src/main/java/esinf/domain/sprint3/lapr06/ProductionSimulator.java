package esinf.domain.sprint3.lapr06;

import java.util.List;

public class ProductionSimulator {
    private List<WorkstationOperationTime> operationTimes;

    public ProductionSimulator(List<WorkstationOperationTime> operationTimes) {
        this.operationTimes = operationTimes;
    }

    public void simulateProduction(List<Order> orders) {
        for (Order order : orders) {
            System.out.println("Simulating production for Order ID: " + order.getOrderId());
            // Implement the logic to simulate production using operationTimes and order details
        }
    }
}