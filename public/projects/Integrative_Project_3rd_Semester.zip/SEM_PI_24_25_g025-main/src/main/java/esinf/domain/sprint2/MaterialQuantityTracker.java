package esinf.domain.sprint2;
import java.math.BigDecimal;

public class MaterialQuantityTracker {
    private BSTNode root; // Root of the BST

    // Add material to the BST
    public void addMaterial(BigDecimal quantity, String material) {
        root = addMaterial(root, quantity, material);
    }

    private BSTNode addMaterial(BSTNode node, BigDecimal quantity, String material) {
        if (node == null) {
            return new BSTNode(quantity, material);
        }
        int cmp = quantity.compareTo(node.quantity);
        if (cmp < 0) {
            node.left = addMaterial(node.left, quantity, material);
        } else if (cmp > 0) {
            node.right = addMaterial(node.right, quantity, material);
        } else {
            node.materials.add(material); // Same quantity, add material to the list
        }
        return node;
    }

    // Traverse the BST in ascending order
    public void printMaterialsInAscendingOrder() {
        System.out.println("Materials in Ascending Order of Quantity:");
        inOrderTraversal(root);
    }

    private void inOrderTraversal(BSTNode node) {
        if (node != null) {
            inOrderTraversal(node.left);
            System.out.println(node.quantity + ": " + node.materials);
            inOrderTraversal(node.right);
        }
    }

    // Traverse the BST in descending order
    public void printMaterialsInDescendingOrder() {
        System.out.println("Materials in Descending Order of Quantity:");
        reverseInOrderTraversal(root);
    }

    private void reverseInOrderTraversal(BSTNode node) {
        if (node != null) {
            reverseInOrderTraversal(node.right);
            System.out.println(node.quantity + ": " + node.materials);
            reverseInOrderTraversal(node.left);
        }
    }

    // Build the BST from the production tree
    public void buildFromProductionTree(TreeNode root) {
        if (root == null) return;

        // If the node is a material, add it to the BST
        if (root.getType() == NodeType.PRODUCT) {
            addMaterial(root.getQuantity(), root.getName());
        }

        // Recursively traverse children
        for (TreeNode child : root.getChildren()) {
            buildFromProductionTree(child);
        }
    }
}
