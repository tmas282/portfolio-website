package esinf.domain.sprint3;

import java.util.*;
import java.util.function.Predicate;

public class PertCpmGraph extends CommonGraph<Activity, Integer> {
    private static final boolean IS_DIRECTED = true;
    private Collection<Edge<Activity, Integer>> edges;

    public PertCpmGraph() {
        super(IS_DIRECTED);
        this.edges = new ArrayList<>();
    }

    @Override
    public ArrayList<Activity> vertices() {
        return vertices;
    }

    @Override
    public Collection<Edge<Activity, Integer>> edges() {
        return edges;
    }

    @Override
    public boolean addVertex(Activity vert) {
        if (key(vert) != -1) { // Vertex already exists
            return false;
        }
        vertices.add(vert);
        numVerts++;
        return true;
    }

    @Override
    public boolean addEdge(Activity vOrig, Activity vDest, Integer weight) {
        if (!vertices.contains(vOrig) || !vertices.contains(vDest)) {
            return false; // Both vertices must exist in the graph
        }
        Edge<Activity, Integer> edge = new Edge<>(vOrig, vDest, weight);
        edges.add(edge);
        numEdges++;
        return true;
    }

    public Activity vertex(String activityKey) {
        for (Activity vertex : vertices) {
            if (vertex.getKey().equals(activityKey)) {
                return vertex;
            }
        }
        return null; // Vertex not found
    }

    @Override
    public boolean removeEdge(Activity vOrig, Activity vDest) {
        Edge<Activity, Integer> edgeToRemove = null;
        for (Edge<Activity, Integer> edge : edges) {
            if (edge.getVOrig().equals(vOrig) && edge.getVDest().equals(vDest)) {
                edgeToRemove = edge;
                break;
            }
        }
        if (edgeToRemove != null) {
            edges.remove(edgeToRemove);
            numEdges--;
            return true;
        }
        return false;
    }

    @Override
    public boolean removeVertex(Activity vert) {
        if (vertices.remove(vert)) {
            // Remove all edges connected to this vertex
            edges.removeIf(edge -> edge.getVOrig().equals(vert) || edge.getVDest().equals(vert));
            numVerts--;
            return true;
        }
        return false;
    }

    @Override
    public Edge<Activity, Integer> edge(int vOrigKey, int vDestKey) {
        Activity vOrig = vertex(vOrigKey);
        Activity vDest = vertex(vDestKey);
        if (vOrig == null || vDest == null) return null;
        return edge(vOrig, vDest);
    }

    @Override
    public Edge<Activity, Integer> edge(Activity vOrig, Activity vDest) {
        for (Edge<Activity, Integer> edge : edges) {
            if (edge.getVOrig().equals(vOrig) && edge.getVDest().equals(vDest)) {
                return edge;
            }
        }
        return null;
    }

    @Override
    public Collection<Activity> adjVertices(Activity vert) {
        Collection<Activity> adjacents = new ArrayList<>();
        for (Edge<Activity, Integer> edge : edges) {
            if (edge.getVOrig().equals(vert)) {
                adjacents.add(edge.getVDest());
            }
        }
        return adjacents;
    }

    @Override
    public Collection<Edge<Activity, Integer>> incomingEdges(Activity vert) {
        Collection<Edge<Activity, Integer>> incomingEdges = new ArrayList<>();
        for (Edge<Activity, Integer> edge : edges) {
            if (edge.getVDest().equals(vert)) {
                incomingEdges.add(edge);
            }
        }
        return incomingEdges;
    }

    @Override
    public int inDegree(Activity vert) {
        return incomingEdges(vert).size();
    }

    @Override
    public Collection<Edge<Activity, Integer>> outgoingEdges(Activity vert) {
        Collection<Edge<Activity, Integer>> outgoingEdges = new ArrayList<>();
        for (Edge<Activity, Integer> edge : edges) {
            if (edge.getVOrig().equals(vert)) {
                outgoingEdges.add(edge);
            }
        }
        return outgoingEdges;
    }

    @Override
    public int outDegree(Activity vert) {
        return outgoingEdges(vert).size();
    }

    @Override
    public String toString() {
        return "Graph:\n" +
                "\t vertices: " + vertices +
                "\n\t edges: " + edges;
    }


    @Override
    public Graph<Activity, Integer> clone() {
        PertCpmGraph clonedGraph = new PertCpmGraph();

        for (Activity vertex : this.vertices) {
            clonedGraph.addVertex(new Activity(vertex.getKey(), vertex.getDescription(),
                    vertex.getDuration(), vertex.getDurationUnit(), vertex.getCost()));
        }

        for (Edge<Activity, Integer> edge : this.edges) {
            Activity vOrig = clonedGraph.vertex(edge.getVOrig().getKey());
            Activity vDest = clonedGraph.vertex(edge.getVDest().getKey());
            clonedGraph.addEdge(vOrig, vDest, edge.getWeight());
        }

        return clonedGraph;
    }
    public static <V, E> List<V> topologicalSort(Graph<V, E> graph) {
        List<V> sortedList = new ArrayList<>();
        Queue<V> queue = new LinkedList<>();
        Map<V, Integer> inDegree = new HashMap<>();

        for (V vertex : graph.vertices()) {
            inDegree.put(vertex, graph.inDegree(vertex));
            if (inDegree.get(vertex) == 0) {
                queue.add(vertex);
            }
        }

        while (!queue.isEmpty()) {
            V vertex = queue.poll();
            sortedList.add(vertex);

            for (V adj : graph.adjVertices(vertex)) {
                int degree = inDegree.get(adj) - 1;
                inDegree.put(adj, degree);
                if (degree == 0) {
                    queue.add(adj);
                }
            }
        }

        if (sortedList.size() != graph.numVertices()) {
            return null;
        }

        return sortedList;
    }

    /*«    @Override
    public Graph<Activity, Integer> clone() {
        PertCpmGraph clone = new PertCpmGraph();
        for (Activity vertex : vertices) {
            clone.addVertex(vertex);
        }
        for (Edge<Activity, Integer> edge : edges) {
            clone.addEdge(edge.getVOrig(), edge.getVDest(), edge.getWeight());
        }
        return clone;
     */
}
