package esinf.domain.trees;

import org.w3c.dom.Node;

public class ProductionTree {
    private ProductionNode root;

    public ProductionTree(ProductionNode root) {
        this.root = root;
    }



    private String createNodeId(ProductionNode node) {
        return node.getName() + "_" + node.getId();
    }


    public void printTree() {
        printNode(root, 0);
    }

    private void printNode(ProductionNode node, int level) {
        if (node != null) {
            for (int i = 0; i < level; i++) {
                System.out.print("  ");
            }
            System.out.println(node.getName());
            for (ProductionNode child : node.getChildren()) {
                printNode(child, level + 1);
            }
        }
    }
}