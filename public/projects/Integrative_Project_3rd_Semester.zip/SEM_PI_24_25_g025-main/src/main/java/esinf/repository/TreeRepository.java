package esinf.repository;

import esinf.domain.BOO;
import esinf.domain.Node;
import esinf.domain.Product;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TreeRepository {
    private static TreeRepository repository;
    private Map<Product, List<Node<BOO>>> operationsTree;
    public static TreeRepository getRepository() {
        if(repository == null){
            repository = new TreeRepository();
        }
        return repository;
    }

    public TreeRepository() {
        operationsTree = new HashMap<>();
    }
    public void addToOperationsTree(Product root, List<Node<BOO>> tree){
        operationsTree.putIfAbsent(root, tree);
    }

    public Map<Product, List<Node<BOO>>> getOperationsTree() {
        return operationsTree;
    }
}
