package esinf.dataStructures;

import esinf.domain.Operation;
import esinf.domain.OperationStation;
import esinf.domain.Station;
import esinf.domain.StationStatistics;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 * Represents a mapping between operations and the stations where they can be performed,
 * including the time each operation takes on each station.
 */
public class OperationStationMap {
    private Map<Operation, List<OperationStation>> operationStationMap;
    /**
     * Default constructor to initialize an empty operation-to-station map.
     */
    public OperationStationMap() {
        this.operationStationMap = new HashMap<>();
    }
    /**
     * Adds an assignment of an operation to a station with a specified time.
     *
     * @param operation     Operation to be assigned
     * @param station       Station where the operation will be performed
     * @param operationTime Time required for the operation at the specified station
     */
    public void addAssignment(Operation operation, Station station, int operationTime) {
        OperationStation assignment = new OperationStation(station, operation, operationTime);

        List<OperationStation> assignments = operationStationMap.getOrDefault(operation, new ArrayList<>());
        assignments.add(assignment);

        operationStationMap.put(operation, assignments);
    }
    /**
     * Retrieves all station assignments for a specified operation.
     *
     * @param operation Operation to retrieve assignments for
     * @return List of assignments for the specified operation
     */

    public List<OperationStation> getAssignmentsForOperation(Operation operation) {
        return operationStationMap.getOrDefault(operation, new ArrayList<>());
    }
    /**
     * Prints all operation-station assignments in the map.
     */
    public void printAllAssignments() {
        for (Map.Entry<Operation, List<OperationStation>> entry : operationStationMap.entrySet()) {
            System.out.println("Operation: " + entry.getKey().getOperationID());
            for (OperationStation assignment : entry.getValue()) {
                System.out.println("\tStation ID: " + assignment.getStation().getStationID() + ", Time: " + assignment.getOperationTime() + " seconds");
            }

        }
    }

    /**
     * Retrieves all unique operations in the map.
     *
     * @return List of operations in the map
     */
    public List<Operation> getOperations() {
        return new ArrayList<>(operationStationMap.keySet());
    }
    /**
     * Finds the operation assigned to a specific station, if any.
     *
     * @param station Station to find the operation for
     * @return Operation assigned to the station, or null if none found
     */
    public Operation getOperationOfStation(Station station) {
        for (Map.Entry<Operation, List<OperationStation>> entry : operationStationMap.entrySet()) {
            for (OperationStation assignment : entry.getValue()) {
                if (assignment.getStation().equals(station)) {
                    return entry.getKey();
                }
            }
        }
        return null;
    }
}
