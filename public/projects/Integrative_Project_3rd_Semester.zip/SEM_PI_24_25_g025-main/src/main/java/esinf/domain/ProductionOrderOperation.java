package esinf.domain;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents an operation within a production order.
 */
public class ProductionOrderOperation {
    private Priority priority;
    private Operation operation;
    private ProductionOrder productionOrder;
    private Station station;
    private int phaseOfProductBOO;
    private OrderStatus orderStatus;
    private List<Station> stationsPassed;

    /**
     * Constructs a ProductionOrderOperation with specified priority, operation, production order, and phase.
     *
     * @param priority        The priority of the operation.
     * @param operation       The operation to be performed.
     * @param productionOrder The associated production order.
     * @param phase           The phase of the product BOO.
     */
    public ProductionOrderOperation(Priority priority, Operation operation, ProductionOrder productionOrder, int phase) {
        this.priority = priority;
        this.operation = operation;
        this.productionOrder = productionOrder;
        this.stationsPassed = new ArrayList<>();
        this.orderStatus = OrderStatus.WAITING;
        this.phaseOfProductBOO = phase;
    }

    /**
     * Gets the priority.
     *
     * @return the priority
     */
    public Priority getPriority() {
        return priority;
    }

    /**
     * Gets the operation.
     *
     * @return the operation
     */
    public Operation getOperation() {
        return operation;
    }

    /**
     * Gets the production order.
     *
     * @return the production order
     */
    public ProductionOrder getProductionOrder() {
        return productionOrder;
    }

    /**
     * Gets the phase of the product BOO.
     *
     * @return the phase of the product BOO
     */
    public int getPhaseOfProductBOO() {
        return phaseOfProductBOO;
    }

    /**
     * Gets the status of the order.
     *
     * @return the order status
     */
    public OrderStatus getStatus() {
        return orderStatus;
    }

    /**
     * Sets the status of the order.
     *
     * @param orderStatus the order status
     */
    public void setStatus(OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
    }

    /**
     * Adds a station to the list of stations passed.
     *
     * @param station the station to add
     */
    public void addStation(Station station) {
        this.station = station;
        stationsPassed.add(station);
    }

    /**
     * Gets the list of stations passed.
     *
     * @return the list of stations passed
     */
    public List<Station> getStationsPassed() {
        return stationsPassed;
    }
    public void setStationsPassed(List<Station> stationsPassed){
        this.stationsPassed = stationsPassed;
    }
}