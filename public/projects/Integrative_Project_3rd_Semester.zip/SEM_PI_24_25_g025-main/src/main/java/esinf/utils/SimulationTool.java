package esinf.utils;

import esinf.dataStructures.OperationStationMap;
import esinf.domain.OperationStation;
import esinf.domain.ProductionOrder;
import esinf.domain.ProductionOrderOperation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SimulationTool {
    /*

    private OperationStationMap operationStationMap;
    private List<ProductionOrder> productionOrders;

    public SimulationTool(OperationStationMap operationStationMap, List<ProductionOrder> productionOrders) {
        this.productionOrders = new ArrayList<>(productionOrders);  // Ensure mutable copy of the list
        this.operationStationMap = operationStationMap;
    }

    @SuppressWarnings("t")
    public void simulateAssignments() {
        while (!productionOrders.isEmpty()) {
            // Use an iterator to allow safe removal of elements while iterating
            Iterator<ProductionOrder> iterator = productionOrders.iterator();
            while (iterator.hasNext()) {
                ProductionOrder productionOrder = iterator.next();
                List<OperationStation> operationStations = operationStationMap.getAssignmentsForOperation(
                        productionOrder.getProduct().getBillOfOperations().getOperationAt(productionOrder.getStage()).getOperationName()
                );
                OperationStation operationStationAssigned = null;

                for (OperationStation operationStation : operationStations) {
                    if (operationStationAssigned == null) {
                        operationStationAssigned = operationStation;
                    }
                    int totalETA = operationStation.getStation().getQueue().getQueueTotalTime() + operationStation.getOperationTime();
                    if (operationStationAssigned.getStation().getQueue().getQueueTotalTime() > totalETA) {
                        operationStationAssigned = operationStation;
                    }
                }

                ProductionOrderOperation productionOrderOperation = new ProductionOrderOperation(
                        operationStationAssigned.getOperationTime(),
                        productionOrder.getPriority(),
                        operationStationAssigned.getOperation(),
                        productionOrder,
                        operationStationAssigned.getStation().getQueue()
                );

                operationStationAssigned.getStation().getQueue().add(productionOrderOperation);
                productionOrderOperation.getProductionOrder().passStage();


                // Remove the production order from the list if it is completed
                if (productionOrderOperation.getProductionOrder().isCompleted()) {
                    iterator.remove();  // Safe removal using iterator
                }
            }
        }
    }
    */
}
