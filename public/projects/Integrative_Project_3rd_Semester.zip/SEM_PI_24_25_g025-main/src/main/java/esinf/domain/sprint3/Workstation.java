package esinf.domain.sprint3;

import esinf.domain.Operation;

public class Workstation {
    private String id;
    private String name;
    private String description;
    private String status;
    private int usageTime;
    private int busyUntil;
    private int idleTime;

    public Workstation(String id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.status = "READY";
        this.usageTime = 0;
        this.busyUntil = 0;
        this.idleTime = 0;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getUsageTime() {
        return usageTime;
    }

    public void setUsageTime(int usageTime) {
        this.usageTime = usageTime;
    }

    public int getBusyUntil() {
        return busyUntil;
    }

    public void setBusyUntil(int busyUntil) {
        this.busyUntil = busyUntil;
    }

    public int getIdleTime() {
        return idleTime;
    }

    public void setIdleTime(int idleTime) {
        this.idleTime = idleTime;
    }

    public void incrementUsageTime(int time) {
        if (this.usageTime + time < 0) throw new ArithmeticException("Usage time can't be negative");
        this.usageTime += time;
    }

    public void incrementIdleTime(int time) {
        if (this.idleTime + time < 0) throw new ArithmeticException("Idle time can't be negative");
        this.idleTime += time;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isAvailable(int currentTime) {
        return currentTime >= busyUntil;
    }

    public void processOperation(Operation operation, int duration, int currentTime) {
        this.status = "BUSY";
        this.busyUntil = currentTime + duration;
        System.out.println("Station " + this.id + " is processing operation " + operation.getOperationID() + " for " + duration + " seconds.");
        incrementUsageTime(duration);
        System.out.println("Station " + this.id + " processing " + operation.getOperationID()
                + " for " + duration + " seconds. Busy until: " + this.busyUntil);
    }

    public void finishOperation() {
        this.status = "READY";
        System.out.println("Station " + this.id + " finished operation.");
    }

    @Override
    public String toString() {
        return "Workstation{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Workstation)) return false;

        Workstation that = (Workstation) o;

        if (!id.equals(that.id)) return false;
        if (!name.equals(that.name)) return false;
        return description.equals(that.description);
    }

    @Override
    public int hashCode() {
        int result = id.hashCode();
        result = 31 * result + name.hashCode();
        result = 31 * result + description.hashCode();
        return result;
    }
}
