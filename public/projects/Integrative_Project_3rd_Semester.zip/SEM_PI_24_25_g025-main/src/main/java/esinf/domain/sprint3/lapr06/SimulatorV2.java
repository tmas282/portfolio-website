package esinf.domain.sprint3.lapr06;

import controllers.TreeProductionController;
import esinf.domain.Operation;
import esinf.domain.sprint2.TreeNode;
import esinf.domain.sprint3.OperationType;
import esinf.domain.sprint3.QueueGeneratorV3;
import esinf.domain.sprint3.Workstation;
import esinf.utils.FileExtractor;
import org.apache.poi.sl.draw.geom.GuideIf;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

public class SimulatorV2 {
    private Map<OperationType, List<Workstation>> workstationsByOperationType; // Map of workstations by operation type
    private Map<OperationType, Queue<Operation>> operationsQueueByType; // Map of queues of operations by operation type
    private LinkedList<String> operationsByDependencyLevel; // List of operations sorted by dependency level
    private int currentTime;

    public SimulatorV2(Map<OperationType, Queue<Operation>> operationsQueueByType) throws SQLException, IOException {
        this.workstationsByOperationType = WorkstationsByOperationType.getWorkstationsByOperationType();
        this.operationsQueueByType = operationsQueueByType;
        this.currentTime = 0;
    }

    public void runSimulation() {
        while (!allQueuesEmpty() || anyWorkstationBusy()) {
            processQueues();
            advanceTime();
        }
    }

    private void processQueues() {
        while (!allQueuesEmpty() || anyWorkstationBusy()) {
            // Assign tasks to workstations
            for (Map.Entry<OperationType, Queue<Operation>> entry : operationsQueueByType.entrySet()) {
                OperationType operationType = entry.getKey();
                Queue<Operation> queue = entry.getValue();

                if (!queue.isEmpty()) {
                    List<Workstation> workstations = workstationsByOperationType.get(operationType);

                    // Iterate through the queue
                    Iterator<Operation> iterator = queue.iterator();
                    while (iterator.hasNext()) {
                        Operation operation = iterator.next();
                        Workstation bestWorkstation = findBestAvailableWorkstation(workstations);

                        if (bestWorkstation != null) {
                            bestWorkstation.processOperation(operation, operation.getDuration(), currentTime);
                            iterator.remove(); // Remove from queue after assignment
                        }
                    }
                }
            }

            // Advance the simulation time
            advanceTime();

            // If the simulation ends, break the loop
            if (allQueuesEmpty() && !anyWorkstationBusy()) {
                break;
            }
        }
    }


    private Workstation findBestAvailableWorkstation(List<Workstation> workstations) {
        Workstation bestWorkstation = null;
        for (Workstation workstation : workstations) {
            if (workstation.isAvailable(currentTime)) {
                if (bestWorkstation == null || workstation.getUsageTime() < bestWorkstation.getUsageTime()) {
                    bestWorkstation = workstation;
                }
            }
        }
        return bestWorkstation;
    }

    private void advanceTime() {
        int nextAvailableTime = Integer.MAX_VALUE;

        // Find the nearest time when a workstation becomes available
        for (List<Workstation> workstations : workstationsByOperationType.values()) {
            for (Workstation workstation : workstations) {
                if (workstation.getBusyUntil() > currentTime) {
                    nextAvailableTime = Math.min(nextAvailableTime, workstation.getBusyUntil());
                }
            }
        }

        // Check if there are any pending operations
        if (nextAvailableTime == Integer.MAX_VALUE) {
            System.out.println("No more pending workstations or operations. Simulation ends at time: " + currentTime);
            return; // Exit the simulation loop
        }

        // Advance the simulation time
        currentTime = nextAvailableTime;
        System.out.println("Advancing simulation time to: " + currentTime);

        // Complete all operations finishing at this time
        for (List<Workstation> workstations : workstationsByOperationType.values()) {
            for (Workstation workstation : workstations) {
                if (workstation.getBusyUntil() <= currentTime && "BUSY".equals(workstation.getStatus())) {
                    workstation.finishOperation();
                }
            }
        }
    }

    private boolean anyWorkstationBusy() {
        for (List<Workstation> workstations : workstationsByOperationType.values()) {
            for (Workstation workstation : workstations) {
                if (!workstation.isAvailable(currentTime)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean allQueuesEmpty() {
        for (Queue<Operation> queue : operationsQueueByType.values()) {
            if (!queue.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    public int getCurrentTime() {
        return currentTime;
    }
}
