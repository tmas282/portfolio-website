package esinf.domain.sprint3;

import bddad.db.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class OperationType {
    private String id;
    private String description;

    public OperationType(String id, String description) {
        this.id = id;
        this.description = description;
    }

    public OperationType(String id) throws SQLException {
        this.id = id;

        String query = "SELECT Description FROM OperationType WHERE ID = ?";
        Connection connection = DatabaseConnection.getConnection();
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    this.description = rs.getString("Description");
                } else {
                    throw new SQLException("OperationType ID not found: " + id);
                }
            }
        }
    }

    public String getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "OperationType{" +
                "id='" + id + '\'' +
                ", description='" + description + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof OperationType)) return false;

        OperationType that = (OperationType) o;

        if (!id.equals(that.id)) return false;
        return description.equals(that.description);
    }

    @Override
    public int hashCode() {
        int result = id.hashCode();
        result = 31 * result + description.hashCode();
        return result;
    }
}
