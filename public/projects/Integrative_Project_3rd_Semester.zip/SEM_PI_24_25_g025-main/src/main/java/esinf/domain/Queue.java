package esinf.domain;

import java.util.LinkedList;

/**
 * Represents a queue of ProductionOrderOperation instances ordered by priority.
 */
public class Queue {
    private LinkedList<ProductionOrderOperation> queue = new LinkedList<>();
    int totalTime = 0;

    /**
     * Constructs an empty Queue.
     */
    public Queue() {
        totalTime = 0;
    }

    /**
     * Adds a ProductionOrderOperation to the queue, maintaining priority order.
     *
     * @param productionOrderOperation The production order operation to add.
     */
    public void add(ProductionOrderOperation productionOrderOperation) {
        if (productionOrderOperation.getPriority().equals(Priority.HIGH)) {
            int position = findLastHighPriority();
            addAtPosition(productionOrderOperation, position);
        } else if (productionOrderOperation.getPriority().equals(Priority.NORMAL)) {
            int position = findLastNormalPriority();
            addAtPosition(productionOrderOperation, position);
        } else {
            queue.addLast(productionOrderOperation);
        }
        //totalTime += productionOrderOperation.getDuration();
    }

    private int findLastNormalPriority() {
        for (int i = 0; i < queue.size(); i++) {
            if (queue.get(i).getPriority().equals(Priority.LOW)) {
                return i;
            }
        }
        return queue.size();
    }

    private void addAtPosition(ProductionOrderOperation productionOrderOperation, int position) {
        queue.add(position, productionOrderOperation);
    }

    private int findLastHighPriority() {
        for (int i = 0; i < queue.size(); i++) {
            if (queue.get(i).getPriority().equals(Priority.NORMAL)) {
                return i;
            }
        }
        return queue.size();
    }

    /**
     * Removes and returns the first ProductionOrderOperation in the queue.
     *
     * @return the first ProductionOrderOperation in the queue
     */
    public ProductionOrderOperation remove() {
        ProductionOrderOperation productionOrderOperation = queue.peek();
        productionOrderOperation.setStatus(OrderStatus.COMPLETED);
        //totalTime -= productionOrderOperation.getDuration();
        return queue.remove();
    }

    /**
     * Peeks at the first ProductionOrderOperation in the queue without removing it.
     *
     * @return the first ProductionOrderOperation in the queue
     */
    public ProductionOrderOperation peek() {
        return queue.peek();
    }

    /**
     * Checks if the queue is empty.
     *
     * @return true if the queue is empty, false otherwise
     */
    public boolean isEmpty() {
        return queue.isEmpty();
    }

    /**
     * Gets the size of the queue.
     *
     * @return the size of the queue
     */
    public int size() {
        return queue.size();
    }

    /**
     * Gets the total time of the queue.
     *
     * @return the total time of the queue
     */
    public int getQueueTotalTime() {
        return totalTime;
    }
}