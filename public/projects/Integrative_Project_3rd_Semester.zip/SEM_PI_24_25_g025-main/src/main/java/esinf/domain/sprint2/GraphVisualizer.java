package esinf.domain.sprint2;

import org.graphstream.graph.Graph;
import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.graph.implementations.AbstractNode;
import org.graphstream.stream.file.FileSinkImages;
import org.graphstream.stream.file.FileSinkImages.OutputType;

public class GraphVisualizer {
//A
    public static Graph createGraph(TreeNode root) {
        Graph graph = new SingleGraph("Product Structure");
        addNodesToGraph(graph, root);
        return graph;
    }

    private static void addNodesToGraph(Graph graph, TreeNode node) {
        if (graph.getNode(node.getName()) == null) {
            AbstractNode graphNode = (AbstractNode) graph.addNode(node.getName());
            graphNode.setAttribute("ui.label", node.getName());
        }
        for (TreeNode child : node.getChildren()) {
            if (graph.getNode(child.getName()) == null) {
                AbstractNode childNode = (AbstractNode) graph.addNode(child.getName());
                childNode.setAttribute("ui.label", child.getName());
            }
            if (graph.getEdge(node.getName() + "-" + child.getName()) == null) {
                graph.addEdge(node.getName() + "-" + child.getName(), node.getName(), child.getName(), true);
            }
            addNodesToGraph(graph, child);
        }
    }

    public static void displayGraph(Graph graph) {
        graph.display();
    }

}