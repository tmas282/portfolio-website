package esinf.utils;

import esinf.domain.*;

import java.util.*;
import java.util.Queue;

/**
 * Utility class to generate queues of ProductionOrderOperation instances with priority-based insertion.
 */
public class QueueGeneratorV2 {
    /**
     * Generates a map of operations to queues of ProductionOrderOperation instances.
     *
     * @param orders List of production orders.
     * @return Map of operations to queues of ProductionOrderOperation instances.
     */
    public Map<Operation, Queue<ProductionOrderOperation>> generate(List<ProductionOrder> orders) {
        Map<Operation, Queue<ProductionOrderOperation>> operationsMap = new HashMap<>();

        for (ProductionOrder order : orders) {
            Product product = order.getProduct();
            BOO boo = product.getBoo();
            List<Operation> operations = boo.getOperations();

            for (Operation operation : operations) {
                // Initialize queue if not present
                operationsMap.putIfAbsent(operation, new LinkedList<>());

                // Create ProductOrderOperation
                ProductionOrderOperation productOp = new ProductionOrderOperation(order.getPriority(), operation, order, order.getStage());
                Queue<ProductionOrderOperation> queue = operationsMap.get(operation);

                // Insert based on priority
                insertBasedOnPriority(queue, productOp);

                // Advance the stage in the order
                order.passStage();

                // Check if order is completed
                if (order.isCompleted()) {
                    break;
                }
            }
        }

        return operationsMap;
    }

    /**
     * Inserts a ProductionOrderOperation into the queue based on priority.
     *
     * @param queue  The queue to insert into.
     * @param newOp  The ProductionOrderOperation to insert.
     */
    private void insertBasedOnPriority(Queue<ProductionOrderOperation> queue, ProductionOrderOperation newOp) {
        List<ProductionOrderOperation> tempList = new ArrayList<>(queue);

        int insertPos = tempList.size(); // Default insert at the end (for LOW priority)

        for (int i = 0; i < tempList.size(); i++) {
            ProductionOrderOperation currentOp = tempList.get(i);

            // If newOp is HIGH priority, find the position after the last HIGH priority
            if (newOp.getPriority() == Priority.HIGH && currentOp.getPriority() != Priority.HIGH) {
                insertPos = i;
                break;
            }

            // If newOp is NORMAL priority, find the position after the last NORMAL priority
            if (newOp.getPriority() == Priority.NORMAL && (currentOp.getPriority() == Priority.LOW)) {
                insertPos = i;
                break;
            }
        }

        // Add the new operation at the correct position
        tempList.add(insertPos, newOp);

        // Rebuild the queue with the updated order
        queue.clear();
        queue.addAll(tempList);
    }
}