package esinf.utils;

import esinf.domain.sprint3.Activity;
import esinf.domain.sprint3.Edge;
import esinf.domain.sprint3.PertCpmGraph;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

public class GraphVizFileManager {
    private static final String FILE_PATH = "./graph_temp.txt";
    public static void writeToFile(PertCpmGraph graph, boolean showDetails) throws IOException {
        writeToFile(graph.vertices(), graph.edges(), showDetails, "PERT/CPM Graph");
    }
    public static void writeToFile(ArrayList<Activity> vertices, Collection<Edge<Activity, Integer>> edges, boolean showDetails, String label) throws IOException{
        FileWriter dotFile = new FileWriter(FILE_PATH);
        dotFile.write("digraph simpleGraph {\n" +
                "\tlabel=\"" + label +
                "\\n\\n\"\n" +
                "\tlabelloc = t\n" +
                "\tfontname=\"Helvetica,Arial,sans-serif\"\n" +
                "\tnode [fontname=\"Helvetica,Arial,sans-serif\"]\n" +
                "\tedge [fontname=\"Helvetica,Arial,sans-serif\"]\n" +
                "\tnode [shape=box];\n");
        for(Activity node: vertices){
            dotFile.append(String.format("\t\"%s\";\n", node.toNotProcessedFile(showDetails)));
        }
        for(Edge<Activity, Integer> edge : edges){
            dotFile.append(String.format("\t\"%s\" -> \"%s\"\n", edge.getVOrig().toNotProcessedFile(showDetails), edge.getVDest().toNotProcessedFile(showDetails)));
        }
        dotFile.append("}");
        dotFile.close();
    }
    public static String processFileToSvg(String destinyFilePath) throws IOException, InterruptedException {
        String[] command = {"dot", "-Tsvg", FILE_PATH, "-o", destinyFilePath};
        ProcessBuilder builder = new ProcessBuilder(command);
        Process p = builder.start();
        p.waitFor();
        p.destroy();
        return destinyFilePath;
    }
    public static boolean deleteFile(){
        File tempFile = new File(FILE_PATH);
        return tempFile.isFile() && tempFile.delete();
    }
}
