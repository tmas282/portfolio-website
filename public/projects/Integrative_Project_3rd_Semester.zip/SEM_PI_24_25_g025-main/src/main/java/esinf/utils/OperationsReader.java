package esinf.utils;

import esinf.domain.Operation;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class OperationsReader {
    public static List<Operation> readCSV(String filePath) throws IOException {
        List<Operation> data = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                data.add(new Operation(line.split(";")[0], line.split(";")[1]));
            }
        }
        data.remove(0);
        return data;
    }
}