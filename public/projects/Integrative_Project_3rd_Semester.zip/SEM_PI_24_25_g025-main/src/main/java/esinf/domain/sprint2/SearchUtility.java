package esinf.domain.sprint2;

public class SearchUtility {
    private TreeProductionBuilder builder;

    public SearchUtility(TreeProductionBuilder builder) {
        this.builder = builder;
    }

    public String searchNodeById(String id) {
        TreeNode node = builder.getNodeById(id);
        return getNodeDetails(node);
    }

    public String searchNodeByName(String name) {
        TreeNode node = builder.getNodeByName(name);
        return getNodeDetails(node);
    }

    private String getNodeDetails(TreeNode node) {
        if (node == null) {
            return "Node not found";
        }

        StringBuilder details = new StringBuilder();
        details.append("Node Type: ").append(node.getType()).append("\n");
        details.append("Quantity: ").append(node.getQuantity()).append("\n");

        TreeNode parent = node.getParent();
        if (parent != null && parent.getType() == NodeType.OPERATION) {
            details.append("Parent Operation: ").append(parent.getName()).append("\n");
        }

        return details.toString();
    }
}