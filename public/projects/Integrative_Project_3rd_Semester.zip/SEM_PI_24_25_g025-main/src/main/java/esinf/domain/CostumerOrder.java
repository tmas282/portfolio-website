
package esinf.domain;

import java.util.Date;
import java.util.List;
/**
 * Represents a customer order containing order details and production orders.
 */
public class CostumerOrder {
    private String costumerOrderID;  // ID of the customer order
    private Date orderDate;  // Order date of the customer order
    private Date deliveryDate;  // Delivery date of the customer order
    private StationStatus stationStatus;  // Status of the customer order
    private Priority priority;  // Priority of the customer order
    private String location;  // Location of the customer order
    private List<ProductionOrder> productionOrders;
    /**
     * Constructs a CostumerOrder with the specified parameters.
     *
     * @param costumerOrderID  ID of the customer order.
     * @param orderDate        Order date.
     * @param deliveryDate     Delivery date.
     * @param stationStatus    Status of the order.
     * @param priority         Priority of the order.
     * @param location         Location of the customer.
     * @param productionOrders List of associated production orders.
     */
    public CostumerOrder(String costumerOrderID, Date orderDate, Date deliveryDate, StationStatus stationStatus, Priority priority, String location, List<ProductionOrder> productionOrders) {
        if(orderDate.compareTo(deliveryDate) > 0) throw new IllegalArgumentException("order date can't be before delivery date");
        this.costumerOrderID = costumerOrderID;
        this.orderDate = orderDate;
        this.deliveryDate = deliveryDate;
        this.stationStatus = stationStatus;
        this.priority = priority;
        this.location = location;
        this.productionOrders = productionOrders;
    }

    /**
     * Retrieves the customer order ID.
     * @return Customer order ID.
     */
    public String getCostumerOrderID() {
        return costumerOrderID;
    }
    /**
     * Sets the customer order ID.
     * @param costumerOrderID New customer order ID.
     */
    public void setCostumerOrderID(String costumerOrderID) {
        this.costumerOrderID = costumerOrderID;
    }
    /**
     * Retrieves the order date.
     * @return Order date.
     */
    public Date getOrderDate() {
        return orderDate;
    }
    /**
     * Sets the order date.
     * @param orderDate New order date.
     */
    public void setOrderDate(Date orderDate) {
        if(orderDate.compareTo(deliveryDate) > 0){
            throw new IllegalArgumentException("order date can't be after delivery date");
        }
        this.orderDate = orderDate;
    }
    /**
     * Retrieves the delivery date.
     * @return Delivery date.
     */
    public Date getDeliveryDate() {
        return deliveryDate;
    }
    /**
     * Sets the delivery date.
     * @param deliveryDate New delivery date.
     */
    public void setDeliveryDate(Date deliveryDate) {
        if(deliveryDate.compareTo(orderDate) < 0){
            throw new IllegalArgumentException("delivery date can't be before order date");
        }
        this.deliveryDate = deliveryDate;
    }

    public StationStatus getStatus() {
        return stationStatus;
    }

    public void setStatus(StationStatus stationStatus) {
        this.stationStatus = stationStatus;
    }
    /**
     * Retrieves the priority level.
     * @return Priority level.
     */
    public Priority getPriority() {
        return priority;
    }
    /**
     * Sets the priority level.
     * @param priority New priority level.
     */
    public void setPriority(Priority priority) {
        this.priority = priority;
    }
    /**
     * Retrieves the location of the customer order.
     * @return Location of the customer order.
     */
    public String getLocation() {
        return location;
    }
    /**
     * Sets the location of the customer order.
     * @param location New location.
     */
    public void setLocation(String location) {
        this.location = location;
    }
    /**
     * Retrieves the list of production orders associated with this customer order.
     * @return List of ProductionOrder objects.
     */
    public List<ProductionOrder> getProductionOrders() {
        return productionOrders;
    }

    /**
     * Sets the list of production orders.
     * @param productionOrders New list of ProductionOrder objects.
     */
    public void setProductionOrders(List<ProductionOrder> productionOrders) {
        this.productionOrders = productionOrders;
    }
}