package esinf.domain;

import java.util.LinkedList;

public class BOM {
    private Operation operationId;
    private Product product;
    private LinkedList<Product> products;

    public BOM(Operation operationId, Product product) {
        this.operationId = operationId;
        this.product = product;
        this.products = new LinkedList<>();
    }

    public Operation getOperationId() {
        return operationId;
    }

    public void setOperationId(Operation operationId) {
        this.operationId = operationId;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public LinkedList<Product> getProducts() {
        return products;
    }

    public void setProducts(LinkedList<Product> products) {
        this.products = products;
    }
}
