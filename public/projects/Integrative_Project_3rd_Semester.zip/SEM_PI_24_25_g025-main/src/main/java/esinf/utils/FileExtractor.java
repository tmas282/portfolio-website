package esinf.utils;

import bddad.db.DatabaseConnection;
import controllers.TreeProductionController;
import esinf.domain.Operation;
import esinf.domain.Priority;
import esinf.domain.sprint2.TreeNode;


import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class FileExtractor {
    private Connection connection = DatabaseConnection.getConnection();

    public FileExtractor() throws SQLException {
    }

    public List<Operation> createFilesForProduct(String productCode, String itemsPath, String operationsPath, String booPath) throws SQLException, IOException {
        Map<String, String> parts = new HashMap<>();
        Map<String, String> operations = new HashMap<>();
        retrieveItems(productCode, parts);
        retrieveOperations(productCode, operations);
        exportPartsToCSV(parts, itemsPath);
        exportOperationsToCSV(operations, operationsPath);
        exportBOOToCSV(getBOOForPart(productCode), booPath);

        return getListOfOperations(operations, Priority.NORMAL.toString(), 1);
    }
    public List<Operation> createFilesForProduct(String productCode, String itemsPath, String operationsPath, String booPath, String Priority, int quantity) throws SQLException, IOException {
        Map<String, String> parts = new HashMap<>();
        Map<String, String> operations = new HashMap<>();
        retrieveItems(productCode, parts);
        retrieveOperations(productCode, operations);
        exportPartsToCSV(parts, itemsPath);
        exportOperationsToCSV(operations, operationsPath);
        exportBOOToCSV(getBOOForPart(productCode), booPath);

        return getListOfOperations(operations, Priority, quantity);
    }

    public void retrieveItems(String partCode, Map<String, String> result) throws SQLException {
        String query = "SELECT bp.PartCode, p.Description FROM BOMPart bp JOIN Part p ON bp.PartCode = p.Code WHERE bp.BOMPartCode = ?";
        String query2 = "SELECT Description FROM Part WHERE Code = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query);
             PreparedStatement stmt2 = connection.prepareStatement(query2)) {
            stmt.setString(1, partCode);
            stmt2.setString(1, partCode);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String subPart = rs.getString("PartCode");
                    String description = rs.getString("Description");

                    if (!result.containsKey(subPart)) {
                        result.put(subPart, description);
                        retrieveItems(subPart, result);
                    }
                }
            }
            try (ResultSet rs = stmt2.executeQuery()) {
                while (rs.next()) {
                    String description = rs.getString("Description");
                    result.put(partCode, description);
                }
            }
        }
    }

    public void retrieveOperations(String partCode, Map<String, String> result) throws SQLException {
        String query = "SELECT o.ID, ot.DESCRIPTION FROM Operation o JOIN OPERATIONTYPE ot ON o.OPERATIONTYPEID = ot.ID WHERE BOOPartCode = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, partCode);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String booPartCode = rs.getString("ID");
                    String description = rs.getString("Description");

                    if (!result.containsKey(booPartCode)) {
                        result.put(booPartCode, description);
                        retrieveOperations(booPartCode, result);
                    }
                }
            }
        }
    }

    public List<Operation> getListOfOperations(Map<String, String> result, String priority, int quantity) throws SQLException {
        List<Operation> operations = new ArrayList<>();

        // SQL query to fetch operation details
        String operationQuery = "SELECT ID, ESTIMATEDTIME, NEXTOPERATIONID, OPERATIONTYPEID FROM Operation WHERE ID = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(operationQuery)) {

            for (Map.Entry<String, String> entry : result.entrySet()) {
                String operationId = entry.getKey();

                // Set the operation ID for the query
                stmt.setString(1, operationId);
                String description = entry.getValue();
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        int estimatedTime = rs.getInt("ESTIMATEDTIME");
                        String nextOperationId = rs.getString("NEXTOPERATIONID");
                        String operationTypeId = rs.getString("OPERATIONTYPEID");

                        // Create Operation object with the fetched details
                        Operation operation = new Operation(operationId, description, estimatedTime, nextOperationId, operationTypeId, priority, quantity);
                        operations.add(operation);
                    }
                }
            }
        }

        return operations;
    }
    public void exportPartsToCSV(Map<String, String> items, String filePath) throws IOException {
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.append("PartCode,Description\n");
            for (Map.Entry<String, String> entry : items.entrySet()) {
                writer.append(entry.getKey()).append(";").append(entry.getValue()).append("\n");
            }
        }
    }
    public void exportOperationsToCSV(Map<String, String> operations, String filePath) throws IOException {
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.append("OpID,Description\n");
            for (Map.Entry<String, String> entry : operations.entrySet()) {
                writer.append(entry.getKey()).append(";").append(entry.getValue()).append("\n");
            }
        }
    }

    public List<Map<String, Object>> getBOOForPart(String partCode) throws SQLException {
        List<Map<String, Object>> booStructure = new ArrayList<>();
        Map<Integer, Integer> operationMap = new HashMap<>();

        // Retrieve all operations with the given part code as BOOPartCode
        String query = "SELECT o.ID AS OperationID, o.BOOPartCode, oo.PartCode AS OutputPartCode, oo.Quantity AS OutputQuantity, o.NextOperationID " +
                "FROM Operation o " +
                "LEFT JOIN OperationOutput oo ON o.ID = oo.OperationID " +
                "WHERE o.BOOPartCode = ?";

        String inputQuery = "SELECT oi.PartCode AS InputPartCode, oi.Quantity AS InputQuantity FROM OperationInput oi WHERE oi.OperationID = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query);
             PreparedStatement inputStmt = connection.prepareStatement(inputQuery)) {

            stmt.setString(1, partCode);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int operationId = rs.getInt("OperationID");
                    String booPartCode = rs.getString("BOOPartCode");
                    String outputPartCode = rs.getString("OutputPartCode");
                    double outputQuantity = rs.getDouble("OutputQuantity");
                    int nextOperationId = rs.getInt("NextOperationID");

                    // Map current operation to its next operation
                    operationMap.put(nextOperationId, operationId);

                    // Retrieve input parts for the current operation
                    List<Map<String, Object>> inputParts = new ArrayList<>();
                    inputStmt.setInt(1, operationId);
                    try (ResultSet inputRs = inputStmt.executeQuery()) {
                        while (inputRs.next()) {
                            Map<String, Object> inputPart = new HashMap<>();
                            inputPart.put("InputPartCode", inputRs.getString("InputPartCode"));
                            inputPart.put("InputQuantity", inputRs.getDouble("InputQuantity"));
                            inputParts.add(inputPart);
                        }
                    }

                    // Create a record for the current operation
                    Map<String, Object> record = new HashMap<>();
                    record.put("OperationID", operationId);
                    record.put("BOOPartCode", booPartCode);
                    record.put("OutputPartCode", outputPartCode);
                    record.put("OutputQuantity", outputQuantity);
                    record.put("InputParts", inputParts);
                    record.put("NextOperationID", nextOperationId);

                    booStructure.add(record);
                }
            }
        }

        // Assign previous operations
        for (Map<String, Object> record : booStructure) {
            int operationId = (int) record.get("OperationID");
            Integer previousOperationId = operationMap.get(operationId);
            record.put("PreviousOperationID", previousOperationId != null ? previousOperationId : null);
        }

        return booStructure;
    }

    public void exportBOOToCSV(List<Map<String, Object>> booStructure, String filePath) throws IOException {
        try (FileWriter writer = new FileWriter(filePath)) {
            // Write header for the first line
            writer.append("OperationID;OutputPartCode;OutputQuantity;PreviousOperation;(InputPartCode;InputQuantity;...;)\n");

            for (Map<String, Object> record : booStructure) {
                StringBuilder line = new StringBuilder();

                // Operation ID, Output Part Code, and Output Quantity
                line.append(record.get("OperationID"))
                        .append(";")
                        .append(record.get("OutputPartCode"))
                        .append(";")
                        .append(record.getOrDefault("OutputQuantity", 0.0))
                        .append(";(;");

                int placeholderCount = 1;
                if (record.get("PreviousOperationID") != null) {
                    line.append(record.get("PreviousOperationID"))
                            .append(";1,0;");
                    placeholderCount += 2; // PreviousOperationID and its quantity
                }

                while (placeholderCount < 7) {
                    line.append(";");
                    placeholderCount++;
                }

                line.append(");");

                // Input Parts Section
                line.append("(;");
                int inputPlaceholderCount = 1;
                List<Map<String, Object>> inputParts = (List<Map<String, Object>>) record.get("InputParts");
                if (inputParts != null && !inputParts.isEmpty()) {
                    for (Map<String, Object> inputPart : inputParts) {
                        line.append(inputPart.get("InputPartCode"))
                                .append(";")
                                .append(inputPart.get("InputQuantity").toString().replace('.', ','))
                                .append(";");
                        inputPlaceholderCount += 2; // InputPartCode and its quantity
                    }
                }

                // Fill with placeholders to ensure at least 8 semicolons inside the parenthesis
                while (inputPlaceholderCount < 7) {
                    line.append(";");
                    inputPlaceholderCount++;
                }

                line.append(");\n");
                writer.append(line.toString());
            }
        }
    }






    public static void main(String[] args) throws SQLException, IOException {
        Map<String, String> parts = new HashMap<>();
        Map<String, String> operations = new HashMap<>();
        FileExtractor fileExtractor = new FileExtractor();
        String partCode = "AS12946S22";
        String itemsPath = "./files/generated/items.csv";
        String operationsPath = "./files/generated/operations.csv";
        String booPath = "./files/generated/boo.csv";
        fileExtractor.retrieveItems(partCode, parts);
        System.out.println("Parts needed for AS12946S20: " + parts);
        fileExtractor.exportPartsToCSV(parts, itemsPath);
        fileExtractor.retrieveOperations(partCode, operations);
        System.out.println("Ops needed for AS12946S20: " + operations);
        fileExtractor.exportOperationsToCSV(operations, operationsPath);
        fileExtractor.exportBOOToCSV(fileExtractor.getBOOForPart(partCode), booPath);
        TreeProductionController treeProductionController = new TreeProductionController(itemsPath, operationsPath, booPath, partCode);
        treeProductionController.buildProductionTree();
        treeProductionController.printProductionTree();
        treeProductionController.extractBOO();
        treeProductionController.printOperationsByDependency();
        LinkedList<String> sortedOperations = treeProductionController.exportOperationsByDependency();
        System.out.println("Operations sorted by dependency levels:");
        sortedOperations.forEach(System.out::println);
    }
}
