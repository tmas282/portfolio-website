package esinf.domain.sprint3.lapr06;

public class WorkstationOperationTime {
    private String workstationId;
    private String operationId;
    private int operationTime;

    public WorkstationOperationTime(String workstationId, String operationId, int operationTime) {
        this.workstationId = workstationId;
        this.operationId = operationId;
        this.operationTime = operationTime;
    }

    // Getters and setters
    public String getWorkstationId() { return workstationId; }
    public String getOperationId() { return operationId; }
    public int getOperationTime() { return operationTime; }
}