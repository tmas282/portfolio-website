package esinf.domain.sprint3;

import java.util.*;

public class ProjectDelaySimulator {
    private PertCpmGraph graph;
    private Map<String, Float> delays;
    private boolean isDelayMapBuilt;

    public ProjectDelaySimulator(PertCpmGraph graph) {
        this.graph = graph;
        this.delays = new HashMap<>();
        this.isDelayMapBuilt = false;
    }

    /**
     * Simulates delays by updating the duration of specified activities.
     */
    public void simulateDelays() {
        if (!isDelayMapBuilt) {
            System.out.println("Delays map is not built. Please build it first.");
            return;
        }

        for (Map.Entry<String, Float> delay : delays.entrySet()) {
            Activity activity = graph.vertex(delay.getKey());
            if (activity != null) {
                float newDuration = activity.getDuration() + delay.getValue();
                activity.setDuration(newDuration);
            }
        }
        recalculateGraph();
    }

    /**
     * Builds the delays map by presenting all activities and asking the user to select delayed activities and their delays.
     */
    public void buildDelaysMap() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Activities in the graph:");
        for (Activity activity : graph.vertices()) {
            System.out.printf("%s: %s (Duration: %.2f %s, Cost: %.2f)%n",
                    activity.getKey(), activity.getDescription(), activity.getDuration(), activity.getDurationUnit(), activity.getCost());
        }

        System.out.println("Enter the keys of the activities that were delayed (comma-separated):");
        String[] delayedActivities = scanner.nextLine().split(",");

        for (String activityKey : delayedActivities) {
            activityKey = activityKey.trim();
            Activity activity = graph.vertex(activityKey);
            if (activity != null) {
                System.out.printf("Enter the delay (in %s) for activity %s: ", activity.getDurationUnit(), activityKey);
                float delay = scanner.nextFloat();
                delays.put(activityKey, delay);
            } else {
                System.out.printf("Activity with key %s not found.%n", activityKey);
            }
        }
        isDelayMapBuilt = true;
        System.out.println("Delays map built successfully.");
    }

    /**
     * Recalculates the graph's critical path, total project duration, and slack times.
     */
    private void recalculateGraph() {
        Algorithms.calculateTimes(graph);
        Collection<LinkedList<Activity>> criticalPaths = Algorithms.findCriticalPath(graph);
        for (LinkedList<Activity> criticalPath : criticalPaths) {
            float totalDuration = Algorithms.calculateCriticalPathDuration(criticalPath);
            System.out.println("Critical Path: " + criticalPath);
            System.out.println("Total Project Duration: " + totalDuration);
        }

        for (Activity activity : graph.vertices()) {
            System.out.println(activity);
        }
    }
}