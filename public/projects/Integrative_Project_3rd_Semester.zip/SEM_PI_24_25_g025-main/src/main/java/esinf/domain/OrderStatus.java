package esinf.domain;

public enum OrderStatus
{
    WAITING, READY, IN_PRODUCTION, COMPLETED
}
