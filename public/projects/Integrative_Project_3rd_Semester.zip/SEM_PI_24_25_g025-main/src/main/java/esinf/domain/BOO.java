package esinf.domain;

import java.util.LinkedList;
/**
 * Represents a Bill of Operations (BOO), which maintains an ordered list of
 * operations for a specific product.
 */

public class BOO {
    private Operation operationId;
    private Product product; // Reference to the product
    private LinkedList<Operation> operations; // List to maintain the sequence of operations in the BOO
    /**
     * Default constructor to create an empty BOO.
     */
    public BOO() {
        this.operations = new LinkedList<>();
    }

    /**
     * Constructor to create a BOO for a specific product.
     *
     * @param product Product associated with the BOO
     */

    public BOO(Product product) {
        this.product = product;
        this.operations = new LinkedList<>();
    }

    // Getters and Setters

    public LinkedList<Operation> getOperations() {
        return operations;
    }

    public void setOperations(LinkedList<Operation> operations) {
        this.operations = operations;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Operation getOperationId() {
        return operationId;
    }

    public void setOperationId(Operation operationId) {
        this.operationId = operationId;
    }

    /**
     * Adds an operation to the end of the sequence.
     *
     * @param operation Operation to be added
     */
    public void addOperation(Operation operation) {
        operations.add(operation);
    }

    /**
     * Adds an operation at a specific position in the sequence.
     *
     * @param operation Operation to be added
     * @param position  Position in the sequence
     * @throws IndexOutOfBoundsException If the position is invalid
     */
    public void addOperationAt(Operation operation, int position) {
        if (position < 0 || position > operations.size()) {
            throw new IndexOutOfBoundsException("Invalid position for the operation.");
        }
        operations.add(position, operation);
    }

    /**
     * Removes an operation from the sequence.
     *
     * @param operation Operation to be removed
     */
    public void removeOperation(Operation operation) {
        operations.remove(operation);
    }

    /**
     * Retrieves the operation at a specified index.
     *
     * @param index Index of the operation in the sequence
     * @return Operation at the specified index
     * @throws IndexOutOfBoundsException If the index is invalid
     */
    public Operation getOperationAt(int index) {
        if (index < 0 || index >= operations.size()) {
            throw new IndexOutOfBoundsException("Invalid index for the operation.");
        }
        return operations.get(index);
    }
    /**
     * Generates a string with details of the BOO.
     *
     * @return String representation of the BOO
     */
    public String getBOODetails(){
        String details = "BOO OF PRODUCT ID: " + product.getProductID() + "\n";
        for (Operation operation : operations) {
            details += "\tOperation Name: " + operation.getOperationID() + "\n";
        }
        return details;
    }
    /**
     * Prints the details of the BOO to the console.
     */
    public void printBOODetails() {
        System.out.println(getBOODetails());
    }
}