package esinf.domain.sprint3;

import esinf.domain.Operation;

import java.sql.SQLException;
import java.util.*;

public class QueueGeneratorV3 {

    public Map<OperationType, Queue<Operation>> generateQueues(List<Operation> operations) throws SQLException {
        Map<OperationType, Queue<Operation>> operationsQueueByType = new HashMap<>();

        // Group operations by OperationType
        Map<OperationType, List<Operation>> groupedByType = new HashMap<>();
        for (Operation operation : operations) {
            OperationType operationType = new OperationType(operation.getOperationTypeID());
            groupedByType.putIfAbsent(operationType, new ArrayList<>());
            groupedByType.get(operationType).add(operation);
        }

        // Sort and create queues
        for (Map.Entry<OperationType, List<Operation>> entry : groupedByType.entrySet()) {
            OperationType operationType = entry.getKey();
            List<Operation> operationList = entry.getValue();

            // Sort by priority and then by duration (descending within the same priority)
            operationList.sort(Comparator
                    .comparing(Operation::getPriority)
                    .thenComparing((o1, o2) -> Integer.compare(o2.getDuration(), o1.getDuration())));

            // Add sorted list to a queue
            Queue<Operation> queue = new LinkedList<>(operationList);
            operationsQueueByType.put(operationType, queue);
        }

        return operationsQueueByType;
    }
}
