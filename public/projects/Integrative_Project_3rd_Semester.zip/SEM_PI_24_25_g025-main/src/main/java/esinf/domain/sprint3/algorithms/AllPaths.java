package esinf.domain.sprint3.algorithms;

import esinf.domain.sprint3.Algorithms;
import esinf.domain.sprint3.Graph;

import java.util.ArrayList;
import java.util.LinkedList;

public class AllPaths
{
    /** Returns all paths from vOrig to vDest
     *
     * @param g       Graph instance
     * @param vOrig   Vertex that will be the source of the path
     * @param vDest   Vertex that will be the end of the path
     * @param visited set of discovered vertices
     * @param path    stack with vertices of the current path (the path is in reverse order)
     * @param paths   ArrayList with all the paths (in correct order)
     */
    public static <V, E> void allPaths(Graph<V, E> g, V vOrig, V vDest, boolean[] visited,
                                       LinkedList<V> path, ArrayList<LinkedList<V>> paths) {
        Algorithms.allPaths(g, vOrig, vDest, visited, path, paths);
    }
}
