package esinf.domain.sprint3.lapr06;

import esinf.domain.Priority;

public class Order {
    private int orderId;
    private int itemId;
    private Priority priority;
    private int quantity;

    public Order(int orderId, int itemId, Priority priority, int quantity) {
        this.orderId = orderId;
        this.itemId = itemId;
        this.priority = priority;
        this.quantity = quantity;
    }

    // Getters and setters
    public int getOrderId() { return orderId; }
    public int getItemId() { return itemId; }
    public Priority getPriority() { return priority; }
    public int getQuantity() { return quantity; }
}