package esinf.domain.sprint2;

import java.math.BigDecimal;
import java.util.*;

public class TreeProductionBuilder {
    private Map<String, BOOEntry> operationMap; // Map to access BOOEntry by operation ID
    private Map<String, String> itemsMap; // Map to access item names by product ID
    private Map<String, String> operationsMap; // Map to access operation names by operation ID
    private Map<String, TreeNode> nodeMap; // Map to associate each node with a unique identifier

    public TreeProductionBuilder(Map<String, String> itemsMap, Map<String, String> operationsMap) {
        this.itemsMap = itemsMap;
        this.operationsMap = operationsMap;
        this.nodeMap = new HashMap<>();
    }

    public TreeNode buildTree(String rootProductId, List<BOOEntry> booEntries) {
        // Create a map for quick lookup of BOO entries by operation ID
        operationMap = new HashMap<>();
        for (BOOEntry entry : booEntries) {
            operationMap.put(entry.operationId, entry);
        }

        // Start building the tree from the root product
        String rootName = itemsMap.getOrDefault(rootProductId, "Unknown Product");
        TreeNode root = new TreeNode(rootProductId, rootName, NodeType.PRODUCT, BigDecimal.ONE, null); // Root is a product
        nodeMap.put(rootProductId, root);

        // Find operations that produce this product
        for (BOOEntry entry : booEntries) {
            if (entry.resultProductId.equals(rootProductId)) {
                // Add the operation and recursively build its dependencies
                TreeNode operationNode = buildSubTree(entry, root);
                root.addChild(operationNode);
            }
        }

        return root;
    }

    private TreeNode buildSubTree(BOOEntry parentEntry, TreeNode parent) {
        // Create the current operation node
        String operationName = operationsMap.getOrDefault(parentEntry.operationId, "Unknown Operation");
        BigDecimal operationQuantity = new BigDecimal(parentEntry.quantity.replace(',', '.')); // Replace comma with dot
        TreeNode operationNode = new TreeNode(parentEntry.operationId, operationName, NodeType.OPERATION, operationQuantity, parent);
        nodeMap.put(parentEntry.operationId, operationNode);

        // Add product dependencies as children of this operation
        for (Map.Entry<String, String> productDependency : parentEntry.productDependencies.entrySet()) {
            String productId = productDependency.getKey();
            String quantity = productDependency.getValue();

            // Create a child node for the product
            String productName = itemsMap.getOrDefault(productId, "Unknown Product");
            BigDecimal quantityBD = new BigDecimal(quantity.replace(',', '.')); // Replace comma with dot
            TreeNode productNode = new TreeNode(productId, productName, NodeType.PRODUCT, quantityBD, operationNode);
            nodeMap.put(productId, productNode);

            operationNode.addChild(productNode);

            // Recursively check if this product has its own operation
            for (BOOEntry childEntry : operationMap.values()) {
                if (childEntry.resultProductId.equals(productId)) {
                    TreeNode childOperationNode = buildSubTree(childEntry, productNode);
                    productNode.addChild(childOperationNode);
                }
            }
        }

        return operationNode;
    }

    // Recursive method to print the tree structure
    public void printTree(TreeNode node, String prefix) {
        System.out.println(prefix + "|-- " + node);

        // Recursively print children with updated prefix
        List<TreeNode> children = node.getChildren();
        for (int i = 0; i < children.size(); i++) {
            TreeNode child = children.get(i);

            // Use a vertical line for all but the last child
            String childPrefix = prefix + (i < children.size() - 1 ? "|   " : "    ");
            printTree(child, childPrefix);
        }
    }

    public TreeNode getNodeById(String id) {
        return nodeMap.get(id);
    }

    public TreeNode getNodeByName(String name) {
        for (TreeNode node : nodeMap.values()) {
            if (node.getName().equals(name)) {
                return node;
            }
        }
        return null;
    }
}