package esinf.domain.trees;

import java.util.ArrayList;
import java.util.List;

public class OperationNode implements ProductionNode {
    private Integer id;
    private String name;
    private ProductionNode parent;
    private ProductionNodeType type;
    private List<ProductionNode> children = new ArrayList<>();
    private double quantity;

    public OperationNode(Integer id, String name, double quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.type = ProductionNodeType.OPERATION;
    }

    @Override
    public Integer getId() {
        return id;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public ProductionNode getParent() {
        return parent;
    }

    @Override
    public void setParent(ProductionNode parent) {
        this.parent = parent;
    }

    @Override
    public ProductionNodeType getType() {
        return type;
    }

    @Override
    public List<ProductionNode> getChildren() {
        return children;
    }

    @Override
    public void addChild(ProductionNode child) {
        children.add(child);
    }

    @Override
    public double getQuantity() {
        return quantity;
    }
}