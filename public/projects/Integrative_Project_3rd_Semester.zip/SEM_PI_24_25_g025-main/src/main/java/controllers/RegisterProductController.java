package controllers;

import bddad.Functions.RegisterProduct;

public class RegisterProductController {
    private RegisterProduct registerproduct;

    public RegisterProductController(){
        registerproduct = new RegisterProduct();
    }

    public void registerProduct(){
        registerproduct.registerProduct();
    }
}
