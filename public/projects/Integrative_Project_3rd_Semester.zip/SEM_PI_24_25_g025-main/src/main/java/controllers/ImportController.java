package controllers;

import esinf.dataStructures.OperationStationMap;
import esinf.domain.Operation;
import esinf.domain.Product;
import esinf.domain.ProductionOrder;
import esinf.domain.Station;
import esinf.utils.ArticleFileReader;
import esinf.utils.WorkstationFileReader;

import java.util.List;
import java.util.Map;

/**
 * Controller for importing and managing workstation and article files.
 * Provides methods for reading CSV files and retrieving data structures.
 */
public class ImportController {
    private WorkstationFileReader workstationFileReader = new WorkstationFileReader();
    private ArticleFileReader articleFileReader;

    /**
     * Constructor for the ImportController class.
     */
    public ImportController(){

    }
    /**
     * Reads a CSV file containing workstation data.
     * @param csvFilePath Path to the workstation CSV file.
     */

    public void readWorkstationFile(String csvFilePath){
        workstationFileReader.readCSV(csvFilePath);
    }

    /**
     * Reads a CSV file containing article data and initializes articleFileReader with workstation operations.
     * @param csvFilePath Path to the article CSV file.
     */
    public void readArticleFile(String csvFilePath){
        articleFileReader = new ArticleFileReader(workstationFileReader.getOperations());
        articleFileReader.readArticles(csvFilePath);
    }
    /**
     * Retrieves the OperationStationMap containing mappings between operations and stations.
     * @return OperationStationMap of operations and stations.
     */

    public OperationStationMap getOperationStationMap(){
        return workstationFileReader.getOperationStationMap();
    }
    /**
     * Retrieves a list of all stations.
     * @return List of Station objects.
     */
    public List<Station> getStations(){
        return workstationFileReader.getStations();
    }
    /**
     * Retrieves a list of all operations.
     * @return List of Operation objects.
     */
    public List<Operation> getOperations(){
        return workstationFileReader.getOperations();
    }

    /**
     * Retrieves a map of products.
     * @return Map of Product objects.
     */
    public Map<String, Product> getProductMap(){
        return articleFileReader.getProducts();
    }
    /**
     * Retrieves a list of production orders.
     * @return List of ProductionOrder objects.
     */
    public List<ProductionOrder> getProductionOrders(){
        return articleFileReader.getProductionOrders();
    }
}
