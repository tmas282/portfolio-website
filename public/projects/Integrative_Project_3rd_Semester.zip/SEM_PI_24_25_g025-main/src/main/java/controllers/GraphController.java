package controllers;

import esinf.domain.sprint3.*;
import esinf.domain.sprint3.algorithms.TopologicalSort;
import esinf.utils.GraphFileReader;
import esinf.utils.GraphVizFileManager;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

import static esinf.domain.sprint3.algorithms.AllPaths.allPaths;

public class GraphController {
    private PertCpmGraph graph;

    public PertCpmGraph readCSVandBuildGraph(String csvPath) throws FileNotFoundException {
        File csv = new File(csvPath);
        graph = new PertCpmGraph();
        GraphFileReader.buildGraphFromFile(graph, csv);
        return graph;
    }

    public String parseGraphToImage(boolean showDetails, String destinyFilePath) throws IOException, InterruptedException {
        GraphVizFileManager.writeToFile(graph, showDetails);
        String pathOfGraph = GraphVizFileManager.processFileToSvg(destinyFilePath);
        GraphVizFileManager.deleteFile();
        return pathOfGraph;
    }
    public String parseGraphToImage(ArrayList<Activity> vertices, Collection<Edge<Activity, Integer>> edges, boolean showDetails, String label, String destinyFilePath) throws IOException, InterruptedException {
        GraphVizFileManager.writeToFile(vertices, edges, showDetails, label);
        String pathOfGraph = GraphVizFileManager.processFileToSvg(destinyFilePath);
        GraphVizFileManager.deleteFile();
        return pathOfGraph;
    }

    // TopologicalSort
    public <V, E> LinkedList<V> topologicalSort(Graph<V, E> g) {
        LinkedList<V> result;
        result = TopologicalSort.topologicalSort(g);
        return result;
    }

    // Shared
    public PertCpmGraph getGraph() {
        if (graph == null) {
            throw new IllegalStateException("Graph is not initialized");
        }
        return graph;
    }

    public static <V, E> boolean hasCircularDependencies(Graph<V, E> g) {
        boolean[] visited = new boolean[g.numVertices()];
        ArrayList<LinkedList<V>> paths = new ArrayList<>();
        LinkedList<V> path = new LinkedList<>();

        // Procura ciclos começando por cada vértice
        for (V vertex : g.vertices()) {
            allPaths(g, vertex, vertex, visited, path, paths);
            if (!paths.isEmpty()) {
                return true; // Ciclo encontrado
            }
        }
        return false; // Nenhum ciclo encontrado
    }

    public static Map<Activity, Integer> findBottleneckActivities(Graph<Activity, Integer> g, Collection<LinkedList<Activity>> criticalPaths) {
        Map<Activity, Integer> bottleneckScores = new HashMap<>();
        Map<Activity, Integer> criticalPathFrequency = new HashMap<>();


        // Calcula a frequência de cada atividade nos caminhos críticos
        for (LinkedList<Activity> path : criticalPaths) {
            for (Activity activity : path) {
                criticalPathFrequency.put(activity, criticalPathFrequency.getOrDefault(activity, 0) + 1);
            }
        }

        // Calcula o score para cada atividade
        for (Activity vertex : g.vertices()) {
            int inDegree = g.inDegree(vertex); // Número de predecessores imediatos
            int criticalFrequency = criticalPathFrequency.getOrDefault(vertex, 0); // Frequência nos caminhos críticos

            // Soma os dois fatores para obter o score
            bottleneckScores.put(vertex, inDegree + criticalFrequency);
        }

        return bottleneckScores;
    }

    public List<Activity> getActivityTimes() {
        Algorithms.calculateTimes(graph);

        List<Activity> activities = new ArrayList<>();

        for (Activity activity : graph.vertices()) {
            activities.add(activity);
        }

        return activities;
    }
    public Collection<LinkedList<Activity>> getCriticalPaths(){
        return Algorithms.findCriticalPath(graph);
    }
    public void parseCriticalPathsToImage() throws IOException, InterruptedException {
        Collection<LinkedList<Activity>> criticalPaths = getCriticalPaths();
        int w=0;
        for(LinkedList<Activity> i : criticalPaths){
            Collection<Edge<Activity, Integer>> edges = new ArrayList<>();
            for (int j = 0; j < i.size() - 1; j++) {
                Edge<Activity, Integer> edge = new Edge<>(i.get(j), i.get(j+1), 0);
                edges.add(edge);
            }
            String criticalPathDuration = Algorithms.calculateCriticalPathDuration(i) + " " + i.get(0).getDurationUnit();
            parseGraphToImage(new ArrayList<>(i), edges, true, "Critical Path: " + criticalPathDuration, "./critical_path_"+w+".svg");
            w++;
        }
    }

    public void simulateDelay(){
        if (graph == null) {
            throw new IllegalStateException("Graph is not initialized");
        }
        ProjectDelaySimulator projectDelaySimulator = new ProjectDelaySimulator(graph);
        projectDelaySimulator.buildDelaysMap();
        projectDelaySimulator.simulateDelays();
    }
}