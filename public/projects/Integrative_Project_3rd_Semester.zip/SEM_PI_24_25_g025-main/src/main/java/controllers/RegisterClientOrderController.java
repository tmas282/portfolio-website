package controllers;

import bddad.Functions.RegisterClientOrder;

public class RegisterClientOrderController {
    private RegisterClientOrder registerClientOrder;

    public RegisterClientOrderController(){
        registerClientOrder = new RegisterClientOrder();
    }

    public void registerClientOrder(){
        registerClientOrder.registerOrder();
    }
}
