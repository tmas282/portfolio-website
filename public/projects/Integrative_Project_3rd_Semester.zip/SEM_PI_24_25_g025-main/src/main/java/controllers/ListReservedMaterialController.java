package controllers;

import bddad.db.DatabaseConnection;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import bddad.Procedures.ListReservedMaterials;

public class ListReservedMaterialController {
    public static List<String> getReservedMaterials() throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        List<String> output = ListReservedMaterials.reservedMaterials(conn);
        conn.close();
        return output;
    }
}
