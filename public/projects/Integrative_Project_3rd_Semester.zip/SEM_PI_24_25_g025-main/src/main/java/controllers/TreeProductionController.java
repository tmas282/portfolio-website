package controllers;

import esinf.domain.sprint2.*;
import esinf.utils.FileReaderUtility;

import java.io.IOException;
import java.util.LinkedList;

public class TreeProductionController {

    private TreeProductionBuilder treeProductionBuilder;
    private FileReaderUtility fileReaderUtility;
    private MaterialQuantityTracker materialQuantityTracker;
    private BOOExtractor booExtractor;
    private String itemsPath = "./files/items.csv";
    private String operationsPath = "./files/operations.csv";
    private String booPath = "./files/boo_v2.csv";
    private String rootProductId = "1006";
    private TreeNode root;

    public TreeProductionController() {
        this.fileReaderUtility = new FileReaderUtility();
        this.materialQuantityTracker = new MaterialQuantityTracker();
        this.booExtractor = new BOOExtractor();
        try {
            fileReaderUtility.readOperationsFile(operationsPath);
            fileReaderUtility.readItemsFile(itemsPath);
            fileReaderUtility.readBOOFile(booPath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        fileReaderUtility.resolveOperationDependenciesToProducts(fileReaderUtility.booEntries);
    }
    public TreeProductionController(String itemsPath, String operationsPath, String booPath, String rootProductId) {
        this.itemsPath = itemsPath;
        this.operationsPath = operationsPath;
        this.booPath = booPath;
        this.rootProductId = rootProductId;
        this.fileReaderUtility = new FileReaderUtility();
        this.materialQuantityTracker = new MaterialQuantityTracker();
        this.booExtractor = new BOOExtractor();
        try {
            fileReaderUtility.readOperationsFile(operationsPath);
            fileReaderUtility.readItemsFile(itemsPath);
            fileReaderUtility.readBOOFile(booPath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        fileReaderUtility.resolveOperationDependenciesToProducts(fileReaderUtility.booEntries);
    }

    public void buildProductionTree() {
        treeProductionBuilder = new TreeProductionBuilder(fileReaderUtility.itemsMap, fileReaderUtility.operationsMap);
        root = treeProductionBuilder.buildTree(rootProductId, fileReaderUtility.booEntries);
    }

    public void printProductionTree() {
        if (root == null) {
            throw new RuntimeException("Production tree has not been built yet.");
        }
        treeProductionBuilder.printTree(root, "");
    }
    public void buildTracker() {
        materialQuantityTracker.buildFromProductionTree(root);
    }

    public void printAscendingOrderMaterials() {
        materialQuantityTracker.printMaterialsInAscendingOrder();
    }

    public void printDescendingOrderMaterials() {
        materialQuantityTracker.printMaterialsInDescendingOrder();
    }

    public void extractBOO() {
        booExtractor.extractBOO(root);
    }

    public void printOperationsByDependency() {
        booExtractor.printOperations();
    }

    public LinkedList<String> exportOperationsByDependency() {
        return booExtractor.getOperationsByDependencyLevel();
    }

    public SearchUtility getSearchUtility() {
        return new SearchUtility(treeProductionBuilder);
    }

    public QualityCheckManager getQualityCheckManager() {
        return new QualityCheckManager();
    }

    public TreeProductionBuilder getTreeProductionBuilder() {
        return treeProductionBuilder;
    }
}
