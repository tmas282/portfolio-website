package controllers;

import bddad.utils.BOMGenerator;
import bddad.utils.XMLPartReader;

import java.io.IOException;
import java.sql.SQLException;

public class ImportBddadController {
    private XMLPartReader reader;
    private BOMGenerator bomGenerator;

    public ImportBddadController(){
        reader = new XMLPartReader();
        bomGenerator = new BOMGenerator();
    }

    public void importBDDAD(String xmlPartFilePath, String xmlOperationFilePath, String xmlBooFilePath, String xmlClientFilePath, String xmlProcurementFilePath, String excelFilePath) throws SQLException, IOException {
        reader.loadPartsFromXML(xmlPartFilePath);
        reader.loadOperationsFromXML(xmlOperationFilePath);
        reader.loadBOOFromXML(xmlBooFilePath);
        reader.loadClientsFromXML(xmlClientFilePath);
        reader.loadProcurementFromXML(xmlProcurementFilePath);
        reader.processExcelFile(excelFilePath);
        bomGenerator.createBOMFromOperations();
    }
}
