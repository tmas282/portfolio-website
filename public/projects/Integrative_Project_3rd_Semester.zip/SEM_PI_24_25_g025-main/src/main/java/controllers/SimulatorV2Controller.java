package controllers;

import esinf.domain.Operation;
import esinf.domain.sprint3.QueueGeneratorV3;
import esinf.domain.sprint3.lapr06.SimulatorV2;
import esinf.utils.FileExtractor;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

public class SimulatorV2Controller {
    FileExtractor fileExtractor = new FileExtractor();
    QueueGeneratorV3 queueGenerator = new QueueGeneratorV3();
    TreeProductionController treeProductionController;

    public SimulatorV2Controller() throws SQLException {
    }

    public List<Operation> getFilesPathForProduct(String productCode, String itemPath, String operationPath, String bomPath, String priority, int quantity) throws SQLException, IOException {
        return fileExtractor.createFilesForProduct(productCode, itemPath, operationPath, bomPath, priority, quantity);
    }

    public void getProductionTree(String itemPath, String operationPath, String bomPath, String productCode) {
        treeProductionController = new TreeProductionController(itemPath, operationPath, bomPath, productCode);
        treeProductionController.buildProductionTree();
    }

    public void printProductionTree() {
        treeProductionController.printProductionTree();
    }

    public LinkedList<String> getOperationsByDependency() {
        treeProductionController.extractBOO();
        return treeProductionController.exportOperationsByDependency();
    }

    public void readOrders(String path) {
        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            String line;

            reader.readLine(); // Skip the header line
            // Read each line from the file
            while ((line = reader.readLine()) != null) {
                // Split the line by commas
                String[] parts = line.split(";");

                // Check if the line contains the correct number of columns
                if (parts.length != 4) {
                    System.err.println("Invalid line format: " + line);
                    continue; // Skip invalid lines
                }

                // Extract order details from the CSV line
                String orderId = parts[0].trim();
                String itemId = parts[1].trim();
                String priority = parts[2].trim();
                int quantity;

                try {
                    quantity = Integer.parseInt(parts[3].trim());
                } catch (NumberFormatException e) {
                    System.err.println("Invalid quantity value in line: " + line);
                    continue; // Skip lines with invalid quantity
                }

                // Call runSimulation or handle the data accordingly
                runSimulator(itemId, priority, quantity); // Assuming this method is available
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void runSimulator(String itemId, String priority, int quantity) throws SQLException, IOException {
        List<Operation> operations = getFilesPathForProduct(itemId, "./files/generated/items.csv", "./files/generated/operations.csv", "./files/generated/boo.csv", priority, quantity);
        getProductionTree("./files/generated/items.csv", "./files/generated/operations.csv", "./files/generated/boo.csv", itemId);
        LinkedList<String> operationsByDependency = getOperationsByDependency();
        SimulatorV2 simulator = new SimulatorV2(queueGenerator.generateQueues(operations));
        simulator.runSimulation();
    }

}
