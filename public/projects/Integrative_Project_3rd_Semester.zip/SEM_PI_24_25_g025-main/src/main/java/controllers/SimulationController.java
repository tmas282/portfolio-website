package controllers;


import esinf.dataStructures.OperationStationMap;
import esinf.domain.*;
import esinf.utils.QueueGeneratorV1;
import esinf.utils.QueueGeneratorV2;
import esinf.utils.Simulator;

import java.util.*;
import java.util.Queue;

public class SimulationController {
    private QueueGeneratorV1 queueGeneratorV1 = new QueueGeneratorV1();
    private QueueGeneratorV2 queueGeneratorV2 = new QueueGeneratorV2();

    private Simulator simulator;
    private boolean flag = false;

    public Map<Operation, Queue<ProductionOrderOperation>> generateQueues(List<ProductionOrder> orders) {
        return queueGeneratorV1.generate(orders);
    }

    public Map<Operation, Queue<ProductionOrderOperation>> generateQueuesV2(List<ProductionOrder> orders) {
        return queueGeneratorV2.generate(orders);
    }
    /**
     * Sets up the simulator with stations, operation-station assignments, and operation queues.
     *
     * @param stations           List of stations
     * @param operationStationMap Map of operation-station assignments
     * @param operationQueues     Map of operation queues
     */
    public void addFilesToSimulator(List<Station> stations,
                                    OperationStationMap operationStationMap,
                                    Map<Operation, Queue<ProductionOrderOperation>> operationQueues) {
        restartStations(stations);
        this.simulator = new Simulator(stations, operationStationMap, operationQueues);
        flag = true;
    }
    /**
     * Starts the simulation if the required files have been added.
     */
    public void startSimulation() {
        if (flag) {
            simulator.processQueues();
        } else {
            System.out.println("Please generate queues first.");
        }
    }

    /**
     * Retrieves the total simulation time.
     *
     * @return Total simulation time
     */
    public int getTotalSimulationTime() {
        return simulator.getCurrentTime();
    }
    /**
     * Retrieves the total time for a specific operation.
     *
     * @param operation Operation to get the total time for
     * @return Total time for the specified operation
     */
    public int getTotalTimeByOperation(Operation operation) {
        return simulator.getTotalTimeByOperation(operation);
    }

    /**
     * Retrieves total times for all operations.
     *
     * @return Map of operations with their total times
     */
    public Map<Operation, Integer> getTotalTimeByOperation() {
        return simulator.getTotalTimeByOperation();
    }

    /**
     * Retrieves average times for each operation.
     *
     * @return Map of operations with their average times
     */
    public Map<Operation, Double> getAverageTimeByOperation() {
        return simulator.getAverageTimeByOperation();
    }
    /**
     * Retrieves statistics for each station in the simulation.
     *
     * @return List of station statistics
     */
    public List<StationStatistics> getStationStatistics() {
        return simulator.createStationStatistics();
    }

    public Simulator getSimulator() {
        return simulator;
    }

    /**
     * Resets each station to its initial state.
     *
     * @param stations List of stations to reset
     */
    public void restartStations(List<Station> stations){
        for (Station station:
             stations) {
            station.reset();
        }
    }
    public Map<esinf.domain.Station, List<esinf.domain.Station>> processFlowDependency() {
        Map<Product, List<Station>> flowDependencies = simulator.getFlowDependencies();
        Map<esinf.domain.Station, List<esinf.domain.Station>> flow = new HashMap<>();
        for (Map.Entry<esinf.domain.Product, List<esinf.domain.Station>> flowDependency
                :
                flowDependencies.entrySet()) {
            List<esinf.domain.Station> stationList = flowDependency.getValue();
            for (int i = 0; i < stationList.size(); i++) {
                flow.putIfAbsent(stationList.get(i), new ArrayList<Station>());
                if(i + 1 < stationList.size() - 1){
                    List<esinf.domain.Station> flowStations = flow.get(stationList.get(i));
                    if(!flowStations.contains(stationList.get(i + 1)))
                        flowStations.add(stationList.get(i + 1));
                }
            }
        }
        return flow;
    }
}
