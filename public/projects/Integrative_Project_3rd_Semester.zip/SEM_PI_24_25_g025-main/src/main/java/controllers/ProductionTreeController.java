package controllers;

import esinf.domain.BOM;
import esinf.domain.BOO;
import esinf.domain.Operation;
import esinf.domain.Product;
import esinf.domain.ProductionTreeBuilder;
import esinf.utils.ItemsReader;
import esinf.utils.OperationsReader;
import esinf.utils.BooBomReader;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ProductionTreeController {
    public void buildProductionTree(String itemsPath, String operationsPath, String booPath) throws IOException {
        List<Product> items = ItemsReader.readCSV(itemsPath);
        List<Operation> operations = OperationsReader.readCSV(operationsPath);
        List<BOO> booList = new ArrayList<>();
        List<BOM> bomList = new ArrayList<>();
        BooBomReader.readCSVAndParse(booPath, operations, items, booList, bomList);
        ProductionTreeBuilder.buildTrees(booList, bomList);
    }
}
