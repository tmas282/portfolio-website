package controllers;

import bddad.Functions.ListPartsByPart;

public class GetPartsByPartController {
    private ListPartsByPart listPartsByPart;

    public GetPartsByPartController(){
        listPartsByPart = new ListPartsByPart();
    }

    public void getPartsByPart(String partCode){
        listPartsByPart.getProductParts(partCode);
    }
}
