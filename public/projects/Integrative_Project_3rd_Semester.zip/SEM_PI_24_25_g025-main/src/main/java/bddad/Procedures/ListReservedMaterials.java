package bddad.Procedures;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ListReservedMaterials
{
    private static List<String> getDbmsOutput(Connection conn) throws SQLException{
        List<String> dbmsLines = new ArrayList<>();
        CallableStatement stmt = conn.prepareCall(
                "declare " +
                        " l_line varchar2(1000); " +
                        " l_done number; " +
                        " l_buffer long; " +
                        "begin " +
                        " loop " +
                        " exit when length(l_buffer)+255 > :maxbytes OR l_done = 1; " +
                        " dbms_output.get_line( l_line, l_done ); " +
                        " l_buffer := l_buffer || l_line || chr(10); " +
                        " end loop; " +
                        " :done := l_done; " +
                        " :buffer := l_buffer; " +
                        "end;" );
        int done = 0;

        stmt.registerOutParameter( 2, java.sql.Types.INTEGER );
        stmt.registerOutParameter( 3, java.sql.Types.VARCHAR );

        do {
            stmt.setInt(1, 32000);
            stmt.executeUpdate();
            dbmsLines.add(stmt.getString(3));
        } while ((done = stmt.getInt(2)) != 1);

        stmt.close();
        return dbmsLines;
    }
    public static List<String> reservedMaterials(Connection conn) throws SQLException {
        conn.prepareStatement("BEGIN DBMS_OUTPUT.ENABLE(); END;").execute();
        String sql = "BEGIN ListReservedMaterials(); END;";
        try (CallableStatement stmt = conn.prepareCall(sql)) {
            stmt.execute();
        }
        return getDbmsOutput(conn);
    }
}
