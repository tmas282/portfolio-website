package bddad.Functions;

import bddad.db.DatabaseConnection;
import oracle.jdbc.OracleTypes;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ListPartsByPart {
    public void getProductParts(String partCode) {
        String functionCall = "{ ? = call GetProductParts(?) }";

        try (Connection conn = DatabaseConnection.getConnection();
             CallableStatement stmt = conn.prepareCall(functionCall)) {

            // Register the return type as a cursor
            stmt.registerOutParameter(1, OracleTypes.CURSOR);
            stmt.setString(2, partCode);

            // Execute the function
            stmt.execute();

            // Process the returned cursor
            try (ResultSet rs = (ResultSet) stmt.getObject(1)) {
                System.out.println("Parts for Product Code: " + partCode);

                // Check if the result set is empty
                if (!rs.isBeforeFirst()) { // No rows in the result set
                    System.out.println("No parts found for the provided Product Code.");
                } else {
                    // Loop through the result set and print the data
                    while (rs.next()) {
                        String partCodeRes = rs.getString("part_code");
                        String partName = rs.getString("part_name");
                        int quantity = rs.getInt("input_quantity"); // Use "output_quantity" if necessary
                        String unit = rs.getString("unit");
                        System.out.printf("Part: %s, Name: %s, Quantity: %d, Unit: %s%n",
                                partCodeRes, partName, quantity, unit);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }
/*
    public static void main(String[] args) {
        ListPartsByPart service = new ListPartsByPart();
        service.getProductParts("AS12945T22"); // Replace with an actual part code
    }

 */
}

