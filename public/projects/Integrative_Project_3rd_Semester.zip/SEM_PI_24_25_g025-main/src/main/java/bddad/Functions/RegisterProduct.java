package bddad.Functions;

import bddad.db.DatabaseConnection;

import java.sql.*;
import java.sql.Date;
import java.util.*;

public class RegisterProduct {

    private Scanner scanner = new Scanner(System.in);

    public void registerProduct() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            System.out.println("Connected to the database!");
            System.out.println("Id do produto:");
            String IdProduct = scanner.nextLine();
            System.out.println("Descricao do produto:");
            String DescricaoProduct = scanner.nextLine();
            System.out.println("Id do tipo de produto:");
            String IdTipoId = scanner.nextLine();
            System.out.println("Id da familia:");
            int IdFamilia = scanner.nextInt();

            insertProduct(connection, IdProduct, DescricaoProduct, IdTipoId,IdFamilia);

            System.out.println("Product registered successfully with ID: " + IdProduct);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void insertProduct(Connection connection,String IdProduct,String DescricaoProduct,String IdTipoId,int IdFamilia) throws SQLException {
        String insertProductSQL = "INSERT INTO Part (Code, Description, PartTypeID, FamilyID) VALUES (?,?,?,?)";

        // Insert the client order
        try (PreparedStatement productStmt = connection.prepareStatement(insertProductSQL)) {
            productStmt.setString(1, IdProduct);
            productStmt.setString(2, DescricaoProduct);
            productStmt.setString(3, IdTipoId);
            productStmt.setInt(4, IdFamilia);
            productStmt.executeUpdate();
        }
    }
}
