package bddad.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import bddad.db.DatabaseConnection;
import org.apache.poi.ss.usermodel.*;
import org.w3c.dom.*;

import static bddad.db.DatabaseConnection.*;

public class XMLPartReader {

    // This method is used to load the BOO data from the XML file into the database

    @SuppressWarnings("t")
    public void loadBOOFromXML(String xmlFilePath) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            System.out.println("Connected to the database!");

            File xmlFile = new File(xmlFilePath);
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(xmlFile);
            document.getDocumentElement().normalize();

            NodeList booNodes = document.getElementsByTagName("boo");

            String insertBOOSQL = "INSERT INTO BOO (PartCode) VALUES (?)";
            String insertOperationSQL = "INSERT INTO Operation (ID, OperationTypeID, NextOperationID, BOOPartCode, EstimatedTime) VALUES (?, ?, NULL, ?, ?)";
            String updateNextOperationSQL = "UPDATE Operation SET NextOperationID = ? WHERE ID = ?";
            String insertInputSQL = "INSERT INTO OperationInput (OperationID, Quantity, PartCode) VALUES (?, ?, ?)";
            String insertOutputSQL = "INSERT INTO OperationOutput (OperationID, Quantity, PartCode) VALUES (?, ?, ?)";

            Map<Integer, Integer> nextOperationMap = new HashMap<>();

            for (int i = 0; i < booNodes.getLength(); i++) {
                Element booElement = (Element) booNodes.item(i);

                // Insert BOO part
                String booId = booElement.getAttribute("id").replace("\"", "");
                try (PreparedStatement booStmt = connection.prepareStatement(insertBOOSQL)) {
                    booStmt.setString(1, booId);
                    booStmt.executeUpdate();
                    System.out.println("Inserted BOO part: " + booId);
                }

                // Process operations
                NodeList operationNodes = booElement.getElementsByTagName("operation");
                for (int j = 0; j < operationNodes.getLength(); j++) {
                    Element operationElement = (Element) operationNodes.item(j);

                    int operationId = Integer.parseInt(operationElement.getAttribute("id"));
                    int operationTypeId = Integer.parseInt(getTagValue("optype_id", operationElement));
                    int estimatedTime = Integer.parseInt(getTagValue("eet", operationElement));
                    String nextOperationIdStr = getTagValue("next_op", operationElement);

                    // Store next operation mapping
                    if (!"None".equals(nextOperationIdStr)) {
                        int nextOperationId = Integer.parseInt(nextOperationIdStr);
                        nextOperationMap.put(operationId, nextOperationId);
                    }

                    // Insert operation with NULL for NextOperationID
                    try (PreparedStatement operationStmt = connection.prepareStatement(insertOperationSQL)) {
                        operationStmt.setInt(1, operationId);
                        operationStmt.setInt(2, operationTypeId);
                        operationStmt.setString(3, booId);
                        operationStmt.setInt(4, estimatedTime);
                        operationStmt.executeUpdate();
                        System.out.println("Inserted operation: " + operationId);
                    }

                    // Process inputs
                    NodeList inputNodes = operationElement.getElementsByTagName("input");
                    for (int k = 0; k < inputNodes.getLength(); k++) {
                        Element inputElement = (Element) inputNodes.item(k);
                        String partCode = getTagValue("part", inputElement).replace("\"", "");
                        int quantity = Integer.parseInt(getTagValue("quantity", inputElement));
                        String unitDescription = getTagValue("unit", inputElement).replace("\"", "");

                        //Update part with unit
                        updatePartWithUnit(connection, partCode, unitDescription);

                        try (PreparedStatement inputStmt = connection.prepareStatement(insertInputSQL)) {
                            inputStmt.setInt(1, operationId);
                            inputStmt.setInt(2, quantity);
                            inputStmt.setString(3, partCode);
                            inputStmt.executeUpdate();
                            System.out.println("Inserted input for operation " + operationId + ": " + partCode);
                        }
                    }

                    // Process output
                    Element outputElement = (Element) operationElement.getElementsByTagName("output").item(0);
                    String partCode = getTagValue("part", outputElement).replace("\"", "");
                    int quantity = Integer.parseInt(getTagValue("quantity", outputElement));
                    String unitDescription = getTagValue("unit", outputElement).replace("\"", "");

                    //Update part with unit
                    updatePartWithUnit(connection, partCode, unitDescription);

                    try (PreparedStatement outputStmt = connection.prepareStatement(insertOutputSQL)) {
                        outputStmt.setInt(1, operationId);
                        outputStmt.setInt(2, quantity);
                        outputStmt.setString(3, partCode);
                        outputStmt.executeUpdate();
                        System.out.println("Inserted output for operation " + operationId + ": " + partCode);
                    }
                }
            }

            // Update NextOperationID for all operations
            for (Map.Entry<Integer, Integer> entry : nextOperationMap.entrySet()) {
                int currentOperationId = entry.getKey();
                int nextOperationId = entry.getValue();

                String checkOperationSQL = "SELECT COUNT(*) FROM Operation WHERE ID = ?";

                boolean currentOperationExists = false;
                boolean nextOperationExists = false;

                // Check if current operation exists
                try (PreparedStatement checkStmt = connection.prepareStatement(checkOperationSQL)) {
                    checkStmt.setInt(1, currentOperationId);
                    try (ResultSet resultSet = checkStmt.executeQuery()) {
                        if (resultSet.next() && resultSet.getInt(1) > 0) {
                            currentOperationExists = true;
                        }
                    }
                }

                // Check if next operation exists
                try (PreparedStatement checkStmt = connection.prepareStatement(checkOperationSQL)) {
                    checkStmt.setInt(1, nextOperationId);
                    try (ResultSet resultSet = checkStmt.executeQuery()) {
                        if (resultSet.next() && resultSet.getInt(1) > 0) {
                            nextOperationExists = true;
                        }
                    }
                }

                if (!currentOperationExists || !nextOperationExists) {
                    System.out.println("Skipping update for NextOperationID. " +
                            "Current operation ID: " + currentOperationId + " exists: " + currentOperationExists +
                            ", Next operation ID: " + nextOperationId + " exists: " + nextOperationExists);
                    continue; // Skip to the next entry
                }

                // Update NextOperationID
                try (PreparedStatement updateStmt = connection.prepareStatement(updateNextOperationSQL)) {
                    updateStmt.setInt(1, nextOperationId);
                    updateStmt.setInt(2, currentOperationId);
                    updateStmt.executeUpdate();
                    System.out.println("Updated NextOperationID for operation " + currentOperationId + " to " + nextOperationId);
                } catch (SQLException e) {
                    System.out.println("Failed to update NextOperationID for operation " + currentOperationId +
                            " to " + nextOperationId + ": " + e.getMessage());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updatePartWithUnit(Connection connection, String partCode, String unitDescription) throws SQLException {
        String getUnitIdSQL = "SELECT ID FROM Unit WHERE LOWER(Description) = LOWER(?)";
        String insertUnitSQL = "INSERT INTO Unit (Description) VALUES (?)";
        String updatePartSQL = "UPDATE Part SET UnitID = ? WHERE Code = ?";

        int unitId = 0;
        try {
            unitId = getOrCreateUnitId(connection, getUnitIdSQL, insertUnitSQL, unitDescription);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        try (PreparedStatement updateStmt = connection.prepareStatement(updatePartSQL)) {
            updateStmt.setInt(1, unitId);
            updateStmt.setString(2, partCode);
            updateStmt.executeUpdate();
            System.out.println("Updated part " + partCode + " with unit ID: " + unitId);
        }
    }
    private int getOrCreateUnitId(Connection connection, String getUnitIdSQL, String insertUnitSQL, String description) throws Exception {
        // Check if the unit already exists
        try (PreparedStatement stmt = connection.prepareStatement(getUnitIdSQL)) {
            stmt.setString(1, description);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1); // Return existing ID
                }
            }
        }

        // Unit doesn't exist, so insert it
        try (PreparedStatement insertStmt = connection.prepareStatement(insertUnitSQL)) {
            insertStmt.setString(1, description);
            insertStmt.executeUpdate();
            System.out.println("Inserted unit: " + description);
        }

        // Retrieve the ID of the newly inserted unit
        try (PreparedStatement stmt = connection.prepareStatement(getUnitIdSQL)) {
            stmt.setString(1, description);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1); // Return the newly inserted ID
                } else {
                    throw new Exception("Failed to retrieve newly inserted unit ID: " + description);
                }
            }
        }
    }

    // This method is used to load the operations data from the XML file into the database

    public void loadOperationsFromXML(String xmlFilePath) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            System.out.println("Connected to the database!");

            File xmlFile = new File(xmlFilePath);
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(xmlFile);
            document.getDocumentElement().normalize();

            NodeList operationNodes = document.getElementsByTagName("operation_type");

            // SQL statements
            String insertOperationTypeSQL = "INSERT INTO OperationType (ID, Description) VALUES (?, ?)";
            String insertWorkstationTypeSQL = "INSERT INTO WorkstationType (ID, Name) VALUES (?, ?)";
            String insertWorkstationTypeOperationSQL =
                    "INSERT INTO WorkstationTypeOperation (OperationTypeID, WorkstationTypeID) VALUES (?, ?)";
            String checkWorkstationTypeExistsSQL = "SELECT 1 FROM WorkstationType WHERE ID = ?";

            for (int i = 0; i < operationNodes.getLength(); i++) {
                Node operationNode = operationNodes.item(i);

                if (operationNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element operationElement = (Element) operationNode;

                    // Extract operation type details
                    String operationId = operationElement.getAttribute("id");
                    String operationDesc = getTagValue("operation_desc", operationElement);

                    // Insert into OperationType table
                    try (PreparedStatement preparedStatement = connection.prepareStatement(insertOperationTypeSQL)) {
                        preparedStatement.setInt(1, Integer.parseInt(operationId));
                        preparedStatement.setString(2, operationDesc.replace("\"", ""));
                        preparedStatement.executeUpdate();
                        System.out.println("Inserted operation type: " + operationId);
                    }

                    // Insert into WorkstationTypeOperation table
                    NodeList workstationNodes = operationElement.getElementsByTagName("workstation_type");
                    for (int j = 0; j < workstationNodes.getLength(); j++) {
                        String workstationTypeId = workstationNodes.item(j).getTextContent().replace("\"", "");

                        // Check if WorkstationType exists
                        boolean workstationExists = false;
                        try (PreparedStatement checkStmt = connection.prepareStatement(checkWorkstationTypeExistsSQL)) {
                            checkStmt.setString(1, workstationTypeId);
                            try (ResultSet resultSet = checkStmt.executeQuery()) {
                                workstationExists = resultSet.next();
                            }
                        }

                        // Insert into WorkstationType if not exists
                        if (!workstationExists) {
                            try (PreparedStatement preparedStatement = connection.prepareStatement(insertWorkstationTypeSQL)) {
                                preparedStatement.setString(1, workstationTypeId);
                                preparedStatement.setString(2, workstationTypeId); // Using the same ID as the name for simplicity
                                preparedStatement.executeUpdate();
                                System.out.println("Inserted workstation type: " + workstationTypeId);
                            }
                        }

                        // Link OperationType and WorkstationType
                        try (PreparedStatement preparedStatement = connection.prepareStatement(insertWorkstationTypeOperationSQL)) {
                            preparedStatement.setInt(1, Integer.parseInt(operationId));
                            preparedStatement.setString(2, workstationTypeId);
                            preparedStatement.executeUpdate();
                            System.out.println("Linked operation " + operationId + " with workstation " + workstationTypeId);
                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // This method is used to load the parts data from the XML file into the database

    public void loadPartsFromXML(String xmlFilePath) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            System.out.println("Connected to the database!");

            File xmlFile = new File(xmlFilePath);
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(xmlFile);
            document.getDocumentElement().normalize();

            NodeList partNodes = document.getElementsByTagName("part");

            String insertSQL = "INSERT INTO Part (Code, Description, PartTypeID) VALUES (?, ?, ?)";

            for (int i = 0; i < partNodes.getLength(); i++) {
                Node partNode = partNodes.item(i);

                if (partNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element partElement = (Element) partNode;

                    String partNumber = getTagValue("part_number", partElement);
                    String description = getTagValue("description", partElement);
                    String partType = getTagValue("part_type", partElement);

                    int partTypeId = getOrCreatePartTypeId(connection, partType); // Fetch or create PartTypeID

                    try (PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {
                        preparedStatement.setString(1, partNumber.replace("\"", ""));
                        preparedStatement.setString(2, description.replace("\"", ""));
                        preparedStatement.setInt(3, partTypeId);

                        preparedStatement.executeUpdate();
                        System.out.println("Inserted part: " + partNumber);
                    }
                }
            }
            System.out.println("Finished loading parts from XML file!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private int getOrCreatePartTypeId(Connection connection, String partType) throws SQLException {
        String fetchSQL = "SELECT ID FROM PartType WHERE LOWER(Description) = LOWER(?)";
        String insertSQL = "INSERT INTO PartType (Description) VALUES (?)";
        String fetchInsertedSQL = "SELECT ID FROM PartType WHERE LOWER(Description) = LOWER(?)";

        // Try fetching the PartTypeID
        try (PreparedStatement fetchStmt = connection.prepareStatement(fetchSQL)) {
            fetchStmt.setString(1, partType.replace("\"", ""));
            try (ResultSet resultSet = fetchStmt.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getInt("ID");
                }
            }
        }

        // If not found, insert the new part type
        try (PreparedStatement insertStmt = connection.prepareStatement(insertSQL)) {
            insertStmt.setString(1, partType.replace("\"", ""));
            insertStmt.executeUpdate();
        }

        // Fetch the inserted PartTypeID
        try (PreparedStatement fetchInsertedStmt = connection.prepareStatement(fetchInsertedSQL)) {
            fetchInsertedStmt.setString(1, partType.replace("\"", ""));
            try (ResultSet resultSet = fetchInsertedStmt.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getInt("ID"); // Return the newly created ID
                }
            }
        }

        throw new SQLException("Failed to fetch or create PartTypeID for: " + partType);
    }


    private String getTagValue(String tag, Element element) {
        NodeList nodeList = element.getElementsByTagName(tag);
        if (nodeList.getLength() > 0) {
            return nodeList.item(0).getTextContent();
        }
        return null;
    }

    // This method is used to load the clients data from the XML file into the database
    public void loadClientsFromXML(String xmlFilePath) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            System.out.println("Connected to the database!");

            File xmlFile = new File(xmlFilePath);
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(xmlFile);
            document.getDocumentElement().normalize();

            NodeList clientNodes = document.getElementsByTagName("client");

            String insertZipSQL = "INSERT INTO ZIP (Code, Town, Country) VALUES (?, ?, ?)";
            String insertAddressSQL = "INSERT INTO Address (Street, ZIPCode) VALUES (?, ?)";
            String insertClientSQL = "INSERT INTO Client (ID, Name, VATIN, Email, Phone, Status, AddressID) VALUES (?, ?, ?, ?, ?, ?, ?)";
            String selectAddressSQL = "SELECT ID FROM Address WHERE Street = ? AND ZIPCode = ?";

            for (int i = 0; i < clientNodes.getLength(); i++) {
                Element clientElement = (Element) clientNodes.item(i);

                // Extract data from XML
                int clientId = Integer.parseInt(clientElement.getAttribute("ID"));
                String name = getTagValue("name", clientElement).replace("\"", "");
                String vatin = getTagValue("vatin", clientElement).replace("\"", "");
                String address = getTagValue("adress", clientElement).replace("\"", "");
                String zipCode = getTagValue("zip", clientElement).replace("\"", "");
                String town = getTagValue("town", clientElement).replace("\"", "");
                String country = getTagValue("country", clientElement).replace("\"", "");
                String email = getTagValue("email", clientElement).replace("\"", "");
                long phone = Long.parseLong(getTagValue("phone", clientElement).replace("\"", "").substring(3));

                // Ensure ZIP exists
                ensureZipExists(connection, insertZipSQL, zipCode, town, country);

                // Ensure Address exists and get its ID
                int addressId = ensureAddressExists(connection, insertAddressSQL, selectAddressSQL, address, zipCode);

                // Insert Client
                try (PreparedStatement clientStmt = connection.prepareStatement(insertClientSQL)) {
                    clientStmt.setInt(1, clientId);
                    clientStmt.setString(2, name);
                    clientStmt.setString(3, vatin);
                    clientStmt.setString(4, email);
                    clientStmt.setLong(5, phone);
                    clientStmt.setString(6, "Active");
                    clientStmt.setInt(7, addressId);
                    clientStmt.executeUpdate();
                    System.out.println("Inserted client: " + clientId);
                }
            }
            System.out.println("Finished loading clients from XML file!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void ensureZipExists(Connection connection, String insertZipSQL, String zipCode, String town, String country) throws SQLException {
        String checkZipSQL = "SELECT Code FROM ZIP WHERE Code = ?";
        try (PreparedStatement checkStmt = connection.prepareStatement(checkZipSQL)) {
            checkStmt.setString(1, zipCode);
            try (ResultSet rs = checkStmt.executeQuery()) {
                if (!rs.next()) {
                    try (PreparedStatement insertStmt = connection.prepareStatement(insertZipSQL)) {
                        insertStmt.setString(1, zipCode);
                        insertStmt.setString(2, town);
                        insertStmt.setString(3, country);
                        insertStmt.executeUpdate();
                        System.out.println("Inserted ZIP: " + zipCode);
                    }
                }
            }
        }
    }

    private int ensureAddressExists(Connection connection, String insertAddressSQL, String selectAddressSQL, String address, String zipCode) throws SQLException {
        // Check if the address already exists
        try (PreparedStatement checkStmt = connection.prepareStatement(selectAddressSQL)) {
            checkStmt.setString(1, address);
            checkStmt.setString(2, zipCode);
            try (ResultSet rs = checkStmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("ID");
                }
            }
        }

        // If not found, insert the address
        try (PreparedStatement insertStmt = connection.prepareStatement(insertAddressSQL)) {
            insertStmt.setString(1, address);
            insertStmt.setString(2, zipCode);
            insertStmt.executeUpdate();
        }

        // Fetch the ID of the inserted address
        try (PreparedStatement selectStmt = connection.prepareStatement(selectAddressSQL)) {
            selectStmt.setString(1, address);
            selectStmt.setString(2, zipCode);
            try (ResultSet rs = selectStmt.executeQuery()) {
                if (rs.next()) {
                    int addressId = rs.getInt("ID");
                    System.out.println("Inserted Address: " + address + ", ZIPCode: " + zipCode);
                    return addressId;
                }
            }
        }

        throw new SQLException("Failed to fetch or create Address ID for: " + address);
    }


    private String normalizeDate(String date) {
        if (date == null || "NULL".equalsIgnoreCase(date.trim())) {
            return null; // Return null for "NULL" or empty date values
        }
        return date.replace("/", "-"); // Replace '/' with '-' for compatibility
    }
    @SuppressWarnings("t")
    public void loadProcurementFromXML(String xmlFilePath) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            System.out.println("Connected to the database!");

            File xmlFile = new File(xmlFilePath);
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(xmlFile);
            document.getDocumentElement().normalize();

            NodeList supplierNodes = document.getElementsByTagName("supplier");

            String fetchSupplierSQL = "SELECT ID FROM Supplier WHERE ID = ?";
            String insertSupplierSQL = "INSERT INTO Supplier (ID, Name) VALUES (?, ?)";
            String checkPartSQL = "SELECT COUNT(*) FROM Part WHERE Code = ?";
            String insertOfferSQL = "INSERT INTO Offer (startDate, endDate, price, minQuantity, SupplierID, PartCode) VALUES (?, ?, ?, ?, ?, ?)";

            for (int i = 0; i < supplierNodes.getLength(); i++) {
                Element supplierElement = (Element) supplierNodes.item(i);

                int supplierId = Integer.parseInt(supplierElement.getAttribute("id"));
                String supplierName = supplierId + " - Unknown Supplier";

                if (!fetchOrCreateSupplier(connection, fetchSupplierSQL, insertSupplierSQL, supplierId, supplierName)) {
                    System.out.println("Failed to create or verify supplier: " + supplierName);
                    continue; // Skip processing this supplier
                }

                NodeList partNodes = supplierElement.getElementsByTagName("part");
                for (int j = 0; j < partNodes.getLength(); j++) {
                    Element partElement = (Element) partNodes.item(j);

                    String partCode = partElement.getAttribute("id");

                    boolean partExists;
                    try (PreparedStatement checkPartStmt = connection.prepareStatement(checkPartSQL)) {
                        checkPartStmt.setString(1, partCode);
                        try (ResultSet rs = checkPartStmt.executeQuery()) {
                            rs.next();
                            partExists = rs.getInt(1) > 0;
                        }
                    }

                    if (!partExists) {
                        System.out.println("Part not found: " + partCode + ". Skipping related offers.");
                        continue;
                    }

                    NodeList offerNodes = partElement.getElementsByTagName("offer");
                    for (int k = 0; k < offerNodes.getLength(); k++) {
                        Element offerElement = (Element) offerNodes.item(k);

                        String startDate = normalizeDate(getTagValue("start_date", offerElement));
                        String endDate = normalizeDate(getTagValue("end_date", offerElement));
                        int minQuantity = Integer.parseInt(getTagValue("min_quantity", offerElement));
                        double price = Double.parseDouble(getTagValue("price", offerElement));

                        try (PreparedStatement offerStmt = connection.prepareStatement(insertOfferSQL)) {
                            offerStmt.setDate(1, startDate != null ? Date.valueOf(startDate) : null);
                            offerStmt.setDate(2, endDate != null ? Date.valueOf(endDate) : null);
                            offerStmt.setDouble(3, price);
                            offerStmt.setInt(4, minQuantity);
                            offerStmt.setInt(5, supplierId);
                            offerStmt.setString(6, partCode);
                            offerStmt.executeUpdate();
                            System.out.println("Inserted offer for part: " + partCode + ", supplier: " + supplierId);
                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean fetchOrCreateSupplier(Connection connection, String fetchSQL, String insertSQL, int supplierId, String supplierName) {
        try (PreparedStatement fetchStmt = connection.prepareStatement(fetchSQL)) {
            fetchStmt.setInt(1, supplierId);
            try (ResultSet rs = fetchStmt.executeQuery()) {
                if (rs.next()) {
                    System.out.println("Supplier already exists: " + supplierName);
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

        // Supplier not found, create one
        try (PreparedStatement insertStmt = connection.prepareStatement(insertSQL)) {
            insertStmt.setInt(1, supplierId);
            insertStmt.setString(2, supplierName);
            insertStmt.executeUpdate();
            System.out.println("Inserted new supplier: " + supplierName);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void processExcelFile(String filePath) throws IOException, SQLException {
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = WorkbookFactory.create(fis);
             Connection connection = DatabaseConnection.getConnection()) {

            connection.setAutoCommit(false); // Start transaction

            processProductFamily(workbook.getSheet("ProductFamily"), connection);
            processOrders(workbook.getSheet("Orders"), connection);
            processWorkstationTypes(workbook.getSheet("WorkstationTypes"), connection);
            processWorkstations(workbook.getSheet("Workstations"), connection);

            connection.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void processProductFamily(Sheet sheet, Connection connection) throws SQLException {
        String updateQuery = "UPDATE Family SET Name = ? WHERE ID = ?";
        String insertQuery = "INSERT INTO Family (ID, Name) VALUES (?, ?)";

        try (PreparedStatement updatePs = connection.prepareStatement(updateQuery);
             PreparedStatement insertPs = connection.prepareStatement(insertQuery)) {

            for (Row row : sheet) {
                if (row.getRowNum() == 0) continue; // Skip header row

                int id = (int) row.getCell(0).getNumericCellValue();
                String name = row.getCell(1).getStringCellValue();

                // Try updating first
                updatePs.setString(1, name);
                updatePs.setInt(2, id);
                int rowsUpdated = updatePs.executeUpdate();

                // If no rows updated, perform an insert
                if (rowsUpdated == 0) {
                    insertPs.setInt(1, id);
                    insertPs.setString(2, name);
                    insertPs.executeUpdate();
                }
            }
        }
    }

    private void processOrders(Sheet sheet, Connection connection) throws SQLException {
        String insertOrderQuery = "INSERT INTO ClientOrder (DateOrder, DateDelivery, ClientID) VALUES (?, ?, ?)";
        String selectOrderQuery = "SELECT ID FROM ClientOrder WHERE DateOrder = ? AND DateDelivery = ? AND ClientID = ?";
        String insertOrderProductQuery = "INSERT INTO ClientOrderProduct (Quantity, CustomerOrderID, PartCode) VALUES (?, ?, ?)";

        Map<Integer, Integer> excelToDbOrderMap = new HashMap<>();

        try (PreparedStatement insertOrderPs = connection.prepareStatement(insertOrderQuery);
             PreparedStatement selectOrderPs = connection.prepareStatement(selectOrderQuery);
             PreparedStatement insertOrderProductPs = connection.prepareStatement(insertOrderProductQuery)) {

            for (Row row : sheet) {
                if (row.getRowNum() == 0) continue; // Skip header row

                int excelOrderId = (int) row.getCell(0).getNumericCellValue();
                if (!excelToDbOrderMap.containsKey(excelOrderId)) {
                    int clientId = (int) row.getCell(1).getNumericCellValue();
                    Date dateOrder = parseDateCell(row.getCell(4));
                    Date dateDelivery = parseDateCell(row.getCell(5));

                    // Insert new order
                    insertOrderPs.setDate(1, dateOrder);
                    insertOrderPs.setDate(2, dateDelivery);
                    insertOrderPs.setInt(3, clientId);
                    insertOrderPs.executeUpdate();

                    // Retrieve the ID of the created order
                    selectOrderPs.setDate(1, dateOrder);
                    selectOrderPs.setDate(2, dateDelivery);
                    selectOrderPs.setInt(3, clientId);

                    try (ResultSet rs = selectOrderPs.executeQuery()) {
                        if (rs.next()) {
                            int dbOrderId = rs.getInt("ID");
                            excelToDbOrderMap.put(excelOrderId, dbOrderId);
                        }
                    }
                }

                // Insert order products
                String partCode = row.getCell(2).getStringCellValue();
                double quantity = row.getCell(3).getNumericCellValue();

                insertOrderProductPs.setDouble(1, quantity);
                insertOrderProductPs.setInt(2, excelToDbOrderMap.get(excelOrderId));
                insertOrderProductPs.setString(3, partCode);
                insertOrderProductPs.executeUpdate();
            }
        }
    }
    private Date parseDateCell(Cell cell) {
        try {
            if (cell.getCellType() == CellType.NUMERIC) {
                return new Date(cell.getDateCellValue().getTime());
            } else if (cell.getCellType() == CellType.STRING) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                return new Date(sdf.parse(cell.getStringCellValue()).getTime());
            } else {
                throw new IllegalStateException("Unsupported cell type for date: " + cell.getCellType());
            }
        } catch (ParseException e) {
            throw new IllegalStateException("Error parsing date from cell", e);
        }
    }

    private void processWorkstationTypes(Sheet sheet, Connection connection) throws SQLException {
        String selectQuery = "SELECT COUNT(*) FROM WorkstationType WHERE ID = ?";
        String insertQuery = "INSERT INTO WorkstationType (ID, Name) VALUES (?, ?)";
        String updateQuery = "UPDATE WorkstationType SET Name = ? WHERE ID = ?";

        try (PreparedStatement selectPs = connection.prepareStatement(selectQuery);
             PreparedStatement insertPs = connection.prepareStatement(insertQuery);
             PreparedStatement updatePs = connection.prepareStatement(updateQuery)) {

            for (Row row : sheet) {
                if (row.getRowNum() == 0) continue; // Skip header row

                String id = row.getCell(0).getStringCellValue();
                String name = row.getCell(1).getStringCellValue();

                // Check if the workstation type exists
                selectPs.setString(1, id);
                try (ResultSet rs = selectPs.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        // Update the name if it exists
                        updatePs.setString(1, name);
                        updatePs.setString(2, id);
                        updatePs.executeUpdate();
                    } else {
                        // Insert if it does not exist
                        insertPs.setString(1, id);
                        insertPs.setString(2, name);
                        insertPs.executeUpdate();
                    }
                }
            }
        }
    }

    private void processWorkstations(Sheet sheet, Connection connection) throws SQLException {
        String updateQuery = "UPDATE Workstation SET Name = ?, Description = ?, WorkstationTypeID = ? WHERE ID = ?";
        String insertQuery = "INSERT INTO Workstation (ID, Name, Description, WorkstationTypeID) VALUES (?, ?, ?, ?)";

        try (PreparedStatement updatePs = connection.prepareStatement(updateQuery);
             PreparedStatement insertPs = connection.prepareStatement(insertQuery)) {

            for (Row row : sheet) {
                if (row.getRowNum() == 0) continue; // Skip header row

                int id = (int) row.getCell(0).getNumericCellValue();
                String name = row.getCell(2).getStringCellValue();
                String description = row.getCell(3).getStringCellValue();
                String workstationTypeId = row.getCell(1).getStringCellValue();

                // Try updating first
                updatePs.setString(1, name);
                updatePs.setString(2, description);
                updatePs.setString(3, workstationTypeId);
                updatePs.setInt(4, id);
                int rowsUpdated = updatePs.executeUpdate();

                // If no rows updated, perform an insert
                if (rowsUpdated == 0) {
                    insertPs.setInt(1, id);
                    insertPs.setString(2, name);
                    insertPs.setString(3, description);
                    insertPs.setString(4, workstationTypeId);
                    insertPs.executeUpdate();
                }
            }
        }
    }
}

