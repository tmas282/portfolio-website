package bddad.utils;

import bddad.db.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class BOMGenerator {
    public void createBOMFromOperations() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            System.out.println("Connected to the database!");

            // SQL Queries
            String fetchOutputsSQL = "SELECT PartCode, quantity, OperationID FROM OperationOutput";
            String fetchInputsSQL = "SELECT PartCode, quantity FROM OperationInput WHERE OperationID = ?";
            String fetchBOMSQL = "SELECT PartCode FROM BOM WHERE PartCode = ?";
            String insertBOMSQL = "INSERT INTO BOM (PartCode) VALUES (?)";
            String insertBOMPartSQL = "INSERT INTO BOMPart (quantity, PartCode, BOMPartCode) VALUES (?, ?, ?)";

            // Fetch all outputs
            try (PreparedStatement fetchOutputsStmt = connection.prepareStatement(fetchOutputsSQL);
                 ResultSet outputs = fetchOutputsStmt.executeQuery()) {

                while (outputs.next()) {
                    String outputPartCode = outputs.getString("PartCode");
                    int outputQuantity = outputs.getInt("quantity");
                    int operationId = outputs.getInt("OperationID");

                    // Check if BOM already exists
                    boolean bomExists = false;
                    try (PreparedStatement fetchBOMStmt = connection.prepareStatement(fetchBOMSQL)) {
                        fetchBOMStmt.setString(1, outputPartCode);
                        try (ResultSet bomResult = fetchBOMStmt.executeQuery()) {
                            if (bomResult.next()) {
                                bomExists = true;
                            }
                        }
                    }

                    // Insert BOM if it does not exist
                    if (!bomExists) {
                        try (PreparedStatement insertBOMStmt = connection.prepareStatement(insertBOMSQL)) {
                            insertBOMStmt.setString(1, outputPartCode);
                            insertBOMStmt.executeUpdate();
                            System.out.println("Created BOM for PartCode: " + outputPartCode);
                        }
                    } else {
                        System.out.println("BOM already exists for PartCode: " + outputPartCode);
                    }

                    // Fetch all inputs for the operation
                    try (PreparedStatement fetchInputsStmt = connection.prepareStatement(fetchInputsSQL)) {
                        fetchInputsStmt.setInt(1, operationId);
                        try (ResultSet inputs = fetchInputsStmt.executeQuery()) {
                            while (inputs.next()) {
                                String inputPartCode = inputs.getString("PartCode");
                                int inputQuantity = inputs.getInt("quantity");

                                // Insert BOMPart for each input
                                try (PreparedStatement insertBOMPartStmt = connection.prepareStatement(insertBOMPartSQL)) {
                                    insertBOMPartStmt.setInt(1, inputQuantity);
                                    insertBOMPartStmt.setString(2, inputPartCode);
                                    insertBOMPartStmt.setString(3, outputPartCode);
                                    insertBOMPartStmt.executeUpdate();
                                    System.out.println("Added BOMPart: InputPartCode=" + inputPartCode + ", OutputPartCode=" + outputPartCode + ", Quantity=" + inputQuantity);
                                }
                            }
                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
