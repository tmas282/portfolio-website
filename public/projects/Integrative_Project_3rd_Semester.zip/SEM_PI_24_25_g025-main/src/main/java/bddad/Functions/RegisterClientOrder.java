package bddad.Functions;

import bddad.db.DatabaseConnection;

import java.sql.*;
import java.sql.Date;
import java.util.*;

public class RegisterClientOrder {

    private Scanner scanner = new Scanner(System.in);

    public void registerOrder() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            System.out.println("Connected to the database!");

            // Step 1: Get the Client ID with Active Status
            int clientId = chooseClient(connection);

            // Step 2: Get the Delivery Date
            System.out.println("Enter the delivery date (format: YYYY-MM-DD, or leave empty for no delivery date):");
            String deliveryDateInput = scanner.nextLine().trim();
            Date deliveryDate = deliveryDateInput.isEmpty() ? null : Date.valueOf(deliveryDateInput);

            // Step 3: Get the Number of Products
            System.out.println("How many products do you want to add?");
            int numberOfProducts = Integer.parseInt(scanner.nextLine().trim());

            // Step 4: Collect Product Information
            List<Map<String, Object>> products = new ArrayList<>();
            for (int i = 0; i < numberOfProducts; i++) {
                System.out.println("Adding product " + (i + 1) + " of " + numberOfProducts);

                Map<String, Object> product = new HashMap<>();
                product.put("PartCode", chooseProduct(connection));
                product.put("Quantity", getProductQuantity());

                products.add(product);
            }

            // Step 5: Insert the Order into the Database
            int orderId = insertOrder(connection, clientId, deliveryDate, products);

            System.out.println("Order registered successfully with ID: " + orderId);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private int chooseClient(Connection connection) throws SQLException {
        System.out.println("Choose a client (only active clients):");

        String query = "SELECT ID, Name FROM Client WHERE Status = 'Active'";
        try (PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            Map<Integer, String> clientOptions = new HashMap<>();
            while (rs.next()) {
                int clientId = rs.getInt("ID");
                String clientName = rs.getString("Name");
                clientOptions.put(clientId, clientName);
                System.out.println(clientId + ": " + clientName);
            }

            if (clientOptions.isEmpty()) {
                throw new SQLException("No active clients found.");
            }

            int clientId;
            while (true) {
                System.out.print("Enter the client ID: ");
                clientId = Integer.parseInt(scanner.nextLine().trim());
                if (clientOptions.containsKey(clientId)) {
                    break;
                }
                System.out.println("Invalid client ID. Please choose from the list above.");
            }

            return clientId;
        }
    }

    private String chooseProduct(Connection connection) throws SQLException {
        System.out.println("Choose a product (OperationType = 'Product'):");

        String query = """
        SELECT p.Code, p.Description
        FROM Part p
        JOIN PartType pt ON p.PartTypeID = pt.ID
        WHERE pt.Description = 'Product'
    """;

        try (PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            Map<String, String> productOptions = new HashMap<>();
            while (rs.next()) {
                String productCode = rs.getString("Code");
                String productDescription = rs.getString("Description");
                productOptions.put(productCode, productDescription);
                System.out.println(productCode + ": " + productDescription);
            }

            if (productOptions.isEmpty()) {
                throw new SQLException("No products with OperationType 'product' found.");
            }

            String productCode;
            while (true) {
                System.out.print("Enter the product code: ");
                productCode = scanner.nextLine().trim();
                if (productOptions.containsKey(productCode)) {
                    break;
                }
                System.out.println("Invalid product code. Please choose from the list above.");
            }

            return productCode;
        }
    }

    private int getProductQuantity() {
        System.out.print("Enter the quantity: ");
        return Integer.parseInt(scanner.nextLine().trim());
    }

    private int insertOrder(Connection connection, int clientId, Date deliveryDate, List<Map<String, Object>> products) throws SQLException {
        String insertOrderSQL = "INSERT INTO ClientOrder (DateOrder, DateDelivery, ClientID) VALUES (?, ?, ?)";
        String findOrderSQL = "SELECT ID FROM ClientOrder WHERE ClientID = ? AND (DateDelivery = ? OR (DateDelivery IS NULL AND ? IS NULL))";
        String insertOrderProductSQL = "INSERT INTO ClientOrderProduct (Quantity, CustomerOrderID, PartCode) VALUES (?, ?, ?)";

        // Insert the client order
        try (PreparedStatement orderStmt = connection.prepareStatement(insertOrderSQL)) {
            orderStmt.setDate(1, new java.sql.Date(System.currentTimeMillis())); // Order date is today
            if (deliveryDate != null) {
                orderStmt.setDate(2, deliveryDate);
            } else {
                orderStmt.setNull(2, Types.DATE);
            }
            orderStmt.setInt(3, clientId);
            orderStmt.executeUpdate();
        }

        // Find the inserted order
        int orderId;
        try (PreparedStatement findOrderStmt = connection.prepareStatement(findOrderSQL)) {
            findOrderStmt.setInt(1, clientId);
            if (deliveryDate != null) {
                findOrderStmt.setDate(2, deliveryDate);
                findOrderStmt.setDate(3, deliveryDate);
            } else {
                findOrderStmt.setNull(2, Types.DATE);
                findOrderStmt.setNull(3, Types.DATE);
            }
            try (ResultSet rs = findOrderStmt.executeQuery()) {
                if (rs.next()) {
                    orderId = rs.getInt("ID");
                } else {
                    throw new SQLException("Failed to find the newly created client order.");
                }
            }
        }

        // Insert each product into the ClientOrderProduct table
        for (Map<String, Object> product : products) {
            try (PreparedStatement productStmt = connection.prepareStatement(insertOrderProductSQL)) {
                productStmt.setInt(1, (int) product.get("Quantity"));
                productStmt.setInt(2, orderId);
                productStmt.setString(3, (String) product.get("PartCode"));
                productStmt.executeUpdate();
            }
        }

        return orderId; // Return the order ID
    }
}
