package bddad.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import oracle.jdbc.pool.OracleDataSource;
public class DatabaseConnection {
    private static final String DB_URL = "jdbc:oracle:thin:@//localhost:1521/XE";//"jdbc:oracle:thin:@//localhost:1521/XEPDB1"; // Update with your DB URL
    private static final String DB_USER = "system"; // Replace with your Oracle DB username
    private static final String DB_PASSWORD = "1234"; // Replace with your Oracle DB password

    public static Connection getConnection() throws SQLException {
            OracleDataSource ods = new OracleDataSource();
            ods.setURL(DB_URL);
            ods.setUser(DB_USER);
            ods.setPassword(DB_PASSWORD);
            return ods.getConnection();
            //return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }
}