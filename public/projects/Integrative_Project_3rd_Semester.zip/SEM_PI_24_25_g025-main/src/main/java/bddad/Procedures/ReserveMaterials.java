package bddad.Procedures;

import bddad.db.DatabaseConnection;

import java.sql.*;
import java.util.*;

public class ReserveMaterials {
    private Scanner scanner = new Scanner(System.in);

    public void showAndSelectOrder() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            System.out.println("Connected to the database!");

            // Step 1: Fetch and Display Orders
            List<Map<String, Object>> orders = fetchOrders(connection);

            if (orders.isEmpty()) {
                System.out.println("No orders found in the database.");
                return;
            }

            // Step 2: Allow User to Select an Order
            int selectedOrderId = selectOrder(orders);

            // Step 3: Call ReserveMaterials Procedure
            callReserveMaterialsProcedure(connection, selectedOrderId);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private List<Map<String, Object>> fetchOrders(Connection connection) throws SQLException {
        List<Map<String, Object>> orders = new ArrayList<>();

        String query = "SELECT ID, ClientID, DateOrder, DateDelivery FROM ClientOrder";
        try (PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            System.out.println("Order List:");
            System.out.printf("%-10s %-10s %-20s %-20s\n", "Order ID", "Client ID", "Order Date", "Delivery Date");
            System.out.println("------------------------------------------------------------------------------------");

            while (rs.next()) {
                Map<String, Object> order = new HashMap<>();
                int orderId = rs.getInt("ID");
                order.put("OrderID", orderId);
                order.put("ClientID", rs.getInt("ClientID"));
                order.put("DateOrder", rs.getDate("DateOrder"));
                order.put("DateDelivery", rs.getDate("DateDelivery"));
                orders.add(order);

                System.out.printf("%-10d %-10d %-20s %-20s\n", orderId, order.get("ClientID"), order.get("DateOrder"), order.get("DateDelivery"));
            }
        }

        return orders;
    }

    private int selectOrder(List<Map<String, Object>> orders) {
        int orderId;

        while (true) {
            System.out.print("Enter the Order ID to proceed: ");
            String input = scanner.nextLine().trim(); // Read input first
            try {
                orderId = Integer.parseInt(input);

                // Use a separate final variable inside the lambda
                int finalOrderId = orderId;
                boolean validOrder = orders.stream().anyMatch(order -> (int) order.get("OrderID") == finalOrderId);

                if (validOrder) {
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid Order ID.");
                continue;
            }

            System.out.println("Invalid Order ID. Please select from the displayed list.");
        }

        return orderId;
    }

    private void callReserveMaterialsProcedure(Connection connection, int orderId) throws SQLException {
        String procedureCall = "{ CALL ReserveMaterials(?, ?) }";

        try (CallableStatement callableStatement = connection.prepareCall(procedureCall)) {
            callableStatement.setInt(1, orderId);
            callableStatement.registerOutParameter(2, Types.VARCHAR);

            callableStatement.execute();

            String result = callableStatement.getString(2);
            System.out.println("Procedure Result: " + result);
        }
    }
}
