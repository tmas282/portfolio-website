package UI.UIs.Sprint2.Bddad;

import UI.Utils.Utils;
import oracle.jdbc.OracleTypes;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import static bddad.db.DatabaseConnection.getConnection;

public class RegisterStation_usbd15 implements Runnable{
    public int registerWorkstation(String type, String name, String description) {
        try (Connection conn = getConnection();) {
            CallableStatement stmt = conn.prepareCall("{? = call RegisterWorkstation(?, ?, ?)}");
            stmt.registerOutParameter(1, OracleTypes.NUMBER);
            stmt.setString(2, type);
            stmt.setString(3, name);
            stmt.setString(4, description);
            stmt.execute();

            return stmt.getInt(1);
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
            return 0;
        }
    }
    @Override
    public void run() {
        try {
            String type = Utils.readLineFromConsole("Enter WorkStation Type ID: ");
            String name = Utils.readLineFromConsole("Enter name: ");
            String description = Utils.readLineFromConsole("Enter description: ");

            int result = registerWorkstation(type, name, description);

            if (result == 1) {
                System.out.println("Registered!");
            } else if (result == -1) {
                System.out.println("A WorkStation with that properties already exists.");
            } else {
                System.out.println("Error.");
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
