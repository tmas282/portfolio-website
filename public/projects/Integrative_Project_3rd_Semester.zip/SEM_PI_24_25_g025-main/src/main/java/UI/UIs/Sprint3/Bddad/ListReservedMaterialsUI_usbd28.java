package UI.UIs.Sprint3.Bddad;

import controllers.ListReservedMaterialController;

import java.sql.SQLException;

public class ListReservedMaterialsUI_usbd28 implements Runnable{
    @Override
    public void run() {
        System.out.println("List Reserved Materials:");
        try {
            for(String line : ListReservedMaterialController.getReservedMaterials()){
                System.out.println(line);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
