package UI.UIs.Sprint3.Lapr;

import controllers.SimulationController;
import controllers.SimulatorV2Controller;
import esinf.utils.OrderReader;
import esinf.domain.sprint3.lapr06.WorkstationOperationTimeDAO;
import esinf.domain.sprint3.lapr06.ProductionSimulator;
import esinf.domain.sprint3.lapr06.Order;
import esinf.domain.sprint3.lapr06.WorkstationOperationTime;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * USLP06_UI class handles the user interface for simulating production based on orders and operation times.
 */
public class USLP06_UI implements Runnable {
    private SimulatorV2Controller simulatorController;

    public void run() {
        try {
            simulatorController = new SimulatorV2Controller();
            simulatorController.readOrders("files/orders.csv");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}