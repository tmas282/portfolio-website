package UI.UIs.Sprint1.Esinf;

import controllers.ImportController;
import controllers.SimulationController;
import esinf.domain.Operation;
import esinf.domain.ProductionOrderOperation;

import java.util.Map;
import java.util.Queue;

/**
 * GenerateUI class represents the UI for generating queues.
 */
public class Generate_usei2_UI implements Runnable {

    private SimulationController controller;
    private ImportController importController;

    /**
     * Constructor for GenerateUI.
     *
     * @param importController the import controller
     * @param controller the simulation controller
     */
    public Generate_usei2_UI(ImportController importController, SimulationController controller) {
        this.importController = importController;
        this.controller = controller;
    }

    /**
     * Runs the UI for generating queues.
     */
    public void run() {
        System.out.println();
        System.out.println("Generating Queues...");
        System.out.println();

        Map<Operation, Queue<ProductionOrderOperation>> queues = controller.generateQueues(importController.getProductionOrders());
        controller.addFilesToSimulator(importController.getStations(), importController.getOperationStationMap(), queues);
        System.out.println("Queues generated successfully!");
        System.out.println();
        System.out.println();
    }

    /**
     * Gets the simulation controller.
     *
     * @return the simulation controller
     */
    public SimulationController getController() {
        return controller;
    }
}