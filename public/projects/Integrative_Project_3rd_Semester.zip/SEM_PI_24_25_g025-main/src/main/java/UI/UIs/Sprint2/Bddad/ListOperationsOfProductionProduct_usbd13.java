package UI.UIs.Sprint2.Bddad;

import UI.Utils.Utils;
import oracle.jdbc.OracleTypes;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static bddad.db.DatabaseConnection.getConnection;

public class ListOperationsOfProductionProduct_usbd13 implements Runnable {

    private List<String> getProductsIDs(){
        List<String> ids = new ArrayList<>();

        try (Connection connection = getConnection()) {
            PreparedStatement stmt = connection.prepareStatement("SELECT CODE FROM PRODUCT");
            stmt.execute();
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    ids.add(rs.getString("CODE"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
        return ids;
    }

    private List<String> getOperationsOfProductionProductList(String id){
        List<String> operations = new ArrayList<>();
        try (Connection connection = getConnection();) {
            CallableStatement stmt = connection.prepareCall("{? = call GetProductOperations(?)}");
            stmt.registerOutParameter(1, OracleTypes.CURSOR);
            stmt.setString(2, id);
            stmt.execute();

            ResultSet rs = (ResultSet) stmt.getObject(1);
            while (rs.next()) {
                operations.add(rs.getInt("ID") + " - WorkStation Type -> " + rs.getString("workstation_type_id"));
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
        return operations;
    }
    @Override
    public void run() {
        List<String> ids = getProductsIDs();
        if (ids.isEmpty()) {
            System.out.println("No Products.");
            return;
        }
        String id = Utils.showAndSelectOne(ids, "Select one: ").toString();

        if (id != null) {
            List<String> operations = getOperationsOfProductionProductList(id);
            if (operations.isEmpty()) {
                System.out.println("No operations for: " + id);
            } else {
                operations.forEach(System.out::println);
            }
        }
    }
}
