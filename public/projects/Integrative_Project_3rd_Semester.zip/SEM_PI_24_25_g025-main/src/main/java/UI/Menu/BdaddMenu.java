package UI.Menu;

import UI.UIs.ImportBDDAD_UI;
import UI.UIs.Sprint2.Bddad.*;
import UI.UIs.Sprint3.Bddad.*;
import UI.Utils.Utils;

import java.util.ArrayList;
import java.util.List;

public class BdaddMenu implements Runnable {
    public void run() {
        List<MenuItem> options = new ArrayList<>();

        options.add(new MenuItem("Import Legacy files", new ImportBDDAD_UI()));
        options.add(new MenuItem("Get parts used to produce a product", new GetPartsByPartUI_usbd12()));
        options.add(new MenuItem("Get a list of operations involved in the production of a product", new ListOperationsOfProductionProduct_usbd13()));
        options.add(new MenuItem("Know which all types of machines available in the factory.", new UseAllTypeMachines_usbd14()));
        options.add(new MenuItem("Register a workstation in the system.", new RegisterStation_usbd15()));
        options.add(new MenuItem("Register a Product in the system.", new Register_Product_UI_usbd16()));
        options.add(new MenuItem("Register Client Order", new RegisterClientOrder_UI_usbd17()));
        options.add(new MenuItem("USBD23 - Ensure Execution Time Compliance", new EnsureExecutionTimeComplianceUI_usbd23()));
        options.add(new MenuItem("USBD22 - Test PL/SQL Code", new TestPLSQLCodeUI_usbd22()));
        options.add(new MenuItem("USBD25 - Get Product Operations", new GetProductOperations_usbd25()));

        // Divider between Sprint 2 and Sprint 3 options
        options.add(new MenuItem("---------------------------------------------", () -> System.out.println("Switching to Sprint 3 options")));

        options.add(new MenuItem("Check if an order can be fulfilled", new CheckOrderStock_usbd26()));
        options.add(new MenuItem("Reserve Materials for an Order", new ReserveMaterialsUI_usbd27()));
        options.add(new MenuItem("List all reserved materials and components, their quantity and the ID of the supplier", new ListReservedMaterialsUI_usbd28()));
        options.add(new MenuItem("Get unused workstation types", new GetUnusedWorkstationTypes_usbd29()));
        options.add(new MenuItem("Consume Material", new ConsumeMaterial_usbd30()));

        int option = 0;
        do {
            option = Utils.showAndSelectIndex(options, "\n\n" +
                    "====================================\n" +
                    "              WELCOME!\n" +
                    "====================================");

            if ((option >= 0) && (option < options.size())) {
                options.get(option).run();
            }
        } while (option != -1);
    }
}