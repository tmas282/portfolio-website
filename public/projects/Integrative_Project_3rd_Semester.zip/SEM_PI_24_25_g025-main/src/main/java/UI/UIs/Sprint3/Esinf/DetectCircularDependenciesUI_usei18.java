package UI.UIs.Sprint3.Esinf;

import controllers.GraphController;


public class DetectCircularDependenciesUI_usei18 implements Runnable {

    private GraphController graphController;

    public DetectCircularDependenciesUI_usei18(GraphController graphController) {
        this.graphController = graphController;
    }
    public void run() {
        System.out.println("Checking for circular dependencies...");

        try {

            // Verifica se existem ciclos
            if (!graphController.hasCircularDependencies(graphController.getGraph())) {
                System.out.println("The graph has circular dependencies.");
            } else {
                System.out.println("The graph has no circular dependencies.");
            }
        } catch (IllegalStateException e) {
            System.out.println("Error: No graph is available. Build the graph first.");
        }
    }
}