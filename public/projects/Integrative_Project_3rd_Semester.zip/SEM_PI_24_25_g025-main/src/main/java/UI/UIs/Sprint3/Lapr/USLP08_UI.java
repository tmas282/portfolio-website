package UI.UIs.Sprint3.Lapr;

import controllers.SimulatorV2Controller;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedList;

public class USLP08_UI implements Runnable {

    private SimulatorV2Controller simulatorController;

    public USLP08_UI() {
        try {
            this.simulatorController = new SimulatorV2Controller();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        System.out.println("\n--- Exportar resultados do simulador para arquivo de texto ---\n");
        try {
            // Executar simulação
            System.out.println("Executando o simulador...");
            String itemId = "item123"; // Exemplo de ID de item
            String priority = "Alta";  // Exemplo de prioridade
            int quantity = 100;        // Exemplo de quantidade

            simulatorController.runSimulator(itemId, priority, quantity);

            // Obter resultados
            LinkedList<String> operationsByDependency = simulatorController.getOperationsByDependency();

            // Exportar resultados para arquivo de texto
            System.out.println("Exportando resultados para arquivo de texto...");
            exportResultsToTextFile(operationsByDependency);

            System.out.println("Resultados exportados com sucesso para o arquivo 'simulator_results.txt'.");
        } catch (Exception e) {
            System.err.println("Erro ao executar ou exportar os resultados: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void exportResultsToTextFile(LinkedList<String> operationsByDependency) throws IOException {
        String filePath = "prodPlanSimulator/src/main/java/org/example/Files/ESINF/Sprint3/simulator_results.txt";

        try (FileWriter writer = new FileWriter(filePath)) {
            for (String operation : operationsByDependency) {
                writer.write(operation + "\n");
            }
        }
    }
}