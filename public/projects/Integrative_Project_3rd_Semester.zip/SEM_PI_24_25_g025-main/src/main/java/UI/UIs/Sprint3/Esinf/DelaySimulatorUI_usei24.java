package UI.UIs.Sprint3.Esinf;

import controllers.GraphController;

public class DelaySimulatorUI_usei24 implements Runnable {
    private GraphController controller;

    public DelaySimulatorUI_usei24(GraphController controller) {
        this.controller = controller;
    }

    public void run() {
        System.out.println("Simulate delay in the project.");
        controller.simulateDelay();
    }
}
