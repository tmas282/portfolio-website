package UI.UIs.Sprint2.Esinf;

import controllers.TreeProductionController;

public class BuildProductionTree_usei8_UI implements Runnable {
    private TreeProductionController productionTreeController;

    public BuildProductionTree_usei8_UI(TreeProductionController productionTreeController) {
        this.productionTreeController = productionTreeController;
    }

    public void run() {
        System.out.println("Build Production Tree");
        System.out.println("Building production tree...");
        productionTreeController.buildProductionTree();
        System.out.println("Production tree built successfully!");
        productionTreeController.printProductionTree();
    }
}
