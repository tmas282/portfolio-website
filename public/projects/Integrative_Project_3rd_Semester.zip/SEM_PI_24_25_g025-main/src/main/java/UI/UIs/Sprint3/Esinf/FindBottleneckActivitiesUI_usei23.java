package UI.UIs.Sprint3.Esinf;

import controllers.GraphController;
import esinf.domain.sprint3.Activity;

import java.util.*;


public class FindBottleneckActivitiesUI_usei23 implements Runnable {

    private GraphController graphController;

    public FindBottleneckActivitiesUI_usei23(GraphController graphController) {
        this.graphController = graphController;
    }

    public void run() {
        try {
            // Obter o grafo e os caminhos críticos
            var graph = graphController.getGraph();
            Collection<LinkedList<Activity>> criticalPaths = graphController.getCriticalPaths();

            // Identificar atividades gargalos
            Map<Activity, Integer> bottlenecks = graphController.findBottleneckActivities(graph, criticalPaths);

            // Permitir ao utilizador escolher entre Top 5 ou todas as atividades
            Scanner scanner = new Scanner(System.in);
            System.out.println("Choose an option:");
            System.out.println("1. Show Top 5 Bottleneck Activities");
            System.out.println("2. Show All Bottleneck Activities");
            String choice = scanner.nextLine();

            if ("1".equals(choice)) {
                System.out.println("Top 5 Bottleneck Activities:");
                bottlenecks.entrySet()
                        .stream()
                        .sorted(Map.Entry.<Activity, Integer>comparingByValue().reversed()) // Ordenar por score decrescente
                        .limit(5) // Limitar ao Top 5
                        .forEach(entry -> System.out.printf("Activity: %s, Score: %d%n", entry.getKey(), entry.getValue()));
            } else if ("2".equals(choice)) {
                System.out.println("All Bottleneck Activities:");
                bottlenecks.entrySet()
                        .stream()
                        .sorted(Map.Entry.<Activity, Integer>comparingByValue().reversed()) // Ordenar por score decrescente
                        .forEach(entry -> System.out.printf("Activity: %s, Score: %d%n", entry.getKey(), entry.getValue()));
            } else {
                System.out.println("Invalid choice. Please select either 1 or 2.");
            }

        } catch (IllegalStateException e) {
            System.out.println("Error: Graph is not initialized. Please build the graph first.");
        }
    }
}