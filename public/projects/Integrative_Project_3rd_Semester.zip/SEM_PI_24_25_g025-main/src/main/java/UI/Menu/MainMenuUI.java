package UI.Menu;

import UI.UIs.*;
import UI.UIs.Sprint1.Esinf.ImportUI;
import UI.UIs.Sprint3.Lapr.USLP06_UI;
import UI.UIs.Sprint3.Lapr.USLP07_UI;
import UI.UIs.Sprint3.Lapr.USLP08_UI;
import UI.Utils.Utils;
import controllers.GraphController;
import controllers.SimulationController;
import controllers.SimulatorV2Controller;
import esinf.domain.sprint2.*;
import esinf.utils.FileReaderUtility;

import java.util.List;
import java.util.ArrayList;

/**
 * MainMenuUI class represents the main menu of the application.
 * It provides various options for the user to interact with the system.
 */
public class MainMenuUI implements Runnable {

    private TreeProductionBuilder builder;
    private QualityCheckManager qualityCheckManager;
    private SearchUtility searchUtility;
    private GraphController graphController;
    private SimulationController simulationController;

    /**
     * Constructor for MainMenuUI.
     */
    public MainMenuUI() {
        try {
            // Initialize the reader to load data from the files
            FileReaderUtility reader = new FileReaderUtility();

            // Replace these file paths with your actual file paths
            String operationsFilePath = "./files/operations.csv";
            String itemsFilePath = "./files/items.csv";
            String booFilePath = "./files/boo_v2.csv";

            // Read the data
            reader.readOperationsFile(operationsFilePath);
            reader.readItemsFile(itemsFilePath);
            reader.readBOOFile(booFilePath);

            // Resolve operation dependencies into product dependencies
            reader.resolveOperationDependenciesToProducts(reader.booEntries);

            // Initialize the production tree builder
            builder = new TreeProductionBuilder(reader.itemsMap, reader.operationsMap);

            // Build the production tree using a root product ID
            String rootProductId = "1006"; // Replace with your desired root product ID
            TreeNode root = builder.buildTree(rootProductId, reader.booEntries);

            // Initialize the QualityCheckManager
            qualityCheckManager = new QualityCheckManager();

            // Initialize the SearchUtility
            searchUtility = new SearchUtility(builder);

            // Initialize controllers
            graphController = new GraphController();
            simulationController = new SimulationController();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Runs the main menu, displaying options and handling user input.
     */
    public void run() {
        List<MenuItem> options = new ArrayList<MenuItem>();
        ImportUI importUI = new ImportUI();
        options.add(new MenuItem("Import Files", importUI));
        options.add(new MenuItem("Simulator Menu", new SimulatorMenuUI_esinfSprint1()));
        options.add(new MenuItem("Production Tree Menu", new ProductionTreeUI_esinfSprint2()));
        options.add(new MenuItem("Graph Menu", new GraphMenuUI_esinfSprint3()));
        options.add(new MenuItem("USLP03 - Visualize Product Structure", new USLP03_UI(builder)));
        options.add(new MenuItem("USLP06 - Simulate Production", new USLP06_UI()));
        options.add(new MenuItem("USLP07 - Update Average Production Times in Oracle DB", new USLP07_UI()));
        options.add(new MenuItem("USLP08 - Export Production Planner Simulator Results to Text File", new USLP08_UI()));

        options.add(new MenuItem("Database Menu", new BdaddMenu()));

        int option = 0;
        do {
            option = Utils.showAndSelectIndex(options, "\n\n" +
                    "====================================\n" +
                    "              WELCOME!\n" +
                    "====================================");

            if ((option >= 0) && (option < options.size())) {
                options.get(option).run();
            }
        } while (option != -1);
    }
}