package UI.UIs;

import controllers.ImportBddadController;

import java.io.IOException;
import java.sql.SQLException;

public class ImportBDDAD_UI implements Runnable {
    private ImportBddadController controller;
    private final String xmlPartFilePath="./files/parts.xml";
    private final String xmlOperationFilePath="./files/operations.xml";
    private final String xmlBooFilePath="./files/boo.xml";
    private final String xmlClientFilePath="./files/clients.xml";
    private final String xmlProcurementFilePath="./files/procurement.xml";
    private final String excelFilePath="./files/Dataset02.xlsx";

    public ImportBDDAD_UI() {
        this.controller = new ImportBddadController();
    }

    public void run() {
        System.out.println("Importing BDDAD");
        try {
            controller.importBDDAD(xmlPartFilePath, xmlOperationFilePath, xmlBooFilePath, xmlClientFilePath, xmlProcurementFilePath, excelFilePath);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
