package UI.UIs.Sprint1.Esinf;

import controllers.SimulationController;
import esinf.domain.Operation;

import java.util.Map;

/**
 * USEI4_UI class represents the UI for displaying execution times by each operation.
 */
public class ExecutionTimes_usei4_UI implements Runnable {
    private SimulationController simulationController;

    /**
     * Constructor for USEI4_UI.
     *
     * @param simulationController the simulation controller
     */
    public ExecutionTimes_usei4_UI(SimulationController simulationController) {
        this.simulationController = simulationController;
    }

    /**
     * Runs the UI for displaying execution times by each operation.
     */
    public void run() {
        System.out.println("USEI4 - Execution times by each operation");
        System.out.println("====================================");
        Map<Operation, Integer> executionTimes = simulationController.getTotalTimeByOperation();
        System.out.println("Operation - Execution Time");
        for (Map.Entry<Operation, Integer> entry : executionTimes.entrySet()) {
            System.out.println(entry.getKey().getOperationTypeID() + " - " + entry.getValue());
        }
    }
}