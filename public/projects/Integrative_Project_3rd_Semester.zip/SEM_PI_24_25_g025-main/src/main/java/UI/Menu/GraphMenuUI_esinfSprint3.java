package UI.Menu;

import UI.UIs.Sprint3.Esinf.*;
import UI.Utils.Utils;
import controllers.GraphController;

import java.util.ArrayList;
import java.util.List;

public class GraphMenuUI_esinfSprint3 implements Runnable {

    public void run() {
        List<MenuItem> options = new ArrayList<>();

        GraphController graphController = new GraphController();

        options.add(new MenuItem("Build PERT/CPM Graph", new BuildGraphUI_usei17(graphController)));
        options.add(new MenuItem("Detect Circular Dependencies", new DetectCircularDependenciesUI_usei18(graphController)));
        options.add(new MenuItem("Topological Sort", new TopologicalSortUI_usei19(graphController)));
        options.add(new MenuItem("Earliest, Latest Times and Finish Times", new ScheduleAnalysisUI_usei20(graphController)));
        options.add(new MenuItem("Export project Schedule to CSV", new ExportScheduleToCSVUI_usei21(graphController)));
        options.add(new MenuItem("Identify the Critical Path", new IdentifyCriticalPathUI_usei22(graphController)));
        options.add(new MenuItem("Find Bottleneck Activities", new FindBottleneckActivitiesUI_usei23(graphController)));
        options.add(new MenuItem("Simulate Activity Delays", new DelaySimulatorUI_usei24(graphController)));

        int option = 0;
        do {
            option = Utils.showAndSelectIndex(options, "\n\n" +
                    "====================================\n" +
                    "              WELCOME!\n" +
                    "====================================");

            if ((option >= 0) && (option < options.size())) {
                options.get(option).run();
            }
        } while (option != -1);
    }
}
