package UI.UIs.Sprint1.Esinf;

import controllers.SimulationController;

/**
 * USEI3_UI class represents the UI for displaying total production time.
 */
public class TotalTime_usei3_UI implements Runnable {
    private SimulationController simulationController;

    /**
     * Constructor for USEI3_UI.
     *
     * @param simulationController the simulation controller
     */
    public TotalTime_usei3_UI(SimulationController simulationController) {
        this.simulationController = simulationController;
    }

    /**
     * Runs the UI for displaying total production time.
     */
    public void run() {
        System.out.println("USEI3 - Total production time for the items");
        System.out.println("====================================");
        System.out.println("Total production time for the items: " + simulationController.getTotalSimulationTime());
    }
}