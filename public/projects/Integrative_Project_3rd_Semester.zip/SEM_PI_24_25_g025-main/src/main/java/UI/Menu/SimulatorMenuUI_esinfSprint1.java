package UI.Menu;

import UI.UIs.Sprint1.Esinf.*;
import UI.Utils.Utils;
import controllers.SimulationController;

import java.util.ArrayList;
import java.util.List;

public class SimulatorMenuUI_esinfSprint1 implements Runnable {

    public void run() {
        List<MenuItem> options = new ArrayList<>();

        ImportUI importUI = new ImportUI();
        options.add(new MenuItem("Import Files", importUI));
        SimulationController simulationController = new SimulationController();
        options.add(new MenuItem("Generate Queues", new Generate_usei2_UI(importUI.getController(), simulationController)));
        options.add(new MenuItem("Generate Queues v2", new GenerateV2_usei2b_UI(importUI.getController(), simulationController)));
        options.add(new MenuItem("Run Simulation", new SimulationUI(simulationController)));
        options.add(new MenuItem("Total Production Time", new TotalTime_usei3_UI(simulationController)));
        options.add(new MenuItem("Execution Times by Each Operation", new ExecutionTimes_usei4_UI(simulationController)));
        options.add(new MenuItem("List of Workstations with Total Time of Operation", new ListWSTotalTime_usei5_UI(simulationController)));
        options.add(new MenuItem("Average Execution Times per Operation", new AveragePerOperation_usei6_UI(simulationController)));
        options.add(new MenuItem("Flow Dependency between Workstations", new FlowDependency_usei7_UI(simulationController)));

        int option = 0;
        do {
            option = Utils.showAndSelectIndex(options, "Simulator Menu");

            if ((option >= 0) && (option < options.size())) {
                options.get(option).run();
            }
        } while (option != -1);
    }
}
