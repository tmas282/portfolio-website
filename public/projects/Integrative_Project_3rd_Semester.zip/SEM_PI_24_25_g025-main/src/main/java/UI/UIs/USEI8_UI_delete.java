package UI.UIs;

import controllers.ProductionTreeController;

import java.io.IOException;

/**
 * USEI8_UI class represents the UI for displaying the flow dependency between workstations.
 */
public class USEI8_UI_delete implements Runnable {
    private ProductionTreeController productionTreeController;

    /**
     * Constructor for USEI8_UI.
     *
     * @param productionTreeController the Production Tree controller
     */
    public USEI8_UI_delete(ProductionTreeController productionTreeController) {
        this.productionTreeController = productionTreeController;
    }
    public void run() {
        System.out.println("USEI8- Buid the production tree");
        System.out.println("====================================");
        String csvBooPath = "./files/boo_v2.csv";
        String csvOperationsPath = "./files/operations.csv";
        String csvItemsPath = "./files/items.csv";
        try {
            productionTreeController.buildProductionTree(csvItemsPath, csvOperationsPath, csvBooPath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}