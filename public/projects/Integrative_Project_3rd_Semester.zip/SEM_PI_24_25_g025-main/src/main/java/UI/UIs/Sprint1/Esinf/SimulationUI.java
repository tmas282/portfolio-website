package UI.UIs.Sprint1.Esinf;

import controllers.SimulationController;

/**
 * SimulationUI class represents the UI for running simulations.
 */
public class SimulationUI implements Runnable {
    private SimulationController simulationController;

    /**
     * Constructor for SimulationUI.
     *
     * @param simulationController the simulation controller
     */
    public SimulationUI(SimulationController simulationController) {
        this.simulationController = simulationController;
    }

    /**
     * Runs the simulation UI.
     */
    public void run() {
        System.out.println("Simulation UI");
        simulationController.startSimulation();
    }
}