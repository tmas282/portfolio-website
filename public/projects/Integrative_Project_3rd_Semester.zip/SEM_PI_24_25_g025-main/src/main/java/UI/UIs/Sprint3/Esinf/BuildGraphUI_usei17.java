package UI.UIs.Sprint3.Esinf;

import UI.Utils.Utils;
import controllers.GraphController;
import esinf.domain.sprint3.PertCpmGraph;

import java.io.IOException;

public class BuildGraphUI_usei17 implements Runnable {

    private GraphController controller;

    public BuildGraphUI_usei17(GraphController controller) {
        this.controller = controller;
    }
    public void run() {
        System.out.println("Build PERT/CPM Graph from CSV file");
        String csvPath = Utils.readLineFromConsole("Enter the csv path: ");
        System.out.println("Building...");
        try {
            PertCpmGraph graph = controller.readCSVandBuildGraph(csvPath);
            String show = Utils.readLineFromConsole("Create graph image (y/n): ");
            if(show != null && show.equalsIgnoreCase("y")){
                System.out.println("Parsing graph to image...");
                String destinyPath = controller.parseGraphToImage(false, "./graph.svg");
                System.out.printf("Path of the graph: %s\n", destinyPath);
            }
            else {
                System.out.println(graph);
            }
        } catch (IOException | InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}