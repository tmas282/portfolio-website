package UI.Menu;

import UI.UIs.Sprint2.Esinf.*;
import UI.Utils.Utils;
import controllers.TreeProductionController;

import java.util.ArrayList;
import java.util.List;

public class ProductionTreeUI_esinfSprint2 implements Runnable {

    public void run() {
        List<MenuItem> options = new ArrayList<>();

        TreeProductionController treeProductionController = new TreeProductionController();
        options.add(new MenuItem("Build Production Tree", new BuildProductionTree_usei8_UI(treeProductionController)));
        options.add(new MenuItem("Search for Operations or Materials", new SearchOpAndMaterial_usei9_UI(treeProductionController)));
        options.add(new MenuItem("Track Material Quantities", new TrackMaterial_usei10_UI(treeProductionController)));
        options.add(new MenuItem("Prioritize Quality Checks", new PrioritizeQuality_usei11_UI(treeProductionController)));
        //TODO: the quantity of materials and time should be updated in the tree (all of them missing updating some)
        options.add(new MenuItem("Update Material Quantities", new UpdateMaterialQuantities_usei12_UI(treeProductionController)));
        options.add(new MenuItem("Calculate total quantity of materials and time", new CalculateTotalMaterialsTime_usei13_UI(treeProductionController)));
        options.add(new MenuItem("Identify and prioritize critical path operations", new IdentifyCriticalPath_usei14_UI(treeProductionController)));
        //TODO: simulator feature doesn't work
        options.add(new MenuItem("Extract BOO and present by their dependency levels", new ExtractBOO_usei15_UI(treeProductionController)));

        int option = 0;
        do{
            option = Utils.showAndSelectIndex(options, "\n\nProduction Tree Menu\n\n");

            if ((option >= 0) && (option < options.size())) {
                options.get(option).run();
            }
        } while (option != -1);
    }
}
