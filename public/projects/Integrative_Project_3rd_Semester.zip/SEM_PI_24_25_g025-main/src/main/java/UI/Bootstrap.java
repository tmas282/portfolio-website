package UI;

public class Bootstrap implements Runnable {

    public void run() {
    }
}
