package UI.UIs.Sprint3.Esinf;

import controllers.GraphController;
import esinf.domain.sprint3.PertCpmGraph;
import esinf.domain.sprint3.ProjectExporter;

import java.util.Scanner;

public class ExportScheduleToCSVUI_usei21 implements Runnable {
    private final GraphController graphController;

    public ExportScheduleToCSVUI_usei21(GraphController graphController) {
        this.graphController = graphController;
    }

    @Override
    public void run() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the file path to export the schedule to CSV:");
        String filePath = scanner.nextLine();

        try {
            PertCpmGraph graph = graphController.getGraph();
            ProjectExporter.exportScheduleToCSV(graph, filePath);
            System.out.println("Schedule exported successfully to " + filePath);
        } catch (Exception e) {
            System.out.println("An error occurred while exporting the schedule.");
            e.printStackTrace();
        }
    }
}