package UI.UIs.Sprint2.Bddad;

import controllers.GetPartsByPartController;

import java.util.Scanner;

public class GetPartsByPartUI_usbd12 implements Runnable {

    private GetPartsByPartController controller;

    public GetPartsByPartUI_usbd12() {
        this.controller = new GetPartsByPartController();
    }

    Scanner scanner = new Scanner(System.in);

    public void run() {
        System.out.println("Get Parts By Part");
        System.out.print("Enter the part code: ");
        String partCode = scanner.nextLine();
        controller.getPartsByPart(partCode);
    }
}
