package UI.UIs.Sprint2.Esinf;

import controllers.TreeProductionController;
import esinf.domain.sprint2.TreeProductionBuilder;
import esinf.domain.sprint2.ProductionTreeCalculator;

/**
 * USEI13_UI class represents the UI for calculating total quantity of materials and time.
 */
public class CalculateTotalMaterialsTime_usei13_UI implements Runnable {
    private TreeProductionBuilder builder;
    private TreeProductionController treeProductionController;

    /**
     * Constructor for USEI13_UI.
     *
     * @param treeProductionController the tree production controller
     */
    public CalculateTotalMaterialsTime_usei13_UI(TreeProductionController treeProductionController) {
        this.treeProductionController = treeProductionController;
    }

    /**
     * Runs the UI for calculating total quantity of materials and time.
     */
    public void run() {
        builder = treeProductionController.getTreeProductionBuilder();
        ProductionTreeCalculator.calculateTotals(builder.getNodeById("1006"));
    }
}