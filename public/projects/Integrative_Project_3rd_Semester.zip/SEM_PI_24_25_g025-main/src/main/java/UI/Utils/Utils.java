package UI.Utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Utils class provides utility methods for reading input from the console and displaying lists.
 */
public class Utils {

    /**
     * Reads a line of text from the console.
     *
     * @param prompt the prompt message to display
     * @return the line of text read from the console
     */
    static public String readLineFromConsole(String prompt) {
        try {
            System.out.print("\n" + prompt);

            InputStreamReader converter = new InputStreamReader(System.in);
            BufferedReader in = new BufferedReader(converter);

            return in.readLine();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Reads an integer from the console.
     *
     * @param prompt the prompt message to display
     * @return the integer read from the console
     */
    static public int readIntegerFromConsole(String prompt) {
        do {
            try {
                String input = readLineFromConsole(prompt);
                int value = Integer.parseInt(input);
                return value;
            } catch (NumberFormatException ex) {
                System.out.println("Please select a valid Integer.");
            }
        } while (true);
    }

    /**
     * Reads a double from the console.
     *
     * @param prompt the prompt message to display
     * @return the double read from the console
     */
    static public double readDoubleFromConsole(String prompt) {
        do {
            try {
                String input = readLineFromConsole(prompt);
                double value = Double.parseDouble(input);
                return value;
            } catch (NumberFormatException ex) {
                Logger.getLogger(Utils.class.getName()).log(Level.SEVERE, null, ex);
            }
        } while (true);
    }

    /**
     * Reads a date from the console.
     *
     * @param prompt the prompt message to display
     * @return the date read from the console
     */
    static public Date readDateFromConsole(String prompt) {
        do {
            try {
                String strDate = readLineFromConsole(prompt);
                SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
                Date date = df.parse(strDate);
                return date;
            } catch (ParseException ex) {
                Logger.getLogger(Utils.class.getName()).log(Level.SEVERE, null, ex);
            }
        } while (true);
    }

    /**
     * Prompts the user to confirm a message.
     *
     * @param message the message to display
     * @return true if the user confirms, false otherwise
     */
    static public boolean confirm(String message) {
        String input;
        do {
            input = Utils.readLineFromConsole(message + "\tYes or No\n");
        } while (!input.equalsIgnoreCase("yes") && !input.equalsIgnoreCase("no"));

        return input.equalsIgnoreCase("yes");
    }

    /**
     * Displays a list and prompts the user to select an item.
     *
     * @param list the list of items to display
     * @param header the header message to display
     * @return the selected item
     */
    static public Object showAndSelectOne(List list, String header) {
        showList(list, header);
        return selectsObject(list);
    }

    /**
     * Displays a list and prompts the user to select an index.
     *
     * @param list the list of items to display
     * @param header the header message to display
     * @return the selected index
     */
    static public int showAndSelectIndex(List list, String header) {
        showList(list, header);
        return selectsIndex(list);
    }

    /**
     * Displays a list and prompts the user to select an index (Admin UI).
     *
     * @param list the list of items to display
     * @param header the header message to display
     * @return the selected index
     */
    static public int showAndSelectIndexAdminUI(List list, String header) {
        showList(list, header);
        return selectsIndex(list);
    }

    /**
     * Displays a list with a header.
     *
     * @param list the list of items to display
     * @param header the header message to display
     */
    static public void showList(List list, String header) {
        System.out.println(header);

        int index = 0;
        for (Object o : list) {
            index++;
            System.out.println("  " + index + " - " + o.toString());
        }
        System.out.println("  0 - Cancel");
    }

    /**
     * Prompts the user to select an object from a list.
     *
     * @param list the list of items to select from
     * @return the selected object
     */
    static public Object selectsObject(List list) {
        String input;
        int value;
        do {
            input = Utils.readLineFromConsole("Type your option: ");
            value = Integer.valueOf(input);
        } while (value < 0 || value > list.size());

        if (value == 0) {
            return null;
        } else {
            return list.get(value - 1);
        }
    }

    /**
     * Prompts the user to select an index from a list.
     *
     * @param list the list of items to select from
     * @return the selected index
     */
    static public int selectsIndex(List list) {
        String input;
        int value;
        do {
            input = Utils.readLineFromConsole("Type your option: ");
            try {
                value = Integer.valueOf(input);
            } catch (NumberFormatException ex) {
                value = -1;
            }
        } while (value < 0 || value > list.size());

        return value - 1;
    }
}