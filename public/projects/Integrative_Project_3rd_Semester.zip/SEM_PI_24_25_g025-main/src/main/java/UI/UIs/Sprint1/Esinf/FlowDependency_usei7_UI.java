package UI.UIs.Sprint1.Esinf;

import controllers.SimulationController;
import esinf.domain.Product;
import esinf.domain.Station;

import java.util.List;
import java.util.Map;

/**
 * USEI7_UI class represents the UI for displaying the flow dependency between workstations.
 */
public class FlowDependency_usei7_UI implements Runnable {
    private SimulationController simulationController;

    /**
     * Constructor for USEI7_UI.
     *
     * @param simulationController the simulation controller
     */
    public FlowDependency_usei7_UI(SimulationController simulationController) {
        this.simulationController = simulationController;
    }

    private void printProcessedItems(Map<Product, List<Station>> flowDependencies){
        for (Map.Entry<Product, List<Station>> flowDependency
                :
                flowDependencies.entrySet()) {
            System.out.printf("%s: ", flowDependency.getKey());
            List<Station> stations = flowDependency.getValue();
            for (Station station:
                    stations) {
                if (station.equals(stations.get(stations.size() - 1)))
                    System.out.printf("%s\n", station);
                else{
                    System.out.printf("%s -> ", station);
                }
            }
        }
    }
    private void printFlowDependency(Map<Station, List<Station>> flow){
        for (Map.Entry<Station, List<Station>> f
                :
                flow.entrySet()) {
            System.out.printf("%s: [", f.getKey());
            List<Station> stations = f.getValue();
            for (Station station:
                    stations) {
                if (station.equals(stations.get(stations.size() - 1)))
                    System.out.printf("(%s)]\n", station);
                else{
                    System.out.printf("(%s) , ", station);
                }
            }
        }
    }


    /**
     * Runs the UI for displaying the flow dependency between workstations.
     */
    public void run() {
        System.out.println("USEI7 - List representing the flow dependency between workstations");
        System.out.println("====================================");
        Map<Product, List<Station>> flowDependencies = simulationController.getSimulator().getFlowDependencies();
        printProcessedItems(flowDependencies);
        Map<Station, List<Station>> flow =  simulationController.processFlowDependency();
        printFlowDependency(flow);
    }
}