package UI.UIs.Sprint3.Bddad;

import UI.Utils.Utils;
import bddad.db.DatabaseConnection;
import oracle.jdbc.internal.OracleTypes;

import java.sql.*;

public class GetProductOperations_usbd25 implements Runnable {

    @Override
    public void run() {
        GetProductOperations_usbd25 getProductOperations = new GetProductOperations_usbd25();
        String productCode = Utils.readLineFromConsole("Enter Product Code: ");
        getProductOperations.getProductOperations(productCode);
    }

    public void getProductOperations(String productCode) {
        try (Connection conn = DatabaseConnection.getConnection()) {

            // Preparar a chamada para a função PL/SQL
            String sql = "{CALL ? := GetProductOperations(?)}";
            try (CallableStatement stmt = conn.prepareCall(sql)) {

                // Registrar o tipo de retorno (cursor)
                stmt.registerOutParameter(1, OracleTypes.CURSOR);

                // Configurar o parâmetro de entrada
                stmt.setString(2, productCode);

                // Executar a chamada
                stmt.execute();

                // Obter o cursor de resultados
                try (ResultSet rs = (ResultSet) stmt.getObject(1)) {
                    if (rs != null) {
                        System.out.println("Operations for product: " + productCode);
                        while (rs.next()) {
                            int operationId = rs.getInt("OperationID");
                            String operationType = rs.getString("OperationType");
                            int executionTime = rs.getInt("ExecutionTime");
                            String inputPart = rs.getString("InputPartCode");
                            double inputQuantity = rs.getDouble("InputQuantity");
                            String outputPart = rs.getString("OutputPartCode");
                            double outputQuantity = rs.getDouble("OutputQuantity");

                            System.out.printf(
                                    "Operation ID: %d, Type: %s, Time: %d, Input: %s (%.2f), Output: %s (%.2f)%n",
                                    operationId, operationType, executionTime,
                                    inputPart, inputQuantity,
                                    outputPart, outputQuantity
                            );
                        }
                    } else {
                        System.out.println("No operations found for the given product.");
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("An error occurred while retrieving product operations.");
            e.printStackTrace();
        }
    }
}
