package UI.UIs.Sprint2.Esinf;

import controllers.TreeProductionController;

public class ExtractBOO_usei15_UI implements Runnable {
    private TreeProductionController productionTreeController;

    public ExtractBOO_usei15_UI(TreeProductionController productionTreeController) {
        this.productionTreeController = productionTreeController;
    }

    public void run() {
        System.out.println("Operations by Level of Dependency");
        System.out.println("Extracting Bill of Operations...");
        productionTreeController.extractBOO();
        System.out.println("Bill of Operations extracted successfully!");
        System.out.println("Operations by Level of Dependency:");
        productionTreeController.printOperationsByDependency();
    }
}
