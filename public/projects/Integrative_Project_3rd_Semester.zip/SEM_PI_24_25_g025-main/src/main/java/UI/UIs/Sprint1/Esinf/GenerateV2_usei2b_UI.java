package UI.UIs.Sprint1.Esinf;

import controllers.ImportController;
import controllers.SimulationController;
import esinf.domain.Operation;
import esinf.domain.ProductionOrderOperation;

import java.util.Map;
import java.util.Queue;

/**
 * GenerateV2_UI class represents the UI for generating queues (version 2).
 */
public class GenerateV2_usei2b_UI implements Runnable {

    private SimulationController controller;
    private ImportController importController;

    /**
     * Constructor for GenerateV2_UI.
     *
     * @param importController the import controller
     * @param simulationController the simulation controller
     */
    public GenerateV2_usei2b_UI(ImportController importController, SimulationController simulationController) {
        this.importController = importController;
        this.controller = simulationController;
    }

    /**
     * Runs the UI for generating queues (version 2).
     */
    public void run() {
        System.out.println("Generating Queues");

        Map<Operation, Queue<ProductionOrderOperation>> queues = controller.generateQueuesV2(importController.getProductionOrders());
        controller.addFilesToSimulator(importController.getStations(), importController.getOperationStationMap(), queues);
    }

    /**
     * Gets the simulation controller.
     *
     * @return the simulation controller
     */
    public SimulationController getController() {
        return controller;
    }
}