package UI.UIs.Sprint3.Esinf;

import controllers.GraphController;
import UI.Utils.Utils;
import esinf.domain.sprint3.Activity;

import java.io.IOException;
import java.util.List;

/**
 * ScheduleAnalysisUI provides a user interface for analyzing schedules.
 */
public class ScheduleAnalysisUI_usei20 implements Runnable {

    private GraphController graphController;
    private boolean calculationsDone = false;

    /**
     * Constructor for ScheduleAnalysisUI.
     *
     * @param graphController the graph controller responsible for PERT/CPM calculations
     */
    public ScheduleAnalysisUI_usei20(GraphController graphController) {
        this.graphController = graphController;
    }

    /**
     * Runs the UI for schedule analysis.
     */
    @Override
    public void run() {
        int option;
        do {
            System.out.println("\n=== Schedule Analysis Menu ===");
            System.out.println("1. Display Activity Times (ES, EF, LS, LF, Slack)");
            System.out.println("2. View Graph");
            System.out.println("0. Return to Previous Menu");

            option = Utils.readIntegerFromConsole("Enter your choice: ");

            switch (option) {
                case 1:
                    displayActivityTimes();
                    break;
                case 2:
                    try {
                        viewGraph();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                    break;
                case 0:
                    System.out.println("Returning to the previous menu...");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        } while (option != 0);
    }

    /**
     * Display activity times (ES, EF, LS, LF, Slack).
     */
    private void displayActivityTimes() {
        try {
            // Assuming this method returns a list of activities with their details
            List<Activity> activities = graphController.getActivityTimes();
            calculationsDone = true;

            System.out.println("\n--- Earliest and Latest Start and Finish Times ---");
            System.out.printf("%-5s %-40s %-5s %-5s %-5s %-5s %-5s%n", "Act", "Description", "ES", "EF", "LS", "LF", "Slack");

            for (Activity activity : activities) {
                String key = (String) activity.getKey();
                String description = (String) activity.getDescription();
                double es = (double) activity.getEarliestStart();
                double ef = (double) activity.getEarliestFinish();
                double ls = (double) activity.getLatestStart();
                double lf = (double) activity.getLatestFinish();
                double slack = (double) activity.getSlack();

                System.out.printf("%-5s %-40s %-5.2f %-5.2f %-5.2f %-5.2f %-5.2f%n", key, description, es, ef, ls, lf, slack);
            }

        } catch (Exception e) {
            System.out.println("Error displaying activity times: " + e.getMessage());
        }
    }

    /**
     * View the graph representation of the schedule.
     */
    private void viewGraph() throws IOException, InterruptedException {
        if (!calculationsDone) {
            graphController.getActivityTimes();
            calculationsDone = true;
        }
        String graphPath = graphController.parseGraphToImage(true, "./graph.svg");
        try {
            System.out.println("\nGraph generated successfully: " + graphPath);
        } catch (Exception e) {
            System.out.println("Error generating graph: " + e.getMessage());
        }
    }
}