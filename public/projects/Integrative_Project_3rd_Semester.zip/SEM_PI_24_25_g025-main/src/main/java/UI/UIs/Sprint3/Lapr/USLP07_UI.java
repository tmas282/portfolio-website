package UI.UIs.Sprint3.Lapr;

import controllers.SimulatorV2Controller;
import bddad.db.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.LinkedList;

public class USLP07_UI implements Runnable {

    private SimulatorV2Controller simulatorController;

    public USLP07_UI() {
        try {
            this.simulatorController = new SimulatorV2Controller();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        System.out.println("\n--- Atualizar tempos médios de produção no banco de dados Oracle ---\n");
        try {
            System.out.println("Executando o simulador...");
            String itemId = "item123"; // Exemplo de ID de item
            String priority = "Alta";  // Exemplo de prioridade
            int quantity = 100;        // Exemplo de quantidade

            simulatorController.runSimulator(itemId, priority, quantity);

            LinkedList<String> operationsByDependency = simulatorController.getOperationsByDependency();

            for (String operationID : operationsByDependency) {
                double averageProductionTime = calculateAverageProductionTime(operationsByDependency);

            }

            System.out.println("Tempos médios de produção atualizados com sucesso no banco de dados.");
        } catch (Exception e) {
            System.err.println("Erro ao executar ou atualizar os tempos de produção: " + e.getMessage());
            e.printStackTrace();
        }
    }


    private double calculateAverageProductionTime(LinkedList<String> operationsByDependency) {
        // Implementar lógica para calcular a média dos tempos de produção
        // Considerando os tempos de espera
        return 0.0; // Exemplo de retorno
    }

    private void updateProductionTimesInDB(double averageProductionTime) throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String updateQuery = "UPDATE Operation SET EstimatedTime = ? WHERE ID = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
                preparedStatement.setDouble(1, averageProductionTime);// Substituir pelo ID real da operação
                preparedStatement.executeUpdate();
            }
            }
        }
    }
