package UI.UIs.Sprint3.Bddad;

import bddad.db.DatabaseConnection;

import java.sql.Connection;
import java.sql.Statement;

public class TestPLSQLCodeUI_usbd22 implements Runnable {
    @Override
    public void run() {
        System.out.println("Testing PL/SQL code...");

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement()) {

            // PL/SQL script to test the trigger
            String plsqlScript = """
                -- Create a test table for operations
                CREATE TABLE Operation (
                    ID NUMBER PRIMARY KEY,
                    OperationTypeID NUMBER,
                    ExpectedExecutionTime NUMBER
                );

                -- Create a test table for workstation types
                CREATE TABLE WorkstationType (
                    ID NUMBER PRIMARY KEY,
                    MaxExecutionTime NUMBER
                );

                -- Create a test table for workstation type operations
                CREATE TABLE WorkstationTypeOperation (
                    WorkstationTypeID NUMBER,
                    OperationTypeID NUMBER
                );

                -- Insert test data into WorkstationType
                INSERT INTO WorkstationType (ID, MaxExecutionTime) VALUES (1, 100);
                INSERT INTO WorkstationType (ID, MaxExecutionTime) VALUES (2, 200);

                -- Insert test data into WorkstationTypeOperation
                INSERT INTO WorkstationTypeOperation (WorkstationTypeID, OperationTypeID) VALUES (1, 1);
                INSERT INTO WorkstationTypeOperation (WorkstationTypeID, OperationTypeID) VALUES (2, 1);

                -- Test the trigger with valid data
                BEGIN
                    INSERT INTO Operation (ID, OperationTypeID, ExpectedExecutionTime) VALUES (1, 1, 50);
                    UPDATE Operation SET ExpectedExecutionTime = 150 WHERE ID = 1;
                END;
                /

                -- Test the trigger with invalid data
                BEGIN
                    INSERT INTO Operation (ID, OperationTypeID, ExpectedExecutionTime) VALUES (2, 1, 250);
                EXCEPTION
                    WHEN OTHERS THEN
                        DBMS_OUTPUT.PUT_LINE(SQLERRM);
                END;
                /

                BEGIN
                    UPDATE Operation SET ExpectedExecutionTime = 300 WHERE ID = 1;
                EXCEPTION
                    WHEN OTHERS THEN
                        DBMS_OUTPUT.PUT_LINE(SQLERRM);
                END;
                /
            """;

            stmt.execute(plsqlScript);
            System.out.println("PL/SQL code tested successfully.");

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("An error occurred while testing PL/SQL code.");
        }
    }
}