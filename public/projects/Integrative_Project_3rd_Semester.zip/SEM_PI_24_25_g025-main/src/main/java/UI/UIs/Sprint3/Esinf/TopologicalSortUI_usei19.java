package UI.UIs.Sprint3.Esinf;

import controllers.GraphController;
import esinf.domain.sprint3.Activity;

import java.util.LinkedList;

public class TopologicalSortUI_usei19 implements Runnable {

    private final GraphController controller;

    public TopologicalSortUI_usei19(GraphController controller) {
        this.controller = controller;
    }

    @Override
    public void run() {
        System.out.println("Perform Topological Sort on PERT/CPM Graph");
        try {
            LinkedList<?> sortedList = controller.topologicalSort(controller.getGraph());
            writeSortedListToConsole(sortedList);
        } catch (IllegalStateException e) {
            System.err.println("Graph is not initialized: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Error during topological sort: " + e.getMessage());
        }
    }

    /**
     * Writes the sorted list to the console.
     *
     * @param sortedList LinkedList of sorted vertices
     */
    private void writeSortedListToConsole(LinkedList<?> sortedList) {
        System.out.println("Topological Order of Activities:");
        int order = 1;
        for (Object vertex : sortedList) {
            if (vertex instanceof Activity) {
                Activity activity = (Activity) vertex;
                System.out.printf("%d. [%s] -> %s\n", order++, activity.getKey(), activity.getDescription());
            } else {
                System.out.println(order++ + ". " + vertex);
            }
        }
    }
}
