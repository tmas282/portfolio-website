package UI.Menu;

import java.util.Objects;

/**
 * MenuItem class represents an item in the menu.
 * Each item has a description and an action associated with it.
 */
public class MenuItem {
    private String description;
    private Runnable action;

    /**
     * Constructor for MenuItem.
     *
     * @param description the description of the menu item
     * @param action the action to be performed when the menu item is selected
     */
    public MenuItem(String description, Runnable action) {
        if (description.isEmpty()) {
            throw new IllegalArgumentException("Description cannot be null or empty");
        }
        if (Objects.isNull(action)) {
            throw new IllegalArgumentException("MenuItem does not support a null UI.");
        }
        this.description = description;
        this.action = action;
    }

    /**
     * Runs the action associated with the menu item.
     */
    public void run() {
        action.run();
    }

    /**
     * Checks if the menu item has the given description.
     *
     * @param description the description to check
     * @return true if the menu item has the given description, false otherwise
     */
    public boolean hasDescription(String description) {
        return this.description.equals(description);
    }

    @Override
    public String toString() {
        return description;
    }
}