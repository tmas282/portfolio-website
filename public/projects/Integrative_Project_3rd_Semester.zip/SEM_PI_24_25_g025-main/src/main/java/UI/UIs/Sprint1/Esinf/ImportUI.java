package UI.UIs.Sprint1.Esinf;

import UI.Utils.Utils;
import controllers.ImportController;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * ImportUI class represents the UI for importing files.
 */
public class ImportUI implements Runnable {

    private ImportController controller;

    /**
     * Constructor for ImportUI.
     */
    public ImportUI() {
        controller = new ImportController();
    }

    /**
     * Runs the UI for importing files.
     */
    public void run() {
        boolean openGUI = Utils.readLineFromConsole("Open GUI File Chooser [Y\\n]: ").equalsIgnoreCase("y");
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new FileNameExtensionFilter("*.csv", "csv"));
        fileChooser.setDialogTitle("Choose a file to import workstations from");
        String csvFilePath;
        int userSelection;
        if (openGUI) {
            userSelection = fileChooser.showOpenDialog(null);
            if (userSelection == JFileChooser.APPROVE_OPTION) {
                JOptionPane.showMessageDialog(null, "File imported successfully!");
                csvFilePath = fileChooser.getSelectedFile().getAbsolutePath();
            } else {
                JOptionPane.showMessageDialog(null, "No file selected. Program will exit.");
                return;
            }
        } else {
            csvFilePath = "./files/workstations.csv";
        }
        controller.readWorkstationFile(csvFilePath);
        fileChooser.setDialogTitle("Choose a file to import articles from");
        if (openGUI) {
            userSelection = fileChooser.showOpenDialog(null);

            if (userSelection == JFileChooser.APPROVE_OPTION) {
                JOptionPane.showMessageDialog(null, "File imported successfully!");
                csvFilePath = fileChooser.getSelectedFile().getAbsolutePath();
            } else {
                JOptionPane.showMessageDialog(null, "No file selected. Program will exit.");
            }
        } else {
            csvFilePath = "./files/articles.csv";
        }
        controller.readArticleFile(csvFilePath);
    }

    /**
     * Gets the import controller.
     *
     * @return the import controller
     */
    public ImportController getController() {
        return controller;
    }
}