package UI.UIs.Sprint2.Bddad;

import controllers.RegisterProductController;

public class Register_Product_UI_usbd16 implements Runnable {

    private RegisterProductController controller;

    public Register_Product_UI_usbd16() {
        this.controller = new RegisterProductController();
    }

    public void run() {
        System.out.println("Register Product");
        controller.registerProduct();
    }
}
