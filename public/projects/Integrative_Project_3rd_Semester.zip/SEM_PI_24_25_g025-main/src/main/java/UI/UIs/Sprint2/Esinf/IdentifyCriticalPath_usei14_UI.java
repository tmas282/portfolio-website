package UI.UIs.Sprint2.Esinf;

import controllers.TreeProductionController;
import esinf.domain.sprint2.TreeProductionBuilder;
import esinf.domain.sprint2.CriticalPathCalculator;

/**
 * USEI14_UI class represents the UI for identifying and prioritizing critical path operations.
 */
public class IdentifyCriticalPath_usei14_UI implements Runnable {
    private TreeProductionBuilder builder;
    private TreeProductionController treeProductionController;

    /**
     * Constructor for USEI14_UI.
     *
     * @param treeProductionController the tree production controller
     */
    public IdentifyCriticalPath_usei14_UI(TreeProductionController treeProductionController) {
        this.treeProductionController = treeProductionController;
    }

    /**
     * Runs the UI for identifying and prioritizing critical path operations.
     */
    public void run() {
        builder = treeProductionController.getTreeProductionBuilder();
        CriticalPathCalculator.identifyAndPrioritizeCriticalPath(builder.getNodeById("1006"));
    }
}