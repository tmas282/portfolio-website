package UI.UIs.Sprint3.Bddad;

import UI.Utils.Utils;
import bddad.db.DatabaseConnection;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class ConsumeMaterial_usbd30 implements Runnable {

    @Override
    public void run() {
        ConsumeMaterial_usbd30 consumeMaterial = new ConsumeMaterial_usbd30();
        String partCode = Utils.readLineFromConsole("Enter Part Code: ");
        int quantity = Integer.parseInt(Utils.readLineFromConsole("Enter Quantity: "));
        consumeMaterial.consumeMaterial(partCode, quantity);
    }

    public void consumeMaterial(String partCode, int quantity) {
        try (Connection conn = DatabaseConnection.getConnection()) {

            conn.prepareStatement("BEGIN DBMS_OUTPUT.ENABLE(); END;").execute();

            String sql = "{Call ConsumeMaterial(?, ?)}";
            try (CallableStatement stmt = conn.prepareCall(sql)) {
                stmt.setString(1, partCode);
                stmt.setInt(2, quantity);
                stmt.execute();
                System.out.println("Material consumed successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}