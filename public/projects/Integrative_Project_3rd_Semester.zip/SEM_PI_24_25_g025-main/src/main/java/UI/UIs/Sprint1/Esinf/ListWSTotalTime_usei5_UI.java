package UI.UIs.Sprint1.Esinf;

import controllers.SimulationController;
import esinf.domain.StationStatistics;

import java.util.List;

/**
 * USEI5_UI class represents the UI for displaying workstations with total time of operation.
 */
public class ListWSTotalTime_usei5_UI implements Runnable {
    private SimulationController simulationController;

    /**
     * Constructor for USEI5_UI.
     *
     * @param simulationController the simulation controller
     */
    public ListWSTotalTime_usei5_UI(SimulationController simulationController) {
        this.simulationController = simulationController;
    }

    /**
     * Runs the UI for displaying workstations with total time of operation.
     */
    public void run() {
        System.out.println("USEI5 -  List of workstations with total time of operation, and percentages relative to the operation time and total execution time, sorted in ascending\n" +
                "order of the percentage of execution time relative to the total time");
        System.out.println("====================================================================================================");
        List<StationStatistics> stationStatistics = simulationController.getStationStatistics();
        stationStatistics.forEach(station -> {
            System.out.println("Station: " + station.getStation().getStationID());
            System.out.println("Total time of operation: " + station.getStation().getUsageTime());
            System.out.println("Percentage relative to the operation time: " + station.getPercentageRelativeToOperation());
            System.out.println("Percentage relative to the total execution time: " + station.getPercentageRelativeToTotalTime());
            System.out.println("====================================================================================================");
        });
    }
}