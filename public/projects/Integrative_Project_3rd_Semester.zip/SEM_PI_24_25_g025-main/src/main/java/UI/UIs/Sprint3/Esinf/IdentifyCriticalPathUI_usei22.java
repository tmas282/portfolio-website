package UI.UIs.Sprint3.Esinf;

import UI.Utils.Utils;
import controllers.GraphController;

import java.io.IOException;

public class IdentifyCriticalPathUI_usei22 implements Runnable{
    private GraphController controller;

    public IdentifyCriticalPathUI_usei22(GraphController controller) {
        this.controller = controller;
    }

    /**
     * Runs this operation.
     */
    @Override
    public void run() {
        System.out.println("Identifying the critical path(s).");
        String show = Utils.readLineFromConsole("Create critical path(s) image(s) demonstration(s) (y/n): ");
        if(show != null && show.equalsIgnoreCase("y")){
            System.out.println("Parsing critical path(s) to image...");
            try {
                controller.parseCriticalPathsToImage();
            } catch (IOException | InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        else{
            controller.getCriticalPaths();
        }
    }
}
