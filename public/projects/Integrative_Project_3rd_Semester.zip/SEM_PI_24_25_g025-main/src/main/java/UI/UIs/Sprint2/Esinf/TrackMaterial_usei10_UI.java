package UI.UIs.Sprint2.Esinf;

import controllers.TreeProductionController;

import java.util.Scanner;

public class TrackMaterial_usei10_UI implements Runnable {
    private TreeProductionController productionTreeController;

    public TrackMaterial_usei10_UI(TreeProductionController productionTreeController) {
        this.productionTreeController = productionTreeController;
    }

    public void run() {
        System.out.println("Track Material");
        System.out.println("Tracking material...");
        productionTreeController.buildTracker();
        System.out.println("Material tracked successfully!");
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("How would you like to display the materials?");
            System.out.println("1. Ascending Order");
            System.out.println("2. Descending Order");
            System.out.println("Enter your choice (1 or 2): ");

            String choice = scanner.nextLine().trim();
            if (choice.equals("1")) {
                System.out.println("Materials in Ascending Order:");
                productionTreeController.printAscendingOrderMaterials();
                break;
            } else if (choice.equals("2")) {
                System.out.println("Materials in Descending Order:");
                productionTreeController.printDescendingOrderMaterials();
                break;
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
