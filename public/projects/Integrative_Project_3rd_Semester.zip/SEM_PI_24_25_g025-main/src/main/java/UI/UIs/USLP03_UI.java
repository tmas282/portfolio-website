package UI.UIs;

import UI.Utils.Utils;
import esinf.domain.sprint2.TreeProductionBuilder;
import org.example.ui.ESINF.ProductStructureVisualizer;

/**
 * USLP03_UI class represents the UI for visualizing the product structure (BOM).
 */
public class USLP03_UI implements Runnable {
    private ProductStructureVisualizer visualizer;

    /**
     * Constructor for USLP03_UI.
     *
     * @param builder the tree production builder to use
     */
    public USLP03_UI(TreeProductionBuilder builder) {
        this.visualizer = new ProductStructureVisualizer(builder);
    }

    /**
     * Runs the UI for visualizing the product structure.
     */
    public void run() {
        String productId = Utils.readLineFromConsole("Enter the product ID to visualize: ");
        visualizer.visualizeProductStructure(productId);
    }
}