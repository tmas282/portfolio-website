package UI.UIs.Sprint3.Bddad;

import bddad.Procedures.ReserveMaterials;

import java.util.Scanner;

public class ReserveMaterialsUI_usbd27 implements Runnable{

    private ReserveMaterials reserveMaterials;

    public ReserveMaterialsUI_usbd27() {
        this.reserveMaterials = new ReserveMaterials();
    }

    Scanner scanner = new Scanner(System.in);

    @Override
    public void run() {
        System.out.println("Display and Select Orders");
        System.out.println("Fetching orders from the database...");

        try {
            reserveMaterials.showAndSelectOrder();
        } catch (Exception e) {
            System.err.println("An error occurred while displaying orders or selecting one: " + e.getMessage());
        }
    }

}
