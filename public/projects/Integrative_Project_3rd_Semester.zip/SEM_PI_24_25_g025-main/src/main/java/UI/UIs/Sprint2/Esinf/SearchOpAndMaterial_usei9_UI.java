package UI.UIs.Sprint2.Esinf;

import controllers.ProductionTreeController;
import controllers.TreeProductionController;
import esinf.domain.sprint2.SearchUtility;
import UI.Utils.Utils;

/**
 * USEI09_UI class represents the UI for searching specific operations or materials.
 */
public class SearchOpAndMaterial_usei9_UI implements Runnable {
    private SearchUtility searchUtility;
    private TreeProductionController treeProductionController;

    /**
     * Constructor for USEI09_UI.
     *
     * @param searchUtility the search utility to use
     */
    /*
    public SearchOpAndMaterial_usei9_UI(SearchUtility searchUtility) {
        this.searchUtility = searchUtility;
    }

     */
    /**
     * Constructor for USEI09_UI.
     *
     * @param treeProductionController the controller for the tree production
     */
    public SearchOpAndMaterial_usei9_UI(TreeProductionController treeProductionController) {
        this.treeProductionController = treeProductionController;
    }

    /**
     * Runs the UI for searching specific operations or materials.
     */
    public void run() {
        //Initialize the search utility
        searchUtility = new SearchUtility(treeProductionController.getTreeProductionBuilder());
        // Read input for ID search
        String searchId = Utils.readLineFromConsole("Enter the ID to search: ");
        System.out.println("\nSearch Result by ID:");
        System.out.println(searchUtility.searchNodeById(searchId));

        // Read input for name search
        String searchName = Utils.readLineFromConsole("Enter the name to search: ");
        System.out.println("\nSearch Result by Name:");
        System.out.println(searchUtility.searchNodeByName(searchName));
    }
}