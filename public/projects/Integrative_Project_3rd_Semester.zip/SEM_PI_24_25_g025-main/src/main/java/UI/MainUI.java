package UI;

import UI.Menu.MainMenuUI;

/**
 * MainUI class is the entry point of the application.
 * It initializes the system and starts the main menu.
 */
public class MainUI {

    /**
     * The main method to start
     * the application.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Bootstrap bootstrap = new Bootstrap();
        bootstrap.run();

        try {
            MainMenuUI mainMenuUI = new MainMenuUI();
            mainMenuUI.run();
        } catch (Exception e) {
            System.out.println("An error occurred. Exiting...");
            e.printStackTrace();
        }
    }
}