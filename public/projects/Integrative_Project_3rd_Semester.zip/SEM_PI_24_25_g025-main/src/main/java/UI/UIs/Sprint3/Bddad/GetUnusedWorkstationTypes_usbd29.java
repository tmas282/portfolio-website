package UI.UIs.Sprint3.Bddad;

import bddad.db.DatabaseConnection;
import oracle.jdbc.internal.OracleTypes;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GetUnusedWorkstationTypes_usbd29 implements Runnable {

    @Override
    public void run() {
        try {
            getUnusedWorkstationTypes();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void getUnusedWorkstationTypes() throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection()) {

            conn.prepareStatement("BEGIN DBMS_OUTPUT.ENABLE(); END;").execute();

            String sql = "{Call GetUnusedWorkstationTypes(?)}";
            try (CallableStatement stmt = conn.prepareCall(sql)) {

                stmt.registerOutParameter(1, OracleTypes.CURSOR);

                // Executa o procedimento armazenado
                stmt.execute();

                // Obtém o REF CURSOR
                ResultSet resultSet = (ResultSet) stmt.getObject(1);

                while (resultSet.next()) {
                    String id = resultSet.getString("ID");
                    String name = resultSet.getString("Name");

                    System.out.println("ID: " + id + ", Name: " + name);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}