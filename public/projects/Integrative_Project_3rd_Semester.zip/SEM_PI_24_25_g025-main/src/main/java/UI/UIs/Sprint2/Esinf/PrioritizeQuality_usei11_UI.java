package UI.UIs.Sprint2.Esinf;

import controllers.TreeProductionController;
import esinf.domain.sprint2.QualityCheckManager;
import esinf.domain.sprint2.QualityCheck;

/**
 * USEI11_UI class represents the UI for prioritizing quality checks.
 */
public class PrioritizeQuality_usei11_UI implements Runnable {
    private QualityCheckManager qualityCheckManager;

    private TreeProductionController treeProductionController;

    /**
     * Constructor for USEI11_UI.
     *
     * @param treeProductionController the controller for tree production
     */
    public PrioritizeQuality_usei11_UI(TreeProductionController treeProductionController) {
        this.qualityCheckManager = treeProductionController.getQualityCheckManager();
    }

    /**
     * Runs the UI for prioritizing quality checks.
     */
    public void run() {

        qualityCheckManager.addQualityCheck(new QualityCheck("QC1", "Check Final Product", 10, 5));
        qualityCheckManager.addQualityCheck(new QualityCheck("QC2", "Check Raw Materials", 5, 1));
        qualityCheckManager.addQualityCheck(new QualityCheck("QC3", "Check Assembly", 8, 3));
        qualityCheckManager.addQualityCheck(new QualityCheck("QC4", "Check Packaging", 9, 4));

        System.out.println("Quality Checks in Order of Priority:");
        qualityCheckManager.printQualityChecks();

        System.out.println("\nPerforming Quality Checks:");
        while (qualityCheckManager.viewNextQualityCheck() != null) {
            System.out.println("Performing: " + qualityCheckManager.performNextQualityCheck());
        }
    }
}