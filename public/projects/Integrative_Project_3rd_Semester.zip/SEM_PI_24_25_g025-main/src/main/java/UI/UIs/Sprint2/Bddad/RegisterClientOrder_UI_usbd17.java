package UI.UIs.Sprint2.Bddad;

import controllers.RegisterClientOrderController;

public class RegisterClientOrder_UI_usbd17 implements Runnable {

    private RegisterClientOrderController controller;

    public RegisterClientOrder_UI_usbd17() {
        this.controller = new RegisterClientOrderController();
    }

    public void run() {
        System.out.println("Register Client Order");
        controller.registerClientOrder();
    }
}
