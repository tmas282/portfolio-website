package UI.UIs.Sprint2.Bddad;

import oracle.jdbc.OracleTypes;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static bddad.db.DatabaseConnection.getConnection;

public class UseAllTypeMachines_usbd14 implements Runnable{
    private List<String> getProductsUsingAllTypeMachines() {
        List<String> products = new ArrayList<>();
        try (Connection conn = getConnection();) {
            CallableStatement stmt = conn.prepareCall("{? = call GetProductsUsingAllMachineTypes()}");
            stmt.registerOutParameter(1, OracleTypes.CURSOR);
            stmt.execute();

            try (ResultSet rs = (ResultSet) stmt.getObject(1)) {
                while (rs.next()) {
                    products.add(rs.getString("NAME"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
        return products;
    }
    @Override
    public void run() {
        try {
            List<String> products = getProductsUsingAllTypeMachines();
            if (products.isEmpty()) {
                System.out.println("No products found using workstation of all types.");
            } else {
                for (String product:
                     products) {
                    System.out.println(product);
                }
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
