package UI.UIs.Sprint2.Esinf;

import controllers.TreeProductionController;
import esinf.domain.sprint2.TreeProductionBuilder;
import esinf.domain.sprint2.ProductionTreeUpdater;
import UI.Utils.Utils;

import java.math.BigDecimal;

/**
 * USEI12_UI class represents the UI for updating material quantities.
 */
public class UpdateMaterialQuantities_usei12_UI implements Runnable {
    private TreeProductionBuilder builder;

    private TreeProductionController treeProductionController;

    /**
     * Constructor for USEI12_UI.
     *
     * @param treeProductionController the tree production controller
     */
    public UpdateMaterialQuantities_usei12_UI(TreeProductionController treeProductionController) {
        this.treeProductionController = treeProductionController;
    }

    /**
     * Runs the UI for updating material quantities.
     */
    public void run() {
        //Initializes the tree production builder
        builder = treeProductionController.getTreeProductionBuilder();

        String materialId = Utils.readLineFromConsole("Enter the material ID to update: ");
        BigDecimal newQuantity = new BigDecimal(Utils.readLineFromConsole("Enter the new quantity: "));
        ProductionTreeUpdater.updateMaterialQuantity(builder.getNodeById(materialId), materialId, newQuantity);
        System.out.println("Updated Production Tree:");
        builder.printTree(builder.getNodeById("1006"), "");
    }
}