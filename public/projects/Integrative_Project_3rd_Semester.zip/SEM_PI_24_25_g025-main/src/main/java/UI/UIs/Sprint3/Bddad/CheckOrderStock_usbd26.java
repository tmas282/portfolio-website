package UI.UIs.Sprint3.Bddad;

import UI.Utils.Utils;
import bddad.db.DatabaseConnection;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class CheckOrderStock_usbd26 implements Runnable {

    @Override
    public void run() {
        CheckOrderStock_usbd26 checkOrderStock = new CheckOrderStock_usbd26();
        int orderId = Integer.parseInt(Utils.readLineFromConsole("Enter Order ID: "));
        checkOrderStock.checkOrderStock(orderId);
    }

    public void checkOrderStock(int orderId) {
        try (Connection conn = DatabaseConnection.getConnection()) {

            // Habilitar o DBMS_OUTPUT
            conn.prepareStatement("BEGIN DBMS_OUTPUT.ENABLE(); END;").execute();

            // Chamar a Procedure
            String sql = "{CALL CheckOrderStock(?)}";
            try (CallableStatement stmt = conn.prepareCall(sql)) {
                stmt.setInt(1, orderId);
                stmt.execute();

                System.out.println("Order stock verification completed successfully.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
