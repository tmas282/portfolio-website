package UI.UIs.Sprint1.Esinf;

import controllers.SimulationController;
import esinf.domain.Operation;

import java.util.Map;

/**
 * USEI6_UI class represents the UI for displaying average execution times per operation.
 */
public class AveragePerOperation_usei6_UI implements Runnable {
    private SimulationController simulationController;

    /**
     * Constructor for USEI6_UI.
     *
     * @param simulationController the simulation controller
     */
    public AveragePerOperation_usei6_UI(SimulationController simulationController) {
        this.simulationController = simulationController;
    }

    /**
     * Runs the UI for displaying average execution times per operation.
     */
    public void run() {
        System.out.println("USEI6 - Average execution times per operation");
        System.out.println("====================================");
        Map<Operation, Double> averageExecutionTimesPerOperation = simulationController.getAverageTimeByOperation();
        for (Map.Entry<Operation, Double> entry : averageExecutionTimesPerOperation.entrySet()) {
            System.out.println("Operation: " + entry.getKey().getOperationID() + " - Average execution time: " + entry.getValue() + " seconds");
        }
    }
}