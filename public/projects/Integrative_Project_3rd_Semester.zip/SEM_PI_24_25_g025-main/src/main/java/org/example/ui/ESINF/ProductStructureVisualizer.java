package org.example.ui.ESINF;

import esinf.domain.sprint2.GraphVisualizer;
import esinf.domain.sprint2.TreeNode;
import esinf.domain.sprint2.TreeProductionBuilder;
import esinf.domain.sprint2.BOOEntry;
import org.graphstream.graph.Graph;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductStructureVisualizer {

    private TreeProductionBuilder builder;
//a
    public ProductStructureVisualizer(TreeProductionBuilder builder) {
        this.builder = builder;
    }

    public void visualizeProductStructure(String productId) {
        TreeNode root = builder.getNodeById(productId);
        if (root == null) {
            System.out.println("Product not found.");
            return;
        }
        Graph graph = GraphVisualizer.createGraph(root);
        GraphVisualizer.displayGraph(graph);
    }

    public static void main(String[] args) {
        // Sample Data Setup
        Map<String, String> itemsMap = new HashMap<>();
        itemsMap.put("P1", "Product1");
        itemsMap.put("P2", "Product2");

        Map<String, String> operationsMap = new HashMap<>();
        operationsMap.put("O1", "Operation1");
        operationsMap.put("O2", "Operation2");

        List<BOOEntry> booEntries = new ArrayList<>();

        // Define operation O1 produces P1 and depends on P2
        Map<String, String> productDependenciesO1 = new HashMap<>();
        productDependenciesO1.put("P2", "5");

        BOOEntry entryO1 = new BOOEntry("O1", "P1", "10", new HashMap<>(), productDependenciesO1);

        // Define operation O2 produces P2 with no dependencies
        BOOEntry entryO2 = new BOOEntry("O2", "P2", "5", new HashMap<>(), new HashMap<>());

        booEntries.add(entryO1);
        booEntries.add(entryO2);

        // Create TreeProductionBuilder
        TreeProductionBuilder builder = new TreeProductionBuilder(itemsMap, operationsMap);
        builder.buildTree("P1", booEntries); // Build initial tree

        // Initialize Visualizer
        ProductStructureVisualizer visualizer = new ProductStructureVisualizer(builder);

        // Visualize structure of product P1
        visualizer.visualizeProductStructure("P1");
    }
}
