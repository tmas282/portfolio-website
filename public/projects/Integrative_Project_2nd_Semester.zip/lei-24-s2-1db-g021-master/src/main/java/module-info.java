module pt.ipp.isep.dei.esoft.project.ui.gui {
    requires AuthLib;
    requires java.logging;
    requires jdk.jshell;
    requires org.apache.commons.lang3;
    requires javafx.controls;
    requires javafx.fxml;

    opens pt.ipp.isep.dei.esoft.project.ui.gui to javafx.fxml;
    exports pt.ipp.isep.dei.esoft.project.ui.gui;
}