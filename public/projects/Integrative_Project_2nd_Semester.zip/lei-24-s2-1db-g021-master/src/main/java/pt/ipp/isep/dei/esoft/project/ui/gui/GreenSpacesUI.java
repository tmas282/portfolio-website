package pt.ipp.isep.dei.esoft.project.ui.gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import pt.ipp.isep.dei.esoft.project.application.controller.ListGreenSpaceController;
import pt.ipp.isep.dei.esoft.project.application.controller.RegisterGreenSpaceController;
import pt.ipp.isep.dei.esoft.project.dto.GreenSpaceDTO;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class GreenSpacesUI implements Initializable {
    private final ListGreenSpaceController listGreenSpaceController = new ListGreenSpaceController();

    @FXML
    private VBox mainPane;
    @FXML
    private TextArea greenSpacesListTextArea;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        List<GreenSpaceDTO> result = listGreenSpaceController.getGreenSpaceList();

        for (GreenSpaceDTO greenSpaceDTO: result){
            addGreenSpaceToList(greenSpaceDTO);
        }
    }

    @FXML
    private void goToGreenSpaceAdd(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(ToDoListUI.class.getResource("add-new-green-space-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 600);

            Stage stage = new Stage();
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(mainPane.getScene().getWindow());
            stage.setScene(scene);

            RegisterGreenSpaceUI registerGreenSpaceUI = fxmlLoader.getController();
            registerGreenSpaceUI.setParent(this);

            stage.show();
        }catch(IOException exception) {
            exception.getStackTrace();
        }
    }

    public void addGreenSpaceToList(GreenSpaceDTO greenSpace) {
        greenSpacesListTextArea.appendText(String.format(
                "Name: %s (%s - %s hectares) %nDoor number: %s - Zip Code: %s %n",
                greenSpace.name(),
                greenSpace.sizeClassification(),
                greenSpace.area(),
                greenSpace.address().doorNumber(),
                greenSpace.address().zipCode()
        ));
    }
}
