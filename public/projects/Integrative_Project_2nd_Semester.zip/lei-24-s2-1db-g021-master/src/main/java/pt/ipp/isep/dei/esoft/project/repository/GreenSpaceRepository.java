package pt.ipp.isep.dei.esoft.project.repository;

import pt.ipp.isep.dei.esoft.project.domain.Collaborator;
import pt.ipp.isep.dei.esoft.project.domain.GreenSpace;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class GreenSpaceRepository implements Serializable {

    private final List<GreenSpace> greenSpacesList;

    public GreenSpaceRepository() {
        greenSpacesList = new ArrayList<>();
    }

    /**
     * @param greenSpace is the object of class GreenSpace that will be validated.
     *              First it will verify if the green space is not duplicated,
     *              then if the green space is valid, it clones the green space givened
     *              and it tries to add the green space to greenSpacesList.
     *              If this operation fails it was an error, if not, it
     * @return the Optional with green space that was cloned.
     */
    public Optional<GreenSpace> add(GreenSpace greenSpace) {
        if(greenSpace == null)
            return Optional.empty();

        if(greenSpacesList.contains(greenSpace))
            return Optional.empty();

        greenSpacesList.add(greenSpace);

        return Optional.of(greenSpace);
    }

    private boolean validateGreenSpace(GreenSpace greenSpace) {
        for (GreenSpace g : greenSpacesList) {
            if (g.getName().equalsIgnoreCase(greenSpace.getName())) {
                return false;
            }
        }
        return true;
    }

    /**
     * This method returns a defensive (immutable) copy of the list of green spaces.
     *
     * @return The list of green spaces.
     */
    public List<GreenSpace> getGreenSpacesList() {
        //This is a defensive copy, so that the repository cannot be modified from the outside.
        return List.copyOf(greenSpacesList);
    }

    public Optional<GreenSpace> getGreenSpaceByName(String name) {
        for(GreenSpace greenSpace : this.greenSpacesList)
            if(greenSpace.getName().equals(name))
                return Optional.of(greenSpace);

        return Optional.empty();
    }

    /**
     * This method gets the Green Spaces managed by a Green Spaces Manager
     * @param gsm The Green Spaces Manager
     * @return a list containing the Green Spaces
     */
    public List<GreenSpace> getGreenSpacesManagedByGSM(Collaborator gsm){
        List<GreenSpace> managedOnes = new ArrayList<>();
        for (GreenSpace greenSpace:
             this.greenSpacesList) {
            if (greenSpace.isManagedByGSM(gsm))
                managedOnes.add(greenSpace);
        }
        return List.copyOf(managedOnes);
    }
    public boolean remove(GreenSpace greenSpace) {
        return greenSpacesList.remove(greenSpace);
    }

}