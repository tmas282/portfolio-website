package pt.ipp.isep.dei.esoft.project.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class Address implements Serializable {
    private int doorNumber;
    private ZipCode zipCode;

    public Address(int doorNumber, ZipCode zipCode) {
        this.doorNumber = doorNumber;
        this.setZipCode(zipCode);
    }

    public Address(Address address) {
        this.doorNumber = address.getDoorNumber();
        this.zipCode = address.getZipCode();
    }

    public Address(String addressString) {
        String[] parts = addressString.split("-");
        if (parts.length != 3) {
            throw new IllegalArgumentException("Invalid address format! Expected: 'Door Number'-'Local'-'Street'");
        }
        this.doorNumber = Integer.parseInt(parts[0].trim());
        int local = Integer.parseInt(parts[1].trim());
        int street = Integer.parseInt(parts[2].trim());
        this.zipCode = new ZipCode(local, street);
    }

    public int getDoorNumber() {
        return doorNumber;
    }

    public void setDoorNumber(int doorNumber) {
        this.doorNumber = doorNumber;
    }

    public ZipCode getZipCode() {
        return new ZipCode(zipCode);
    }

    public void setZipCode(ZipCode zipCode) {
        this.zipCode = new ZipCode(zipCode);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Address address = (Address) o;
        return doorNumber == address.doorNumber && Objects.equals(zipCode, address.zipCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(doorNumber, zipCode);
    }

    @Override
    public String toString() {
        return "Address{" +
                "doorNumber=" + doorNumber +
                ", zipCode='" + zipCode + '\'' +
                '}';
    }
}