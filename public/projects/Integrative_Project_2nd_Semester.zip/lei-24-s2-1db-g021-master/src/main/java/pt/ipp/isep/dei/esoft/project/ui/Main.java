package pt.ipp.isep.dei.esoft.project.ui;

import pt.ipp.isep.dei.esoft.project.repository.Repositories;
import pt.ipp.isep.dei.esoft.project.ui.console.menu.MainMenuUI;
import pt.ipp.isep.dei.esoft.project.utils.SerializeUtils;

public class Main {
    private static final String PATH = "src/main/resources/database.bin";

    public static void main(String[] args) {
        Repositories newRepositories = SerializeUtils.deserializeInfo(PATH);
        Repositories.setInstance(newRepositories);

        Bootstrap bootstrap = new Bootstrap();
        bootstrap.run();

        try {
            MainMenuUI menu = new MainMenuUI();
            menu.run();
        } catch (Exception e) {
            e.printStackTrace();
        }

        SerializeUtils.serializeInfo(PATH);
    }
}