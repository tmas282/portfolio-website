package pt.ipp.isep.dei.esoft.project.dto;

import java.util.List;

public record TeamDTO(String name, int minSize, int maxSize, List<CollaboratorDTO> collaboratorList, List<SkillDTO> selectedSkills) {
    @Override
    public String toString() {
        return name;
    }
}
