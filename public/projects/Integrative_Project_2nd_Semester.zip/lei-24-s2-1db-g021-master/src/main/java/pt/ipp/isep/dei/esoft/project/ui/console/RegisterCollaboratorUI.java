package pt.ipp.isep.dei.esoft.project.ui.console;

import pt.ipp.isep.dei.esoft.project.application.controller.ListJobsController;
import pt.ipp.isep.dei.esoft.project.application.controller.RegisterCollaboratorController;
import pt.ipp.isep.dei.esoft.project.domain.*;
import pt.ipp.isep.dei.esoft.project.domain.ZipCode;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class RegisterCollaboratorUI implements Runnable{
    private final RegisterCollaboratorController registerCollaboratorController;
    private final ListJobsController listJobsController;
    private final Scanner scanner;

    /**
     * This instantiates the controller of this operation.
     */
    public RegisterCollaboratorUI() {
        this.registerCollaboratorController = new RegisterCollaboratorController();
        this.listJobsController = new ListJobsController();
        this.scanner = new Scanner(System.in);
    }

    /**
     * Runs this operation. This operation is based on register a job that a collaborator may have.
     */
    @Override
    public void run() {
        int count=0;
        while (true) {
            if(count!=0) {
                System.out.println("Enter 'exit' to return to the main menu, or any other key to continue:");
                String input = scanner.nextLine();
                if (input.equalsIgnoreCase("exit")) {
                    break;
                }
            }

            /*List<Job> jobList = controller.getJobs();
            Utils.showList(jobList, "Jobs");
            int jobIndex = Utils.readIntegerFromConsole("Select the job: ") - 1;
            if (jobIndex == -1)
                return;
            controller.setJobSelected(jobList.get(jobIndex));*/

            List<Job> jobList = listJobsController.listJobs();
            Job jobSelected = new Job("erro");

            System.out.println("Jobs to be selected: ");
            System.out.println("0. Exit");
            for (int i = 0; i < jobList.size(); i++) {
                System.out.println((i + 1) + ". " + jobList.get(i).getName());
            }
            int jobNumber = scanner.nextInt();
            if (jobNumber == 0) {
                break;
            }
            if (jobNumber > 0 && jobNumber <= jobList.size()) {
                jobSelected=(jobList.get(jobNumber - 1));
            } else {
                System.out.println("Invalid number selected");
            }

            System.out.println("=== Collaborator Fundamental Information ===");
            System.out.print("Name: ");
            scanner.nextLine();
            String name = scanner.nextLine();

            System.out.print("Born Date (yyyy-MM-dd format): ");
            Date bornDate = null;
            while (bornDate == null) {
                String dateStr = scanner.nextLine();
                try {
                    bornDate = new SimpleDateFormat("yyyy-MM-dd").parse(dateStr);
                } catch (ParseException e) {
                    System.out.print("Invalid date format. Please enter again (yyyy-MM-dd format): ");
                }
            }

            System.out.print("Admission Date (yyyy-MM-dd format): ");
            Date admDate = null;
            while (admDate == null) {
                String dateStr = scanner.nextLine();
                try {
                    admDate = new SimpleDateFormat("yyyy-MM-dd").parse(dateStr);
                } catch (ParseException e) {
                    System.out.print("Invalid date format. Please enter again (yyyy-MM-dd format): ");
                }
            }

            System.out.print("Local (4-digit integer): ");
            int local = Integer.parseInt(scanner.nextLine());

            System.out.print("Street (3-digit integer): ");
            int street = Integer.parseInt(scanner.nextLine());

            ZipCode zipCode = new ZipCode(
                    local, street
            );
            System.out.print("Door number (integer): ");
            int doorNumber = Integer.parseInt(scanner.nextLine());
            Address address = new Address(
                    doorNumber, zipCode
            );

            System.out.print("Phone number: ");
            int phoneNumber = Integer.parseInt(scanner.nextLine());

            System.out.print("Email: ");
            String email = scanner.nextLine();

            System.out.print("Card number: ");
            int cardNumber = Integer.parseInt(scanner.nextLine());

            System.out.print("Tax payer number: ");
            int taxtPayerNumber = Integer.parseInt(scanner.nextLine());

            Optional<Collaborator> collaborator = registerCollaboratorController.createCollaborator(new Document(name, bornDate, cardNumber), admDate,address,phoneNumber,email, taxtPayerNumber, jobSelected);
            if (collaborator.isPresent()) {
                System.out.println("Collaborator registed successfully!");
            } else {
                System.out.println("Collaborator already exists or job name is an invalid name.");
            }
            count++;

        }
        System.out.println("List of Registered Collaborators:");
        for (Collaborator collaborators : registerCollaboratorController.getCollaborators()) {
            System.out.println(collaborators);
        }

    }
}