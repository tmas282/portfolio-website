package pt.ipp.isep.dei.esoft.project.dto;

import pt.ipp.isep.dei.esoft.project.domain.SizeClassification;

public record GreenSpaceDTO(String name, SizeClassification sizeClassification, float area, AddressDTO address) { }