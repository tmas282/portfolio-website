package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.dto.TeamDTO;
import pt.ipp.isep.dei.esoft.project.mapper.TeamMapper;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;
import pt.ipp.isep.dei.esoft.project.repository.TeamRepository;

import java.util.List;

public class ListTeamController {
    private final TeamRepository teamRepository;

    public ListTeamController() {
        teamRepository = Repositories.getInstance().getTeamRepository();
    }

    /**
     * Allows injection of repositories to be used by the controller. Useful for testing.
     *
     * @param teamRepository to be used
     */
    public ListTeamController(TeamRepository teamRepository) {
        this.teamRepository = teamRepository;
    }

    public List<TeamDTO> listTeams() {
        return TeamMapper.toDTO(List.copyOf(teamRepository.getTeamList()));
    }
}
