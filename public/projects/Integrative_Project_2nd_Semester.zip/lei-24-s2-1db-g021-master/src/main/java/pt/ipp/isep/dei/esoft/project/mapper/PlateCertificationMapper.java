package pt.ipp.isep.dei.esoft.project.mapper;

import pt.ipp.isep.dei.esoft.project.domain.PlateCertification;
import pt.ipp.isep.dei.esoft.project.dto.PlateCertificationDTO;

import java.util.ArrayList;
import java.util.List;

public class PlateCertificationMapper {

    public static PlateCertificationDTO toDTO(PlateCertification plateCertification) {
        return new PlateCertificationDTO(
                plateCertification.getBrand(),
                plateCertification.getModel(),
                plateCertification.getType(),
                plateCertification.getTare(),
                plateCertification.getGrossWeight(),
                plateCertification.getRegisterDate(),
                plateCertification.getPlate()
        );
    }

    public static List<PlateCertificationDTO> toDTO(List<PlateCertification> plateCertificationList) {
        List<PlateCertificationDTO> newList = new ArrayList<>();

        for(PlateCertification plateCertification : plateCertificationList) {
            newList.add(toDTO(plateCertification));
        }

        return List.copyOf(newList);
    }
}
