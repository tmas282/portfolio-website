package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.domain.Skill;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;
import pt.ipp.isep.dei.esoft.project.repository.SkillRepository;

import java.util.List;
import java.util.Optional;

public class RegisterSkillController {

    private SkillRepository skillRepository;

    public RegisterSkillController() {
        getSkillsRepository();
    }

    public RegisterSkillController(SkillRepository skillRepository) {
        this.skillRepository = skillRepository;
    }

    private SkillRepository getSkillsRepository() {
        if (skillRepository == null) {
            Repositories repositories = Repositories.getInstance();
            skillRepository = repositories.getSkillRepository();
        }
        return skillRepository;
    }

    /**
     * @param name is the name of the skill that will be created
     *             if the skill was a valid name,
     * @return the new skill
     *             if not, it throws a IllegalArgumentException
     */
    public Optional<Skill> createSkill(String name) {
        Optional<Skill> newSkill;
        try {
            newSkill = skillRepository.add(new Skill(name));
        } catch (IllegalArgumentException e) {
            return Optional.empty();
        }
        return newSkill;
    }

    public List<Skill> getSkillsList() {
        return skillRepository.getSkillsList();
    }
}