package pt.ipp.isep.dei.esoft.project.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import java.util.regex.Pattern;

public class PlateCertification implements Serializable {
    private String brand;
    private String model;
    private String type;
    private double tare;
    private double grossWeight;
    private Date registerDate;
    private String plate;

    /**
     * Creates a new instance of PlateCertification Class.
     * @param brand Represents the brand of the vehicle.
     * @param model Represents the car model.
     * @param type Represents the type of vehicle.
     * @param tare Represents the total weight of the vehicle when it is empty.
     * @param grossWeight Represents the total weight of the vehicle along with all its contents.
     * @param registerDate Represents the date on which the plate was registered.
     * @param plate Represents the plate format.
     */
    public PlateCertification(String brand, String model, String type, double tare, double grossWeight, Date registerDate, String plate) {
        validateAttributes(brand, model, type, tare, grossWeight, registerDate, plate);
        this.brand = brand;
        this.model = model;
        this.type = type;
        this.tare = tare;
        this.grossWeight = grossWeight;
        this.registerDate = registerDate;
        this.plate = plate;
    }

    /**
     * Validates the attributes of the PlateCertification object.
     * @param brand Represents the brand of the vehicle.
     * @param model Represents the car model.
     * @param type Represents the type of vehicle.
     * @param tare Represents the total weight of the vehicle when it is empty.
     * @param grossWeight Represents the total weight of the vehicle along with all its contents.
     * @param registerDate Represents the date on which the plate was registered.
     * @param plate Represents the plate format.
     * @throws IllegalArgumentException if any of the validation rules are violated.
     */
    private void validateAttributes(String brand, String model, String type, double tare, double grossWeight, Date registerDate, String plate) {
        if (brand == null || brand.isEmpty()) {
            throw new IllegalArgumentException("Brand can't be empty.");
        }
        if (model == null || model.isEmpty()) {
            throw new IllegalArgumentException("Model can't be empty.");
        }
        if (type == null || type.isEmpty()) {
            throw new IllegalArgumentException("Type can't be empty.");
        }
        if (tare <= 0) {
            throw new IllegalArgumentException("Tare can't have negative values or 0.");
        }
        if (grossWeight <= 0) {
            throw new IllegalArgumentException("Gross weight can't have negative values or 0.");
        }
        /*if (grossWeight <= tare) {
            throw new IllegalArgumentException("Gross weight can't be less than or equal to tare.");
        }*/
        if (registerDate == null) {
            throw new IllegalArgumentException("Register date can't be null.");
        }
        //validatePlate(plate, registerDate);
    }

    /**
     * Validates the plate format based on the registration date.
     * @param plate The plate to be validated.
     * @param registerDate The date when the plate was registered.
     */
    /*private void validatePlate(String plate, Date registerDate) {
        if (plate == null || plate.isEmpty()) {
            throw new IllegalArgumentException("Plate can't be empty.");
        }
        Pattern pattern = getPlatePattern(registerDate);
        if (!pattern.matcher(plate).matches()) {
            throw new IllegalArgumentException("Invalid plate format for the given registration date.");
        }
    }*/

    /**
     * Returns the appropriate plate pattern based on the registration date.
     * @param registerDate The date when the plate was registered.
     * @return The plate pattern.
     */
    /*private Pattern getPlatePattern(Date registerDate) {
        if (registerDate.after(new Date(120, 0, 1))) { // After 2020
            return Pattern.compile("[A-Z]{2}-\\d{2}-[A-Z]{2}");
        } else if (registerDate.after(new Date(105, 0, 1))) { // Between 2005 and 2020
            return Pattern.compile("\\d{2}-[A-Z]{2}-\\d{2}");
        } else { // Between 1992 and 2005
            return Pattern.compile("\\d{2}-\\d{2}-[A-Z]{2}");
        }
    }*/

    /**
     * Returns the value of the attribute brand.
     * @return the brand value.
     */
    public String getBrand() {
        return brand;
    }

    /**
     * @param brand it's the brand of vehicle,
     *             if the brand is valid, set the brand,
     *             if it's null or empty, it throws a IllegalArgumentException.
     */
    public void setBrand(String brand) {
        if (brand == null || brand.isEmpty()){
            throw new IllegalArgumentException("Brand can't be empty.");
        }
        this.brand = brand;
    }

    /**
     * Returns the value of the attribute model.
     * @return the model value.
     */
    public String getModel() {
        return model;
    }

    /**
     * @param model it's the model of vehicle,
     *             if the model is valid, set the model,
     *             if it's null or empty, it throws a IllegalArgumentException.
     */
    public void setModel(String model) {
        if (model == null || model.isEmpty()){
            throw new IllegalArgumentException("Model can't be empty.");
        }
        this.model = model;
    }

    /**
     * Returns the value of the attribute type.
     * @return the type value.
     */
    public String getType() {
        return type;
    }

    /**
     * @param type it's the type of vehicle,
     *             if the model is valid, set the model,
     *             if it's null or empty, it throws a IllegalArgumentException.
     */
    public void setType(String type) {
        if (type == null || type.isEmpty()){
            throw new IllegalArgumentException("Type can't be empty.");
        }
        this.type = type;
    }

    /**
     * Returns the value of the attribute tare.
     * @return the tare value.
     */
    public double getTare() {
        return tare;
    }

    /**
     * @param tare it's the tare of vehicle,
     *             if the tare is valid, set the tare,
     *             if it's less than or equal to zero, and is greater than grossWeight, it throws a IllegalArgumentException.
     */
    public void setTare(double tare) {
        if (tare <= 0){
            throw new IllegalArgumentException("Tare can't have negative values or 0.");
        }
        if (tare > this.grossWeight) {
            throw new IllegalArgumentException("Tare can't be greater than gross weight.");
        }
        this.tare = tare;
    }

    /**
     * Returns the value of the attribute grossWeight.
     * @return the grossWeight value.
     */
    public double getGrossWeight() {
        return grossWeight;
    }

    /**
     * @param grossWeight it's the gross weight of the vehicle,
     *             if the grossWeight is valid, set the grossWeight,
     *             if it's less than or equal to zero, and is less than tare, it throws a IllegalArgumentException.
     */
    public void setGrossWeight(double grossWeight) {
        if (grossWeight <= 0){
            throw new IllegalArgumentException("Gross weight can't have negative values or 0.");
        }
        if (grossWeight < this.tare) {
            throw new IllegalArgumentException("Gross weight can't be less than tare.");
        }
        this.grossWeight = grossWeight;
    }

    /**
     * Returns the value of the attribute registerDate.
     * @return the registerDate value.
     */
    public Date getRegisterDate() {
        return registerDate;
    }

    /**
     * @param registerDate it's the date on which the plate was registered.
     */
    public void setRegisterDate(Date registerDate) {
        if (registerDate == null) {
            throw new IllegalArgumentException("Register date can't be null.");
        }
        this.registerDate = registerDate;
    }

    /**
     * Returns the value of the attribute plate.
     * @return the plate value.
     */
    public String getPlate() {
        return plate;
    }

    /**
     * Validates the plate format based on the registration date.
     * @param plate it's the vehicle plate,
     *             if the plate is valid, set the model,
     *             if it's null or empty, it throws a IllegalArgumentException.
     */
    public void setPlate(String plate) {
        //validatePlate(plate, this.registerDate);
        this.plate = plate;
    }

    /**
     * Compare this PlateCertification object with another for equality.
     * @param o The object to be compared.
     * @return True if the objects are equal, false otherwise.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PlateCertification that = (PlateCertification) o;
        return Double.compare(tare, that.tare) == 0 && Double.compare(grossWeight, that.grossWeight) == 0 && Objects.equals(brand, that.brand) && Objects.equals(model, that.model) && Objects.equals(type, that.type) && Objects.equals(registerDate, that.registerDate) && Objects.equals(plate, that.plate);
    }

    /**
     * Returns a hash code for the PlateCertification object.
     * This method is supported to facilitate the use of objects in hash-based data structures such as HashMap.
     * @return A hash code for the object.
     */
    @Override
    public int hashCode() {
        return Objects.hash(brand, model, type, tare, grossWeight, registerDate, plate);
    }

    /**
     * Returns a String representation of the PlateCertification object.
     * This representation includes relevant information about the PlateCertification object.
     * @return String representation of the PlateCertification object.
     */
    @Override
    public String toString() {
        return "PlateCertification{" +
                "brand='" + brand + '\'' +
                ", model='" + model + '\'' +
                ", type='" + type + '\'' +
                ", tare=" + tare +
                ", grossWeight=" + grossWeight +
                ", registerDate=" + registerDate +
                ", plate='" + plate + '\'' +
                '}';
    }

    /**
     * Creates and returns a copy of this Job object.
     * @return A copy of this object.
     */
    public PlateCertification clone() {
        return new PlateCertification(this.brand, this.model, this.type, this.tare, this.grossWeight, this.registerDate, this.plate);
    }
}