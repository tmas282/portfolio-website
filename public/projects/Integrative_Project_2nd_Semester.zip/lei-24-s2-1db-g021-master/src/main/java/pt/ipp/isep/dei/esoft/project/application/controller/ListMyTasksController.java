package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.application.session.ApplicationSession;
import pt.ipp.isep.dei.esoft.project.domain.AgendaEntry;
import pt.ipp.isep.dei.esoft.project.domain.Collaborator;
import pt.ipp.isep.dei.esoft.project.dto.MyTasksFilterDTO;
import pt.ipp.isep.dei.esoft.project.dto.TaskDTO;
import pt.ipp.isep.dei.esoft.project.mapper.TaskMapper;
import pt.ipp.isep.dei.esoft.project.repository.AgendaEntryRepository;
import pt.ipp.isep.dei.esoft.project.repository.CollaboratorRepository;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class ListMyTasksController {
    private final AgendaEntryRepository agendaEntryRepository;
    private final CollaboratorRepository collaboratorRepository;
    private final ApplicationSession applicationSession;

    public ListMyTasksController() {
        agendaEntryRepository = Repositories.getInstance().getAgendaEntryRepository();
        collaboratorRepository = Repositories.getInstance().getCollaboratorRepository();
        applicationSession = ApplicationSession.getInstance();
    }

    /**
     * Allows injection of repositories to be used by the controller. Useful for testing.
     *
     * @param agendaEntryRepository to be used
     * @param collaboratorRepository to be used
     * @param applicationSession to be used
     */
    public ListMyTasksController(AgendaEntryRepository agendaEntryRepository, CollaboratorRepository collaboratorRepository, ApplicationSession applicationSession) {
        this.agendaEntryRepository = agendaEntryRepository;
        this.collaboratorRepository = collaboratorRepository;
        this.applicationSession = applicationSession;
    }

    public List<TaskDTO> listTasks(MyTasksFilterDTO myTasksFilterDTO) {
        if(myTasksFilterDTO == null)
            return List.of();

        String userEmail = applicationSession.getCurrentSession().getUserEmail();

        if(userEmail == null)
            return List.of();

        Optional<Collaborator> collaborator = collaboratorRepository.getCollaboratorByEmail(userEmail);

        if(collaborator.isEmpty())
            return List.of();

        List<AgendaEntry> agendaEntryList = agendaEntryRepository.getAgendaEntriesByCollaboratorAndStateBetweenDates(
                collaborator.get(),
                myTasksFilterDTO.entryStatus(),
                myTasksFilterDTO.start(),
                myTasksFilterDTO.end()
        );

        List<AgendaEntry> tempAgendaEntryList = new ArrayList<>(agendaEntryList);

        tempAgendaEntryList.sort(new Comparator<AgendaEntry>() {
            @Override
            public int compare(AgendaEntry agendaEntry1, AgendaEntry agendaEntry2) {
                if(agendaEntry1.getStartDate().before(agendaEntry2.getStartDate()))
                    return -1;
                else if(agendaEntry1.getStartDate().after(agendaEntry2.getStartDate()))
                    return 1;
                else
                    return 0;
            }
        });

        return TaskMapper.toDTO(tempAgendaEntryList.stream().map(AgendaEntry::getTask).toList());
    }
}
