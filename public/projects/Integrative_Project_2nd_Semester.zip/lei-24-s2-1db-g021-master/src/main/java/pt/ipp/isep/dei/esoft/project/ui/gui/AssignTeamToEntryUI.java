package pt.ipp.isep.dei.esoft.project.ui.gui;

import javafx.fxml.FXML;
import javafx.scene.control.ListView;

public class AssignTeamToEntryUI {
    @FXML
    public ListView<String> listViewTeam;
    @FXML
    public ListView<String> listViewEntries;

    public void clickAssignButton(){
    }
}
