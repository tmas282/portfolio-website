package pt.ipp.isep.dei.esoft.project.dto;

import pt.ipp.isep.dei.esoft.project.domain.EntryStatus;

import java.util.Date;
import java.util.List;

public record NewAgendaEntryDTO(int expectedDuration, Date startDate, List<VehicleDTO> equipment, TeamDTO team, TaskDTO task) {
}