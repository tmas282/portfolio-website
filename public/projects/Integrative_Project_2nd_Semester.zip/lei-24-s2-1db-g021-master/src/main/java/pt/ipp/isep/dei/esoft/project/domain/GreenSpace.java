package pt.ipp.isep.dei.esoft.project.domain;

import java.io.Serializable;
import java.util.Objects;
import java.util.regex.Pattern;

public class GreenSpace implements Serializable {
    private String name;
    private SizeClassification sizeClassification;
    private float area;
    private Address address;

    private Collaborator theManager;

    public GreenSpace(String name, SizeClassification sizeClassification, float area, Address address, Collaborator theManager) throws IllegalArgumentException {
        if(!verifyName(name))
            throw new IllegalArgumentException("Invalid name");

        if(sizeClassification == null)
            throw new IllegalArgumentException("Invalid sizeClassification");

        if(!verifyArea(area))
            throw new IllegalArgumentException("Invalid area");

        if(address == null)
            throw new IllegalArgumentException("Invalid address");


        this.name = name;
        this.sizeClassification = sizeClassification;
        this.area = area;
        this.address = address;
        this.theManager = theManager;
    }

    /**
     * Verify if the name is valid. The name must not be blank.
     * The valid characters are A-Z, a-z, 0-9, '-', '_' and ' '
     *
     * @param name
     * @return true if the name is valid and false if it is not valid
     */
    boolean verifyName(String name) {
        if(name == null)
            return false;

        if(name.isBlank())
            return false;

        Pattern validName = Pattern.compile("^[A-z0-9-_ ]+$");

        if(!validName.matcher(name).matches())
            return false;

        return true;
    }

    /**
     * Verify if the area is valid. Area must be greater than 0.
     *
     * @param area
     * @return true if the area is valid and false if it is not valid
     */
    boolean verifyArea(float area) {
        if (area <= 0)
            return false;
        return true;
    }

    public SizeClassification getSizeClassification() {
        return sizeClassification;
    }

    public String getName() {
        return name;
    }

    public float getArea() {
        return area;
    }

    public Address getAddress() {
        return address;
    }

    /**
     * This method checks if this instance is managed by a Green Spaces Manager
     * @param gsm the Green Spaces Manager
     * @return a boolean value
     */
    public boolean isManagedByGSM(Collaborator gsm){
        if (gsm == null) {
            return false;
        }
        return gsm.equals(theManager);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GreenSpace that = (GreenSpace) o;
        return Float.compare(area, that.area) == 0 && Objects.equals(sizeClassification, that.sizeClassification) && Objects.equals(name, that.name) && Objects.equals(address, that.address);
    }
}