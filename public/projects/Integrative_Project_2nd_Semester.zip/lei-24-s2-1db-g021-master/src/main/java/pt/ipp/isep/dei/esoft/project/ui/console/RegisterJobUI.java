package pt.ipp.isep.dei.esoft.project.ui.console;

import pt.ipp.isep.dei.esoft.project.application.controller.RegisterJobController;
import pt.ipp.isep.dei.esoft.project.domain.Job;
import java.util.Optional;
import java.util.Scanner;

public class RegisterJobUI implements Runnable{
    private RegisterJobController controller;
    private Scanner scanner;

    /**
     * This instantiates the controller of this operation.
     */
    public RegisterJobUI() {
        this.controller = new RegisterJobController();
        this.scanner = new Scanner(System.in);
    }

    /**
     * This gets the instantiated controller.
     * @return a RegisterJobController object.
     */
    public RegisterJobController getController() {
        return controller;
    }

    /**
     * Runs this operation. This operation is based on register a job that a collaborator may have.
     */
    @Override
    public void run() {
        while (true) {
            System.out.println("Insert the job name or 'exit' to return to HRM menu:");
            String jobName = scanner.nextLine();
            if (jobName.equalsIgnoreCase("exit")) {
                break;
            }
            Optional<Job> job = controller.createJob(jobName);
            if (job.isPresent()) {
                System.out.println("Job added successfully!");
            } else {
                System.out.println("Job already exists or job name is an invalid name.");
            }

        }
        //Se eu encerrar o programa e voltar a inserir, ele não mostra os anteriores, fica vazio! Aposto que é do Serializable, e vamos ter de dar implements!!
        System.out.println("List of Registered Jobs:");
        for (Job job : controller.getJobsList()) {
            System.out.println(job);
        }
    }
}