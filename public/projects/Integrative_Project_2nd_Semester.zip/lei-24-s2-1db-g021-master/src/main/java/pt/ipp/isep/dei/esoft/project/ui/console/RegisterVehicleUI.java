package pt.ipp.isep.dei.esoft.project.ui.console;

import pt.ipp.isep.dei.esoft.project.application.controller.RegisterVehicleController;
import pt.ipp.isep.dei.esoft.project.domain.PlateCertification;
import pt.ipp.isep.dei.esoft.project.domain.Vehicle;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;
import java.util.Scanner;
import java.util.regex.Pattern;

public class RegisterVehicleUI implements Runnable {
    private RegisterVehicleController vehicleController;
    private Scanner scanner;

    /**
     * This instantiates the controller of this operation.
     */
    public RegisterVehicleUI() {
        this.vehicleController = new RegisterVehicleController();
        this.scanner = new Scanner(System.in);
    }

    /**
     * Runs this operation.
     */
    @Override
    public void run() {
        System.out.println("=== Register Vehicle ===");

        while (true) {
            System.out.println("Enter 'exit' to return to the main menu, or any other key to continue:");
            String input = scanner.nextLine();
            if (input.equalsIgnoreCase("exit")) {
                break;
            }

            double currentKm = -1;
            while (currentKm < 0) {
                try {
                    System.out.print("Current kilometers: ");
                    currentKm = Double.parseDouble(scanner.nextLine());
                    if (currentKm < 0) {
                        System.out.println("Current kilometers cannot be negative.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a valid number for current kilometers.");
                }
            }

            Date acquisitionDate = null;
            while (acquisitionDate == null) {
                System.out.print("Acquisition date (yyyy-MM-dd format): ");
                String dateStr = scanner.nextLine();
                try {
                    acquisitionDate = new SimpleDateFormat("yyyy-MM-dd").parse(dateStr);
                } catch (ParseException e) {
                    System.out.print("Invalid date format. Please enter again. ");
                }
            }

            double maintenance = -1;
            while (maintenance <= 0) {
                try {
                    System.out.print("Maintenance distance (km): ");
                    maintenance = Double.parseDouble(scanner.nextLine());
                    if (maintenance <= 0) {
                        System.out.println("Maintenance distance must be greater than zero.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a valid number for maintenance.");
                }
            }

            System.out.println("=== Plate Certification Information ===");

            System.out.print("Brand: ");
            String brand = scanner.nextLine();

            System.out.print("Model: ");
            String model = scanner.nextLine();

            System.out.print("Type: ");
            String type = scanner.nextLine();

            double tare = -1;
            while (tare <= 0) {
                try {
                    System.out.print("Tare: ");
                    tare = Double.parseDouble(scanner.nextLine());
                    if (tare <= 0) {
                        System.out.println("Tare must be greater than zero.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a valid number for tare.");
                }
            }

            double grossWeight = -1;
            while (grossWeight <= tare) {
                try {
                    System.out.print("Gross Weight: ");
                    grossWeight = Double.parseDouble(scanner.nextLine());
                    if (grossWeight <= tare) {
                        System.out.println("Gross Weight must be greater than Tare.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a valid number for gross weight.");
                }
            }

            Date registerDate = null;
            while (registerDate == null || registerDate.before(acquisitionDate)) {
                System.out.print("Register date (yyyy-MM-dd format): ");
                String dateStr = scanner.nextLine();
                try {
                    registerDate = new SimpleDateFormat("yyyy-MM-dd").parse(dateStr);
                    if (registerDate.before(acquisitionDate)) {
                        System.out.println("Register date must be after acquisition date.");
                        registerDate = null;
                    }
                } catch (ParseException e) {
                    System.out.print("Invalid date format. Please enter again. ");
                }
            }

            String plate = "";
            while (!validatePlate(plate, registerDate)) {
                System.out.print("Plate: ");
                plate = scanner.nextLine();
                if (!validatePlate(plate, registerDate)) {
                    System.out.println("Invalid plate format for the given registration date.");
                }
            }

            PlateCertification plateCertification = new PlateCertification(
                    brand, model, type, tare, grossWeight, registerDate, plate
            );

            Optional<Vehicle> vehicle = vehicleController.createVehicle(
                    currentKm, acquisitionDate, maintenance, plateCertification
            );

            if (vehicle.isPresent()) {
                System.out.println("Vehicle registered successfully: " + vehicle.get());
            } else {
                System.out.println("Failed to register vehicle.");
            }
        }

        System.out.println("Registered Vehicles:");
        for (Vehicle vehicle : vehicleController.getVehiclesList()) {
            System.out.println(vehicle);
        }
    }

    private boolean validatePlate(String plate, Date registerDate) {
        int year = Integer.parseInt(new SimpleDateFormat("yyyy").format(registerDate));
        String pattern;
        if (year > 2020) {
            pattern = "^[A-Z]{2}-\\d{2}-[A-Z]{2}$"; // AA-00-AA
        } else if (year >= 2005) {
            pattern = "^\\d{2}-[A-Z]{2}-\\d{2}$"; // 00-AA-00
        } else if (year >= 1992) {
            pattern = "^\\d{2}-\\d{2}-[A-Z]{2}$"; // 00-00-AA
        } else {
            return false; // No valid format for years before 1992
        }
        return Pattern.matches(pattern, plate);
    }
}