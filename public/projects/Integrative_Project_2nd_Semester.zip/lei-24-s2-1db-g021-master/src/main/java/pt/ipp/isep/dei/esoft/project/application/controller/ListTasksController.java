package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.dto.TaskDTO;
import pt.ipp.isep.dei.esoft.project.mapper.TaskMapper;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;
import pt.ipp.isep.dei.esoft.project.repository.TaskRepository;

import java.util.List;

public class ListTasksController {
    private final TaskRepository taskRepository;

    public ListTasksController() {
        taskRepository = Repositories.getInstance().getTaskRepository();
    }

    /**
     * Allows injection of repositories to be used by the controller. Useful for testing.
     *
     * @param taskRepository to be used
     */
    public ListTasksController(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    public List<TaskDTO> listTasks() {
        return TaskMapper.toDTO(List.copyOf(taskRepository.getTasks()));
    }
}
