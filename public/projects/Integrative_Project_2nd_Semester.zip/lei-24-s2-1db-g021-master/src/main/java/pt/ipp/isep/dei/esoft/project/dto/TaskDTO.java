package pt.ipp.isep.dei.esoft.project.dto;

import pt.ipp.isep.dei.esoft.project.domain.TaskCategory;
import pt.ipp.isep.dei.esoft.project.domain.TaskUrgency;

public record TaskDTO(String name, String description, TaskCategory category, TaskUrgency urgency, GreenSpaceDTO greenSpace) {
    @Override
    public String toString() {
        return name;
    }
}
