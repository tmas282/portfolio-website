package pt.ipp.isep.dei.esoft.project.ui.console;

import pt.ipp.isep.dei.esoft.project.application.controller.AssignSkillController;
import pt.ipp.isep.dei.esoft.project.dto.CollaboratorDTO;
import pt.ipp.isep.dei.esoft.project.dto.SkillDTO;
import pt.ipp.isep.dei.esoft.project.ui.console.utils.Utils;

import java.util.ArrayList;
import java.util.List;

public class AssignSkillUI implements Runnable{
    private final AssignSkillController controller = new AssignSkillController();

    private List<SkillDTO> getSkillsSelected(List<SkillDTO> skills){
        List<SkillDTO> skillsSelected = new ArrayList<>();

        int skillIndexSelected = 0;

        while (true) {
            skillIndexSelected = Utils.readIntegerFromConsole("Select one Skill: ") - 1;

            if (skillIndexSelected != -1)
                skillsSelected.add(skills.get(skillIndexSelected));
            else
                break;
        }

        return skillsSelected;
    }

    /**
     * Runs this operation. This operation is based on assigning skills to a collaborator.
     */
    @Override
    public void run() {
        List<CollaboratorDTO> collaboratorList = controller.getCollaborators();

        Utils.showList(collaboratorList, "Collaborators");

        int collaboratorIndex = Utils.readIntegerFromConsole("Select the collaborator: ") - 1;

        if (collaboratorIndex == -1)
            return;

        CollaboratorDTO selectedCollaborator = collaboratorList.get(collaboratorIndex);

        List<SkillDTO> skills = controller.getSkills();

        Utils.showList(skills, "Skills");

        List<SkillDTO> selectedSkills = getSkillsSelected(skills);

        int confirm = -1;

        while (confirm < 0 || confirm > 1) {
            confirm = Utils.readIntegerFromConsole("Press 1 to confirm and 0 to discard changes: ");
        }

        if(confirm == 0)
            return;

        for(SkillDTO skill : selectedSkills) {
            controller.addSkillToCollaborator(skill, selectedCollaborator);
        }
    }
}
