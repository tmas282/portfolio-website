package pt.ipp.isep.dei.esoft.project.ui.gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import pt.ipp.isep.dei.esoft.project.application.controller.ListAgendaEntriesController;
import pt.ipp.isep.dei.esoft.project.dto.AgendaEntryDTO;
import pt.ipp.isep.dei.esoft.project.dto.TaskDTO;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class AgendaUI implements Initializable {
    private final ListAgendaEntriesController listAgendaEntriesController = new ListAgendaEntriesController();

    @FXML
    private VBox mainPane;
    @FXML
    private TextArea txtAgenda;
    @FXML
    private Button addTaskButton;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        writeAgendaEntryList();
    }

    @FXML
    public void openAddEntry(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(ToDoListUI.class.getResource("add-entry-agenda.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 600);

            Stage stage = new Stage();
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(mainPane.getScene().getWindow());
            stage.setScene(scene);

            AddEntryAgendaUI addEntryAgendaUI = fxmlLoader.getController();
            addEntryAgendaUI.setParent(this);

            stage.show();
        }catch(IOException exception) {
            exception.getStackTrace();
        }
    }

    @FXML
    public void openPostponeEntry(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(ToDoListUI.class.getResource("postpone-entry-agenda-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 600);

            Stage stage = new Stage();
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(mainPane.getScene().getWindow());
            stage.setScene(scene);

            PostponeEntryAgendaUI postponeEntryAgendaUI = fxmlLoader.getController();
            postponeEntryAgendaUI.setParent(this);

            stage.show();
        }catch(IOException exception) {
            exception.getStackTrace();
        }
    }

    @FXML
    public void openCancelEntry(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(ToDoListUI.class.getResource("cancel-entry-agenda.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 600);

            Stage stage = new Stage();
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(mainPane.getScene().getWindow());
            stage.setScene(scene);

            CancelEntryAgendaUI cancelEntryAgendaUI = fxmlLoader.getController();
            cancelEntryAgendaUI.setParent(this);

            stage.show();
        }catch(IOException exception) {
            exception.getStackTrace();
        }
    }

    public void writeAgendaEntryList() {
        txtAgenda.clear();

        List<AgendaEntryDTO> result = listAgendaEntriesController.listEntries();

        for(AgendaEntryDTO agendaEntry : result)
            addAgendaEntryToList(agendaEntry);
    }

    public void addAgendaEntryToList(AgendaEntryDTO agendaEntry) {
        txtAgenda.appendText(String.format(
                "%s (expected duration: %s) : %s%n",
                agendaEntry.task().name(),
                agendaEntry.expectedDuration(),
                agendaEntry.status()
        ));
    }
}