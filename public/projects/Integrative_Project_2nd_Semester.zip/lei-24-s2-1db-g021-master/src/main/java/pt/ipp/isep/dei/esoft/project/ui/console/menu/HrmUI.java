package pt.ipp.isep.dei.esoft.project.ui.console.menu;


import pt.ipp.isep.dei.esoft.project.ui.console.*;
import pt.ipp.isep.dei.esoft.project.ui.console.utils.Utils;

import java.util.ArrayList;
import java.util.List;

public class HrmUI implements Runnable {
    public HrmUI() {
    }

    public void run() {
        List<MenuItem> options = new ArrayList<MenuItem>();
        //substituir na zona do ShowTextUI pelo nome da UI da US
        options.add(new MenuItem("Register Skills", new RegisterSkillUI()));
        options.add(new MenuItem("Register Jobs", new RegisterJobUI()));
        options.add(new MenuItem("Register a Collaborator with a job and other attributes", new RegisterCollaboratorUI()));
        options.add(new MenuItem("Assign skills to a Collaborator", new AssignSkillUI()));
        options.add(new MenuItem("Generate a Team Proposal", new GenerateTeamProposalUI()));

        int option = 0;
        do {
            option = Utils.showAndSelectIndex(options, "\n\n--- HUMAN RESOURCES MANAGER MENU -------------------------");

            if ((option >= 0) && (option < options.size())) {
                options.get(option).run();
            }
        } while (option != -1);
    }
}