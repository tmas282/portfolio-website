package pt.ipp.isep.dei.esoft.project.ui.console;

import pt.ipp.isep.dei.esoft.project.application.controller.RegisterTaskController;
import pt.ipp.isep.dei.esoft.project.application.controller.ListGreenSpaceController;
import pt.ipp.isep.dei.esoft.project.domain.*;
import pt.ipp.isep.dei.esoft.project.dto.GreenSpaceDTO;
import pt.ipp.isep.dei.esoft.project.dto.NewTaskDTO;
import pt.ipp.isep.dei.esoft.project.dto.TaskDTO;

import java.util.*;
import java.util.regex.Pattern;

public class RegisterTaskUI implements Runnable {
    private final RegisterTaskController taskController = new RegisterTaskController();
    private final ListGreenSpaceController greenSpaceController = new ListGreenSpaceController();
    private final Scanner input = new Scanner(System.in);;
    private String name;
    private String description;
    private TaskCategory category;
    private TaskUrgency urgency;
    private String greenSpaceName;

    @Override
    public void run() {
        if(greenSpaceController.getGreenSpaceList().isEmpty()) {
            System.out.println("No green spaces available to assign tasks");

            return;
        }

        System.out.println("\n\n--- Register Task ------------------------");

        requestData();
        submitData();
    }

    private void requestData() {
        this.name = requestName();
        this.description = requestDescription();
        this.category = requestCategory();
        this.urgency = requestUrgency();
        this.greenSpaceName = requestGreenSpaceName();
    }

    private void submitData() {
        NewTaskDTO newTask = new NewTaskDTO(
                this.name,
                this.description,
                this.category,
                this.urgency,
                this.greenSpaceName
        );

        Optional<TaskDTO> result = this.taskController.registerTask(newTask);

        if (result.isPresent()) {
            System.out.println("\nTask successfully registered");
        }else {
            System.out.println("\nTask unsuccessfully registered");
        }
    }

    private String requestName() {
        String name;

        do {
            System.out.print("Name: ");
            name = this.input.nextLine();
        }while (!validName(name));

        return name;
    }

    private boolean validName(String name) {
        if(name.isBlank()) {
            System.out.println("Invalid: Blank name");

            return false;
        }

        Pattern validName = Pattern.compile("^[A-z0-9-_ ]+$");

        if(!validName.matcher(name).matches()) {
            System.out.println("Invalid: The valid characters for an name are A-Z, a-z, 0-9, '-', '_', ' '");

            return false;
        }

        return true;
    }

    private String requestDescription() {
        String description;

        do {
            System.out.print("Description: ");
            description = this.input.nextLine();
        }while (!validDescription(description));

        return description;
    }

    private boolean validDescription(String description) {
        if(description.isBlank()) {
            System.out.println("Invalid: Blank description");

            return false;
        }

        return true;
    }

    private TaskCategory requestCategory() {
        TaskCategory[] taskCategories = TaskCategory.values();
        int listLength = taskCategories.length;

        for (int i = 0; i < listLength; i++)
            System.out.printf(" %d - %s%n", i + 1, taskCategories[i]);

        int option = 0;

        while (option < 1 || option > listLength) {
            System.out.print("Select an task category: ");
            option = Integer.parseInt(this.input.nextLine());
        }

        return taskCategories[option - 1];
    }

    private TaskUrgency requestUrgency() {
        TaskUrgency[] taskUrgencies = TaskUrgency.values();
        int listLength = taskUrgencies.length;

        for (int i = 0; i < listLength; i++)
            System.out.printf(" %d - %s%n", i + 1, taskUrgencies[i]);

        int option = 0;

        while (option < 1 || option > listLength) {
            System.out.print("Select an urgency: ");
            option = Integer.parseInt(this.input.nextLine());
        }

        return taskUrgencies[option - 1];
    }

    private String requestGreenSpaceName() {
        List<GreenSpaceDTO> greenSpaceList = greenSpaceController.getGreenSpaceList();
        int listLength = greenSpaceList.size();

        for(int i = 0; i < listLength; i++) {
            System.out.printf(" %d - %s%n", i + 1, greenSpaceList.get(i).name());
        }

        int option = 0;

        while (option < 1 || option > listLength) {
            System.out.print("Select a green space");
            option = Integer.parseInt(this.input.nextLine());
        }

        return greenSpaceList.get(option - 1).name();
    }
}
