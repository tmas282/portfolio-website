package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.domain.AgendaEntry;
import pt.ipp.isep.dei.esoft.project.domain.Collaborator;
import pt.ipp.isep.dei.esoft.project.domain.Team;
import pt.ipp.isep.dei.esoft.project.repository.AgendaEntryRepository;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;
import pt.ipp.isep.dei.esoft.project.repository.TeamRepository;
import pt.ipp.isep.dei.esoft.project.utils.MessageServiceUtils;

import java.util.List;

public class AssignTeamToEntryController {
    AgendaEntryRepository agenda;
    TeamRepository teamRepository;

    /**
     * This constructor instantiates this class
     */
    public AssignTeamToEntryController() {
        Repositories instance = Repositories.getInstance();
        this.agenda = instance.getAgendaEntryRepository();
        this.teamRepository = instance.getTeamRepository();
    }

    /**
     * This method gets the active entries
     * @return the list of the active entries
     */
    public List<AgendaEntry> getActiveEntries(){
        return agenda.getAgendaEntryList();
    }

    /**
     * This method gets the available teams.
     * @return the list of available teams.
     */
    public List<Team> getTeams(){
        return teamRepository.getTeamList();
    }

    /**
     * This method assigns a team to an entry.
     * @param team The Team
     * @param entry The Entry
     * @return A boolean value returning the success of the operation.
     */
    public boolean assignTeamToEntry(Team team, AgendaEntry entry){
        try{
            entry.setTeam(team);
            sendMessageToTeamMembers(team, "You got assigned to an entry!", "Dear collaborator,\nYou got assigned to a new entry, check the agenda.\nBest regards.");
            return true;
        }
        catch (Exception e){
            return false;
        }
    }
    private void sendMessageToTeamMembers(Team team, String header, String msg){
        MessageServiceUtils msgService = new MessageServiceUtils();
        for (Collaborator col:
                team.getCollaboratorList()) {
            msgService.sendMessage(col.getEmail(), header, msg);
        }
    }
}
