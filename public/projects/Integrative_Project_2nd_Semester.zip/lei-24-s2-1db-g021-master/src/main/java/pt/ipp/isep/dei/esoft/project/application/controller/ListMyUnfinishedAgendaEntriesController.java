package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.application.session.ApplicationSession;
import pt.ipp.isep.dei.esoft.project.domain.Collaborator;
import pt.ipp.isep.dei.esoft.project.dto.AgendaEntryDTO;
import pt.ipp.isep.dei.esoft.project.mapper.AgendaEntryMapper;
import pt.ipp.isep.dei.esoft.project.repository.AgendaEntryRepository;
import pt.ipp.isep.dei.esoft.project.repository.CollaboratorRepository;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;

import java.util.List;
import java.util.Optional;

public class ListMyUnfinishedAgendaEntriesController {
    private final AgendaEntryRepository agendaEntryRepository;
    private final CollaboratorRepository collaboratorRepository;
    private final ApplicationSession applicationSession;

    public ListMyUnfinishedAgendaEntriesController() {
        agendaEntryRepository = Repositories.getInstance().getAgendaEntryRepository();
        collaboratorRepository = Repositories.getInstance().getCollaboratorRepository();
        applicationSession = ApplicationSession.getInstance();
    }

    /**
     * Allows injection of repositories to be used by the controller. Useful for testing.
     *
     * @param agendaEntryRepository to be used
     * @param collaboratorRepository to be used
     * @param applicationSession to be used
     */
    public ListMyUnfinishedAgendaEntriesController(AgendaEntryRepository agendaEntryRepository, CollaboratorRepository collaboratorRepository, ApplicationSession applicationSession) {
        this.agendaEntryRepository = agendaEntryRepository;
        this.collaboratorRepository = collaboratorRepository;
        this.applicationSession = applicationSession;
    }

    public List<AgendaEntryDTO> listAgendaEntries() {
        String userEmail = applicationSession.getCurrentSession().getUserEmail();

        if(userEmail == null)
            return List.of();

        Optional<Collaborator> collaborator = collaboratorRepository.getCollaboratorByEmail(userEmail);

        if(collaborator.isEmpty())
            return List.of();

        return AgendaEntryMapper.toDTO(agendaEntryRepository.getUnfinishedAgendaEntriesByCollaborator(collaborator.get()));
    }
}
