package pt.ipp.isep.dei.esoft.project.dto;

import pt.ipp.isep.dei.esoft.project.domain.Address;
import pt.ipp.isep.dei.esoft.project.domain.SizeClassification;

public record NewGreenSpaceDTO(String name, SizeClassification sizeClassification, float area, Address address) { }
