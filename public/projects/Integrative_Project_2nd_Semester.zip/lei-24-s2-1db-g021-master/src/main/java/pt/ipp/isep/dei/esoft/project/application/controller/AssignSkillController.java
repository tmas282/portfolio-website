package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.domain.Collaborator;
import pt.ipp.isep.dei.esoft.project.domain.Skill;
import pt.ipp.isep.dei.esoft.project.dto.CollaboratorDTO;
import pt.ipp.isep.dei.esoft.project.dto.SkillDTO;
import pt.ipp.isep.dei.esoft.project.mapper.CollaboratorMapper;
import pt.ipp.isep.dei.esoft.project.mapper.SkillMapper;
import pt.ipp.isep.dei.esoft.project.repository.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class AssignSkillController {
    private final CollaboratorRepository collaboratorRepository;
    private final SkillRepository skillRepository;

    /**
     * This constructor instantiates with the default Collaborators and Skills Repositories
     */
    public AssignSkillController() {
        collaboratorRepository = Repositories.getInstance().getCollaboratorRepository();
        skillRepository = Repositories.getInstance().getSkillRepository();
    }

    /**
     * This constructor instantiates with custom Collaborators and Skills Repositories
     * @param collaboratorRepository the Collaborators Repository
     * @param skillRepository the Skills Repository
     */
    public AssignSkillController(CollaboratorRepository collaboratorRepository, SkillRepository skillRepository) {
        this.collaboratorRepository = collaboratorRepository;
        this.skillRepository = skillRepository;
    }

    /**
     * This method gets the collaborators added on the repository
     * @return the all collaborators list
     */
    public List<CollaboratorDTO> getCollaborators() {
        return CollaboratorMapper.toDTO(collaboratorRepository.getCollaboratorsList());
    }

    /**
     * This method returns the list of skills.
     * @return The list of all skills
     */
    public List<SkillDTO> getSkills() {
        return SkillMapper.toDTO(skillRepository.getSkillsList());
    }

    public Optional<CollaboratorDTO> addSkillToCollaborator(SkillDTO skillDTO, CollaboratorDTO collaboratorDTO) {
        if(skillDTO == null)
            return Optional.empty();

        Optional<Skill> skill = skillRepository.getSkillByName(skillDTO.name());

        if(skill.isEmpty())
            return Optional.empty();

        if(collaboratorDTO == null)
            return Optional.empty();

        Optional<Collaborator> collaborator = collaboratorRepository.getCollaboratorByEmail(collaboratorDTO.email());

        if(collaborator.isEmpty())
            return Optional.empty();

        collaborator.get().addSkill(skill.get());

        return Optional.of(CollaboratorMapper.toDTO(collaborator.get()));
    }
}
