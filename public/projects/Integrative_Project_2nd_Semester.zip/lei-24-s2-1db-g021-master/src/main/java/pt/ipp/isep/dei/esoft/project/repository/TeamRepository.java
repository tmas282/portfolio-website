package pt.ipp.isep.dei.esoft.project.repository;

import pt.ipp.isep.dei.esoft.project.domain.Team;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class TeamRepository implements Serializable {
    private final List<Team> teamList;

    public TeamRepository() {
        teamList = new ArrayList<>();
    }

    public Optional<Team> add(Team team) {
        if(team == null)
            return Optional.empty();

        if(teamList.contains(team))
            return Optional.empty();

        teamList.add(team);

        return Optional.of(team);
    }

    public Optional<Team> getTeamByName(String name) {
        for(Team team : teamList)
            if(Objects.equals(name, team.getName()))
                return Optional.of(team);

        return Optional.empty();
    }

    /**
     * getTeam is a method that returns a defensive (immutable) copy of the list of teams.
     *
     * @return the list of teams.
     */
    public List<Team> getTeamList() {
        // This is a defensive copy, so that the repository cannot be modified from the outside.
        return List.copyOf(teamList);
    }

}