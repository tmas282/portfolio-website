package pt.ipp.isep.dei.esoft.project.domain;

import java.io.Serializable;

public enum SizeClassification {
    GARDEN("Garden"), MEDIUM_SIZED_PARK("Medium sized park"), LARGE_SIZED_PARK("Large sized park");

    private final String stringRepresentation;

    SizeClassification(String stringRepresentation) {
        this.stringRepresentation = stringRepresentation;
    }

    @Override
    public String toString() {
        return stringRepresentation;
    }
}
