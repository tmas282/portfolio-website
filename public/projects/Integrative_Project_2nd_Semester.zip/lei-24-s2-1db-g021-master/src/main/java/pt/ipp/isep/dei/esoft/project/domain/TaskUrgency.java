package pt.ipp.isep.dei.esoft.project.domain;

public enum TaskUrgency {
    HIGH("High"), MEDIUM("Medium"), LOW("Low");

    private final String stringRepresentation;

    TaskUrgency(String stringRepresentation) {
        this.stringRepresentation = stringRepresentation;
    }

    @Override
    public String toString() {
        return stringRepresentation;
    }
}
