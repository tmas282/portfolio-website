package pt.ipp.isep.dei.esoft.project.mapper;

import pt.ipp.isep.dei.esoft.project.domain.Document;
import pt.ipp.isep.dei.esoft.project.dto.DocumentDTO;

import java.util.ArrayList;
import java.util.List;

public class DocumentMapper {
    public static DocumentDTO toDTO(Document document) {
        return new DocumentDTO(
                document.getName(),
                document.getBornDate(),
                document.getCardNumber()
        );
    }

    public static List<DocumentDTO> toDTO(List<Document> documentList) {
        List<DocumentDTO> newList = new ArrayList<>();

        for(Document document : documentList) {
            newList.add(toDTO(document));
        }

        return List.copyOf(newList);
    }
}
