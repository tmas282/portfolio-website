package pt.ipp.isep.dei.esoft.project.domain;

public enum CollaboratorRole {
    COLLABORATOR("Collaborator"), ADMIN("Administrator"), HRM("Human Resources Manager"), VFM("Vehicle Fleet Manager");

    private final String stringRepresentation;

    CollaboratorRole(String stringRepresentation) {
        this.stringRepresentation = stringRepresentation;
    }

    @Override
    public String toString() {
        return stringRepresentation;
    }
}
