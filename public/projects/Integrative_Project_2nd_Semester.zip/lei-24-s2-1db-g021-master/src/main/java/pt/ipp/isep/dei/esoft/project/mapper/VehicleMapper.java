package pt.ipp.isep.dei.esoft.project.mapper;

import pt.ipp.isep.dei.esoft.project.domain.Vehicle;
import pt.ipp.isep.dei.esoft.project.dto.VehicleDTO;

import java.util.ArrayList;
import java.util.List;

public class VehicleMapper {

    public static VehicleDTO toDTO(Vehicle vehicle) {
        return new VehicleDTO(
                vehicle.getCurrentKm(),
                vehicle.getAcquisitionDate(),
                vehicle.getMaintenance(),
                PlateCertificationMapper.toDTO(vehicle.getPlateCertification())
        );
    }

    public static List<VehicleDTO> toDTO(List<Vehicle> vehicleList) {
        List<VehicleDTO> newList = new ArrayList<>();

        for(Vehicle vehicle : vehicleList) {
            newList.add(toDTO(vehicle));
        }

        return List.copyOf(newList);
    }
}
