package pt.ipp.isep.dei.esoft.project.dto;

import java.util.Date;
import java.util.List;

public record CollaboratorDTO(DocumentDTO document, Date admDate, AddressDTO address, int phoneNumber, String email, int taxpayerNumber, List<SkillDTO> skills) {
    @Override
    public String toString() {
        return email;
    }
}