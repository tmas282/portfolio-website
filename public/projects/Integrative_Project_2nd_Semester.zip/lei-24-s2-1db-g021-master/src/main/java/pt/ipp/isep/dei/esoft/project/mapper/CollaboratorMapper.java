package pt.ipp.isep.dei.esoft.project.mapper;

import pt.ipp.isep.dei.esoft.project.domain.Collaborator;
import pt.ipp.isep.dei.esoft.project.domain.Document;
import pt.ipp.isep.dei.esoft.project.dto.CollaboratorDTO;

import java.util.ArrayList;
import java.util.List;

public class CollaboratorMapper {
    public static CollaboratorDTO toDTO(Collaborator collaborator) {
        return new CollaboratorDTO(
                DocumentMapper.toDTO(collaborator.getDocument()),
                collaborator.getAdmDate(),
                AddressMapper.toDTO(collaborator.getAddress()),
                collaborator.getPhoneNumber(),
                collaborator.getEmail(),
                collaborator.getTaxpayerNumber(),
                SkillMapper.toDTO(collaborator.getSkills())
        );
    }

    public static List<CollaboratorDTO> toDTO(List<Collaborator> collaboratorList) {
        List<CollaboratorDTO> newList = new ArrayList<>();

        for(Collaborator collaborator : collaboratorList) {
            newList.add(toDTO(collaborator));
        }

        return List.copyOf(newList);
    }
}
