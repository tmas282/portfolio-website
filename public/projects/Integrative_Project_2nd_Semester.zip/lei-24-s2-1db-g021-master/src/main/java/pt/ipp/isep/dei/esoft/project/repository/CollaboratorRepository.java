package pt.ipp.isep.dei.esoft.project.repository;

import pt.ipp.isep.dei.esoft.project.domain.Collaborator;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class CollaboratorRepository implements Serializable {
    private final List<Collaborator> collaboratorList;

    public CollaboratorRepository() {
        collaboratorList = new ArrayList<>();
    }

    public Optional<Collaborator> getCollaboratorByEmail(String email) {
        for(Collaborator collaborator : collaboratorList)
            if(Objects.equals(collaborator.getEmail(), email))
                return Optional.of(collaborator);

        return Optional.empty();
    }

    public Optional<Collaborator> add(Collaborator newCollaborator) {
        if(newCollaborator == null)
            return Optional.empty();

        if(collaboratorList.contains(newCollaborator))
            return Optional.empty();

        collaboratorList.add(newCollaborator);

        return Optional.of(newCollaborator);
    }

    /**
     * This method returns a defensive (immutable) copy of the list of collaborators.
     *
     * @return The list of collaborators.
     */
    public List<Collaborator> getCollaboratorsList() {
        return List.copyOf(collaboratorList);
    }
}