package pt.ipp.isep.dei.esoft.project.domain;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public class Team implements Serializable {
    private String name;
    private int minSize;
    private int maxSize;
    private List<Collaborator> collaboratorList;
    private List<Skill> selectedSkills;

    public Team(String name, int minSize, int maxSize, List<Collaborator> collaboratorList, List<Skill> selectedSkills) throws IllegalArgumentException {
        verifyName(name);
        verifySize(minSize, maxSize);

        if(collaboratorList == null)
            throw new IllegalArgumentException("Invalid collaborator list: collaborator list can't be null");

        if(selectedSkills == null)
            throw new IllegalArgumentException("Invalid selected skills: selected skills can't be null");

        this.name = name;
        this.minSize = minSize;
        this.maxSize = maxSize;
        this.collaboratorList = collaboratorList;
        this.selectedSkills = selectedSkills;
    }

    private void verifyName(String name) throws IllegalArgumentException {
        if(name == null)
            throw new IllegalArgumentException("Invalid name: name can't be null");

        if(name.isBlank())
            throw new IllegalArgumentException("Invalid name: name can't be blank");
    }

    private void verifySize(int minSize, int maxSize) throws IllegalArgumentException {
        if(minSize < 0)
            throw new IllegalArgumentException("Invalid minimum size: minimum size must be greater or equal to 0");

        if(maxSize < 0)
            throw new IllegalArgumentException("Invalid maximum size: maximum size must be greater or equal to 0");

        if(minSize > maxSize)
            throw new IllegalArgumentException("Invalid minimum size: minimum size must be equal or inferior than maximum size");
    }

    public String getName() {
        return name;
    }

    public int getMinSize() {
        return minSize;
    }

    public int getMaxSize() {
        return maxSize;
    }

    public List<Collaborator> getCollaboratorList() {
        return collaboratorList;
    }

    public List<Skill> getSelectedSkills() {
        return selectedSkills;
    }

    @Override
    public boolean equals(Object object) {
        if(object == this)
            return true;

        if(object == null)
            return false;

        if(object.getClass() != this.getClass())
            return false;

        Team team = (Team) object;

        if(!Objects.equals(team.name, this.name))
            return false;

        return true;
    }
}