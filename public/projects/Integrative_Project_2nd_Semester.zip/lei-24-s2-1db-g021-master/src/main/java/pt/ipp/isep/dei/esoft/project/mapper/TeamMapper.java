package pt.ipp.isep.dei.esoft.project.mapper;

import pt.ipp.isep.dei.esoft.project.domain.Collaborator;
import pt.ipp.isep.dei.esoft.project.domain.Team;
import pt.ipp.isep.dei.esoft.project.dto.TeamDTO;

import java.util.ArrayList;
import java.util.List;

public class TeamMapper {
    public static TeamDTO toDTO(Team team) {
        return new TeamDTO(
                team.getName(),
                team.getMinSize(),
                team.getMaxSize(),
                CollaboratorMapper.toDTO(team.getCollaboratorList()),
                SkillMapper.toDTO(team.getSelectedSkills())
        );
    }

    public static List<TeamDTO> toDTO(List<Team> teamsList) {
        List<TeamDTO> newList = new ArrayList<>();

        for(Team entry : teamsList) {
            newList.add(toDTO(entry));
        }

        return List.copyOf(newList);
    }
}
