package pt.ipp.isep.dei.esoft.project.ui.console;

/**
 * @author Paulo Maio pam@isep.ipp.pt
 */
public class DevTeamUI implements Runnable {

    public DevTeamUI() {

    }

    public void run() {
        System.out.println("\n");
        System.out.println("--- DEVELOPMENT TEAM -------------------");
        System.out.println("  João Jorge - 1231080@isep.ipp.pt");
        System.out.println("  Dinis Félix - 1231727@isep.ipp.pt");
        System.out.println("  Leonardo Silva - 1231360@isep.ipp.pt");
        System.out.println("  Tomás Moreira - 1231087@isep.ipp.pt");
        System.out.println("  Bernardo Cardoso - 1231070@isep.ipp.pt");
        System.out.println("\n");
    }
}
