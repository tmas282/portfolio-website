package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.dto.AgendaEntryDTO;
import pt.ipp.isep.dei.esoft.project.mapper.AgendaEntryMapper;
import pt.ipp.isep.dei.esoft.project.repository.AgendaEntryRepository;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;

import java.util.List;

public class ListAgendaEntriesController {
    private final AgendaEntryRepository agendaEntryRepository;

    public ListAgendaEntriesController() {
        agendaEntryRepository = Repositories.getInstance().getAgendaEntryRepository();
    }

    /**
     * Allows injection of repositories to be used by the controller. Useful for testing.
     *
     * @param agendaEntryRepository to be used
     */
    public ListAgendaEntriesController(AgendaEntryRepository agendaEntryRepository) {
        this.agendaEntryRepository = agendaEntryRepository;
    }

    public List<AgendaEntryDTO> listEntries() {
        return AgendaEntryMapper.toDTO(List.copyOf(agendaEntryRepository.getAgendaEntryList()));
    }
}
