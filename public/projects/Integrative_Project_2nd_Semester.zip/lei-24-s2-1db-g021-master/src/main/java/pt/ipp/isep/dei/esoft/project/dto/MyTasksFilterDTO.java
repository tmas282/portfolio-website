package pt.ipp.isep.dei.esoft.project.dto;

import pt.ipp.isep.dei.esoft.project.domain.EntryStatus;

import java.util.Date;

public record MyTasksFilterDTO(Date start, Date end, EntryStatus entryStatus) { }
