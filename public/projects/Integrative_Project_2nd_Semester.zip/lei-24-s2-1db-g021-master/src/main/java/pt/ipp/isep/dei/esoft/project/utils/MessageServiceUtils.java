package pt.ipp.isep.dei.esoft.project.utils;

import java.io.*;

public class MessageServiceUtils {
    private static final String LOG_FILE_NAME = "log_messages_us23.txt";
    private static final String EMAIL_CONFIG_FILE_NAME = "email_config_us23.txt";

    private static final String SENDER_EMAIL_BY_NULL = "ms_sublime@this.app";
    private static final String SENDER_SERVICE_BY_NULL = "Musgo Sublime Email Service";
    private String senderEmail;
    private String senderService;

    /**
     * this method instantiates the message services
     */
    public MessageServiceUtils() {
        this.senderEmail = SENDER_EMAIL_BY_NULL;
        this.senderService = SENDER_SERVICE_BY_NULL;
        openAndReadConfigFile();
    }

    /**
     * This method sends a message to the receiver
     * @param receiverEmail the receiver
     * @param header the header of the message
     * @param msgBody the body of the message
     */
    public void sendMessage(String receiverEmail, String header, String msgBody){
        String lineToLog = this.senderEmail + " to " + receiverEmail + " : " + header +
                " (using '" + senderService + "' services)\n" + msgBody + "\n\n";
        if (!(createFile(LOG_FILE_NAME) && logString(lineToLog, LOG_FILE_NAME))){
            System.out.println("Error logging");
        }

    }
    private boolean createFile(String fileName){
        try{
            File logFile = new File(fileName);
            logFile.createNewFile();
            return true;
        } catch (IOException e) {
            System.out.println(e);
            return false;
        }
    }
    private boolean logString(String theString, String fileName){
        try{
            FileWriter logFw = new FileWriter(fileName, true);
            logFw.write(theString);
            logFw.flush();
            logFw.close();
            return true;
        } catch (IOException e) {
            System.out.println(e);
            return false;
        }
    }
    private void openAndReadConfigFile(){
        if(!(new File(EMAIL_CONFIG_FILE_NAME).exists())){
            createFile(EMAIL_CONFIG_FILE_NAME);
            logString("Email: " + SENDER_EMAIL_BY_NULL + "\n", EMAIL_CONFIG_FILE_NAME);
            logString("Service: " + SENDER_SERVICE_BY_NULL + "\n", EMAIL_CONFIG_FILE_NAME);
        }
        try (BufferedReader br = new BufferedReader(new FileReader(EMAIL_CONFIG_FILE_NAME))) {
            String line;
            while ((line = br.readLine()) != null) {
                if(line.contains("Email: "))
                    senderEmail = line.replace("Email: ","");
                if (line.contains("Service: "))
                    senderService = line.replace("Service: ","");
            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }
}
