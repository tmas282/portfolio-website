package pt.ipp.isep.dei.esoft.project.repository;

import java.io.Serializable;

public class Repositories implements Serializable {
    private static Repositories instance;
    private final SkillRepository skillRepository;
    private final CollaboratorRepository collaboratorRepository;
    private final TeamRepository teamRepository;
    private final AuthenticationRepository authenticationRepository;
    private final VehicleRepository vehicleRepository;
    private final JobRepository jobRepository;
    private final PlateCertificationRepository plateCertificationRepository;
    private final TaskRepository taskRepository;
    private final VehicleCheckUpRepository vehicleCheckUpRepository;
    private final GreenSpaceRepository greenSpaceRepository;
    private final AgendaEntryRepository agendaEntryRepository;

    private Repositories() {
        skillRepository = new SkillRepository();
        collaboratorRepository = new CollaboratorRepository();
        teamRepository = new TeamRepository();
        authenticationRepository = new AuthenticationRepository();
        vehicleRepository = new VehicleRepository();
        jobRepository = new JobRepository();
        plateCertificationRepository = new PlateCertificationRepository();
        vehicleCheckUpRepository = new VehicleCheckUpRepository();
        taskRepository = new TaskRepository();
        greenSpaceRepository = new GreenSpaceRepository();
        agendaEntryRepository = new AgendaEntryRepository();
    }

    public static Repositories getInstance() {
        if (instance == null) {
            synchronized (Repositories.class) {
                instance = new Repositories();
            }
        }

        return instance;
    }

    public AuthenticationRepository getAuthenticationRepository() {
        return authenticationRepository;
    }

    public SkillRepository getSkillRepository() {
        return skillRepository;
    }

    public CollaboratorRepository getCollaboratorRepository() {
        return collaboratorRepository;
    }

    public TeamRepository getTeamRepository() {
        return teamRepository;
    }

    public VehicleRepository getVehicleRepository() {
        return vehicleRepository;
    }

    public JobRepository getJobRepository() {
        return jobRepository;
    }

    public PlateCertificationRepository getPlateCertificationRepository() {
        return plateCertificationRepository;
    }

    public VehicleCheckUpRepository getVehicleCheckUpRepository() {
        return vehicleCheckUpRepository;
    }

    public TaskRepository getTaskRepository() {
        return taskRepository;
    }

    public GreenSpaceRepository getGreenSpaceRepository() {
        return greenSpaceRepository;
    }

    public AgendaEntryRepository getAgendaEntryRepository() {
        return agendaEntryRepository;
    }

    public static void setInstance(Repositories instance) {
        Repositories.instance = instance;
    }
}