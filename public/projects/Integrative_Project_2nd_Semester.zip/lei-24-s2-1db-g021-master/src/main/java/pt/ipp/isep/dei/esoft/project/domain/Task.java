package pt.ipp.isep.dei.esoft.project.domain;

import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;
import java.util.regex.Pattern;

public class Task implements Serializable {
    private String name;
    private String description;
    private TaskCategory category;
    private TaskUrgency urgency;
    private GreenSpace greenSpace;

    public Task(String name, String description, TaskCategory category, TaskUrgency urgency, GreenSpace greenSpace) throws IllegalArgumentException {
        verifyName(name);
        verifyDescription(description);

        if(category == null)
            throw new IllegalArgumentException("Invalid category: category can't be null");

        if(urgency == null)
            throw new IllegalArgumentException("Invalid urgency: urgency can't be null");

        if(greenSpace == null)
            throw new IllegalArgumentException("Invalid green space: green space can't be null");

        this.name = name;
        this.description = description;
        this.category = category;
        this.urgency = urgency;
        this.greenSpace = greenSpace;
    }

    /**
     * Verify if the name is valid. The name must not be blank.
     * The valid characters are A-Z, a-z, 0-9, '-', '_' and ' '
     *
     * @param name
     */
    private void verifyName(String name) throws IllegalArgumentException {
        if(name == null)
            throw new IllegalArgumentException("Invalid name: name can't be null");

        if(name.isBlank())
            throw new IllegalArgumentException("Invalid name: name can't be blank");

        Pattern validName = Pattern.compile("^[A-z0-9-_ ]+$");

        if(!validName.matcher(name).matches())
            throw new IllegalArgumentException("Invalid name: name must only contain A-Z, a-z, 0-9, '-', '_' and ' '");
    }

    /**
     * Verify if the description is valid. The description must not be blank.
     *
     * @param description
     */
    private void verifyDescription(String description) throws IllegalArgumentException {
        if(description == null)
            throw new IllegalArgumentException("Invalid description: description can't be null");

        if(description.isBlank())
            throw new IllegalArgumentException("Invalid description: description can't be blank");
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public TaskCategory getCategory() {
        return category;
    }

    public TaskUrgency getUrgency() {
        return urgency;
    }

    public GreenSpace getGreenSpace() {
        return greenSpace;
    }

    @Override
    public boolean equals(Object object) {
        if(object == this)
            return true;

        if(object == null)
            return false;

        if(object.getClass() != this.getClass())
            return false;

        Task task = (Task) object;

        if(!Objects.equals(task.name, this.name))
            return false;

        return true;
    }
}
