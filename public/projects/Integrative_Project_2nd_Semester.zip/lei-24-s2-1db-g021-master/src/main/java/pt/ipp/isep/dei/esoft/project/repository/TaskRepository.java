package pt.ipp.isep.dei.esoft.project.repository;

import pt.ipp.isep.dei.esoft.project.domain.Task;
import pt.ipp.isep.dei.esoft.project.domain.Team;

import java.io.Serializable;
import java.util.*;

public class TaskRepository implements Serializable {
    private final List<Task> taskList;

    public TaskRepository() {
        taskList = new ArrayList<>();
    }

    /**
     * Adds a new task to the repository. The task to be added must be new
     *
     * @param newTask the task to be added
     * @return Empty optional if the creation of task failed
     * and TaskDTO optional if the creation was successful
     */
    public Optional<Task> add(Task newTask) {
        if(newTask == null)
            return Optional.empty();

        if(taskList.contains(newTask))
            return Optional.empty();

        taskList.add(newTask);

        return Optional.of(newTask);
    }


    public Optional<Task> getTaskByName(String name) {
        for(Task task : this.taskList)
            if(task.getName().equals(name))
                return Optional.of(task);

        return Optional.empty();
    }

    /**
     * @return immutable list of all the tasks
     */
    public List<Task> getTasks() {
        return List.copyOf(taskList);
    }
}
