package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.domain.Job;
import pt.ipp.isep.dei.esoft.project.repository.JobRepository;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;

import java.util.List;
import java.util.Optional;

public class RegisterJobController {

    private JobRepository jobRepository;

    /**
     * Constructs a new RegisterJobController object.
     */
    public RegisterJobController() {
        getJobsRepository();
    }

    /**
     * Constructs a new RegisterJobController object with a specified JobRepository.
     *
     * @param jobRepository The JobRepository to be used by the controller.
     */
    public RegisterJobController(JobRepository jobRepository) {
        this.jobRepository = jobRepository;
    }

    private JobRepository getJobsRepository() {
        if (jobRepository == null) {
            Repositories repositories = Repositories.getInstance();
            jobRepository = repositories.getJobRepository();
        }
        return jobRepository;
    }

    /**
     * Creates a new Job with the given name.
     *
     * @param name The name of the job to be created.
     * @return An Optional containing the newly created Job, or empty if the operation fails.
     */
    public Optional<Job> createJob(String name) {
        Optional<Job> newJob;
        try {
            newJob = jobRepository.add(new Job(name));
        } catch (IllegalArgumentException e) {
            return Optional.empty();
        }
        return newJob;
    }

    /**
     * Retrieves the list of all jobs.
     *
     * @return The list of all jobs.
     */
    public List<Job> getJobsList() {
        return jobRepository.getJobsList();
    }
}