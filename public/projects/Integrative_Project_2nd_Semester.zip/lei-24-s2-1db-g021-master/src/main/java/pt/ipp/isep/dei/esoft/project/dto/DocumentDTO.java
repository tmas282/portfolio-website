package pt.ipp.isep.dei.esoft.project.dto;


import java.util.Date;

public record DocumentDTO(String name, Date bornDate, int cardNumber) { }