package pt.ipp.isep.dei.esoft.project.mapper;

import pt.ipp.isep.dei.esoft.project.domain.AgendaEntry;
import pt.ipp.isep.dei.esoft.project.domain.GreenSpace;
import pt.ipp.isep.dei.esoft.project.domain.Vehicle;
import pt.ipp.isep.dei.esoft.project.dto.AgendaEntryDTO;
import pt.ipp.isep.dei.esoft.project.dto.GreenSpaceDTO;

import java.util.ArrayList;
import java.util.List;

public class AgendaEntryMapper {
    public static AgendaEntryDTO toDTO(AgendaEntry entry) {
        return new AgendaEntryDTO(
                entry.getId(),
                entry.getExpectedDuration(),
                VehicleMapper.toDTO(entry.getEquipment()),
                entry.getStatus(),
                TeamMapper.toDTO(entry.getTeam()),
                TaskMapper.toDTO(entry.getTask())
        );
    }

    public static List<AgendaEntryDTO> toDTO(List<AgendaEntry> entrysList) {
        List<AgendaEntryDTO> newList = new ArrayList<>();

        for(AgendaEntry entry : entrysList) {
            newList.add(toDTO(entry));
        }

        return List.copyOf(newList);
    }
}
