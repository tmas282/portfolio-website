package pt.ipp.isep.dei.esoft.project.ui.gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import pt.ipp.isep.dei.esoft.project.application.controller.CancelEntryAgendaController;
import pt.ipp.isep.dei.esoft.project.domain.EntryStatus;
import pt.ipp.isep.dei.esoft.project.dto.AgendaEntryDTO;
import pt.ipp.isep.dei.esoft.project.dto.CancelEntryDTO;

import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

public class CancelEntryAgendaUI implements Initializable {
    private AgendaUI parent;
    private final CancelEntryAgendaController ctrl = new CancelEntryAgendaController();

    @FXML
    private ComboBox<AgendaEntryDTO> cbEntry;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        List<AgendaEntryDTO> agendaEntries = ctrl.getAgendaEntries();
        cbEntry.getItems().setAll(agendaEntries);
    }

    public void setParent(AgendaUI parent) {
        this.parent = parent;
    }

    @FXML
    void btnCancelclick(ActionEvent event) {
        AgendaEntryDTO selectedEntry = cbEntry.getSelectionModel().getSelectedItem();
        if (selectedEntry == null) {
            new Alert(Alert.AlertType.ERROR, "Invalid: selected a entry to cancel.").show();
        }

        CancelEntryDTO cancelEntryDTO = new CancelEntryDTO(EntryStatus.POSTPONED, selectedEntry.id());

        Optional<AgendaEntryDTO> updatedEntryOpt = ctrl.cancelEntryAgenda(cancelEntryDTO);

        if (updatedEntryOpt.isPresent()) {
            new Alert(Alert.AlertType.INFORMATION, "Entry in agenda canceled with success!").show();

            List<AgendaEntryDTO> agendaEntries = ctrl.getAgendaEntries();
            cbEntry.getItems().setAll(agendaEntries);
            parent.writeAgendaEntryList();
        }

        else {
            new Alert(Alert.AlertType.ERROR, "Invalid: it is not possible to cancel this entry in agenda.").show();
        }
    }
}