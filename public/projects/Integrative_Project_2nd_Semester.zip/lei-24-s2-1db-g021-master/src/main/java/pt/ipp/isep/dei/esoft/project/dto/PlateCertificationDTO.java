package pt.ipp.isep.dei.esoft.project.dto;


import pt.ipp.isep.dei.esoft.project.domain.PlateCertification;

import java.util.Date;

public record PlateCertificationDTO(String brand, String model, String type, double tare, double grossWeight, Date registerDate, String plate) {
    @Override
    public String toString() {
        return String.format("%s - %s - %s : %s", brand, model, type, plate);
    }
}