package pt.ipp.isep.dei.esoft.project.ui.console;

import pt.ipp.isep.dei.esoft.project.application.controller.RegistVehicleCheckUpController;
import pt.ipp.isep.dei.esoft.project.domain.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class RegisterVehicleCheckUpUI implements Runnable{
    private RegistVehicleCheckUpController controller;
    private Scanner scanner;

    /**
     * This instantiates the controller of this operation.
     */
    public RegisterVehicleCheckUpUI() {
        this.controller = new RegistVehicleCheckUpController();
        this.scanner = new Scanner(System.in);
    }

    /**
     * This gets the instantiated controller.
     * @return a RegisterCollaboratorController object.
     */
    public RegistVehicleCheckUpController getController() {
        return controller;
    }

    /**
     * Runs this operation. This operation is based on register a job that a collaborator may have.
     */
    @Override
    public void run() {
        int count=0;
        while (true) {
            if(count!=0) {
                System.out.println("Enter 'exit' to return to the main menu, or any other key to continue:");
                String input = scanner.nextLine();
                if (input.equalsIgnoreCase("exit")) {
                    break;
                }
            }

            List<Vehicle> vehicleList = controller.getVehiclesRepository().getVehiclesList();

            System.out.println("Vehicle to be selected: ");
            System.out.println("Exit");
            for (int i = 0; i < vehicleList.size(); i++) {
                System.out.println((i + 1) + ". " + vehicleList.get(i).getPlateCertification().getPlate());
            }
            Vehicle vehicle = vehicleList.get(0);
            String plate="error";
            while (true) {
                System.out.print("Plate: ");
                plate = scanner.nextLine();
                int aux=0;
                for (int i = 0; i < vehicleList.size(); i++) {
                    if (plate.equalsIgnoreCase(vehicleList.get(i).getPlateCertification().getPlate())) {
                        vehicle = vehicleList.get(i);
                        aux=1;
                    }
                    else if(plate.equalsIgnoreCase("Exit")) aux=1;
                }
                if(aux==1) break;
            }
            if (plate.equalsIgnoreCase("Exit")) break;



            System.out.print("Date (yyyy-MM-dd format): ");
            Date date = null;
            while (date == null) {
                String dateStr = scanner.nextLine();
                try {
                    date = new SimpleDateFormat("yyyy-MM-dd").parse(dateStr);
                } catch (ParseException e) {
                    System.out.print("Invalid date format. Please enter again (yyyy-MM-dd format): ");
                }
            }


            System.out.print("Local: ");
            int local = Integer.parseInt(scanner.nextLine());

            System.out.print("Street: ");
            int street = Integer.parseInt(scanner.nextLine());

            ZipCode zipCode = new ZipCode(
                    local, street
            );
            System.out.print("Door number: ");
            int doorNumber = Integer.parseInt(scanner.nextLine());
            Address place = new Address(
                    doorNumber, zipCode
            );

            System.out.print("Kms: ");
            int kms = Integer.parseInt(scanner.nextLine());


            Optional<VehicleCheckUp> vehicleCheckUp = controller.registVehicleCheckUp(date,place,kms,vehicle);
            if (vehicleCheckUp.isPresent()) {
                System.out.println("Vehicle registed successfully!");
            } else {
                System.out.println("Vehicle already exists or plate is an invalid name.");
            }
            count++;

        }

        System.out.println("List of Registered VehicleCheckUps:");
        for (VehicleCheckUp vehicleCheckUps : controller.getVehiclesCheckUps()) {
            System.out.println(vehicleCheckUps);
        }

    }
}