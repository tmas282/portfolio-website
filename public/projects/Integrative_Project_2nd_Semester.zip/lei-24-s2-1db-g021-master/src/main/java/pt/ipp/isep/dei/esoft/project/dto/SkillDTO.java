package pt.ipp.isep.dei.esoft.project.dto;

public record SkillDTO(String name) {
    @Override
    public String toString() {
        return name;
    }
}