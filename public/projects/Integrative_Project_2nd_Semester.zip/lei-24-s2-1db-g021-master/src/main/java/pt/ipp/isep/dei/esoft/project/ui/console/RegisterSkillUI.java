package pt.ipp.isep.dei.esoft.project.ui.console;

import pt.ipp.isep.dei.esoft.project.application.controller.RegisterSkillController;
import pt.ipp.isep.dei.esoft.project.domain.Skill;

import java.util.Optional;
import java.util.Scanner;

public class RegisterSkillUI implements Runnable{
    private RegisterSkillController controller;
    private Scanner scanner;

    /**
     * This instantiates the controller of this operation.
     */
    public RegisterSkillUI() {
        this.controller = new RegisterSkillController();
        this.scanner = new Scanner(System.in);
    }

    /**
     * This gets the instantiated controller.
     * @return a RegisterSkillController object.
     */
    public RegisterSkillController getController() {
        return controller;
    }

    /**
     * Runs this operation. This operation is based on register a skill that will be assigned to a collaborator lately.
     */
    @Override
    public void run() {
        while (true) {
            System.out.println("Insert the skill name or 'exit' to return to HRM menu:");
            String skillName = scanner.nextLine();
            if (skillName.equalsIgnoreCase("exit")) {
                break;
            }
            Optional<Skill> skill = controller.createSkill(skillName);
            if (skill.isPresent()) {
                System.out.println("Skill added successfully!");
            } else {
                System.out.println("Skill already exists or skill name is an invalid name.");
            }
        }

        System.out.println("List of Registered Skills:");
        for (Skill skill : controller.getSkillsList()) {
            System.out.println(skill);
        }
    }
}