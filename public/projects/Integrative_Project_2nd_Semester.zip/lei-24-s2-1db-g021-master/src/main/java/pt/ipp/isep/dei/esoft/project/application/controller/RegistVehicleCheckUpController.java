package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.domain.*;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;
import pt.ipp.isep.dei.esoft.project.repository.VehicleCheckUpRepository;
import pt.ipp.isep.dei.esoft.project.repository.VehicleRepository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public class RegistVehicleCheckUpController {
    private final Repositories repositories = Repositories.getInstance();

    private VehicleCheckUpRepository vehicleCheckUpRepository;
    private VehicleRepository vehicleRepository;
    private Vehicle vehicle;
    public RegistVehicleCheckUpController() {
        getVehicleCheckUpRepository();
        getVehiclesRepository();
    }
    public RegistVehicleCheckUpController(VehicleCheckUpRepository vehicleCheckUpRepository, VehicleRepository vehicleRepository) {
        this.vehicleCheckUpRepository = vehicleCheckUpRepository;
        this.vehicleRepository = vehicleRepository;
    }
    private VehicleCheckUpRepository getVehicleCheckUpRepository() {
        if (vehicleCheckUpRepository == null) {
            Repositories repositories = Repositories.getInstance();

            vehicleCheckUpRepository = repositories.getVehicleCheckUpRepository();
        }
        return vehicleCheckUpRepository;
    }
    public List<Vehicle> getVehicles(){
        List<Vehicle> vehiclesList = vehicleRepository.getVehiclesList();
        return vehiclesList;
    }
    public List<VehicleCheckUp> getVehiclesCheckUps(){
        List<VehicleCheckUp> vehicleCheckUpsList = vehicleCheckUpRepository.getVehiclesCheckUpsList();
        return vehicleCheckUpsList;
    }
    public VehicleRepository getVehiclesRepository() {
        if (vehicleRepository == null) {
            Repositories repositories = Repositories.getInstance();

            vehicleRepository = repositories.getVehicleRepository();
        }
        return vehicleRepository;
    }
    public Optional<VehicleCheckUp> registVehicleCheckUp(Date date, Address place, float kms, Vehicle vehicle) {
        Optional<VehicleCheckUp> newVehicleCheckUp;
        try {
            newVehicleCheckUp = vehicleCheckUpRepository.add(new VehicleCheckUp(date,place,kms,vehicle));
        } catch (IllegalArgumentException e) {
            return Optional.empty();
        }
        return  newVehicleCheckUp;
    }
    public void storeVehicle(Vehicle vehicle){
        this.vehicle = vehicle;
    }
}
