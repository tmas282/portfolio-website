package pt.ipp.isep.dei.esoft.project.ui.gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import pt.ipp.isep.dei.esoft.project.application.controller.PostponeEntryAgendaController;
import pt.ipp.isep.dei.esoft.project.domain.AgendaEntry;
import pt.ipp.isep.dei.esoft.project.domain.EntryStatus;
import pt.ipp.isep.dei.esoft.project.dto.AgendaEntryDTO;
import pt.ipp.isep.dei.esoft.project.dto.NewAgendaEntryDTO;
import pt.ipp.isep.dei.esoft.project.dto.PostponeEntryDTO;

import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class PostponeEntryAgendaUI implements Initializable {
    private AgendaUI parent;
    private final PostponeEntryAgendaController ctrl = new PostponeEntryAgendaController();

    @FXML
    private Label EntryLabel;

    @FXML
    private Button btnPostponeEntry;

    @FXML
    private ComboBox<AgendaEntryDTO> cbEntry;

    @FXML
    private Label futureDateLabel;

    @FXML
    private TextField futureDateText;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        List<AgendaEntryDTO> agendaEntries = ctrl.getAgendaEntries();
        cbEntry.getItems().setAll(agendaEntries);
    }

    public void setParent(AgendaUI parent) {
        this.parent = parent;
    }

    @FXML
    void postponeEntryAgenda(ActionEvent event) {
        AgendaEntryDTO selectedEntry = cbEntry.getSelectionModel().getSelectedItem();
        if (selectedEntry == null) {
            new Alert(Alert.AlertType.ERROR, "Invalid: selected a entry to postpone.").show();
        }

        String futureDateString = futureDateText.getText();
        Date futureDate;
        try {
            futureDate = new SimpleDateFormat("yyyy-MM-dd").parse(futureDateString);

            PostponeEntryDTO postponeEntryDTO = new PostponeEntryDTO(futureDate, EntryStatus.POSTPONED, selectedEntry.id());

            Optional<AgendaEntryDTO> updatedEntryOpt = ctrl.postponeEntryAgenda(postponeEntryDTO);

            if (updatedEntryOpt.isPresent()) {
                new Alert(Alert.AlertType.INFORMATION, "Entry in agenda postponed with success!").show();

                List<AgendaEntryDTO> agendaEntries = ctrl.getAgendaEntries();
                cbEntry.getItems().setAll(agendaEntries); // Reload the entries

                parent.writeAgendaEntryList();
            } else {
                new Alert(Alert.AlertType.ERROR, "Invalid: it is not possible to postpone this entry in agenda.").show();

            }
        } catch (ParseException e) {
            new Alert(Alert.AlertType.ERROR, "Invalid date: Use format 'yyyy-MM-dd'.").show();
        }
    }
}
