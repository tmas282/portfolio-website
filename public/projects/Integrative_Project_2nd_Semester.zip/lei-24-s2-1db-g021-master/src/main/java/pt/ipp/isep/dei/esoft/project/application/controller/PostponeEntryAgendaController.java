package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.application.session.ApplicationSession;
import pt.ipp.isep.dei.esoft.project.domain.AgendaEntry;
import pt.ipp.isep.dei.esoft.project.domain.Collaborator;
import pt.ipp.isep.dei.esoft.project.domain.EntryStatus;
import pt.ipp.isep.dei.esoft.project.dto.AgendaEntryDTO;
import pt.ipp.isep.dei.esoft.project.dto.PostponeEntryDTO;
import pt.ipp.isep.dei.esoft.project.mapper.AgendaEntryMapper;
import pt.ipp.isep.dei.esoft.project.repository.AgendaEntryRepository;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;

import java.util.List;
import java.util.Optional;

public class PostponeEntryAgendaController {
    private AgendaEntryRepository agendaEntryRepository;

    public PostponeEntryAgendaController() {
        getAgendaEntryRepository();
    }

    /**
     * Allows injection of repositories to be used by the controller. Useful for testing.
     *
     * @param agendaEntryRepository to be used
     */
    public PostponeEntryAgendaController(AgendaEntryRepository agendaEntryRepository) {
        this.agendaEntryRepository = agendaEntryRepository;
    }

    private AgendaEntryRepository getAgendaEntryRepository() {
        if (agendaEntryRepository == null) {
            Repositories repositories = Repositories.getInstance();
            agendaEntryRepository = repositories.getAgendaEntryRepository();
        }
        return agendaEntryRepository;
    }

    public Optional<AgendaEntryDTO> postponeEntryAgenda(PostponeEntryDTO postponeEntryDTO) {
        if (postponeEntryDTO == null)
            return Optional.empty();

        Optional<AgendaEntry> agendaEntryOpt = agendaEntryRepository.findById(postponeEntryDTO.id());

        if (agendaEntryOpt.isEmpty())
            return Optional.empty();

        AgendaEntry agendaEntry = agendaEntryOpt.get();

        agendaEntry.setStartDate(postponeEntryDTO.futureDate());

        agendaEntry.setStatus(EntryStatus.POSTPONED);

        return Optional.of(AgendaEntryMapper.toDTO(agendaEntry));
    }

    public List<AgendaEntryDTO> getAgendaEntries() {
        return AgendaEntryMapper.toDTO(agendaEntryRepository.getAgendaEntryList());
    }
}