package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.dto.SkillDTO;
import pt.ipp.isep.dei.esoft.project.mapper.SkillMapper;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;
import pt.ipp.isep.dei.esoft.project.repository.SkillRepository;

import java.util.List;

public class ListSkillsController {
    private final SkillRepository skillRepository;

    public ListSkillsController() {
        skillRepository = Repositories.getInstance().getSkillRepository();
    }

    /**
     * Allows injection of repositories to be used by the controller. Useful for testing.
     *
     * @param skillRepository to be used
     */
    public ListSkillsController(SkillRepository skillRepository) {
        this.skillRepository = skillRepository;
    }

    public List<SkillDTO> listSkills() {
        return SkillMapper.toDTO(List.copyOf(skillRepository.getSkillsList()));
    }
}
