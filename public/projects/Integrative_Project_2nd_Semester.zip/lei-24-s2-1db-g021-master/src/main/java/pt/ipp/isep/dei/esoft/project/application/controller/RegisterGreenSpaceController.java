package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.application.session.ApplicationSession;
import pt.ipp.isep.dei.esoft.project.domain.*;
import pt.ipp.isep.dei.esoft.project.dto.GreenSpaceDTO;
import pt.ipp.isep.dei.esoft.project.dto.NewGreenSpaceDTO;
import pt.ipp.isep.dei.esoft.project.dto.NewTaskDTO;
import pt.ipp.isep.dei.esoft.project.dto.TaskDTO;
import pt.ipp.isep.dei.esoft.project.mapper.GreenSpaceMapper;
import pt.ipp.isep.dei.esoft.project.mapper.TaskMapper;
import pt.ipp.isep.dei.esoft.project.repository.GreenSpaceRepository;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;

import java.util.List;
import java.util.Optional;

public class RegisterGreenSpaceController {

    private GreenSpaceRepository greenSpaceRepository;

    public RegisterGreenSpaceController() {
        getGreenSpacesRepository();
    }

    /**
     * Allows injection of repositories to be used by the controller. Useful for testing.
     *
     * @param greenSpaceRepository to be used
     */
    public RegisterGreenSpaceController(GreenSpaceRepository greenSpaceRepository) {
        this.greenSpaceRepository = greenSpaceRepository;
    }

    private GreenSpaceRepository getGreenSpacesRepository() {
        if (greenSpaceRepository == null) {
            Repositories repositories = Repositories.getInstance();
            greenSpaceRepository = repositories.getGreenSpaceRepository();
        }
        return greenSpaceRepository;
    }

    /**
     * Regists a new green space. Verifies the current collaborator based on the email from the Application Session.
     *
     * @param newGreenSpaceDTO
     * @return optional empty if newGreenSpaceDTO is null or if the collaborator was not found, return an optional containing the new green space if it was successfully registered.
     */
    public Optional<GreenSpaceDTO> registerGreenSpace(NewGreenSpaceDTO newGreenSpaceDTO) {
        if(newGreenSpaceDTO == null)
            return Optional.empty();

        Collaborator c = null;
        String email = ApplicationSession.getInstance().getCurrentSession().getUserEmail();
        for ( Collaborator collaborator:
            Repositories.getInstance().getCollaboratorRepository().getCollaboratorsList()) {
            if(collaborator.getEmail().equals(email))
                c = collaborator;
        }

        GreenSpace newGreenSpace = new GreenSpace(
                newGreenSpaceDTO.name(),
                newGreenSpaceDTO.sizeClassification(),
                newGreenSpaceDTO.area(),
                newGreenSpaceDTO.address(),
                c
        );

        Optional<GreenSpace> result = greenSpaceRepository.add(newGreenSpace);

        if(result.isEmpty())
            return Optional.empty();

        return Optional.of(GreenSpaceMapper.toDTO(result.get()));
    }

    /**
     * Get the list of green spaces in the green space repository
     *
     * @return green spaces list
     */
    public List<GreenSpace> getGreenSpacesList() {
        return greenSpaceRepository.getGreenSpacesList();
    }
}