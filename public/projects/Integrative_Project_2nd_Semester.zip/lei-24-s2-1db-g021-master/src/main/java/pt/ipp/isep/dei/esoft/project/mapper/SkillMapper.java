package pt.ipp.isep.dei.esoft.project.mapper;

import pt.ipp.isep.dei.esoft.project.domain.Skill;
import pt.ipp.isep.dei.esoft.project.dto.SkillDTO;

import java.util.ArrayList;
import java.util.List;

public class SkillMapper {
    public static SkillDTO toDTO(Skill Skill) {
        return new SkillDTO(
                Skill.getName()
        );
    }

    public static List<SkillDTO> toDTO(List<Skill> SkillList) {
        List<SkillDTO> newList = new ArrayList<>();

        for(Skill Skill : SkillList) {
            newList.add(toDTO(Skill));
        }

        return List.copyOf(newList);
    }
}
