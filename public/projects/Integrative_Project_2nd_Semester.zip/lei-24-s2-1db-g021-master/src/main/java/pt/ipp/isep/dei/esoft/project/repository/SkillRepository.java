package pt.ipp.isep.dei.esoft.project.repository;

import pt.ipp.isep.dei.esoft.project.domain.Skill;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class SkillRepository implements Serializable {

    private final List<Skill> skillsList;

    public SkillRepository() {
        skillsList = new ArrayList<>();
    }

    /**
     * @param skill is the object of class Skill that will be validated
     *              first it will verify if the skill is not duplicated,
     *              then if the skill is valid, it clones the skill givened
     *              and it tries to add the skill to skillsList.
     *              If this operation fails it was an error, if not, it
     * @return the Optional with skill that was cloned.
     */
    public Optional<Skill> add(Skill skill) {
        Optional<Skill> newskill = Optional.empty();
        boolean operationSuccess = false;

        if (validateSkill(skill)) {
            newskill = Optional.of(skill.clone());
            operationSuccess = skillsList.add(newskill.get());
        }

        if (!operationSuccess) {
            newskill = Optional.empty();
        }

        return newskill;
    }

    private boolean validateSkill(Skill skill) {
        for (Skill s : skillsList) {
            if (s.getName().equalsIgnoreCase(skill.getName())) {
                return false;
            }
        }
        return true;
    }

    public Optional<Skill> getSkillByName(String name) {
        for(Skill skill : skillsList)
            if(Objects.equals(name, skill.getName()))
                return Optional.of(skill);

        return Optional.empty();
    }

    /**
     * This method returns a defensive (immutable) copy of the list of skills.
     *
     * @return The list of skills.
     */
    public List<Skill> getSkillsList() {
        //This is a defensive copy, so that the repository cannot be modified from the outside.
        return List.copyOf(skillsList);
    }

    public boolean remove(Skill skill) {
        return skillsList.remove(skill);
    }
}