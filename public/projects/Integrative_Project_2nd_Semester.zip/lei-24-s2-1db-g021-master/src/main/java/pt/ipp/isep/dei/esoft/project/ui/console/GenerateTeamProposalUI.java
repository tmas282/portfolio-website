package pt.ipp.isep.dei.esoft.project.ui.console;

import pt.ipp.isep.dei.esoft.project.application.controller.GenerateTeamProposalController;
import pt.ipp.isep.dei.esoft.project.application.controller.ListSkillsController;
import pt.ipp.isep.dei.esoft.project.domain.Collaborator;
import pt.ipp.isep.dei.esoft.project.domain.Skill;
import pt.ipp.isep.dei.esoft.project.dto.SkillDTO;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class GenerateTeamProposalUI implements Runnable{
    private final GenerateTeamProposalController generateTeamProposalController;
    private final ListSkillsController listSkillsController;
    private final Scanner scanner;

    /**
     * This instantiates the controller of this operation.
     */
    public GenerateTeamProposalUI() {
        this.generateTeamProposalController = new GenerateTeamProposalController();
        this.listSkillsController = new ListSkillsController();
        this.scanner = new Scanner(System.in);
    }

    /**
     * Runs this operation. This operation is based on generate a team with collaborators.
     */
    @Override
    public void run() {
        System.out.println("Insert the minimum team size: ");
        int minTeamSize = Integer.parseInt(scanner.nextLine());

        System.out.println("Insert the maximum team size: ");
        int maxTeamSize = Integer.parseInt(scanner.nextLine());

        List<SkillDTO> skillsList = listSkillsController.listSkills();
        List<SkillDTO> skillsSelected = new ArrayList<>();

        System.out.println("Skills to be selected: ");
        for (int i = 0; i < skillsList.size(); i++) {
            System.out.println((i + 1) + ". " + skillsList.get(i).name());
        }

        while (true) {
            System.out.println("Select a skill that a collaborator need to have by number or '0' to generate a team: ");
            int skillNumber = scanner.nextInt();
            if (skillNumber == 0) {
                break;
            }
            if (skillNumber > 0 && skillNumber <= skillsList.size()) {
                skillsSelected.add(skillsList.get(skillNumber - 1));
            } else {
                System.out.println("Invalid number selected. Please select a valid number or '0' to generate a team.");
            }
        }

        List<Collaborator> team = generateTeamProposalController.generateTeamProposal(minTeamSize, maxTeamSize, skillsSelected);

        if (team.isEmpty()) {
            System.out.println("It wasn't possible to generate a team with those specified requirements.");
        } else {
            System.out.println("Team proposal generated successfully: ");
            for (Collaborator collaborator : team) {
                System.out.println(collaborator);
            }
        }
    }
}