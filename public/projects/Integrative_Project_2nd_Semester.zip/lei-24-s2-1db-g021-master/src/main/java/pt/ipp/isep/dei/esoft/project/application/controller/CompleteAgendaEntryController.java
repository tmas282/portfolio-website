package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.domain.AgendaEntry;
import pt.ipp.isep.dei.esoft.project.domain.EntryStatus;
import pt.ipp.isep.dei.esoft.project.dto.AgendaEntryDTO;
import pt.ipp.isep.dei.esoft.project.mapper.AgendaEntryMapper;
import pt.ipp.isep.dei.esoft.project.repository.AgendaEntryRepository;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;

import java.util.Optional;
import java.util.UUID;

public class CompleteAgendaEntryController {
    private final AgendaEntryRepository agendaEntryRepository;

    public CompleteAgendaEntryController() {
        agendaEntryRepository = Repositories.getInstance().getAgendaEntryRepository();
    }

    /**
     * Allows injection of repositories to be used by the controller. Useful for testing.
     *
     * @param agendaEntryRepository to be used
     */
    public CompleteAgendaEntryController(AgendaEntryRepository agendaEntryRepository) {
        this.agendaEntryRepository = agendaEntryRepository;
    }

    public Optional<AgendaEntryDTO> complete(UUID agendaEntryId) {
        Optional<AgendaEntry> agendaEntry = agendaEntryRepository.findById(agendaEntryId);

        if(agendaEntry.isEmpty())
            return Optional.empty();

        agendaEntry.get().setStatus(EntryStatus.DONE);

        return Optional.of(AgendaEntryMapper.toDTO(agendaEntry.get()));
    }
}
