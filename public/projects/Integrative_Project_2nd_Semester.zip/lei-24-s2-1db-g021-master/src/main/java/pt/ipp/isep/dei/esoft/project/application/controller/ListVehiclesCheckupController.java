package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.domain.Vehicle;
import pt.ipp.isep.dei.esoft.project.domain.VehicleCheckUp;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;
import pt.ipp.isep.dei.esoft.project.repository.VehicleCheckUpRepository;
import pt.ipp.isep.dei.esoft.project.repository.VehicleRepository;

import java.util.*;

public class ListVehiclesCheckupController {
    private VehicleRepository vehicleRepository;
    private VehicleCheckUpRepository vehiclesCheckUpsRepository;

    /**
     * This constructor instantiates it with the default vehicle and vehicles check-ups repositories.
     */
    public ListVehiclesCheckupController() {
        getVehiclesRepository();
        getVehiclesCheckUpsRepository();
    }

    /**
     * This constructor instantiates it with the custom vehicles and vehicles check-ups repositories.
     * @param vehicleRepository the custom vehicle repository
     * @param vehicleCheckUpRepository the custom vehicles check-ups repository
     */
    public ListVehiclesCheckupController(VehicleRepository vehicleRepository, VehicleCheckUpRepository vehicleCheckUpRepository) {
        this.vehicleRepository = vehicleRepository;
        this.vehiclesCheckUpsRepository = vehicleCheckUpRepository;
    }
    private VehicleRepository getVehiclesRepository(){
        if (vehicleRepository == null) {
            Repositories repositories = Repositories.getInstance();
            vehicleRepository = repositories.getVehicleRepository();
        }
        return vehicleRepository;
    }
    private VehicleCheckUpRepository getVehiclesCheckUpsRepository(){
        if (vehiclesCheckUpsRepository == null) {
            Repositories repositories = Repositories.getInstance();
            vehiclesCheckUpsRepository = repositories.getVehicleCheckUpRepository();
        }
        return vehiclesCheckUpsRepository;
    }

    /**
     * This method gets the vehicles needing or almost needing a check-up
     * @return a Map containing the vehicles needing or almost needing a check-up
     */
    public Map<Vehicle, VehicleCheckUp[]> getVehiclesNeedingCheckup(){
        List<Vehicle> vehicles = vehicleRepository.getVehiclesList();
        Map<Vehicle, VehicleCheckUp[]> vehiclesNeedingIt = new HashMap<>();
        for (Vehicle vehicle:
             vehicles) {
                List<VehicleCheckUp> vehicleCheckUps = vehiclesCheckUpsRepository.getVehicleCheckUps(vehicle);
                if (vehicleCheckUps.isEmpty()){
                    if(isVehicleNeedingOrAlmostCheckup(vehicle)){
                        vehiclesNeedingIt.put(vehicle, null);
                    }
                }
                else{
                    VehicleCheckUp[] lastNextCheckups = getNextAndLastCheckup(vehicleCheckUps, vehicle);
                    if(isVehicleNeedingOrAlmostCheckup(vehicle, lastNextCheckups[0])){
                        vehiclesNeedingIt.put(vehicle, lastNextCheckups);
                    }
                }
        }
        return vehiclesNeedingIt;
    }

    private boolean isVehicleNeedingOrAlmostCheckup(Vehicle vehicle){
        return didVehExceededCheckup(vehicle) || isVehicleCloseToExceedCheckup(vehicle);
    }
    private boolean isVehicleNeedingOrAlmostCheckup(Vehicle vehicle, VehicleCheckUp lastCheckup){
        return didVehExceededCheckup(vehicle, lastCheckup) || isVehicleCloseToExceedCheckup(vehicle, lastCheckup);
    }
    private boolean didVehExceededCheckup(Vehicle vehicle){
        double maintenance = vehicle.getMaintenance();
        double currentKm = vehicle.getCurrentKm();
        return currentKm >= maintenance;
    }
    private boolean didVehExceededCheckup(Vehicle vehicle, VehicleCheckUp lastCheckup){
        double lastMaintenanceKms = lastCheckup.getKms();
        double maintenance = vehicle.getMaintenance();
        double currentKm = vehicle.getCurrentKm();
        return (lastMaintenanceKms + maintenance <= currentKm);
    }
    private boolean isVehicleCloseToExceedCheckup(Vehicle vehicle){
        double maintenance = vehicle.getMaintenance();
        double currentKm = vehicle.getCurrentKm();
        double dif = maintenance - currentKm;
        return dif <= maintenance * 0.05;
    }
    private boolean isVehicleCloseToExceedCheckup(Vehicle vehicle, VehicleCheckUp lastCheckup){
        double lastMaintenanceKms = lastCheckup.getKms();
        double maintenance = vehicle.getMaintenance();
        double currentKm = vehicle.getCurrentKm();
        double dif = lastMaintenanceKms + maintenance - currentKm;
        return dif <= maintenance * 0.05;
    }
    private VehicleCheckUp[] getNextAndLastCheckup(List<VehicleCheckUp> vehicleCheckUpList, Vehicle vehicle){
        VehicleCheckUp lastCheckup = null;
        VehicleCheckUp nextCheckup = null;
        double currentKms = vehicle.getCurrentKm();
        for (VehicleCheckUp vehCheckUp:
             vehicleCheckUpList) {
            if (nextCheckup == null && vehCheckUp.getKms() >= currentKms) {
                nextCheckup = vehCheckUp;
            }
            if (nextCheckup != null && vehCheckUp.getKms() <= nextCheckup.getKms() && vehCheckUp.getKms() >= currentKms) {
                nextCheckup = vehCheckUp;
            }
            if (lastCheckup == null && vehCheckUp.getKms() < currentKms) {
                lastCheckup = vehCheckUp;
            }
            if (lastCheckup != null && vehCheckUp.getKms() >= lastCheckup.getKms() && vehCheckUp.getKms() < currentKms) {
                lastCheckup = vehCheckUp;
            }
        }
        return new VehicleCheckUp[]{lastCheckup, nextCheckup};
    }
}
