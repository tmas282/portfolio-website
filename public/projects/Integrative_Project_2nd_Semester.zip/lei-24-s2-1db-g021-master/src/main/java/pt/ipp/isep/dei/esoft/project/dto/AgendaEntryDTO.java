package pt.ipp.isep.dei.esoft.project.dto;

import pt.ipp.isep.dei.esoft.project.domain.*;

import java.util.List;
import java.util.UUID;

public record AgendaEntryDTO(UUID id, int expectedDuration, List<VehicleDTO> equipment, EntryStatus status, TeamDTO team, TaskDTO task) {
    @Override
    public String toString() {
        return String.format("%s - %s - %s", task, status, id);
    }
}