package pt.ipp.isep.dei.esoft.project.dto;

public record AddressDTO(int doorNumber, String zipCode) { }
