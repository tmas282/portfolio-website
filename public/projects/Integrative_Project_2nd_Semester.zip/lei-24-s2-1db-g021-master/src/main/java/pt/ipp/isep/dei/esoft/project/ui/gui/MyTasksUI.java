package pt.ipp.isep.dei.esoft.project.ui.gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import pt.ipp.isep.dei.esoft.project.application.controller.ListMyTasksController;
import pt.ipp.isep.dei.esoft.project.domain.EntryStatus;
import pt.ipp.isep.dei.esoft.project.dto.MyTasksFilterDTO;
import pt.ipp.isep.dei.esoft.project.dto.TaskDTO;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

public class MyTasksUI implements Initializable {
    private final ListMyTasksController listMyTasksController = new ListMyTasksController();

    @FXML
    private VBox mainPane;
    @FXML
    private DatePicker startDatePicker;
    @FXML
    private DatePicker endDatePicker;
    @FXML
    private ComboBox<EntryStatus> statusComboBox;
    @FXML
    private Button searchButton;
    @FXML
    private TextArea myTaskListTextArea;
    @FXML
    private Button completeTasksButton;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        statusComboBox.getItems().setAll(List.of(EntryStatus.values()));

        LocalDate currentDate = LocalDate.now();

        startDatePicker.setValue(currentDate.minusMonths(1));
        endDatePicker.setValue(currentDate.plusDays(1));

        statusComboBox.setValue(EntryStatus.PLANNED);
    }

    @FXML
    private void openCompleteMyAgendaEntries(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(MyTasksUI.class.getResource("complete-my-agenda-entries-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 600);

            Stage stage = new Stage();
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(mainPane.getScene().getWindow());
            stage.setScene(scene);

            CompleteMyAgendaEntriesUI completeMyAgendaEntriesUI = fxmlLoader.getController();
            completeMyAgendaEntriesUI.setParent(this);

            stage.show();
        }catch(IOException exception) {
            exception.getStackTrace();
        }
    }

    public void writeTaskList() {
        myTaskListTextArea.clear();

        if(startDatePicker.getValue() == null)
            return;

        if(endDatePicker.getValue() == null)
            return;

        if(statusComboBox.getValue() == null)
            return;

        Date startDate = Date.from(startDatePicker.getValue().atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
        Date endDate = Date.from(endDatePicker.getValue().atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());

        List<TaskDTO> taskList = listMyTasksController.listTasks(new MyTasksFilterDTO(
                startDate,
                endDate,
                statusComboBox.getValue()
        ));

        for(TaskDTO task : taskList) {
            myTaskListTextArea.appendText(String.format(
                    "%s (%s - %s) for %s:%n%s%n",
                    task.name(),
                    task.category(),
                    task.urgency(),
                    task.greenSpace().name(),
                    task.description()
            ));
        }
    }
}
