package pt.ipp.isep.dei.esoft.project.repository;

import pt.ipp.isep.dei.esoft.project.domain.AgendaEntry;
import pt.ipp.isep.dei.esoft.project.domain.Collaborator;
import pt.ipp.isep.dei.esoft.project.domain.EntryStatus;

import java.io.Serializable;
import java.util.*;

public class AgendaEntryRepository implements Serializable {
    private final List<AgendaEntry> agendaEntryList;

    public AgendaEntryRepository() {
        this.agendaEntryList = new ArrayList<>();
    }

    /**
     * Adds a new agenda entry to the repository. The agenda entry to be added must be new
     *
     * @param newAgendaEntry the task to be added
     * @return Empty optional if the creation of agenda entry failed
     * and AgendaEntryDTO optional if the creation was successful
     */
    public Optional<AgendaEntry> add(AgendaEntry newAgendaEntry) {
        if (agendaEntryList.contains(newAgendaEntry))
            return Optional.empty();

        this.agendaEntryList.add(newAgendaEntry);

        return Optional.of(newAgendaEntry);
    }

    /**
     * @return immutable list of all the agenda entry
     */
    public List<AgendaEntry> getAgendaEntryList() {
        return List.copyOf(this.agendaEntryList);
    }

    public List<AgendaEntry> getAgendaEntriesByCollaboratorAndStateBetweenDates(Collaborator collaborator, EntryStatus entryStatus, Date start, Date end) {
        return agendaEntryList.stream().filter(entry -> {
            if(entryStatus != null && entry.getStatus() != entryStatus)
                return false;

            if(entry.getStartDate().before(start))
                return false;

            if(entry.getStartDate().after(end))
                return false;

            for(Collaborator teamCollaborator : entry.getTeam().getCollaboratorList())
                if(Objects.equals(collaborator, teamCollaborator))
                    return true;

            return false;
        }).toList();
    }

    public List<AgendaEntry> getUnfinishedAgendaEntriesByCollaborator(Collaborator collaborator) {
        return agendaEntryList.stream().filter(entry -> {
            if(entry.getStatus() != EntryStatus.PLANNED)
                return false;

            for(Collaborator teamCollaborator : entry.getTeam().getCollaboratorList())
                if(Objects.equals(collaborator, teamCollaborator))
                    return true;

            return false;
        }).toList();
    }

    /**
     * Finds an agenda entry by its UUID.
     *
     * @param id the UUID of the agenda entry to find.
     * @return an Optional containing the found AgendaEntry, or an empty Optional if no entry was found
     */
    public Optional<AgendaEntry> findById(UUID id) {
        for(AgendaEntry agendaEntry : agendaEntryList)
            if(Objects.equals(id, agendaEntry.getId()))
                return Optional.of(agendaEntry);

        return Optional.empty();
    }
}
