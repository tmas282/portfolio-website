package pt.ipp.isep.dei.esoft.project.mapper;

import pt.ipp.isep.dei.esoft.project.domain.Address;
import pt.ipp.isep.dei.esoft.project.dto.AddressDTO;

public class AddressMapper {
    public static AddressDTO toDTO(Address address) {
        return new AddressDTO(
                address.getDoorNumber(),
                String.format("%04d-%03d", address.getZipCode().getLocal(), address.getZipCode().getStreet())
        );
    }
}
