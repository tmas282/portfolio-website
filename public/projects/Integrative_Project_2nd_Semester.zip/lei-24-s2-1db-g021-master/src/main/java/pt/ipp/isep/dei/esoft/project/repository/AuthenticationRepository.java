package pt.ipp.isep.dei.esoft.project.repository;

import pt.ipp.isep.dei.esoft.project.domain.CollaboratorRole;
import pt.isep.lei.esoft.auth.AuthFacade;
import pt.isep.lei.esoft.auth.UserSession;

import java.io.*;

public class AuthenticationRepository implements Externalizable {
    private AuthFacade authenticationFacade;

    public AuthenticationRepository() {
        authenticationFacade = new AuthFacade();
    }

    public boolean doLogin(String email, String pwd) {
        return authenticationFacade.doLogin(email, pwd).isLoggedIn();
    }

    public void doLogout() {
        authenticationFacade.doLogout();
    }

    public UserSession getCurrentUserSession() {
        return authenticationFacade.getCurrentUserSession();
    }

    public boolean addUserRole(CollaboratorRole role) {
        return authenticationFacade.addUserRole(role.name(), role.toString());
    }

    public boolean addUserWithRole(String name, String email, String pwd, CollaboratorRole role) {
        return authenticationFacade.addUserWithRole(name, email, pwd, role.name());
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException { }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        this.authenticationFacade = new AuthFacade();
    }
}