package pt.ipp.isep.dei.esoft.project.repository;

import pt.ipp.isep.dei.esoft.project.domain.Task;
import pt.ipp.isep.dei.esoft.project.domain.Vehicle;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class VehicleRepository implements Serializable {
    private final List<Vehicle> vehiclesList;

    /**
     * Constructs a new VehicleRepository object.
     */
    public VehicleRepository() {
        vehiclesList = new ArrayList<>();
    }

    /**
     * Adds a new Vehicle to the repository.
     *
     * @param vehicle The Vehicle object to be added.
     * @return An Optional containing the newly added Vehicle, or empty if the operation fails.
     */
    public Optional<Vehicle> add(Vehicle vehicle) {

        Optional<Vehicle> newVehicle = Optional.empty();
        boolean operationSuccess = false;

        if (validateVehicle(vehicle)) {
            newVehicle = Optional.of(vehicle.clone());
            operationSuccess = vehiclesList.add(newVehicle.get());
        }

        if (!operationSuccess) {
            newVehicle = Optional.empty();
        }

        return newVehicle;
    }

    private boolean validateVehicle(Vehicle vehicle) {
        return !vehiclesList.contains(vehicle);
    }

    public Optional<Vehicle> getVehicleByPlate(String plate) {
        for(Vehicle vehicle : vehiclesList)
            if(Objects.equals(plate, vehicle.getPlateCertification().getPlate()))
                return Optional.of(vehicle);

        return Optional.empty();
    }

    /**
     * Retrieves a defensive (immutable) copy of the list of vehicles.
     *
     * @return The list of vehicles.
     */
    public List<Vehicle> getVehiclesList() {
        // This is a defensive copy, so that the repository cannot be modified from the outside.
        return List.copyOf(vehiclesList);
    }

    public List<Optional<Vehicle>> getVehiclesByName(String plates) {
        List<Optional<Vehicle>> vehicles = new ArrayList<>();
        String[] plateslist = plates.split("\n");
        for(int i=0; i<plateslist.length;i++){
            for (Vehicle vehicle : this.vehiclesList)
                if (vehicle.getPlateCertification().getPlate().equals(plateslist[i]))
                    vehicles.add(Optional.of(vehicle));
        }

        return vehicles;
    }
    /**
     * Removes a Vehicle from the repository.
     *
     * @param vehicle The Vehicle object to be removed.
     * @return True if the Vehicle was successfully removed, false otherwise.
     */
    public boolean remove(Vehicle vehicle) {
        return vehiclesList.remove(vehicle);
    }
}