package pt.ipp.isep.dei.esoft.project.ui;

import pt.ipp.isep.dei.esoft.project.domain.*;
import pt.ipp.isep.dei.esoft.project.repository.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public class Bootstrap implements Runnable {
    private final AuthenticationRepository authenticationRepository = Repositories.getInstance().getAuthenticationRepository();
    private final CollaboratorRepository collaboratorRepository = Repositories.getInstance().getCollaboratorRepository();
    private final JobRepository jobRepository = Repositories.getInstance().getJobRepository();
    private final SkillRepository skillRepository = Repositories.getInstance().getSkillRepository();
    private final TeamRepository teamRepository = Repositories.getInstance().getTeamRepository();
    private final VehicleRepository vehicleRepository = Repositories.getInstance().getVehicleRepository();
    private final GreenSpaceRepository greenSpaceRepository = Repositories.getInstance().getGreenSpaceRepository();
    private final TaskRepository taskRepository = Repositories.getInstance().getTaskRepository();
    private final AgendaEntryRepository agendaEntryRepository = Repositories.getInstance().getAgendaEntryRepository();

    private static final String JOB1_NAME = "Mecânico";
    private static final String SKILL1_NAME = "Falar inglês";
    private static final String SKILL2_NAME = "Experiência em gestão de eventos lúdicos";
    private static final String COLLABORATOR1_EMAIL = "collaborator1@this.app";
    private static final String COLLABORATOR2_EMAIL = "collaborator2@this.app";
    private static final String TEAM1_NAME = "Team 1";
    private static final String GREEN_SPACE1_NAME = "Green Space 1";
    private static final String TASK1_NAME = "Task 1";

    public void run() {
        bootstrapRoles();
        bootstrapMainCollaborators();
        bootstrapJobs();
        bootstrapSkills();
        bootstrapCollaborators();
        bootstrapTeams();
        bootstrapGreenSpaces();
        bootstrapTasks();
        bootstrapAgendaEntries();

        vehicleRepository.add(new Vehicle(
                1,
                new Date(),
                1000,
                new PlateCertification(
                        "Mercedes",
                        "Benz",
                        "car",
                        1000,
                        1200,
                        new Date(),
                        "AA-11-BB"
                )
        ));

        vehicleRepository.add(new Vehicle(
                1,
                new Date(),
                1000,
                new PlateCertification(
                        "Tesla",
                        "D",
                        "truck",
                        1000,
                        2000,
                        new Date(),
                        "AA-22-BB"
                )
        ));

        Optional<Collaborator> collaborator = collaboratorRepository.getCollaboratorByEmail("collaborator@this.app");
        Optional<Skill> skill = skillRepository.getSkillByName("Falar inglês");

        if(collaborator.isPresent() && skill.isPresent())
            collaborator.get().addSkill(skill.get());

        bootstrapAuthentication();
    }

    private void bootstrapRoles() {
        for (CollaboratorRole role : CollaboratorRole.values())
            authenticationRepository.addUserRole(role);
    }

    private void bootstrapAuthentication() {
        for(Collaborator collaborator : collaboratorRepository.getCollaboratorsList())
            authenticationRepository.addUserWithRole(collaborator.getDocument().getName(), collaborator.getEmail(), collaborator.getPassword(), collaborator.getRole());
    }

    private void bootstrapMainCollaborators() {
        collaboratorRepository.add(new Collaborator(
                new Document("Administrator", new Date(), 12341234),
                "admin@this.app",
                CollaboratorRole.ADMIN,
                "admin"
        ));

        collaboratorRepository.add(new Collaborator(
                new Document("Collaborator", new Date(), 12341235),
                "collaborator@this.app",
                CollaboratorRole.COLLABORATOR,
                "pwd"
        ));

        collaboratorRepository.add(new Collaborator(
                new Document("Human Resources Manager", new Date(), 12341235),
                "hrm@this.app",
                CollaboratorRole.HRM,
                "hrm"
        ));

        collaboratorRepository.add(new Collaborator(
                new Document("Vehicle Fleet Manager", new Date(), 12341235),
                "vfm@this.app",
                CollaboratorRole.VFM,
                "vfm"
        ));
    }

    private void bootstrapJobs() {
        jobRepository.add(new Job("Contabilista"));
        jobRepository.add(new Job("Jardineiro"));
        jobRepository.add(new Job(JOB1_NAME));
    }

    private void bootstrapSkills() {
        skillRepository.add(new Skill(SKILL1_NAME));
        skillRepository.add(new Skill(SKILL2_NAME));
    }

    private void bootstrapCollaborators() {
        Optional<Job> job = jobRepository.getJobByName(JOB1_NAME);

        if(job.isEmpty())
            return;

        Optional<Skill> skill1 = skillRepository.getSkillByName(SKILL1_NAME);

        if(skill1.isEmpty())
            return;

        Optional<Skill> skill2 = skillRepository.getSkillByName(SKILL2_NAME);

        if(skill2.isEmpty())
            return;

        Collaborator collaborator1 = new Collaborator(
                new Document("Collaborator 1", new Date(), 88888888),
                new Date(),
                new Address(1, new ZipCode(4444, 333)),
                999999999,
                COLLABORATOR1_EMAIL,
                999999999,
                job.get()
        );

        collaborator1.addSkill(skill1.get());

        collaboratorRepository.add(collaborator1);

        Collaborator collaborator2 = new Collaborator(
                new Document("Collaborator 2", new Date(), 88888888),
                new Date(),
                new Address(1, new ZipCode(4444, 333)),
                999999999,
                COLLABORATOR2_EMAIL,
                999999999,
                job.get()
        );

        collaborator1.addSkill(skill2.get());

        collaboratorRepository.add(collaborator2);
    }

    private void bootstrapTeams() {
        Optional<Collaborator> collaborator1 = collaboratorRepository.getCollaboratorByEmail(COLLABORATOR1_EMAIL);

        if(collaborator1.isEmpty())
            return;

        Optional<Collaborator> collaborator2 = collaboratorRepository.getCollaboratorByEmail(COLLABORATOR2_EMAIL);

        if(collaborator2.isEmpty())
            return;

        Optional<Skill> skill1 = skillRepository.getSkillByName(SKILL1_NAME);

        if(skill1.isEmpty())
            return;

        Optional<Skill> skill2 = skillRepository.getSkillByName(SKILL2_NAME);

        if(skill2.isEmpty())
            return;

        Team team1 = new Team(
                TEAM1_NAME,
                2,
                2,
                List.of(collaborator1.get(), collaborator2.get()),
                List.of(skill1.get(), skill2.get())
        );

        teamRepository.add(team1);
    }

    private void bootstrapGreenSpaces() {
        Optional<Collaborator> manager = collaboratorRepository.getCollaboratorByEmail(COLLABORATOR1_EMAIL);

        if(manager.isEmpty())
            return;

        GreenSpace greenSpace1 = new GreenSpace(
                GREEN_SPACE1_NAME,
                SizeClassification.GARDEN,
                1,
                new Address(1, new ZipCode(4444, 333)),
                manager.get()
        );

        greenSpaceRepository.add(greenSpace1);
    }

    private void bootstrapTasks() {
        Optional<GreenSpace> greenSpace1 = greenSpaceRepository.getGreenSpaceByName(GREEN_SPACE1_NAME);

        if(greenSpace1.isEmpty())
            return;

        Task task1 = new Task(
                TASK1_NAME,
                "Task description",
                TaskCategory.REGULAR,
                TaskUrgency.HIGH,
                greenSpace1.get()
        );

        taskRepository.add(task1);
    }

    private void bootstrapAgendaEntries() {
        Optional<Team> team1 = teamRepository.getTeamByName(TEAM1_NAME);

        if(team1.isEmpty())
            return;

        Optional<Task> task1 = taskRepository.getTaskByName(TASK1_NAME);

        if(task1.isEmpty())
            return;

        AgendaEntry agendaEntry1 = new AgendaEntry(
                1,
                new Date(),
                List.of(),
                EntryStatus.PLANNED,
                team1.get(),
                task1.get()
        );

        agendaEntryRepository.add(agendaEntry1);
    }
}