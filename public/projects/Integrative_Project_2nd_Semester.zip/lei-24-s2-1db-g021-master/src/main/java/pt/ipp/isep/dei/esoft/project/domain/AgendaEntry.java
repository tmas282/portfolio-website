package pt.ipp.isep.dei.esoft.project.domain;

import java.io.Serializable;
import java.util.*;

public class AgendaEntry implements Serializable {
    private final UUID id;
    private int expectedDuration;
    private Date startDate;
    private List<Vehicle> equipment;
    private EntryStatus status;
    private Team team;
    private Task task;

    private static final Team DEFAULT_TEAM = new Team("default team", 0, 0, new ArrayList<>(), new ArrayList<>());

    public AgendaEntry(int expectedDuration, Date startDate, List<Vehicle> equipment, EntryStatus status, Team team, Task task) throws IllegalArgumentException {
        if(expectedDuration <= 0)
            throw new IllegalArgumentException("Invalid expected duration: expected duration must be greater than 0");

        if(startDate == null)
            throw new IllegalArgumentException("Invalid start date: start date can't be null");

        if(equipment == null)
            throw new IllegalArgumentException("Invalid equipment: equipment can't be null");

        if(status == null)
            throw new IllegalArgumentException("Invalid status: status can't be null");

        if(team == null)
            throw new IllegalArgumentException("Invalid team: team can't be null");

        if(task == null)
            throw new IllegalArgumentException("Invalid task: task can't be null");

        this.id = UUID.randomUUID();
        this.expectedDuration = expectedDuration;
        this.startDate = startDate;
        this.equipment = equipment;
        this.status = status;
        this.team = team;
        this.task = task;
    }

    public AgendaEntry(int expectedDuration, Date startDate, List<Vehicle> equipment, EntryStatus status, Task task) throws IllegalArgumentException {
        if(expectedDuration <= 0)
            throw new IllegalArgumentException("Invalid expected duration: expected duration must be greater than 0");

        if(startDate == null)
            throw new IllegalArgumentException("Invalid start date: start date can't be null");

        if(equipment == null)
            throw new IllegalArgumentException("Invalid equipment: equipment can't be null");

        if(status == null)
            throw new IllegalArgumentException("Invalid status: status can't be null");

        if(task == null)
            throw new IllegalArgumentException("Invalid task: task can't be null");

        this.id = UUID.randomUUID();
        this.expectedDuration = expectedDuration;
        this.startDate = startDate;
        this.equipment = equipment;
        this.status = status;
        this.team = DEFAULT_TEAM;
        this.task = task;
    }

    public UUID getId() {
        return id;
    }

    public int getExpectedDuration() {
        return expectedDuration;
    }

    public Date getStartDate() {
        return startDate;
    }

    public List<Vehicle> getEquipment() {
        return equipment;
    }

    public EntryStatus getStatus() {
        return status;
    }

    public void setStatus(EntryStatus status) {
        this.status = status;
    }

    public Team getTeam() {
        return team;
    }

    public void setTeam(Team team) {
        if(team == null)
            throw new IllegalArgumentException("Invalid team: team can't be null");

        this.team = team;
    }

    public Task getTask() {
        return task;
    }

    @Override
    public boolean equals(Object object) {
        if(object == this)
            return true;

        if(object == null)
            return false;

        if(object.getClass() != this.getClass())
            return false;

        AgendaEntry agendaEntry = (AgendaEntry) object;

        if(Objects.equals(agendaEntry.id, this.id))
            return true;

        if(!Objects.equals(agendaEntry.team, this.team))
            return false;

        if(!Objects.equals(agendaEntry.task, this.task))
            return false;

        return true;
    }

    public void setStartDate(Date newStartDate) {
        this.startDate = newStartDate;
    }
}
