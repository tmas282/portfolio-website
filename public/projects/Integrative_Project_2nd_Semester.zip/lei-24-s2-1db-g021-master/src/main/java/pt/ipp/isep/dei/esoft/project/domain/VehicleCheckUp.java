package pt.ipp.isep.dei.esoft.project.domain;

import java.io.Serializable;
import java.util.Date;

public class VehicleCheckUp implements Serializable {
    private Date date;
    private Address place;
    private float kms;
    private Vehicle vehicle;

    /**
     * This method gets the vehicle registered in this Vehicle check-up instance.
     * @return The Vehicle
     */
    public Vehicle getVehicle() {
        return vehicle;
    }

    /**
     * This method gets the date registered in this Vehicle check-up instance.
     * @return The Date
     */
    public Date getDate() {
        return date;
    }

    /**
     * This method sets the date in this Vehicle check-up instance.
     * @param date The Date
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * This method gets the address registered in this Vehicle check-up instance.
     * @return The Address
     */
    public Address getPlace() {
        return place;
    }

    /**
     * This method sets the address in this Vehicle check-up instance.
     * @param place The Address
     */
    public void setPlace(Address place) {
        this.place = place;
    }

    /**
     * This method gets the kilometers registered in this Vehicle check-up instance.
     * @return The Kilometers
     */
    public float getKms() {
        return kms;
    }

    /**
     * This method set the kilometers of the vehicle check-up
     * if the kilometers provided are negative, its returns false
     * @param kms the kilometers
     * @return a boolean value indicating the success of it
     */
    public boolean setKms(float kms) {
        if(kmsAreNegative(kms)){
            return false;
        }
        this.kms = kms;
        return true;
    }

    /**
     * Initializes a new VehicleCheckUp
     * Throws IllegalArgumentException if the kilometers is negative i.e. below 0
     * @param date the date
     * @param place the place
     * @param kms the kilometers
     * @param vehicle the vehicle
     */
    public VehicleCheckUp(Date date, Address place, float kms, Vehicle vehicle) {
        if(kmsAreNegative(kms)){
            throw new IllegalArgumentException("Kilometers can't be negative.");
        }
        if (date == null || place == null || vehicle == null) {
            throw new IllegalArgumentException("Null values are invalid.");
        }
        this.kms = kms;
        this.vehicle = vehicle;
        this.date = date;
        this.place = place;
    }

    /**
     * This method returns true if the kilometers are negative i.e. are below 0
     * @param kms the kilometers
     * @return a boolean value
     */
    private static boolean kmsAreNegative(float kms){
        return kms < 0;
    }

    /**
     * This method clones the instance into a new instance.
     * @return a VehicleCheckUp object
     */
    public VehicleCheckUp clone() {
        return new VehicleCheckUp(this.date, this.place, this.kms, this.vehicle);
    }

}
