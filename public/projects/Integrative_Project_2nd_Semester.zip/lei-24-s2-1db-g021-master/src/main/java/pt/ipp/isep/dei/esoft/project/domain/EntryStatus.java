package pt.ipp.isep.dei.esoft.project.domain;

public enum EntryStatus {
    PLANNED("Planned"), POSTPONED("Postponed"), CANCELED("Canceled"), DONE("Done");

    private final String stringRepresentation;

    EntryStatus(String stringRepresentation) {
        this.stringRepresentation = stringRepresentation;
    }

    @Override
    public String toString() {
        return stringRepresentation;
    }
}
