package pt.ipp.isep.dei.esoft.project.ui.gui;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import pt.ipp.isep.dei.esoft.project.application.controller.authorization.AuthenticationController;
import pt.ipp.isep.dei.esoft.project.domain.CollaboratorRole;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;
import pt.ipp.isep.dei.esoft.project.ui.Bootstrap;
import pt.ipp.isep.dei.esoft.project.utils.SerializeUtils;
import pt.isep.lei.esoft.auth.mappers.dto.UserRoleDTO;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class MainUI extends Application implements Initializable {
    private static final String PATH = "src/main/resources/database.bin";
    private final AuthenticationController authenticationController = new AuthenticationController();

    @FXML
    private Tab agendaTab;
    @FXML
    private TabPane mainPane;
    @FXML
    private GridPane inputPane;
    @FXML
    private TextField userField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private Button loginButton;
    @FXML
    private Button logoutButton;
    @FXML
    private Button exitButton;
    @FXML
    private Tab toDoListTab;
    @FXML
    private Tab greenSpacesTab;
    @FXML
    private Tab myTasksTab;
    @FXML
    private Tab myGreenSpacesTab;

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainUI.class.getResource("main-view.fxml"));

        Scene scene = new Scene(fxmlLoader.load(), 800, 600);
        stage.setTitle("MusgoSublime");
        stage.setScene(scene);

        stage.show();
    }

    public static void main(String[] args) {
        Repositories newRepositories = SerializeUtils.deserializeInfo(PATH);
        Repositories.setInstance(newRepositories);

        Bootstrap bootstrap = new Bootstrap();
        bootstrap.run();

        launch();

        SerializeUtils.serializeInfo(PATH);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
    }

    @FXML
    private void login(ActionEvent event) {
        boolean result = authenticationController.doLogin(userField.getText(), passwordField.getText());

        if(!result) {
            new Alert(Alert.AlertType.ERROR, "Invalid credentials").show();

            return;
        }

        myTasksTab.setDisable(true);
        loginButton.setVisible(false);
        inputPane.setVisible(false);
        logoutButton.setVisible(true);

        List<UserRoleDTO> userRoleDTOList = authenticationController.getUserRoles();

        for(UserRoleDTO userRoleDTO : userRoleDTOList) {
            try {
                CollaboratorRole role = CollaboratorRole.valueOf(userRoleDTO.getId());

                switch(role) {
                    case COLLABORATOR:
                        myTasksTab.setDisable(false);
                        break;
                    case ADMIN:
                        myTasksTab.setDisable(false);
                        toDoListTab.setDisable(false);
                        greenSpacesTab.setDisable(false);
                        agendaTab.setDisable(false);
                        myGreenSpacesTab.setDisable(false);
                        break;
                    case HRM:
                        myTasksTab.setDisable(false);
                        break;
                    case VFM:
                        myTasksTab.setDisable(false);
                        break;
                }
            }catch(IllegalArgumentException exception) {
                new Alert(Alert.AlertType.INFORMATION, "Unknown role").show();
            }
        }
    }

    @FXML
    private void logout(ActionEvent event) {
        authenticationController.doLogout();

        myTasksTab.setDisable(true);
        toDoListTab.setDisable(true);
        greenSpacesTab.setDisable(true);
        agendaTab.setDisable(true);
        myGreenSpacesTab.setDisable(true);

        logoutButton.setVisible(false);
        inputPane.setVisible(true);
        loginButton.setVisible(true);
        myGreenSpacesTab.setDisable(true);
    }

    @FXML
    void exit(ActionEvent event) {
        Platform.exit();
    }
}