package pt.ipp.isep.dei.esoft.project.dto;


import java.util.Date;

public record VehicleDTO(double currentKm, Date acquisitionDate, double maintenance, PlateCertificationDTO plateCertification) {
    @Override
    public String toString() {
        return plateCertification.toString();
    }
}