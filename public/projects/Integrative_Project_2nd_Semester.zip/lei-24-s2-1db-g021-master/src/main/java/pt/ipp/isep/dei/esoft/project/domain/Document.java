package pt.ipp.isep.dei.esoft.project.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class Document implements Serializable {
    private String name;
    private Date bornDate;
    private int cardNumber;

    public Document(String name, Date bornDate, int cardNumber) {
        this.name = name;
        this.bornDate = bornDate;
        this.cardNumber = cardNumber;
    }

    public String getName() {
        return name;
    }

    public Date getBornDate() {
        return bornDate;
    }

    public int getCardNumber() {
        return cardNumber;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBornDate(Date bornDate) {
        this.bornDate = bornDate;
    }

    public void setCardNumber(int cardNumber) {
        if (cardNumber > 99999999 || cardNumber < 10000000) {
            throw new IllegalArgumentException("Card Number has 8 digits.");
        }
        this.cardNumber = cardNumber;
    }

    public Document clone() {
        return new Document(this.name, this.bornDate, this.cardNumber);
    }
}