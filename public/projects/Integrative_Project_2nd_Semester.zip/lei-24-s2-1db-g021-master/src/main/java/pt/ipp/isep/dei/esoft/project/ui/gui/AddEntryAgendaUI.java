package pt.ipp.isep.dei.esoft.project.ui.gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.util.StringConverter;
import pt.ipp.isep.dei.esoft.project.application.controller.*;
import pt.ipp.isep.dei.esoft.project.domain.EntryStatus;
import pt.ipp.isep.dei.esoft.project.dto.*;

import java.net.URL;
import java.util.*;

public class AddEntryAgendaUI implements Initializable {
    private AgendaUI parent;

    private final RegisterAgendaEntryController registerAgendaEntryController = new RegisterAgendaEntryController();
    private final ListTasksController listTasksController = new ListTasksController();
    private final ListTeamController listTeamController = new ListTeamController();
    private final ListVehicleController listVehicleController = new ListVehicleController();
    private final List<VehicleDTO> selectedVehicles = new ArrayList<>();

    @FXML
    private TextArea txtVehicle;
    @FXML
    private TextField txtTaskDuration;
    @FXML
    private ComboBox<TaskDTO> cbTask;
    @FXML
    private ComboBox<TeamDTO> cbTeam;
    @FXML
    private ComboBox<VehicleDTO> cbVehicle;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        List<TaskDTO> tasklist = listTasksController.listTasks();

        for(TaskDTO taskDTO : tasklist) {
            cbTask.getItems().add(taskDTO);
        }

        List<TeamDTO> teamlist = listTeamController.listTeams();

        for(TeamDTO teamDTO : teamlist) {
            cbTeam.getItems().add(teamDTO);
        }

        List<VehicleDTO> vehiclelist = listVehicleController.listVehicle();

        for(VehicleDTO vehicleDTO : vehiclelist) {
            cbVehicle.getItems().add(vehicleDTO);
        }
    }

    public void setParent(AgendaUI parent) {
        this.parent = parent;
    }

    @FXML
    private void addVehicles(ActionEvent event){
        if(cbVehicle.getValue() == null) {
            new Alert(Alert.AlertType.ERROR, "Invalid: Choose a vehicle").show();
            return;
        }

        VehicleDTO vehicle = cbVehicle.getValue();

        selectedVehicles.add(vehicle);

        txtVehicle.appendText(String.format(
                "%d - %s\n",
                selectedVehicles.size(),
                vehicle
        ));

        cbVehicle.getItems().remove(vehicle);
        cbVehicle.valueProperty().set(null);
    }

    @FXML
    private void registerEntry(ActionEvent event) {
        int taskDuration = 1;

        try {
            taskDuration = Integer.parseInt(txtTaskDuration.getText());
        }catch (NumberFormatException exception) {
            System.out.println("Invalid task duration");
        }

        if(cbTask.getValue() == null) {
            new Alert(Alert.AlertType.ERROR, "Invalid: Choose a task").show();
            return;
        }

        if(cbTeam.getValue() == null) {
            new Alert(Alert.AlertType.ERROR, "Invalid: Choose a team").show();
            return;
        }

        Optional<AgendaEntryDTO> result = registerAgendaEntryController.addAgendaEntry(new NewAgendaEntryDTO(taskDuration, new Date(), selectedVehicles, cbTeam.getValue(), cbTask.getValue()));

        if(result.isEmpty())
            return;

        parent.addAgendaEntryToList(result.get());

        new Alert(Alert.AlertType.INFORMATION, "Entry successfully added to agenda").show();
    }
}
