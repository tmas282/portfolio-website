package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.domain.*;
import pt.ipp.isep.dei.esoft.project.dto.*;
import pt.ipp.isep.dei.esoft.project.mapper.AgendaEntryMapper;
import pt.ipp.isep.dei.esoft.project.mapper.TaskMapper;
import pt.ipp.isep.dei.esoft.project.repository.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public class RegisterAgendaEntryController {
    private final TaskRepository taskRepository;
    private final TeamRepository teamRepository;
    private final VehicleRepository vehicleRepository;
    private final AgendaEntryRepository agendaEntryRepository;

    public RegisterAgendaEntryController() {
        taskRepository = Repositories.getInstance().getTaskRepository();
        teamRepository = Repositories.getInstance().getTeamRepository();
        vehicleRepository = Repositories.getInstance().getVehicleRepository();
        agendaEntryRepository = Repositories.getInstance().getAgendaEntryRepository();
    }

    /**
     * Allows injection of repositories to be used by the controller. Useful for testing.
     *
     * @param taskRepository to be used
     * @param teamRepository to be used
     * @param vehicleRepository to be used
     * @param agendaEntryRepository to be used
     */
    public RegisterAgendaEntryController(TaskRepository taskRepository, TeamRepository teamRepository, VehicleRepository vehicleRepository, AgendaEntryRepository agendaEntryRepository) {
        this.taskRepository = taskRepository;
        this.teamRepository = teamRepository;
        this.vehicleRepository = vehicleRepository;
        this.agendaEntryRepository = agendaEntryRepository;
    }

    public List<TaskDTO> listTasks() {
        return TaskMapper.toDTO(List.copyOf(taskRepository.getTasks()));
    }

    public Optional<AgendaEntryDTO> addAgendaEntry(NewAgendaEntryDTO newAgendaEntryDTO) {
        if(newAgendaEntryDTO == null)
            return Optional.empty();

        List<Vehicle> vehicleList = new ArrayList<>();

        for(VehicleDTO vehicleDTO : newAgendaEntryDTO.equipment()) {
            Optional<Vehicle> vehicle = vehicleRepository.getVehicleByPlate(vehicleDTO.plateCertification().plate());

            if(vehicle.isPresent())
                vehicleList.add(vehicle.get());
        }

        String teamName = newAgendaEntryDTO.team().name();

        Optional<Team> team = teamRepository.getTeamByName(teamName);

        if(team.isEmpty())
            return Optional.empty();

        String taskName = newAgendaEntryDTO.task().name();

        Optional<Task> task = taskRepository.getTaskByName(taskName);

        if(task.isEmpty())
            return Optional.empty();

        AgendaEntry newAgendaEntry;

        try {
            Team selectedTeam = team.get();
            newAgendaEntry = new AgendaEntry(newAgendaEntryDTO.expectedDuration(), newAgendaEntryDTO.startDate(), vehicleList, EntryStatus.PLANNED, task.get());
            AssignTeamToEntryController us23controller = new AssignTeamToEntryController();
            us23controller.assignTeamToEntry(selectedTeam, newAgendaEntry);
        }catch(IllegalArgumentException exception) {
            System.out.println("Invalid agenda entry");

            return Optional.empty();
        }

        Optional<AgendaEntry> result = agendaEntryRepository.add(newAgendaEntry);

        if(result.isEmpty())
            return Optional.empty();

        return Optional.of(AgendaEntryMapper.toDTO(result.get()));
    }
}
