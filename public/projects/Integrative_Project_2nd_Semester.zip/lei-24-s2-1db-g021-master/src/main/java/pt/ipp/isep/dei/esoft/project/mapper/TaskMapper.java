package pt.ipp.isep.dei.esoft.project.mapper;

import pt.ipp.isep.dei.esoft.project.domain.Task;
import pt.ipp.isep.dei.esoft.project.dto.TaskDTO;

import java.util.ArrayList;
import java.util.List;

public class TaskMapper {
    public static TaskDTO toDTO(Task task) {
        return new TaskDTO(
                task.getName(),
                task.getDescription(),
                task.getCategory(),
                task.getUrgency(),
                GreenSpaceMapper.toDTO(task.getGreenSpace())
        );
    }

    public static List<TaskDTO> toDTO(List<Task> taskList) {
        List<TaskDTO> newList = new ArrayList<>();

        for(Task task : taskList)
            newList.add(toDTO(task));

        return newList;
    }
}
