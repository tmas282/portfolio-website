package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.domain.AgendaEntry;
import pt.ipp.isep.dei.esoft.project.domain.EntryStatus;
import pt.ipp.isep.dei.esoft.project.dto.AgendaEntryDTO;
import pt.ipp.isep.dei.esoft.project.dto.CancelEntryDTO;
import pt.ipp.isep.dei.esoft.project.mapper.AgendaEntryMapper;
import pt.ipp.isep.dei.esoft.project.repository.AgendaEntryRepository;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public class CancelEntryAgendaController {
    private AgendaEntryRepository agendaEntryRepository;

    public CancelEntryAgendaController() {
        getAgendaEntryRepository();
    }

    /**
     * Allows injection of repositories to be used by the controller. Useful for testing.
     *
     * @param agendaEntryRepository to be used
     */
    public CancelEntryAgendaController(AgendaEntryRepository agendaEntryRepository) {
        this.agendaEntryRepository = agendaEntryRepository;
    }

    private AgendaEntryRepository getAgendaEntryRepository() {
        if (agendaEntryRepository == null) {
            Repositories repositories = Repositories.getInstance();
            agendaEntryRepository = repositories.getAgendaEntryRepository();
        }
        return agendaEntryRepository;
    }

    /**
     * Regists a new agenda entry with state "Canceled". Verifies the current collaborator based on the email from the Application Session.
     *
     * @param cancelEntryDTO
     * @return optional empty if cancelEntryDTO is null or if the entry is null, return an optional containing the new entry with status changed.
     */
    public Optional<AgendaEntryDTO> cancelEntryAgenda(CancelEntryDTO cancelEntryDTO) {
        if(cancelEntryDTO == null)
            return Optional.empty();

        Optional<AgendaEntry> agendaEntryOpt = agendaEntryRepository.findById(cancelEntryDTO.id());

        if (agendaEntryOpt.isEmpty())
            return Optional.empty();

        AgendaEntry agendaEntry = agendaEntryOpt.get();

        agendaEntry.setStatus(EntryStatus.CANCELED);

        return Optional.of(AgendaEntryMapper.toDTO(agendaEntry));
    }

    /**
     * Get the list of entrys in the agenda entrys repository
     *
     * @return agenda entrys list
     */
    public List<AgendaEntryDTO> getAgendaEntries() {
        return AgendaEntryMapper.toDTO(agendaEntryRepository.getAgendaEntryList());
    }
}