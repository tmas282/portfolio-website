package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.domain.Collaborator;
import pt.ipp.isep.dei.esoft.project.domain.GreenSpace;
import pt.ipp.isep.dei.esoft.project.repository.GreenSpaceRepository;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;

import java.util.List;

public class ListGreenSpacesManagedByMeGsmController {
    private GreenSpaceRepository greenSpaceRepository;

    /**
     * This constructor instantiates the controller.
     */
    public ListGreenSpacesManagedByMeGsmController() {
        greenSpaceRepository = Repositories.getInstance().getGreenSpaceRepository();
    }

    /**
     * This method gets the Green Spaces managed by the Green Spaces Manager
     * @param collaborator the Green Spaces Manager
     * @return the list of Green Spaces managed by collaborator
     */
    public List<GreenSpace> getGreenSpacesByGSM(Collaborator collaborator){
        return greenSpaceRepository.getGreenSpacesManagedByGSM(collaborator);
    }
}
