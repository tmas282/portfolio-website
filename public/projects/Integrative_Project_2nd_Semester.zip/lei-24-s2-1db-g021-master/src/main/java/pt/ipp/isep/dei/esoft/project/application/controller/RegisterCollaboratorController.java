package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.domain.Address;
import pt.ipp.isep.dei.esoft.project.domain.Collaborator;
import pt.ipp.isep.dei.esoft.project.domain.Document;
import pt.ipp.isep.dei.esoft.project.domain.Job;
import pt.ipp.isep.dei.esoft.project.repository.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public class RegisterCollaboratorController {
    private final CollaboratorRepository collaboratorRepository;
    private final AuthenticationRepository authenticationRepository;

    public RegisterCollaboratorController() {
        collaboratorRepository = Repositories.getInstance().getCollaboratorRepository();
        authenticationRepository = Repositories.getInstance().getAuthenticationRepository();
    }

    /**
     * Allows injection of repositories to be used by the controller. Useful for testing.
     *
     * @param collaboratorRepository to be used
     * @param authenticationRepository to be used
     */
    public RegisterCollaboratorController(CollaboratorRepository collaboratorRepository, AuthenticationRepository authenticationRepository) {
        this.collaboratorRepository = collaboratorRepository;
        this.authenticationRepository = authenticationRepository;
    }

    public List<Collaborator> getCollaborators(){
        return collaboratorRepository.getCollaboratorsList();
    }

    public Optional<Collaborator> createCollaborator(Document document, Date admDate, Address address, int phoneNumber, String email, int taxpayerNumber, Job job) {
        Optional<Collaborator> newCollaborator;
        try {
            Collaborator collaborator = new Collaborator(document, admDate, address, phoneNumber, email, taxpayerNumber, job);

            newCollaborator = collaboratorRepository.add(collaborator);
            authenticationRepository.addUserWithRole(collaborator.getDocument().getName(), collaborator.getEmail(), collaborator.getPassword(), collaborator.getRole());
        } catch (IllegalArgumentException e) {
            return Optional.empty();
        }
        return  newCollaborator;
    }
}