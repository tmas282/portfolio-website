package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.domain.Job;
import pt.ipp.isep.dei.esoft.project.repository.JobRepository;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;

import java.util.List;

public class ListJobsController {
    private final JobRepository jobRepository;

    public ListJobsController() {
        jobRepository = Repositories.getInstance().getJobRepository();
    }

    /**
     * Allows injection of repositories to be used by the controller. Useful for testing.
     *
     * @param jobRepository to be used
     */
    public ListJobsController(JobRepository jobRepository) {
        this.jobRepository = jobRepository;
    }

    public List<Job> listJobs() {
        return List.copyOf(jobRepository.getJobsList());
    }
}
