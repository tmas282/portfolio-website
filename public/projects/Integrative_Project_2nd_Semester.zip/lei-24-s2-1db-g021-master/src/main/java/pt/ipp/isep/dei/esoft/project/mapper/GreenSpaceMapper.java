package pt.ipp.isep.dei.esoft.project.mapper;

import pt.ipp.isep.dei.esoft.project.domain.GreenSpace;
import pt.ipp.isep.dei.esoft.project.dto.GreenSpaceDTO;

import java.util.ArrayList;
import java.util.List;

public class GreenSpaceMapper {
    public static GreenSpaceDTO toDTO(GreenSpace greenSpace) {
        return new GreenSpaceDTO(
                greenSpace.getName(),
                greenSpace.getSizeClassification(),
                greenSpace.getArea(),
                AddressMapper.toDTO(greenSpace.getAddress())
        );
    }

    public static List<GreenSpaceDTO> toDTO(List<GreenSpace> greenSpaceList) {
        List<GreenSpaceDTO> newList = new ArrayList<>();

        for(GreenSpace greenSpace : greenSpaceList) {
            newList.add(toDTO(greenSpace));
        }

        return List.copyOf(newList);
    }
}
