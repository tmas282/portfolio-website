package pt.ipp.isep.dei.esoft.project.ui.gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import pt.ipp.isep.dei.esoft.project.application.controller.ListGreenSpaceController;
import pt.ipp.isep.dei.esoft.project.application.controller.RegisterTaskController;
import pt.ipp.isep.dei.esoft.project.domain.TaskCategory;
import pt.ipp.isep.dei.esoft.project.domain.TaskUrgency;
import pt.ipp.isep.dei.esoft.project.dto.GreenSpaceDTO;
import pt.ipp.isep.dei.esoft.project.dto.NewTaskDTO;
import pt.ipp.isep.dei.esoft.project.dto.TaskDTO;

import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

public class RegisterTaskUI implements Initializable {
    private ToDoListUI parent;
    private final RegisterTaskController registerTaskController = new RegisterTaskController();
    private final ListGreenSpaceController listGreenSpaceController = new ListGreenSpaceController();

    @FXML
    private VBox mainPane;
    @FXML
    private TextField nameTextField;
    @FXML
    private TextArea descriptionTextArea;
    @FXML
    private ComboBox<TaskCategory> categoryComboBox;
    @FXML
    private ComboBox<TaskUrgency> urgencyComboBox;
    @FXML
    private ComboBox<String> greenSpaceComboBox;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        categoryComboBox.getItems().setAll(List.of(TaskCategory.values()));
        urgencyComboBox.getItems().setAll(List.of(TaskUrgency.values()));

        List<GreenSpaceDTO> greenSpaceList = listGreenSpaceController.getGreenSpaceList();

        for(GreenSpaceDTO greenSpace : greenSpaceList) {
            greenSpaceComboBox.getItems().add(greenSpace.name());
        }
    }

    public void setParent(ToDoListUI parent) {
        this.parent = parent;
    }

    @FXML
    private void registerTask(ActionEvent event) {
        String name = nameTextField.getText();
        String description = descriptionTextArea.getText();
        TaskCategory category = categoryComboBox.getValue();
        TaskUrgency urgency = urgencyComboBox.getValue();
        String greenSpace = greenSpaceComboBox.getValue();

        if(!verifyName(name))
            return;
        if(!verifyDescription(description))
            return;
        if(!verifyCategory(category))
            return;
        if(!verifyUrgency(urgency))
            return;
        if(!verifyGreenSpace(greenSpace))
            return;

        NewTaskDTO newTask = new NewTaskDTO(
                name,
                description,
                category,
                urgency,
                greenSpace
        );

        Optional<TaskDTO> result = registerTaskController.registerTask(newTask);

        if(result.isEmpty()) {
            new Alert(Alert.AlertType.ERROR, "Task unsuccessfully registered").show();

            return;
        }

        parent.addTaskToList(result.get());

        new Alert(Alert.AlertType.INFORMATION, "Task successfully registered").show();
    }

    private boolean verifyName(String name) {
        if(name.isBlank()) {
            new Alert(Alert.AlertType.ERROR, "Invalid: Blank name").show();

            return false;
        }

        Pattern validName = Pattern.compile("^[A-z0-9-_ ]+$");

        if(!validName.matcher(name).matches()) {
            new Alert(Alert.AlertType.ERROR, "Invalid: The valid characters for an name are A-Z, a-z, 0-9, '-', '_', ' '").show();

            return false;
        }

        return true;
    }

    private boolean verifyDescription(String description) {
        if(description.isBlank()) {
            new Alert(Alert.AlertType.ERROR, "Invalid: Blank description").show();

            return false;
        }

        return true;
    }

    private boolean verifyCategory(TaskCategory category) {
        if(category == null) {
            new Alert(Alert.AlertType.ERROR, "Invalid: Blank category").show();

            return false;
        }

        return true;
    }

    private boolean verifyUrgency(TaskUrgency urgency) {
        if(urgency == null) {
            new Alert(Alert.AlertType.ERROR, "Invalid: Blank urgency").show();
            return false;
        }

        return true;
    }

    private boolean verifyGreenSpace(String greenSpace) {
        if(greenSpace == null) {
            new Alert(Alert.AlertType.ERROR, "Invalid: Blank green space").show();

            return false;
        }

        return true;
    }
}
