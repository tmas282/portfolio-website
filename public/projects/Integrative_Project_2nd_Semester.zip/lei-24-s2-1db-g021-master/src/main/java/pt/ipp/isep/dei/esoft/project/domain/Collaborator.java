package pt.ipp.isep.dei.esoft.project.domain;

import pt.ipp.isep.dei.esoft.project.application.controller.authorization.AuthenticationController;
import pt.ipp.isep.dei.esoft.project.domain.Skill;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class Collaborator implements Serializable {
    private Document document;
    private Date admDate;
    private Address address;
    private int phoneNumber;
    private String email;
    private int taxpayerNumber;
    private List<Skill> skills;
    private Job job;
    private final CollaboratorRole role;
    private final String password;

    private static final Address DEFAULT_ADDRESS = new Address(1, new ZipCode(4444, 333));
    private static final CollaboratorRole DEFAULT_ROLE = CollaboratorRole.COLLABORATOR;
    private static final String DEFAULT_PASSWORD = "default_password";

    public Collaborator(Document document, Date admDate, Address address, int phoneNumber, String email, int taxpayerNumber, List<Skill> skills, Job job, CollaboratorRole role, String password) {
        if(skills == null)
            throw new IllegalArgumentException("Skills can't be null");

        this.document = document;
        this.admDate = admDate;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.taxpayerNumber = taxpayerNumber;
        this.skills = skills;
        this.job = job;
        this.role = role;
        this.password = password;
    }

    public Collaborator(Document document, Date admDate, Address address, int phoneNumber, String email, int taxpayerNumber, Job job) {
        this.document = document;
        this.admDate = admDate;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.taxpayerNumber = taxpayerNumber;
        this.skills = new ArrayList<>();
        this.job = job;
        this.role = DEFAULT_ROLE;
        this.password = DEFAULT_PASSWORD;
    }

    public Collaborator(Document document, String email, CollaboratorRole role, String password) {
        this.document = document;
        this.address = DEFAULT_ADDRESS;
        this.email = email;
        this.skills = new ArrayList<>();
        this.role = role;
        this.password = password;
    }

    public Collaborator(String email) {
        this.address = DEFAULT_ADDRESS;
        this.email = email;
        this.skills = new ArrayList<>();
        this.role = DEFAULT_ROLE;
        this.password = DEFAULT_PASSWORD;
    }

    public Document getDocument() {
        return document;
    }

    public Date getAdmDate() {
        return admDate;
    }

    public Address getAddress() {
        return address;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public int getTaxpayerNumber() {
        return taxpayerNumber;
    }

    public List<Skill> getSkills() {
        return skills;
    }

    public Job getJob() {
        return job;
    }

    public CollaboratorRole getRole() {
        return role;
    }

    public String getPassword() {
        return password;
    }

    @Override
    public boolean equals(Object object) {
        if(object == this)
            return true;

        if(object == null)
            return false;

        if(object.getClass() != this.getClass())
            return false;

        Collaborator collaborator = (Collaborator) object;

        if(!Objects.equals(collaborator.email, this.email))
            return false;

        return true;
    }

    public void addSkill(Skill skill) {
        if(!skills.contains(skill))
            skills.add(skill);
    }

    public void removeSkill(Skill skill) {
        skills.remove(skill);
    }
}