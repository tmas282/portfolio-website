package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.dto.GreenSpaceDTO;
import pt.ipp.isep.dei.esoft.project.mapper.GreenSpaceMapper;
import pt.ipp.isep.dei.esoft.project.repository.GreenSpaceRepository;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;

import java.util.List;

public class ListGreenSpaceController {
    private final GreenSpaceRepository greenSpaceRepository;

    public ListGreenSpaceController() {
        this.greenSpaceRepository = Repositories.getInstance().getGreenSpaceRepository();
    }
    /**
     * Allows injection of repositories to be used by the controller. Useful for testing.
     *
     * @param greenSpaceRepository to be used
     */
    public ListGreenSpaceController(GreenSpaceRepository greenSpaceRepository) {
        this.greenSpaceRepository = greenSpaceRepository;
    }

    public List<GreenSpaceDTO> getGreenSpaceList() {
        return GreenSpaceMapper.toDTO(greenSpaceRepository.getGreenSpacesList());
    }
}
