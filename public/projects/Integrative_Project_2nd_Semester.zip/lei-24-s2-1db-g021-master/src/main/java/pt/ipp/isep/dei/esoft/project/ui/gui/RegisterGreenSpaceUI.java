package pt.ipp.isep.dei.esoft.project.ui.gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import pt.ipp.isep.dei.esoft.project.application.controller.RegisterGreenSpaceController;
import pt.ipp.isep.dei.esoft.project.domain.Address;
import pt.ipp.isep.dei.esoft.project.domain.SizeClassification;
import pt.ipp.isep.dei.esoft.project.dto.GreenSpaceDTO;
import pt.ipp.isep.dei.esoft.project.dto.NewGreenSpaceDTO;

import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.regex.Pattern;


public class RegisterGreenSpaceUI implements Initializable {
    private GreenSpacesUI parent;
    private final RegisterGreenSpaceController ctrl = new RegisterGreenSpaceController();

    @FXML
    private Button addNewGreenSpace;
    @FXML
    private TextField nameText;
    @FXML
    private ComboBox<SizeClassification> sizeClassificationComboBox;
    @FXML
    private TextField areaText;
    @FXML
    private TextField addressText;
    @FXML
    private Label nameLabel;
    @FXML
    private Label classificationLabel;
    @FXML
    private Label areaLabel;
    @FXML
    private Label addressLabel;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        sizeClassificationComboBox.getItems().setAll(List.of(SizeClassification.values()));
    }

    public void setParent(GreenSpacesUI parent) {
        this.parent = parent;
    }
    
    @FXML
    void addNewGreenSpace(ActionEvent event) {
        String name = nameText.getText();
        SizeClassification sizeClassification = sizeClassificationComboBox.getValue();
        float area = 0;
        try {
            area = Float.parseFloat(areaText.getText());
        } catch (NumberFormatException e) {
            new Alert(Alert.AlertType.ERROR, "Invalid: Area must be a number.").show();
        }

        Address address = new Address(addressText.getText());
        
        if(!verifyName(name))
            return;
        if(!verifySizeClassification(sizeClassification))
            return;
        if(!verifyArea(area))
            return;
        if(!verifyAddress(address))
            return;

        NewGreenSpaceDTO newGreenSpace = new NewGreenSpaceDTO(
                name,
                sizeClassification,
                area,
                address
        );

        Optional<GreenSpaceDTO> result = ctrl.registerGreenSpace(newGreenSpace);

        if(result.isEmpty()) {
            new Alert(Alert.AlertType.ERROR, "GreenSpace unsuccessfully registered.").show();

            return;
        }

        parent.addGreenSpaceToList(result.get());

        new Alert(Alert.AlertType.INFORMATION, "GreenSpace successfully registered.").show();
    }

    private boolean verifyName(String name) {
        if(name.isBlank()) {
            new Alert(Alert.AlertType.ERROR, "Invalid: Blank name. Format: DoorNumber-ZipCode(4digits)-ZipCode(3digits)").show();
            return false;
        }

        Pattern validName = Pattern.compile("^[A-z0-9-_ ]+$");

        if(!validName.matcher(name).matches()) {
            new Alert(Alert.AlertType.ERROR, "Invalid: The valid characters for an name are A-Z, a-z, 0-9, '-', '_', ' '.").show();
            return false;
        }

        return true;
    }

    private boolean verifySizeClassification(SizeClassification sizeClassification) {
        if(sizeClassification == null) {
            new Alert(Alert.AlertType.ERROR, "Invalid: Blank size classification.").show();
            return false;
        }

        return true;
    }

    private boolean verifyArea(Float area) {
        if(area <= 0) {
            new Alert(Alert.AlertType.ERROR, "Invalid: Area must be greater than 0.").show();
            return false;
        }

        return true;
    }

    private boolean verifyAddress(Address address) {
        if(address == null) {
            new Alert(Alert.AlertType.ERROR, "Invalid: Blank address.").show();
            return false;
        }

        return true;
    }
}
