package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.domain.*;
import pt.ipp.isep.dei.esoft.project.dto.NewTaskDTO;
import pt.ipp.isep.dei.esoft.project.dto.TaskDTO;
import pt.ipp.isep.dei.esoft.project.mapper.TaskMapper;
import pt.ipp.isep.dei.esoft.project.repository.GreenSpaceRepository;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;
import pt.ipp.isep.dei.esoft.project.repository.TaskRepository;

import java.util.Optional;

public class RegisterTaskController {
    private final TaskRepository taskRepository;
    private final GreenSpaceRepository greenSpaceRepository;

    public RegisterTaskController() {
        taskRepository = Repositories.getInstance().getTaskRepository();
        greenSpaceRepository = Repositories.getInstance().getGreenSpaceRepository();
    }

    /**
     * Allows injection of repositories to be used by the controller. Useful for testing.
     *
     * @param taskRepository to be used
     * @param greenSpaceRepository to be used
     */
    public RegisterTaskController(TaskRepository taskRepository, GreenSpaceRepository greenSpaceRepository) {
        this.taskRepository = taskRepository;
        this.greenSpaceRepository = greenSpaceRepository;
    }

    public Optional<TaskDTO> registerTask(NewTaskDTO newTaskDTO) {
        if(newTaskDTO == null)
            return Optional.empty();

        Optional<GreenSpace> greenSpace = greenSpaceRepository.getGreenSpaceByName(newTaskDTO.greenSpaceName());

        if(greenSpace.isEmpty())
            return Optional.empty();

        Task newTask;

        try {
            newTask = new Task(
                    newTaskDTO.name(),
                    newTaskDTO.description(),
                    newTaskDTO.category(),
                    newTaskDTO.urgency(),
                    greenSpace.get()
            );
        }catch(IllegalArgumentException exception) {
            System.out.println("Invalid task");

            return Optional.empty();
        }

        Optional<Task> result = taskRepository.add(newTask);

        if(result.isEmpty())
            return Optional.empty();

        return Optional.of(TaskMapper.toDTO(result.get()));
    }
}
