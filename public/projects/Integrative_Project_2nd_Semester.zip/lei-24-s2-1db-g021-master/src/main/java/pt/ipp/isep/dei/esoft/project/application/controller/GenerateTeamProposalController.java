package pt.ipp.isep.dei.esoft.project.application.controller;

import pt.ipp.isep.dei.esoft.project.domain.Collaborator;
import pt.ipp.isep.dei.esoft.project.domain.Skill;
import pt.ipp.isep.dei.esoft.project.dto.SkillDTO;
import pt.ipp.isep.dei.esoft.project.repository.CollaboratorRepository;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;
import pt.ipp.isep.dei.esoft.project.repository.SkillRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class GenerateTeamProposalController {
    private final CollaboratorRepository collaboratorRepository;
    private final SkillRepository skillRepository;

    public GenerateTeamProposalController() {
        this.collaboratorRepository = Repositories.getInstance().getCollaboratorRepository();
        this.skillRepository = Repositories.getInstance().getSkillRepository();
    }

    /**
     * Allows injection of repositories to be used by the controller. Useful for testing.
     *
     * @param collaboratorRepository to be used
     * @param skillRepository to be used
     */
    public GenerateTeamProposalController(CollaboratorRepository collaboratorRepository, SkillRepository skillRepository) {
        this.collaboratorRepository = collaboratorRepository;
        this.skillRepository = skillRepository;
    }

    /**
     *
     * @return If successful it returns a list of collaborator as a representation
     * of the proposed team.
     * If the minTeamSize is not reached it returns an empty Optional.
     * If the maxTeamSize is reached the addition of new collaborators to the team is stopped.
     *
     * @param maxTeamSize Maximum team size
     * @param minTeamSize Minimum team size
     * @param skillRequirementsDTO Skills required to make the team
     */
    public List<Collaborator> generateTeamProposal(int minTeamSize, int maxTeamSize, List<SkillDTO> skillRequirementsDTO) {
        List<Skill> remainingSkills = new ArrayList<>();

        for(SkillDTO skillDTO : skillRequirementsDTO) {
            Optional<Skill> result = skillRepository.getSkillByName(skillDTO.name());

            if(result.isPresent())
                remainingSkills.add(result.get());
        }

        List<Collaborator> listCollaborators = collaboratorRepository.getCollaboratorsList();
        List<Collaborator> team = new ArrayList<>();

        for (int i = 0; i < listCollaborators.size() && team.size() < maxTeamSize; i++) {
            if(listCollaborators.get(i).getSkills() != null)
                for (Skill collaboratorSkill : listCollaborators.get(i).getSkills()) {
                    if (remainingSkills.contains(collaboratorSkill)) {
                        team.add(listCollaborators.get(i));
                        remainingSkills.remove(collaboratorSkill);
                    }
                }
        }

        if(team.size() < minTeamSize)
            return new ArrayList<>();

        return team;
    }
}
