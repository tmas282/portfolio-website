package pt.ipp.isep.dei.esoft.project.domain;

public enum TaskCategory {
    REGULAR("Regular"), OCCASIONAL("Occasional");

    private final String stringRepresentation;

    TaskCategory(String stringRepresentation) {
        this.stringRepresentation = stringRepresentation;
    }

    @Override
    public String toString() {
        return stringRepresentation;
    }
}
