package pt.ipp.isep.dei.esoft.project.ui.gui;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import pt.ipp.isep.dei.esoft.project.application.controller.ListGreenSpacesManagedByMeGsmController;
import pt.ipp.isep.dei.esoft.project.application.session.ApplicationSession;
import pt.ipp.isep.dei.esoft.project.application.session.UserSession;
import pt.ipp.isep.dei.esoft.project.domain.Collaborator;
import pt.ipp.isep.dei.esoft.project.domain.GreenSpace;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;

import java.net.URL;
import java.util.*;

public class ListGreenSpacesManagedByMeGsmUI implements Initializable{
    private ListGreenSpacesManagedByMeGsmController controller;
    @FXML
    private ListView<String> listView;
    @FXML
    private ComboBox<String> orderByBox;

    /**
     * This method instatiates it and sets the ComboBox values.
     * @param url JavaFx Parameter
     * @param resourceBundle JavaFx Parameter
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        this.controller = new ListGreenSpacesManagedByMeGsmController();
        orderByBox.getItems().add("By area (ascending)");
        orderByBox.getItems().add("By area (descending)");
        orderByBox.getItems().add("By A to Z");
        orderByBox.getItems().add("By Z to A");
    }
    @FXML
    private void clickShowMyGreenSpaces(){
        UserSession current = ApplicationSession.getInstance().getCurrentSession();
        String email = current.getUserEmail();
        Optional<Collaborator> collaborator = Repositories.getInstance().getCollaboratorRepository().getCollaboratorByEmail(email);
        List<GreenSpace> greenSpaces = controller.getGreenSpacesByGSM(collaborator.get());
        if (orderByBox.getValue() == null) {
            this.showListInListView(greenSpaces);
        } else if (orderByBox.getValue().equals("By area (ascending)")){
            List<GreenSpace> sorted = this.ascArea(greenSpaces);
            this.showListInListView(sorted);

        } else if (orderByBox.getValue().equals("By area (descending)")) {
            List<GreenSpace> sorted = this.descArea(greenSpaces);
            this.showListInListView(sorted);
        } else if (orderByBox.getValue().equals("By A to Z")) {
            List<GreenSpace> sorted = this.byAtoZ(greenSpaces);
            this.showListInListView(sorted);
        } else if (orderByBox.getValue().equals("By Z to A")) {
            List<GreenSpace> sorted = this.byZtoA(greenSpaces);
            this.showListInListView(sorted);
        }

    }
    private String greenSpaceToString(GreenSpace greenSpace){
        String str = greenSpace.getName() +
                " (" + greenSpace.getSizeClassification() + ";" +
                " Area: " + greenSpace.getArea() +
                "); Door Number: " + greenSpace.getAddress().getDoorNumber() +
                "; Zip code: "+greenSpace.getAddress().getZipCode().getLocal() +
                "-" + greenSpace.getAddress().getZipCode().getStreet();
        return str;
    }
    private void showListInListView(List<GreenSpace> greenSpaces){
        List<String> greenSpaceStrings = new ArrayList<>();
        for (GreenSpace greenSpace:
             greenSpaces) {
            greenSpaceStrings.add(greenSpaceToString(greenSpace));
        }
        listView.getItems().setAll(greenSpaceStrings);
    }
    private List<GreenSpace> ascArea(List<GreenSpace> greenSpaces){
        List<GreenSpace> sorted = new ArrayList<>(greenSpaces);
        sorted.sort((o1, o2) -> {
            Float o1F = o1.getArea();
            Float o2F = o2.getArea();
            return o1F.compareTo(o2F);
        });
        return sorted;
    }
    private List<GreenSpace> descArea(List<GreenSpace> greenSpaces){
        List<GreenSpace> sorted = new ArrayList<>(greenSpaces);
        sorted.sort((o1, o2) -> {
            Float o1F = o1.getArea();
            Float o2F = o2.getArea();
            return (-1) * o1F.compareTo(o2F);
        });
        return sorted;
    }
    private List<GreenSpace> byAtoZ(List<GreenSpace> greenSpaces){
        List<GreenSpace> sorted = new ArrayList<>(greenSpaces);
        sorted.sort((o1, o2) -> {
            return o1.getName().compareTo(o2.getName());
        });
        return sorted;
    }
    private List<GreenSpace> byZtoA(List<GreenSpace> greenSpaces){
        List<GreenSpace> sorted = new ArrayList<>(greenSpaces);
        sorted.sort((o1, o2) -> {
            return (-1) * o1.getName().compareTo(o2.getName());
        });
        return sorted;
    }
}
