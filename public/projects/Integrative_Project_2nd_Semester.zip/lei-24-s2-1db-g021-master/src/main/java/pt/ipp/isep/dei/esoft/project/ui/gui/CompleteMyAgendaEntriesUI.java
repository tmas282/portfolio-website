package pt.ipp.isep.dei.esoft.project.ui.gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.VBox;
import pt.ipp.isep.dei.esoft.project.application.controller.CompleteAgendaEntryController;
import pt.ipp.isep.dei.esoft.project.application.controller.ListMyUnfinishedAgendaEntriesController;
import pt.ipp.isep.dei.esoft.project.dto.AgendaEntryDTO;

import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

public class CompleteMyAgendaEntriesUI implements Initializable {
    private MyTasksUI parent;
    private final ListMyUnfinishedAgendaEntriesController listMyUnfinishedAgendaEntriesController = new ListMyUnfinishedAgendaEntriesController();
    private final CompleteAgendaEntryController completeAgendaEntryController = new CompleteAgendaEntryController();

    @FXML
    private VBox mainPane;
    @FXML
    private ComboBox<AgendaEntryDTO> taskComboBox;
    @FXML
    private Button completeTaskButton;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        List<AgendaEntryDTO> agendaEntryList = listMyUnfinishedAgendaEntriesController.listAgendaEntries();

        for(AgendaEntryDTO agendaEntry : agendaEntryList) {
            taskComboBox.getItems().add(agendaEntry);
        }
    }

    public void setParent(MyTasksUI parent) {
        this.parent = parent;
    }

    @FXML
    private void completeTask(ActionEvent event) {
        AgendaEntryDTO agendaEntry = taskComboBox.getValue();

        if(!verifyTask(agendaEntry))
            return;

        Optional<AgendaEntryDTO> result = completeAgendaEntryController.complete(agendaEntry.id());

        if(result.isEmpty()) {
            new Alert(Alert.AlertType.ERROR, "Task unsuccessfully completed").show();

            return;
        }

        taskComboBox.setValue(null);
        taskComboBox.getItems().remove(agendaEntry);
        parent.writeTaskList();

        new Alert(Alert.AlertType.INFORMATION, "Task successfully completed").show();
    }

    private boolean verifyTask(AgendaEntryDTO agendaEntry) {
        if(agendaEntry == null) {
            new Alert(Alert.AlertType.ERROR, "Invalid: Blank task").show();

            return false;
        }

        return true;
    }
}
