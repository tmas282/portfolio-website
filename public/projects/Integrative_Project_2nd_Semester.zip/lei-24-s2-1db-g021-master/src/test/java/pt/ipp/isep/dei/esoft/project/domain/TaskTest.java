package pt.ipp.isep.dei.esoft.project.domain;

import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.GregorianCalendar;

import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {
    private final Collaborator validCollaborator = new Collaborator("collaborator@a.a");
    private final GreenSpace validGreenSpace = new GreenSpace(
            "Green space",
            SizeClassification.GARDEN,
            10,
            new Address(
                    10,
                    new ZipCode(
                            1111,
                            111
                    )
            ),
            validCollaborator
    );

    @Test
    void ensureThrownOnNullName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "description", TaskCategory.REGULAR, TaskUrgency.LOW, validGreenSpace);
        });
    }

    @Test
    void ensureThrowsOnBlankName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(" ", "description", TaskCategory.REGULAR, TaskUrgency.LOW, validGreenSpace);
        });
    }

    @Test
    void ensureThrowsOnInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("@", "description", TaskCategory.REGULAR, TaskUrgency.LOW, validGreenSpace);
        });
    }

    @Test
    void ensureThrowsOnNullDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("name", null, TaskCategory.REGULAR, TaskUrgency.LOW, validGreenSpace);
        });
    }

    @Test
    void ensureThrowsOnBlankDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("name", " ", TaskCategory.REGULAR, TaskUrgency.LOW, validGreenSpace);
        });
    }

    @Test
    void ensureThrowsOnNullCategory() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("name", "description", null, TaskUrgency.LOW, validGreenSpace);
        });
    }

    @Test
    void ensureThrowsOnNullUrgency() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("name", "description", TaskCategory.REGULAR, null, validGreenSpace);
        });
    }

    @Test
    void ensureThrowsOnNullGreenSpace() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("name", "description", TaskCategory.REGULAR, TaskUrgency.LOW, null);
        });
    }
}
