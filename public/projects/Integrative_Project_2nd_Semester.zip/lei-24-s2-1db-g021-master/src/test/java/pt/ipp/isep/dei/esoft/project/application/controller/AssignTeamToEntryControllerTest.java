package pt.ipp.isep.dei.esoft.project.application.controller;

import org.junit.jupiter.api.Test;
import pt.ipp.isep.dei.esoft.project.domain.*;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class AssignTeamToEntryControllerTest {
    @Test
    void ensureAssignTeamToEntryWorks(){
        Collaborator c1 = new Collaborator("temp@temp.a");
        Collaborator c2 = new Collaborator("tempo@tempo.com");
        List<Collaborator> collaboratorList = new ArrayList<>();
        collaboratorList.add(c1);
        collaboratorList.add(c2);
        List<Skill> skills = new ArrayList<>();
        skills.add(new Skill("carta A"));
        Team t1 = new Team("Equipa 1",1, 8, collaboratorList, skills);
        Repositories.getInstance().getTeamRepository().add(t1);
        List<Vehicle> vehicles = new ArrayList<>();
        vehicles.add(new Vehicle(0, new Date(), 10000, new PlateCertification("Ford", "Transit","Vehicle",1000,1200, new Date(), "12-AB-34")));
        AgendaEntry ag1 = new AgendaEntry(100, new Date(), vehicles, EntryStatus.PLANNED, new Task("T1", "task", TaskCategory.REGULAR, TaskUrgency.MEDIUM, new GreenSpace("G1",SizeClassification.LARGE_SIZED_PARK,1000, new Address("71-4000-033"), c1)));
        Repositories.getInstance().getAgendaEntryRepository().add(ag1);

        AssignTeamToEntryController controller = new AssignTeamToEntryController();
        List<Team> actualTeams = controller.getTeams();
        List<Team> expectedTeams = new ArrayList<>();
        expectedTeams.add(t1);
        List<AgendaEntry> actualEntries = controller.getActiveEntries();
        List<AgendaEntry> expectedEntries = new ArrayList<>();
        expectedEntries.add(ag1);

        controller.assignTeamToEntry(t1, ag1);

        assertEquals(expectedEntries, actualEntries);
        assertEquals(expectedTeams, actualTeams);
        assertEquals(t1, ag1.getTeam());
    }
}