package pt.ipp.isep.dei.esoft.project.repository;

import org.junit.jupiter.api.Test;
import pt.ipp.isep.dei.esoft.project.domain.Skill;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class SkillRepositoryTest {

    @Test
    void ensureNewSkillSuccessfullyAdded() {
        // Arrange
        SkillRepository skillRepository = new SkillRepository();
        Skill skill = new Skill("Tree Pruner");

        // Act
        Optional<Skill> addedSkill = skillRepository.add(skill);

        // Assert
        assertTrue(addedSkill.isPresent());
        assertEquals(skill, addedSkill.get());
    }

    @Test
    void ensureAddingDuplicateSkillFails() {
        // Arrange
        SkillRepository skillRepository = new SkillRepository();
        Skill skill = new Skill("Tree Pruner");

        // Act
        Optional<Skill> addedFirstSkill = skillRepository.add(skill);
        Optional<Skill> addedSecondSkill = skillRepository.add(skill);

        // Assert
        assertTrue(addedFirstSkill.isPresent());
        assertTrue(addedSecondSkill.isEmpty());
    }

    @Test
    void ensureSkillsListIsNotNull() {
        // Arrange
        SkillRepository skillRepository = new SkillRepository();

        // Act
        List<Skill> skillsList = skillRepository.getSkillsList();

        // Assert
        assertTrue(skillsList.isEmpty());

    }

    @Test
    void ensureGetSkillsReturnsAnImmutableList() {
        // Arrange
        SkillRepository skillRepository = new SkillRepository();
        Skill skill = new Skill("Tree Pruner");
        // Act
        skillRepository.add(skill);
        List<Skill> skillsList = skillRepository.getSkillsList();
        // Assert
        assertThrows(UnsupportedOperationException.class,
                () -> skillsList.add(new Skill("Light Vehicle Driving Licence")));
    }

    @Test
    void ensureRemovingSkillFromListWorks() {
        // Arrange
        SkillRepository skillRepository = new SkillRepository();
        Skill skill1 = new Skill("Tree Pruner");

        // Act
        skillRepository.add(skill1);
        boolean removed = skillRepository.remove(skill1);

        // Assert
        assertTrue(removed);
        assertFalse(skillRepository.getSkillsList().contains(skill1));
    }

}