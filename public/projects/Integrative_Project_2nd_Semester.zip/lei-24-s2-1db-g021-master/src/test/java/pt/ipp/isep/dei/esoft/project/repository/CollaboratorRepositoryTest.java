package pt.ipp.isep.dei.esoft.project.repository;

import org.junit.jupiter.api.Test;
import pt.ipp.isep.dei.esoft.project.domain.*;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class CollaboratorRepositoryTest {
    private final Job validJob = new Job("job");

    @Test
    void ensureNewCollaboratorSuccessfullyAdded() {
        // Arrange
        CollaboratorRepository collaboratorRepository = new CollaboratorRepository();

        Collaborator collaborator = new Collaborator(
                new Document(
                        "John Doe",
                        new Date(2000, Calendar.JUNE, 1),
                        12341234
                ),
                new Date(2020, Calendar.FEBRUARY, 1),
                new Address(1, new ZipCode(1234, 1)),
                123456789,
                "john.doe@example.com",
                123412345,
                validJob
        );


        // Act
        Optional<Collaborator> addedCollaborator = collaboratorRepository.add(collaborator);

        // Assert
        assertTrue(addedCollaborator.isPresent());
        assertEquals(collaborator, addedCollaborator.get());
        assertEquals(1, collaboratorRepository.getCollaboratorsList().size());
    }

    @Test
    void ensureAddDuplicateCollaboratorFails() {
        // Arrange
        CollaboratorRepository collaboratorRepository = new CollaboratorRepository();

        Collaborator collaborator = new Collaborator(
                new Document(
                        "John Doe",
                        new Date(2000, Calendar.JUNE, 1),
                        12341234
                ),
                new Date(2020, Calendar.FEBRUARY, 1),
                new Address(1, new ZipCode(1234, 1)),
                123456789,
                "john.doe@example.com",
                123412345,
                validJob
        );

        // Act
        collaboratorRepository.add(collaborator);
        Optional<Collaborator> addedCollaborator = collaboratorRepository.add(collaborator);

        // Assert
        assertFalse(addedCollaborator.isPresent());
        assertEquals(1, collaboratorRepository.getCollaboratorsList().size());
    }

    @Test
    void ensureCollaboratorsListIsNotNull() {
        // Arrange
        CollaboratorRepository collaboratorRepository = new CollaboratorRepository();

        // Act
        List<Collaborator> collaboratorsList = collaboratorRepository.getCollaboratorsList();

        // Assert
        assertTrue(collaboratorsList.isEmpty());
    }

}