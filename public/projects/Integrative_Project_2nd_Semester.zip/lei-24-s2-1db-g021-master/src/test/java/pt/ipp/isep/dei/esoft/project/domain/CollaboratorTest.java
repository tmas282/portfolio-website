package pt.ipp.isep.dei.esoft.project.domain;

import org.junit.jupiter.api.Test;

import javax.print.Doc;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CollaboratorTest {
    private final Job validJob = new Job("job");

    @Test
    void ensureTwoCollaboratorsWithSameEmailEquals() {
        Collaborator Collaborator1 = new Collaborator("john.doe@this.company.com");
        Collaborator Collaborator2 = new Collaborator("john.doe@this.company.com");
        assertEquals(Collaborator1, Collaborator2);
    }

    @Test
    void ensureCollaboratorWithDifferentEmailNotEquals() {
        Collaborator Collaborator1 = new Collaborator("john.doe@this.company.com");
        Collaborator Collaborator2 = new Collaborator("jane.doe@this.company.com");
        assertNotEquals(Collaborator1, Collaborator2);
    }

    @Test
    void ensureCollaboratorDoesNotEqualNull() {
        Collaborator Collaborator1 = new Collaborator("john.doe@this.company.com");
        assertNotEquals(Collaborator1, null);
    }

    @Test
    void ensureCollaboratorDoesNotEqualOtherObject() {
        Collaborator Collaborator1 = new Collaborator("john.doe@this.company.com");
        assertNotEquals(Collaborator1, new Object());
    }

    @Test
    void ensureTheSameObjectIsEqual() {
        Collaborator Collaborator1 = new Collaborator("john.doe@this.company.com");
        assertEquals(Collaborator1, Collaborator1);
    }


    @Test
    void ensureRemoveSkillRemovesSkillFromCollaborator() {
        // Arrange
        Skill skill1 = new Skill("Tree Pruner");
        Skill skill2 = new Skill("Light Vehicle Driving Licence");
        Skill skill3 = new Skill("Heavy Vehicle Driving Licence");

        Date date1 = new Date(2000, Calendar.JUNE, 1);
        Date date2 = new Date(2020, Calendar.FEBRUARY, 1);
        Address address1 = new Address(1, new ZipCode(1234,1));
        Document document1 = new Document("John Doe", date1, 80808080);

        Collaborator collaborator = new Collaborator(document1, date2, address1, 123456789,
                "john.doe@example.com", 123456789,
                validJob);

        collaborator.addSkill(skill1);
        collaborator.addSkill(skill2);
        collaborator.addSkill(skill3);

        // Act
        collaborator.removeSkill(skill2);

        // Assert
        List<Skill> skills = collaborator.getSkills();
        assertEquals(2, skills.size());
        assertTrue(skills.contains(skill1));
        assertTrue(skills.contains(skill3));
    }

}