package pt.ipp.isep.dei.esoft.project.domain;

import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.GregorianCalendar;

import static org.junit.jupiter.api.Assertions.*;

class GreenSpaceTest {
    @Test
    void ensureIsManagedByGSMWorks(){
        Address address = new Address("725-4500-034");
        Document d1 = new Document("Tomás Moreira", new GregorianCalendar(2005, Calendar.FEBRUARY,29 ).getTime(),1231087);
        Collaborator c1 = new Collaborator("temp@temp.a");
        GreenSpace g1 = new GreenSpace("Parque da cidade", SizeClassification.LARGE_SIZED_PARK,10,address, c1);

        boolean expected = true;
        boolean actual = g1.isManagedByGSM(c1);

        assertEquals(expected, actual);
    }

    @Test
    void ensureIsManagedByNullDontWork(){
        Address address = new Address("725-4500-034");
        Document d1 = new Document("Tomás Moreira", new GregorianCalendar(2005, Calendar.FEBRUARY,29 ).getTime(),1231087);
        Collaborator c1 = new Collaborator("temp@temp.a");
        GreenSpace g1 = new GreenSpace("Parque da cidade", SizeClassification.LARGE_SIZED_PARK,10,address, c1);

        boolean expected = false;
        boolean actual = g1.isManagedByGSM(null);

        assertEquals(expected, actual);
    }
}