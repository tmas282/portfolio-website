package pt.ipp.isep.dei.esoft.project.application.controller;

import org.junit.jupiter.api.Test;
import pt.ipp.isep.dei.esoft.project.domain.*;
import pt.ipp.isep.dei.esoft.project.repository.Repositories;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ListGreenSpacesManagedByMeGsmControllerTest {

    @Test
    void ensureGetGreenSpacesByGSMWork() {
        Address address = new Address("725-4500-034");
        Document d1 = new Document("Tomás Moreira", new GregorianCalendar(2005, Calendar.FEBRUARY,29 ).getTime(),1231087);
        Collaborator c1 = new Collaborator("temp@temp.a");
        GreenSpace g1 = new GreenSpace("Parque da cidade", SizeClassification.LARGE_SIZED_PARK,10,address, c1);
        Repositories.getInstance().getGreenSpaceRepository().add(g1);
        ListGreenSpacesManagedByMeGsmController controller = new ListGreenSpacesManagedByMeGsmController();

        List<GreenSpace> result = controller.getGreenSpacesByGSM(c1);

        List<GreenSpace> expected = new ArrayList<>();
        expected.add(g1);
        assertEquals(result, expected);
    }
}