package pt.ipp.isep.dei.esoft.project.application.controller;

import org.junit.jupiter.api.Test;
import pt.ipp.isep.dei.esoft.project.domain.Collaborator;
import pt.ipp.isep.dei.esoft.project.domain.Skill;
import pt.ipp.isep.dei.esoft.project.dto.SkillDTO;
import pt.ipp.isep.dei.esoft.project.mapper.SkillMapper;
import pt.ipp.isep.dei.esoft.project.repository.CollaboratorRepository;
import pt.ipp.isep.dei.esoft.project.repository.SkillRepository;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

public class GenerateTeamProposalControllerTest {
    @Test
    void generateTeamProposal() {
        CollaboratorRepository collaboratorRepository = new CollaboratorRepository();
        SkillRepository skillRepository = new SkillRepository();
        GenerateTeamProposalController generateTeamProposalController = new GenerateTeamProposalController(collaboratorRepository, skillRepository);
        Collaborator collaborator1 = new Collaborator("collaborator1@a.a");
        Collaborator collaborator2 = new Collaborator("collaborator2@a.a");
        Collaborator collaborator3 = new Collaborator("collaborator3@a.a");
        Collaborator collaborator4 = new Collaborator("collaborator4@a.a");
        Collaborator collaborator5 = new Collaborator("collaborator5@a.a");
        Skill skill1 = new Skill("andar");
        Skill skill2 = new Skill("voar");
        Skill skill3 = new Skill("comer");
        collaborator1.addSkill(skill1);
        collaborator2.addSkill(skill1);
        collaborator3.addSkill(skill1);
        collaborator4.addSkill(skill1);
        collaborator3.addSkill(skill2);
        collaborator5.addSkill(skill3);
        collaboratorRepository.add(collaborator1);
        collaboratorRepository.add(collaborator2);
        collaboratorRepository.add(collaborator3);
        collaboratorRepository.add(collaborator4);
        collaboratorRepository.add(collaborator5);
        skillRepository.add(skill1);
        skillRepository.add(skill2);
        skillRepository.add(skill3);
        int maxTeam = 3;
        int minTeam = 2;
        List<Skill> skillRequirements = new ArrayList<>(Arrays.asList(skill1, skill2));

        List<Collaborator> result = generateTeamProposalController.generateTeamProposal(maxTeam, minTeam, SkillMapper.toDTO(skillRequirements));

        assertFalse(result.isEmpty());
    }

    @Test
    void generateTeamProposalFailsWithoutEnoughMembers() {
        CollaboratorRepository collaboratorRepository = new CollaboratorRepository();
        SkillRepository skillRepository = new SkillRepository();
        GenerateTeamProposalController generateTeamProposalController = new GenerateTeamProposalController(collaboratorRepository, skillRepository);
        Collaborator collaborator1 = new Collaborator("collaborator1@a.a");
        Collaborator collaborator2 = new Collaborator("collaborator2@a.a");
        Collaborator collaborator3 = new Collaborator("collaborator3@a.a");
        Collaborator collaborator4 = new Collaborator("collaborator4@a.a");
        Collaborator collaborator5 = new Collaborator("collaborator5@a.a");
        Skill skill1 = new Skill("andar");
        Skill skill2 = new Skill("voar");
        Skill skill3 = new Skill("comer");
        collaborator1.addSkill(skill1);
        collaborator5.addSkill(skill3);
        collaboratorRepository.add(collaborator1);
        collaboratorRepository.add(collaborator2);
        collaboratorRepository.add(collaborator3);
        collaboratorRepository.add(collaborator4);
        collaboratorRepository.add(collaborator5);
        skillRepository.add(skill1);
        skillRepository.add(skill2);
        skillRepository.add(skill3);
        int maxTeam = 3;
        int minTeam = 2;
        List<Skill> skillRequirements = new ArrayList<>(Arrays.asList(skill1, skill2));

        List<Collaborator> result = generateTeamProposalController.generateTeamProposal(maxTeam, minTeam, SkillMapper.toDTO(skillRequirements));

        assertTrue(result.isEmpty());
    }
}
