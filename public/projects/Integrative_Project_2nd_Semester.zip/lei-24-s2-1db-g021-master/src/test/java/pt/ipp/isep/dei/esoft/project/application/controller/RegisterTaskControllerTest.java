package pt.ipp.isep.dei.esoft.project.application.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import pt.ipp.isep.dei.esoft.project.domain.*;
import pt.ipp.isep.dei.esoft.project.dto.NewTaskDTO;
import pt.ipp.isep.dei.esoft.project.dto.TaskDTO;
import pt.ipp.isep.dei.esoft.project.repository.GreenSpaceRepository;
import pt.ipp.isep.dei.esoft.project.repository.TaskRepository;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

public class RegisterTaskControllerTest {
    private TaskRepository taskRepository;
    private GreenSpaceRepository greenSpaceRepository;
    private RegisterTaskController registerTaskController;

    private final Collaborator validCollaborator = new Collaborator("collaborator@a.a");
    private final GreenSpace validGreenSpace = new GreenSpace(
            "greenspace",
            SizeClassification.GARDEN,
            10,
            new Address(
                    10,
                    new ZipCode(1111, 111)
            ),
            validCollaborator
    );

    @BeforeEach
    void beforeEachSetUp() {
        taskRepository = new TaskRepository();
        greenSpaceRepository = new GreenSpaceRepository();
        registerTaskController = new RegisterTaskController(taskRepository, greenSpaceRepository);
    }

    @Test
    void ensureEmptyOnEmptyNewTask() {
        Optional<TaskDTO> result = registerTaskController.registerTask(null);

        assertTrue(result.isEmpty());
    }

    @Test
    void ensureEmptyOnNonExistentGreenSpace() {
        NewTaskDTO newTaskDTO = new NewTaskDTO(
                "Name",
                "Description",
                TaskCategory.REGULAR,
                TaskUrgency.LOW,
                "none"
        );

        Optional<TaskDTO> result = registerTaskController.registerTask(newTaskDTO);

        assertTrue(result.isEmpty());
    }

    @Test
    void ensureEmptyOnNullGreenSpace() {
        NewTaskDTO newTaskDTO = new NewTaskDTO(
                "Name",
                "Description",
                TaskCategory.REGULAR,
                TaskUrgency.LOW,
                null
        );

        Optional<TaskDTO> result = registerTaskController.registerTask(newTaskDTO);

        assertTrue(result.isEmpty());
    }

    @Test
    void ensureRegistrationOfValidTask() {
        Optional<GreenSpace> result1 = greenSpaceRepository.add(validGreenSpace);

        assertTrue(result1.isPresent());

        NewTaskDTO newTaskDTO = new NewTaskDTO(
                "Name",
                "Description",
                TaskCategory.REGULAR,
                TaskUrgency.LOW,
                validGreenSpace.getName()
        );

        Optional<TaskDTO> result2 = registerTaskController.registerTask(newTaskDTO);

        assertTrue(result2.isPresent());

        boolean exists = false;

        for(Task task : taskRepository.getTasks())
            if(task.getName().equals(result2.get().name()))
                exists = true;

        assertTrue(exists);
    }
}
