package pt.ipp.isep.dei.esoft.project.domain;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class AgendaEntryTest {
    private final Collaborator validCollaborator = new Collaborator("collaborator@a.a");
    private final GreenSpace validGreenSpace = new GreenSpace(
            "greenspace",
            SizeClassification.GARDEN,
            10,
            new Address(10, new ZipCode(1111, 111)),
            validCollaborator
    );

    @Test
    void ensureCreationWithNullTaskAndStatusDontWork() {
        assertThrows(IllegalArgumentException.class, () ->
                new AgendaEntry(0, null, null, null, null)
        );
    }
    @Test
    void ensureCreationWithNegativeDurationDontWork() {
        Task t = new Task("none", "none", TaskCategory.REGULAR, TaskUrgency.MEDIUM, validGreenSpace);
        assertThrows(IllegalArgumentException.class, () ->
                new AgendaEntry(-1000, new Date(), new ArrayList<>(), EntryStatus.PLANNED, t)
        );
    }

    @Test
    void ensureCreationWithNoDurationDontWork() {
        Task t = new Task("none", "none", TaskCategory.REGULAR, TaskUrgency.MEDIUM, validGreenSpace);
        assertThrows(IllegalArgumentException.class, () ->
                new AgendaEntry(0, new Date(), new ArrayList<>(), EntryStatus.PLANNED, t)
        );
    }
}