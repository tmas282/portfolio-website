package pt.ipp.isep.dei.esoft.project.domain;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.GregorianCalendar;

import static org.junit.jupiter.api.Assertions.*;

class VehicleCheckUpTest {
    @Test()
    public void checkIfNotPossibleToCreateCheckUpWithNull(){
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->{
            new VehicleCheckUp(null, null, 0, null);
        });
    }
}