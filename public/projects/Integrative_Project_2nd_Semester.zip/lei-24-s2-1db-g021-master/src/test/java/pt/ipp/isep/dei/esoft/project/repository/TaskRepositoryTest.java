package pt.ipp.isep.dei.esoft.project.repository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import pt.ipp.isep.dei.esoft.project.domain.*;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

public class TaskRepositoryTest {
    private TaskRepository taskRepository;

    private final Collaborator validCollaborator = new Collaborator("collaborator@a.a");
    private final Task validTask = new Task(
            "name",
            "description",
            TaskCategory.REGULAR,
            TaskUrgency.LOW,
            new GreenSpace(
                    "greenspace",
                    SizeClassification.GARDEN,
                    10,
                    new Address(
                            10,
                            new ZipCode(1111, 111)
                    ),
                    validCollaborator
            )
    );

    @BeforeEach
    void beforeEachSetUp() {
        taskRepository = new TaskRepository();
    }

    @Test
    void ensureAdditionOfValidTask() {
        Optional<Task> result1 = taskRepository.add(validTask);
        assertTrue(result1.isPresent());

        List<Task> result2 = taskRepository.getTasks();
        assertTrue(result2.contains(result1.get()));
    }

    @Test
    void ensureEmptyOnDuplicatedTask() {
        taskRepository.add(validTask);
        Optional<Task> result = taskRepository.add(validTask);

        assertTrue(result.isEmpty());
    }
}
