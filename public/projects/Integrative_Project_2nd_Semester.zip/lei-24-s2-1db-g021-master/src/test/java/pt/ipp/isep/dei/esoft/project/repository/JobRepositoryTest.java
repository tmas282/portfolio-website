package pt.ipp.isep.dei.esoft.project.repository;

import org.junit.jupiter.api.Test;
import pt.ipp.isep.dei.esoft.project.domain.Job;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertFalse;

public class JobRepositoryTest {
    @Test
    void ensureNewJobSuccessfullyAdded() {
        // Arrange
        JobRepository jobRepository = new JobRepository();
        Job job = new Job("Budget Manager");

        // Act
        Optional<Job> addedJob = jobRepository.add(job);

        // Assert
        assertTrue(addedJob.isPresent());
        assertEquals(job, addedJob.get());
    }

    @Test
    void ensureAddingDuplicateJobFails() {
        // Arrange
        JobRepository jobRepository = new JobRepository();
        Job job = new Job("Budget Manager");

        // Act
        Optional<Job> addedFirstJob = jobRepository.add(job);
        Optional<Job> addedSecondJob = jobRepository.add(job);

        // Assert
        assertTrue(addedFirstJob.isPresent());
        assertTrue(addedSecondJob.isEmpty());
    }

    @Test
    void ensureJobsListIsNotNull() {
        // Arrange
        JobRepository jobRepository = new JobRepository();

        // Act
        List<Job> jobsList = jobRepository.getJobsList();

        // Assert
        assertTrue(jobsList.isEmpty());
    }

    @Test
    void ensureGetJobsReturnsAnImmutableList() {
        // Arrange
        JobRepository jobRepository = new JobRepository();
        Job job = new Job("Gardener");

        // Act
        jobRepository.add(job);
        List<Job> jobsList = jobRepository.getJobsList();

        // Assert
        assertThrows(UnsupportedOperationException.class,
                () -> jobsList.add(new Job("Bricklayer")));
    }

    @Test
    void ensureRemovingJobFromListWorks() {
        // Arrange
        JobRepository jobRepository = new JobRepository();
        Job job = new Job("Gardener");

        // Act
        jobRepository.add(job);
        boolean removed = jobRepository.remove(job);

        // Assert
        assertTrue(removed);
        assertFalse(jobRepository.getJobsList().contains(job));
    }
}