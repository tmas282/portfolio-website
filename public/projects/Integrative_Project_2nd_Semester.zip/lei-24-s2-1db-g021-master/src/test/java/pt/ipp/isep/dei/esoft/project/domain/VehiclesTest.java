package pt.ipp.isep.dei.esoft.project.domain;

import org.junit.jupiter.api.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class VehiclesTest {
    @Test
    public void testConstruction() throws ParseException {
        //Arrange
        String ExampleDate = "2005-01-02";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date dateTest = sdf.parse(ExampleDate);

        String ExampleDate2 = "2006-01-02";
        Date dateTest2 = sdf.parse(ExampleDate2);

        PlateCertification plateCertification = new PlateCertification("Renault","Clio","Electric",900,1200,dateTest2,"72-XQ-70");
        Vehicle vehicle = new Vehicle(10000, dateTest, 2000, plateCertification);

        //Act and assert
        assertEquals(10000, vehicle.getCurrentKm(), 0);
        assertNotNull(vehicle.getAcquisitionDate());
        assertEquals(2000, vehicle.getMaintenance(), 0);
        assertEquals(plateCertification, vehicle.getPlateCertification());
    }

    @Test
    public void testSetCurrentKm_NegativeValue() throws ParseException {
        //Arrange
        String ExampleDate = "2005-01-02";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date dateTest = sdf.parse(ExampleDate);

        String ExampleDate2 = "2006-01-02";
        Date dateTest2 = sdf.parse(ExampleDate2);

        PlateCertification plateCertification = new PlateCertification("Renault","Clio","Electric",900,1200,dateTest2,"72-XQ-70");
        Vehicle vehicle = new Vehicle(10000, dateTest, 2000, plateCertification);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            vehicle.setCurrentKm(-100);
        });
        assertEquals("There cannot be negative values for Km.", exception.getMessage());
    }

    @Test
    public void testSetMaintenance_NegativeValue() throws ParseException {
        //Arrange
        String ExampleDate = "2005-01-02";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date dateTest = sdf.parse(ExampleDate);

        String ExampleDate2 = "2006-01-02";
        Date dateTest2 = sdf.parse(ExampleDate2);

        PlateCertification plateCertification = new PlateCertification("Renault","Clio","Electric",900,1200,dateTest2,"72-XQ-70");
        Vehicle vehicle = new Vehicle(10000, dateTest, 2000, plateCertification);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            vehicle.setMaintenance(-200);
        });
        assertEquals("There cannot be negative values or 0 for maintenance (in kms).", exception.getMessage());
    }

    @Test
    public void testSetMaintenance_ZeroValue() throws ParseException {
        //Arrange
        String ExampleDate = "2005-01-02";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date dateTest = sdf.parse(ExampleDate);

        String ExampleDate2 = "2006-01-02";
        Date dateTest2 = sdf.parse(ExampleDate2);

        PlateCertification plateCertification = new PlateCertification("Renault","Clio","Electric",900,1200,dateTest2,"72-XQ-70");
        Vehicle vehicle = new Vehicle(10000,dateTest, 2000, plateCertification);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            vehicle.setMaintenance(0);
        });
        assertEquals("There cannot be negative values or 0 for maintenance (in kms).", exception.getMessage());
    }
}