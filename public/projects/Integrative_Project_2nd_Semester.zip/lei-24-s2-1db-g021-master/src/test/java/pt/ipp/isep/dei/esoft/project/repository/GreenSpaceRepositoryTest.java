package pt.ipp.isep.dei.esoft.project.repository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import pt.ipp.isep.dei.esoft.project.domain.*;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

public class GreenSpaceRepositoryTest {
    private GreenSpaceRepository greenSpaceRepository;

    private final Collaborator validCollaborator = new Collaborator(
            new Document(
                    "John Doe",
                    new Date(2000, Calendar.JUNE, 1),
                    12341234
            ),
            new Date(2020, Calendar.FEBRUARY, 1),
            new Address(1, new ZipCode(1234, 1)),
            123456789,
            "john.doe@example.com",
            123412345,
            new Job("job")
    );
    private final GreenSpace validGreenSpace = new GreenSpace(
            "greenspace",
            SizeClassification.GARDEN,
            10,
            new Address(
                    10,
                    new ZipCode(1111, 111)
            ),
            validCollaborator
    );

    @BeforeEach
    public void beforeEachSetUp() {
        greenSpaceRepository = new GreenSpaceRepository();
    }

    @Test
    public void ensureValidGreenSpaceAddition() {
        Optional<GreenSpace> result1 = greenSpaceRepository.add(validGreenSpace);
        assertTrue(result1.isPresent());

        List<GreenSpace> result2 = greenSpaceRepository.getGreenSpacesList();
        assertTrue(result2.contains(result1.get()));
    }
}
