package pt.ipp.isep.dei.esoft.project.repository;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RepositoriesTest {

    @Test
    void testGetInstance() {
        Repositories instance = Repositories.getInstance();
        assertNotNull(instance);
    }

    @Test
    void testSkillRepository() {
        Repositories instance = Repositories.getInstance();
        assertNotNull(instance.getSkillRepository());
    }

    @Test
    void testCollaboratorRepository() {
        Repositories instance = Repositories.getInstance();
        assertNotNull(instance.getCollaboratorRepository());
    }

    @Test
    void testTeamRepository() {
        Repositories instance = Repositories.getInstance();
        assertNotNull(instance.getTeamRepository());
    }

    @Test
    void testAuthenticationRepository() {
        Repositories instance = Repositories.getInstance();
        assertNotNull(instance.getAuthenticationRepository());
    }

    @Test
    void testVehicleRepository() {
        Repositories instance = Repositories.getInstance();
        assertNotNull(instance.getVehicleRepository());
    }

    @Test
    void testJobRepository() {
        Repositories instance = Repositories.getInstance();
        assertNotNull(instance.getJobRepository());
    }

    @Test
    void testPlateCertificationRepository() {
        Repositories instance = Repositories.getInstance();
        assertNotNull(instance.getPlateCertificationRepository());
    }

    @Test
    void testTaskRepository() {
        Repositories instance = Repositories.getInstance();
        assertNotNull(instance.getTaskRepository());
    }

    @Test
    void testVehicleCheckUpRepository() {
        Repositories instance = Repositories.getInstance();
        assertNotNull(instance.getVehicleCheckUpRepository());
    }

    @Test
    void testGreenSpaceRepository() {
        Repositories instance = Repositories.getInstance();
        assertNotNull(instance.getGreenSpaceRepository());
    }

}