# US006 - Register Vehicle

## 2. Analysis

### 2.1. Relevant Domain Model Excerpt 

![Domain Model](svg/us006-domain-model.svg)

### 2.2. Other Remarks

n/a