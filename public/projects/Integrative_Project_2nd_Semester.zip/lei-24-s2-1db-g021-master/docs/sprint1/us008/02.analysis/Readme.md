# US08 - As an FM, I want to list the vehicles needing the check-up.

## 2. Analysis

### 2.1. Relevant Domain Model Excerpt 

![Domain Model](svg/us008-domain-model.svg)

### 2.2. Other Remarks

n/a