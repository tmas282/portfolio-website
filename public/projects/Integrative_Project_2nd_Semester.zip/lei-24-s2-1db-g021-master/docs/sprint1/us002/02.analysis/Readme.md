# US002 - Register Job

## 2. Analysis

### 2.1. Relevant Domain Model Excerpt 

![Domain Model](svg/us002-domain-model.svg)

### 2.2. Other Remarks

n/a