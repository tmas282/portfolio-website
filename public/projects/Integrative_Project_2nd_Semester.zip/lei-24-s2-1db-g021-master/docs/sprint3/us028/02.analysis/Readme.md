# US028 - As a Collaborator, I wish to consult the tasks assigned to me between two dates.

## 2. Analysis

### 2.1. Relevant Domain Model Excerpt 

![Domain Model](svg/us028-domain-model.svg)

### 2.2. Other Remarks

n/a