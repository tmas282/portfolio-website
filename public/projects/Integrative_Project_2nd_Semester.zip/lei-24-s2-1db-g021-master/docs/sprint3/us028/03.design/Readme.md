# US028 - Consult Tasks Assigned

## 3. Design - User Story Realization 

### 3.1. Rationale

_**Note that SSD is adopted.**_

| Interaction ID | Question: Which class is responsible for...            | Answer                         | Justification (with patterns)                                                                                |
|:---------------|:-------------------------------------------------------|:-------------------------------|:-------------------------------------------------------------------------------------------------------------|
| Step 1  		     | 	... interacting with the actor?                       | ConsultTasksAssignedUI         | Pure Fabrication: there is no reason to assign this responsibility to any existing class in the Domain Model. |
| 			  	         | 	... coordinating the US?                              | ConsultTasksAssignedController | Controller.                                                                                                  |
| Step 2  		     | 	... displaying the form for the actor to input data?  | ConsultTasksAssignedUI         | Pure Fabrication.                                                                                            |
| Step 3		       | 	... validating inputted data?                         | ConsultTasksAssignedUI         | Pure Fabrication.                                                                                            |
| 		             | 	... temporarily keeping inputted data?                | ConsultTasksAssignedUI         | Pure Fabrication.                                                                                            |
| Step 4  		     | 	... displaying all the information before submitting? | ConsultTasksAssignedUI         | Pure Fabrication.                                                                                            |
| Step 5  		     | 	                                                      |                                |                                                                                            |
| Step 6  		     | 	... informing operation success?                      | ConsultTasksAssignedUI         | Pure Fabrication. IE: is responsible for user interactions.                                                  |

### Systematization ##

According to the taken rationale, the conceptual classes promoted to software classes are: 

* Collaborator
* SKill

Other software classes (i.e. Pure Fabrication) identified: 

* ConsultTasksAssignedUI  
* ConsultTasksAssignedController
* Repositories
* SkillRepository

## 3.2. Sequence Diagram (SD)

### Full Diagram

This diagram shows the full sequence of interactions between the classes involved in the realization of this user story.

![Sequence Diagram - Full](svg/us028-sequence-diagram-full.svg)

## 3.3. Class Diagram (CD)

![Class Diagram](svg/us028-class-diagram.svg)