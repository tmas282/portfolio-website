# US027 - List Green Spaces Managed Managed by me (GSM)

## 3. Design - User Story Realization 

### 3.1. Rationale

_**Note that SSD is adopted.**_

| Interaction ID  | Question: Which class is responsible for...       | Answer                                                          | Justification (with patterns)                                                                                 |
|:----------------|:--------------------------------------------------|:----------------------------------------------------------------|:--------------------------------------------------------------------------------------------------------------|
| Step 1  		   | 	... interacting with the actor?                  | ListGreenSpacesManagedByMeGsmUI                                 | Pure Fabrication: there is no reason to assign this responsibility to any existing class in the Domain Model. |
| 			  	   | 	... coordinating the US?                         | ListGreenSpacesManagedByMeGsmController                         | Controller                                                                                                    |
|          | ... creating the Controller?                      | ListGreenSpacesManagedByMeGsmUI                                 | Creator (Rule 3): ListGreenSpacesManagedByMeGsmUI closely uses ListGreenSpacesManagedByMeGsmController        |
| 			  	   | 	... knowing the information of the Green Spaces? | GreenSpaceRepository                                            | IE: GreenSpaceRepository knows alls Green Spaces.                                                             |
|          | ... knowing the GreenSpaceRepository              | Repositories                                                    | IE: Repositories is a singleton that knows all repositories.                                                  |
|          | ... knowing the GreenSpace information?           |          GreenSpace                                                       | IE: GreenSpace knows every details of a green space.                                                          |
| Step 2  		   | 	                                                 |                                                                 |                                                                                                               |

### Systematization ##

According to the taken rationale, the conceptual classes promoted to software classes are: 

* ListGreenSpacesManagedByMeGsmUI
* ListGreenSpacesManagedByMeGsmController

Other software classes (i.e. Pure Fabrication) identified:

* GreenSpaceRepository
* Repositories

## 3.2. Sequence Diagram (SD)

_**Note that SSD - Alternative One is adopted.**_

### Full Diagram

This diagram shows the full sequence of interactions between the classes involved in the realization of this user story.

![Sequence Diagram - Full](svg/us027-sequence-diagram-full.svg)

## 3.3. Class Diagram (CD)

![Class Diagram](svg/us027-class-diagram.svg)