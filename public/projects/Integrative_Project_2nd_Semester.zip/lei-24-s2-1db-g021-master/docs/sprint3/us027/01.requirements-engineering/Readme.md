# US027 - List Green Spaces Managed Managed by me (GSM)


## 1. Requirements Engineering

### 1.1. User Story Description

As a GSM, I need to list all green spaces managed by me.

### 1.2. Customer Specifications and Clarifications 

**From the specifications document:**

> Green spaces for collective use can vary significantly in dimensions and
available amenities. They may range from small landscaped areas, parks
with trees and some amenities like benches or playgrounds, to parks with
multiple hectares (e.g., in Porto, there are the _Parque da Cidade_ - City Park -
the _Parque Oriental_ - the Oriental Park), wooded areas, lakes, and various
facilities and installations.

> Green Spaces Manager (GSM) - the person responsible for managing
the green spaces in charge of the organization.

**From the client clarifications:**

> **Question:** Boa tarde cliente, na us27 é pedido que um GSM possa listar os green spaces administrados por ele, isto significa que podemos ter mais que 1 GSM? Tendo em conta a forma como fazemos o login no programa, a função de GSM está associada a apenas uma pessoa, se tivermos varias pessoas com a função de GSM como fazemos para atribuir a cada uma delas um green space?
>
> **Answer:** Creio que já foi respondido essa questão!
Já foi explicitada a diferença entre Papel/Privilégio e Usuário.

> **Question:** Dear client, in this user story you only want to list the Green Spaces manage by the GSM. Due to this, the GSM should be register in the app previusly, isn't it? Which atributes should it have? A  GSM is a collaborator?
> 
> **Answer:** yes; the GSM (you can have many) should be registered in the app.
GSM is a role that can be played a registered user with the appropriate priviliges;

> **Question:** Dear client, in this user story you only want to list the Green Spaces manage by the GSM. Due to this, the GSM should be register in the app previusly, isn't it? Which atributes should it have? A  GSM is a collaborator?
> 
> **Answer:** Yes, the app can have multiple GSM registered (for instance that can be done during usgin the boostrap);
A collaborator is a person (an employee) that have a name, birthdate, a salary, etc, A GSM is a role played by a collaborator. Depending in the size of the company, you can have a collaborator playing multiple roles like GSM, VFM or HRM or different persons playing the same role like GSM.

> **Question:** Dear client, which info about Green Spaces do you want the GSM see when listing? only the name ?
>
> **Answer:** Each de team can decide about the aspects related to UX/UI.

### 1.3. Acceptance Criteria

* **AC1:** The list of green spaces must be sorted by size in descending
order (area in hectares should be used). The sorting algorithm to
be used by the application must be defined through a configuration
file. At least two sorting algorithms should be available.

### 1.4. Found out Dependencies

* There is a dependency on "US020 - Register Green Space" because the Green Space Manager
need, at least, one Green Space to list it out.

### 1.5 Input and Output Data

**Input Data:**

* Typed data:
    * None.
	
* Selected data:
    * None.

**Output Data:**

* List of green spaces.

### 1.6. System Sequence Diagram (SSD)

![System Sequence Diagram - Alternative One](svg/us027-system-sequence-diagram.svg)

### 1.7 Other Relevant Remarks

*