# US021 - Add Entry To-Do List

## 3. Design - User Story Realization 

### 3.1. Rationale

_**Note that SSD is adopted.**_

| Interaction ID | Question: Which class is responsible for...          | Answer                     | Justification (with patterns)                                                                                 |
|:---------------|:-----------------------------------------------------|:---------------------------|:--------------------------------------------------------------------------------------------------------------|
| Step 1  		     | 	... interacting with the actor?                     | AddEntryToDoListUI         | Pure Fabrication: there is no reason to assign this responsibility to any existing class in the Domain Model. |
| 			  	         | 	... coordinating the US?                            | AddEntryToDoListController | Controller                                                                                                    |
| 			  	         | 	... instantiating a new Green Space?                | Repositories               | GreenSpaceRepository has Green Spaces.                                                                        |
| Step 2  		     | 	... displaying the form for the actor to input data | AddEntryToDoListUI         | Pure Fabrication                                                                                              |
| Step 3  		     | 	... saving the inputted data?                       | Task                       | IE: object created in step 1 has its own data.                                                                |
| 		             | 	... temporarily keeping input data?                 | AddEntryToDoListUI         | Pure Fabrication                                                                                              |
| Step 4  		     | 	... knowing the data to show?                       | System                     | IE: Task Categories are defined by the Administrators.                                                        |
| 		             | 	... saving the selected category?                   | ToDoList                   | IE: object created in step 1 is classified in one Category.                                                   |
| Step 5  		     | 	... validating all data (local validation)?         | ToDoList                   | IE: owns its data.                                                                                            |
| 			  	         | 	... validating all data (global validation)?        | TaskRepository             | IE: knows all its entrys.                                                                                     |
| 			  	         | 	... saving the created entry?                       | TaskRepository             | IE: owns all its entrys.                                                                                      |
| Step 6  		     | 	... informing operation success?                    | AddEntryToDoListUI         | Pure Fabrication. IE: is responsible for user interactions.                                                   |

### Systematization ##

According to the taken rationale, the conceptual classes promoted to software classes are: 

* Task

Other software classes (i.e. Pure Fabrication) identified: 

* AddEntryToDoListUI
* AddEntryToDoListController
* Repositories
* TaskRepository

## 3.2. Sequence Diagram (SD)

_**Note that SSD - Alternative Two is adopted.**_

### Full Diagram

This diagram shows the full sequence of interactions between the classes involved in the realization of this user story.

![Sequence Diagram - Full](svg/us021-sequence-diagram-full.svg)

## 3.3. Class Diagram (CD)

![Class Diagram](svg/us021-class-diagram.svg)