# US026 - Assign Vehicle to Agenda Entry


## 1. Requirements Engineering

### 1.1. User Story Description

As a GSM, I want to assign one or more vehicles to an entry in
the Agenda.

### 1.2. Customer Specifications and Clarifications

**From the specifications document:**

> The system should allow the GSM to assign one or more vehicles to an entry in the Agenda.

**From the client clarifications:**

> **Question:** Should each GSM only be able to assign vehicles to its own entries or every GSM can assign vehicles to every entry, even if the green space associated with the task is not registered with their email?

> **Answer:** For the sake of simplicity, you can assume that GSM will only manage its Agenda Entries.

> **Question:** How will the Green Spaces Manager choose the vehicle to assign? By its plate?
>
> **Answer:** Assuming you mean assingning to a Task/Agenda Entry, the data related with vehicle should be provided in order to ease the selection.

> **Question:** Is the number of vehicles to be assigned provided by the Green Spaces Manager?
>
> **Answer:** There is no specification concerning the number of vehicles, is upt to GSM decide what vehicles the task needs.

> **Question:** Should all company vehicles be available to assign them to a calendar entry, or only vehicles with up-to-date maintenance?
>
> **Answer:** All vehicles that are not assigned to a task in the same period.
In a real context, we would also need to manage the (un)availability of vehicles due to overhauls or breakdowns, but this is not necessary in this proof-of-concept.


### 1.3. Acceptance Criteria

* **AC1:** The system shall allow the GSM to assign one or more vehicles to an entry in the Agenda.
* **AC2:** The system shall not allow the GSM to assign a vehicle that is already assigned to another entry in the same period.
* **AC3:** The system shall not allow the GSM to assign a vehicle that is not up-to-date with its maintenance.

### 1.4. Found out Dependencies

* This US depends on the implementation of US006 - "Register Vehicle". This user story is necessary because before a vehicle can be assigned to an agenda entry, it must first be registered in the system.
* This US depends on the implementation of US022 - "Add a new entry in the Agenda". This user story is necessary because before a vehicle can be assigned, there must be an agenda entry to assign the vehicle to.
* This US could depend on US025 - "Cancel an entry in the Agenda". This user story could potentially impact US026 if an agenda entry to which a vehicle has been assigned is cancelled. The system would need to handle this situation appropriately, for example by unassigning the vehicle or notifying the relevant parties.

### 1.5 Input and Output Data

**Input Data:**

* Entry to which vehicles need to be assigned
* Vehicles to be assigned

**Output Data:**

* Confirmation message upon successful assignment of vehicles to the entry

### 1.6. System Sequence Diagram (SSD)

**_Other alternatives might exist._**

![System Sequence Diagram ](svg/us026-system-sequence-diagram.svg)


### 1.7 Other Relevant Remarks

* N/A