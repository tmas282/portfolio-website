# US026 - Assign Vehicles to Entry

## 3. Design - User Story Realization

### 3.1. Rationale

_**Note that SSD is adopted.**_

| Interaction ID     | Question: Which class is responsible for...           | Answer                        | Justification (with patterns)                                                                                 |
|:-------------------|:------------------------------------------------------|:------------------------------|:--------------------------------------------------------------------------------------------------------------|
| Step 1             | ... interacting with the actor?                      | AssignVehiclesToEntryUI         | Pure Fabrication: there is no reason to assign this responsibility to any existing class in the Domain Model. |
|                    | ... coordinating the US?                             | AssignVehiclesToEntryController | Controller.                                                                                                   |
|                    | ... obtaining the entries list?                      | EntryRepository                 | Information Expert, Pure Fabrication.                                                                         |
| Step 2             | ... displaying the entries list?                     | AssignVehiclesToEntryUI         | Pure Fabrication.                                                                                             |
| Step 3             | ... validating the selected data?                    | AssignVehiclesToEntryUI         | Pure Fabrication.                                                                                             |
|                    | ... temporarily keeping the selected data?           | AssignVehiclesToEntryUI         | Pure Fabrication.                                                                                             |
| Step 4             | ... displaying the available vehicles list?          | AssignVehiclesToEntryUI         | Pure Fabrication.                                                                                             |
| Step 5             | ... validating selected vehicles?                    | AssignVehiclesToEntryUI         | Pure Fabrication.                                                                                             |
|                    | ... temporarily keeping selected vehicles?           | AssignVehiclesToEntryUI         | Pure Fabrication.                                                                                             |
| Step 6             | ... displaying all the data before submitting?       | AssignVehiclesToEntryUI         | Pure Fabrication.                                                                                             |
| Step 7             | ... assigning the vehicles to the entry?             | AssignVehiclesToEntryController | Controller.                                                                                                   |
|                    | ... saving the assignment?                           | EntryRepository                 | Information Expert, Pure Fabrication.                                                                         |
| Step 8             | ... informing operation success?                     | AssignVehiclesToEntryUI         | Pure Fabrication.                                                                                             |

### Systematization

According to the taken rationale, the conceptual classes promoted to software classes are:

* AgendaEntry

Other software classes (i.e. Pure Fabrication) identified:

* AssignVehiclesToEntryUI
* AssignVehiclesToEntryController
* Repositories
* VehicleRepository
* EntryRepository

## 3.2. Sequence Diagram (SD)

_**Note that SSD - Alternative Two is adopted.**_

### Full Diagram

This diagram shows the full sequence of interactions between the classes involved in the realization of this user story.

![Sequence Diagram - Full](svg/us026-sequence-diagram-full.svg)

## 3.3. Class Diagram (CD)

![Class Diagram](svg/us026-class-diagram.svg)