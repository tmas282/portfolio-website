# US001 - Register Skills

## 4. Tests

### 4.1 Skill Tests

**Test 1:** This test checks the getJobName method of the Job class.

	@Test
    public void testCreateSkill() {
        Skill skill = new Skill("Programming");
        assertEquals("Programming", skill.getSkillName());
    }

**Test 2:** his test checks the toString method of the Skill class.

	@Test
    public void testToString() {
        Skill skill = new Skill("Programming");
        assertEquals("Skill Name: Programming", skill.toString());
    }

**Test 3:** This test checks the equals method of the Skill class.

    @Test
    public void testEquals() {
        Skill skill1 = new Skill("Programming");
        Skill skill2 = new Skill("Programming");
        Skill skill3 = new Skill("Testing");

        assertTrue(skill1.equals(skill2));
        assertFalse(skill1.equals(skill3));
    }

**Test 4:** This test checks the clone method of the Skill class.

     @Test
    public void testClone() {
        Skill originalSkill = new Skill("Programming");
        Skill clonedSkill = originalSkill.clone();

        assertEquals(originalSkill.getSkillName(), clonedSkill.getSkillName());
        assertNotSame(originalSkill, clonedSkill); // Ensure they are not the same object
    }

### 4.2 SkillRepository Tests

**Test 1:** This test checks the successful registration of a Skill object in the SkillRepository.

    @Test
    public void testRegisterSkill_Success() {
        Skill skill = new Skill("Programming");
        Optional<Skill> addedSkill = skillRepository.registerSkill(skill);
        assertTrue(addedSkill.isPresent());
        assertEquals(skill, addedSkill.get());
    }

**Test 2:** This test checks the scenario where the registration of a Skill object in the SkillRepository fails.

        @Test
    public void testRegisterSkill_Failure() {
        Skill skill1 = new Skill("Programming");
        Skill skill2 = new Skill("Programming");
        skillRepository.registerSkill(skill1);
        Optional<Skill> addedSkill = skillRepository.registerSkill(skill2);
        assertFalse(addedSkill.isPresent());
    }

## 5. Construction (Implementation)

### Class RegisterSkillController

```java
public class RegisterSkillController {
    private final SkillRepository skillRepository;

    public RegisterSkillController(){
        skillRepository = new SkillRepository();
    }

    public boolean registerSkill(String skillName){
        Skill newSkill = new Skill(skillName);
        Optional<Skill> addedSkill = skillRepository.registerSkill(newSkill);
        return addedSkill.isPresent();
    }

    public void validateSkillName(String skillName){
        if(skillName == null || skillName.trim().isEmpty()){
            throw new IllegalArgumentException("Invalid skill name.");
        }
        if (!skillName.matches("[a-zA-Z ]+")) {
            throw new IllegalArgumentException("Job name must not contain special characters or numbers");
        }

    }

    public List<Skill> listSkills() {
        return skillRepository.getSkills();
    }
}
```

### Class Skill

```java
public class Skill implements Cloneable {
    private String skillName;

    public Skill(String skillName) {
        setSkillName (skillName);
    }

    private void setSkillName(String skillName) {
        this.skillName = skillName;
    }

    public String getSkillName() {
        return skillName;
    }



    @Override
    public Skill clone(){
        return new Skill(this.skillName);
    }

    @Override
    public String toString() {
        return String.format("Skill Name: %s", skillName);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Skill)) return false;
        Skill skill = (Skill) o;
        return skillName.equals(skill.skillName);
    }
}
```


### Class SkillRepository

```java
public class SkillRepository {
    private final List<Skill> listSkills;

    public SkillRepository() {
        listSkills = new ArrayList<>();
    }

    public Optional<Skill> registerSkill(Skill skill) {
        Optional<Skill> newSkill = Optional.empty();
        boolean isAdded = false;

        if (validateSkillname(skill)) {
            newSkill = Optional.of(skill.clone());
            isAdded = listSkills.add(newSkill.get());
        }

        if (!isAdded) {
            newSkill = Optional.empty();
        }
        return newSkill;
    }

    private boolean validateSkillname(Skill skill) {
        boolean isValid = !listSkills.contains(skill);
        return isValid;
    }


    public List<Skill> getSkills() {
        return listSkills;
    }
}
```

### Class RegisterSkillUI

```java
public class RegisterSkillUI implements Runnable{
    private final RegisterSkillController controller;
    private String skillName;

    public RegisterSkillUI(){
        controller = new RegisterSkillController();
    }

    private RegisterSkillController getController(){
        return controller;
    }

    @Override
    public void run() {
        System.out.println("\n\n----Register Skill----");

        Scanner input = new Scanner(System.in);
        skillName = input.nextLine();

        boolean isRegistered = controller.registerSkill(skillName);

        if(isRegistered){
            System.out.println("Skill registered successfully.");
        } else {
            System.out.println("Skill not registered.");
        }

        List<Skill> skills = controller.listSkills();
        System.out.println("\n");
        System.out.println("Skills:");
        for(Skill skill : skills){
            System.out.println(skill.toString());
        }
    }
}
```



## 6. Integration and Demo

* A new option on the Employee menu options was added.

* For demo purposes some tasks are bootstrapped while system starts.

## 7. Observations

n/a