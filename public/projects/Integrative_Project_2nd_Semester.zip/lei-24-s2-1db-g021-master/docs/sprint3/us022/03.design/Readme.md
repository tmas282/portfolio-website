# US001 - Create a Task

## 3. Design - User Story Realization

### 3.1. Rationale

_**Note that SSD - Alternative One is adopted.**_


| Interaction ID | Question: Which class is responsible for...   | Answer               | Justification (with patterns)                                |
|:---------------|:----------------------------------------------|:---------------------|:-------------------------------------------------------------|
| Step 1               | ...interacting with the actor?                | GreenSpaceUI         | Pure Fabrication                                             |
|                | ...Coordinate the system actions              | GreenSpaceController | Controller                                                   |
|                | ... provides the green space list             | Green Space          | Information Expert                                           |
| Step 2         | ...verify the association                     | Green Space          | Information Expert                                           |
|                | ...provides the to-do list                    | To-Do List           | Information Expert                                           |
|                | ... create an agendaEntry                     | Agenda Entry         | Creator (Rule 1: contains/aggregates instances of the class) |
| Step 3         | ... saving the agenda                         | Agenda Repository    | Information Expert                                           |
| Step 3         | ... displays confirmation message             | AssignTeamToEntryUI  | Pure Fabrication                                             |

## Systematization ##

According to the taken rationale, the conceptual classes promoted to software classes are:

* AgendaRepository
*  AgendaEntry
* Agenda


Other software classes (i.e. Pure Fabrication) identified:

* AddEntryAgendaUI
* AddEntryAgendaController

## 3.2. Sequence Diagram (SD)


### Full Diagram

This diagram shows the full sequence of interactions between the classes involved in the realization of this user story.

[us001-sequence-diagram.puml](puml%2Fus001-sequence-diagram.puml)

## 3.3. Class Diagram (CD)

[us001-class-diagram.puml](puml%2Fus001-class-diagram.puml)