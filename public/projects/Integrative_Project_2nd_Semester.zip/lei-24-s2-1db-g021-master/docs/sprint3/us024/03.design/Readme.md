# US024 - Postpone Entry Agenda

## 3. Design - User Story Realization 

### 3.1. Rationale

_**Note that SSD is adopted.**_

| Interaction ID     | Question: Which class is responsible for...           | Answer                        | Justification (with patterns)                                                                                 |
|:-------------------|:------------------------------------------------------|:------------------------------|:--------------------------------------------------------------------------------------------------------------|
| Step 1  		         | 	... interacting with the actor?                      | PostponeEntryAgendaUI         | Pure Fabrication: there is no reason to assign this responsibility to any existing class in the Domain Model. |
| 			  	             | 	... coordinating the US?                             | PostponeEntryAgendaController | Controller.                                                                                                   |
| 			  	             | 	... obtaining the entrys list?                       | AgendaEntryRepository         | Information Expert, Pure Fabrication.                                                                         |
| Step 2  		         | 	... displaying the entrys list?                      | PostponeEntryAgendaUI         | Pure Fabrication.                                                                                             |
| Step 3  		         | 	... validating the selected data?                    | PostponeEntryAgendaUI         | Pure Fabrication.                                                                                                              |
| 			  	             | 	... temporarily keeping the selected data?           | PostponeEntryAgendaUI         | Pure Fabrication.                                                                         |
| Step 4  		         | 	... displaying the form for the actor to input data? | PostponeEntryAgendaUI         | Pure Fabrication.                                                         |
| Step 5  		         | 	... validating inputed data?                         | PostponeEntryAgendaUI         | Pure Fabrication.                                                                                           |
| 			  	             | 	... temporarily keeping input data?                  | PostponeEntryAgendaUI         | Pure Fabrication.                                                                                     |
| Step 6  		         | 	... displaying all the data before submitting?       | PostponeEntryAgendaUI         | Pure Fabrication.                                                                    |
| Step 7  		         | 	                                                     |                               |                                                                      |
| Step 8  		         | 	... informing operation success?                     | PostponeEntryAgendaUI         | Pure Fabrication.                                                                     |

### Systematization ##

According to the taken rationale, the conceptual classes promoted to software classes are: 

* Agenda

Other software classes (i.e. Pure Fabrication) identified: 

* PostponeEntryAgendaUI  
* PostponeEntryAgendaController
* Repositories
* AgendaEntryRepository
* AgendaRepository

## 3.2. Sequence Diagram (SD)

### Full Diagram

This diagram shows the full sequence of interactions between the classes involved in the realization of this user story.

![Sequence Diagram - Full](svg/us024-sequence-diagram-full.svg)

## 3.3. Class Diagram (CD)

![Class Diagram](svg/us024-class-diagram.svg)