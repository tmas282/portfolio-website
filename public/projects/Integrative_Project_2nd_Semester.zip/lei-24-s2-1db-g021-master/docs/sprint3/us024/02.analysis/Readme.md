# US024 - As a Green Space Manager (GSM), I want to Postpone an entry in the Agenda to a specific future date.

## 2. Analysis

### 2.1. Relevant Domain Model Excerpt 

![Domain Model](svg/us024-domain-model.svg)

### 2.2. Other Remarks

n/a