# US001 - Register Skill

## 3. Design - User Story Realization 

### 3.1. Rationale

_**Note that SSD - Alternative One is adopted.**_

| Interaction ID | Question: Which class is responsible for... | Answer                                    | Justification (with patterns)                                                                     |
|:---------------|:--------------------------------------------|:------------------------------------------|:--------------------------------------------------------------------------------------------------|
| Step 1  		     | 	... interacting with the actor?            | AssignTeamToEntryUI                       | Pure Fabrication                                                                                  |
| 			  	         | 	... coordinating the US?                   | AssignTeamToEntryController               | Controller                                                                                        |
|                | ... creating the controller?                | AssignTeamToEntryUI                       | Creator: AssignTeamToEntryUI closely uses AssignTeamToEntryController                             |
| Step 2  		     | 	... displaying information?                | AssignTeamToEntryUI                       | Pure Fabrication                                                                                  |
|                | ... obtaining the entries?                  | Agenda                                    | Information Expert: knows all the entries instances.                                              |
| Step 3  		     | 	...saving temporarily the inputted data?   | AssignTeamToEntryController               | Controller: because it is the class responsible for the US coordination                           |
| Step 4  		     | 	                                           |                                           |                                                                                                   |
| Step 5  		     | 	                                           |                                           |                                                                                                   |
| Step 6		  	    | 	... getting the teams?                     | TeamRepository                            | Information Expert: knows all the teams instances.                                                |
| Step 7         |                                             |                                           |                                                                                                   |
| Step 8         |                                             |                                           |                                                                                                   |
| Step 9         | ...assign a team to an entry?               | AgendaEntry                               | Information Expert: must have a team assigned to.                                                 |
| Step 10        |                                             |                                           |                                                                                                   |

### Systematization ##

According to the taken rationale, the conceptual classes promoted to software classes are: 

* Agenda
* Entry

Other software classes (i.e. Pure Fabrication) identified: 

* AssignTeamToEntryUI  
* AssignTeamToEntryController
* TeamRepository

## 3.2. Sequence Diagram (SD)

_**Note that SSD - Alternative One is adopted.**_

### Full Diagram

This diagram shows the full sequence of interactions between the classes involved in the realization of this user story.

![Sequence Diagram - Full](svg/us023-sequence-diagram-full.svg)

## 3.3. Class Diagram (CD)

![Class Diagram](svg/us023-class-diagram.svg)