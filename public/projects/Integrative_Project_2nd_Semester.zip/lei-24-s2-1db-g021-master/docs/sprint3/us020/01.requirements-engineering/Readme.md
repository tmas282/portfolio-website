# US020 - Register Green Space

## 1. Requirements Engineering

### 1.1. User Story Description

As a Green Space Manager (GSM), I want to register a green space (garden, medium-sized park or large-sized park) and its respective area.

### 1.2. Customer Specifications and Clarifications 

**From the specifications document:**

> The management of green areas for public use requires the timely management and completion of multiple tasks throughout the year.

**From the client clarifications:**

> **Question:** Should the green space have any more traits, other than the type of green space and area?
>
> **Answer:** Already answered in the forum and client session.

> **Question:** In which unit should the area be measured in?
> 
> **Answer:** Usually, areas are measured in hectares.

> **Question:** Can the GSM register multiple green spaces at once?
> 
> **Answer:** That's a matter of UX/UI, each dev team can decide about it.

> **Question:** We understand that type (garden, medium-size, large-size), area, name, and address are required inputs for a Green Space (and if we are wrong in this, please correct us), but are there any other inputs that we are unaware of?
> 
> **Answer:** Seems enough.

> **Question:** What is the definition of an entry?
> 
> **Answer:** Not sure if fully understand you question. There are Agenda Entries and To-do List Entries. A To-Do list is a list of "tasks" one need to do, each "task" one insert in the list is an Entry. Agenda and its Entries, follow the same logic.

> **Question:** Can two green spaces have the same name?
>
> **Answer:** No.

> **Question:** Dear client, which atributes a Green Space have?
>
> **Answer:** Previously answered inthe forum.

> **Question:** To register a green space, what is the criteria needed to classify it as a medium-sized park or a large-sized park?
>
> **Answer:** It's a GSM responsability to decide the classification.

> **Question:** Should the Green Space have any field in which it would store the GSM who created it, meaning that green space is managed by that GSM?
>
> **Answer:** I have no knowledge about data models.

> **Question:** Good afternoon, I would like to know between what ranges of hectares a green space is classified as garden, medium or large, or if it is possible to register 2 green spaces with the same area but in different typology, depending on the GSM it registers.
>
> **Answer:** The classification is not automatic, it's up to GSM decide about it.

> **Question:** Good evening, in view of the description of GreenSpaces does it make sense to ask for optional mind for the different types this data?
Garden:
 Presence of trees (yes/no)
 Presence of irrigation system (yes/no)
 Presence of benches (yes/no)
Medium-sized park:
 Presence of a wooded garden area (yes/no)
 Presence of toilets (yes/no)
 Presence of drinking fountains (yes/no)
 Presence of an irrigation system (yes/no)
 Presence of lighting (yes/no)
 Presence of a playground (yes/no)
Large park:
 All data (medium-sized park)
 Presence of gardens (yes/no)
 Presence of woodland (yes/no)
 Presence of various facilities (yes/no)
Thank you
> 
> **Answer:** In the current version, it is sufficient to define a park using name, size classification, area (hectare) and address.

> **Question:** In the registration of a green space, should a green space's name be allowed to contain digits and special characters, or just letters and whitespaces?
>
> **Answer:** Same rules for other names in the business, letters, spaces and dashes.

> **Question:** Dear teacher, in order to register a green space the only information the collaborator has to give is the type of park?
> 
> **Answer:** Already answered in this forum.

> **Question:** Can two different green spaces have the same address?
> 
> **Answer:** No.

> **Question:** What is the attribute that identifies the green space?
>
> **Answer:** Already answered in this forum.


### 1.3. Acceptance Criteria

*

### 1.4. Found out Dependencies

* This User Storie doesn't have any dependencie.

### 1.5 Input and Output Data

**Input Data:**

* Typed data:
  * The green space data.
  * The area of green space.
	
* Selected data:
  * The green space data.
  * The area of green space.

**Output Data:**
  * Operation Success.

### 1.6. System Sequence Diagram (SSD)

![System Sequence Diagram (SSD) - Register Green Space](svg/us020-system-sequence-diagram.svg)

### 1.7 Other Relevant Remarks

*