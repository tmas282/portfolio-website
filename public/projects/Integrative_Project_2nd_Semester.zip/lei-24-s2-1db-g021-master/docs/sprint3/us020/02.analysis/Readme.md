# US020 - As a Green Space Manager (GSM), I want to register a green space (garden, medium-sized park or large-sized park) and its respective area.

## 2. Analysis

### 2.1. Relevant Domain Model Excerpt 

![Domain Model](svg/us020-domain-model.svg)

### 2.2. Other Remarks

n/a