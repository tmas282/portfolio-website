# US020 - Register Green Space

## 3. Design - User Story Realization 

### 3.1. Rationale

_**Note that SSD is adopted.**_

| Interaction ID     | Question: Which class is responsible for...          | Answer                       | Justification (with patterns)                                                                                 |
|:-------------------|:-----------------------------------------------------|:-----------------------------|:--------------------------------------------------------------------------------------------------------------|
| Step 1  		         | 	... interacting with the actor?                     | RegisterGreenSpaceUI         | Pure Fabrication: there is no reason to assign this responsibility to any existing class in the Domain Model. |
| 			  	             | 	... coordinating the US?                            | RegisterGreenSpaceController | Controller                                                                                                    |
| 			  	             | 	... instantiating a new Green Space?                | Repositories                 | GreenSpaceRepository has Green Spaces.                                                                        |
| Step 2  		         | 	... displaying the form for the actor to input data | RegisterGreenSpaceUI         | Pure Fabrication                                                                                              |
| Step 3  		         | 	... saving the inputted data?                       | GreenSpace                   | IE: object created in step 1 has its own data.                                                                |
| 		                 | 	... validating input data?                          | RegisterGreenSpaceUI         | Pure Fabrication                                                                                              |
| 		                 | 	... temporarily keeping input data?                 | RegisterGreenSpaceUI         | Pure Fabrication                                                                                              |
| Step 4  		         | 	... knowing the data to show?                       | System                       | IE: Task Categories are defined by the Administrators.                                                        |
| 		                 | 	... saving the selected category?                   | GreenSpace                   | IE: object created in step 1 is classified in one Category.                                                   |
| Step 5  		         | 	... validating all data (local validation)?         | GreenSpace                   | IE: owns its data.                                                                                            |
| 			  	             | 	... validating all data (global validation)?        | GreenSpaceRepository         | IE: knows all its green spaces.                                                                               |
| 			  	             | 	... saving the created green space?                 | GreenSpaceRepository         | IE: owns all its green spaces.                                                                                      |
| Step 6  		         | 	... informing operation success?                    | RegisterGreenSpaceUI         | Pure Fabrication. IE: is responsible for user interactions.                                                   |


### Systematization ##

According to the taken rationale, the conceptual classes promoted to software classes are: 

* GreenSpace

Other software classes (i.e. Pure Fabrication) identified: 

* RegisterGreenSpaceUI  
* RegisterGreenSpaceController
* Repositories
* GreenSpaceRepository

## 3.2. Sequence Diagram (SD)

### Full Diagram

This diagram shows the full sequence of interactions between the classes involved in the realization of this user story.

![Sequence Diagram - Full](svg/us020-sequence-diagram-full.svg)



## 3.3. Class Diagram (CD)

![Class Diagram](svg/us020-class-diagram.svg)