# US008 - List Vehicles Need Check-up

## 4. Tests 

**Test 1:** Check that it is not possible to create an instance of the VehicleCheckUp class with null values. 

    @Test()
    public void checkIfNotPossibleToCreateCheckUpWithNull(){
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->{
            new VehicleCheckUp(null, null, 0, null);
        });
    }
	

**Test 2:** Check that it is possible to create an instance of the Vehicle class with valid values.

	@Test
    public void testConstruction() throws ParseException {
        //Arrange
        String ExampleDate = "2005-01-02";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date dateTest = sdf.parse(ExampleDate);

        PlateCertification plateCertification = new PlateCertification("Renault","Clio","Electric",900,1200,dateTest,"72-XQ-70");
        Vehicle vehicle = new Vehicle(10000, new Date(), 2000, plateCertification);

        //Act and assert
        assertEquals(10000, vehicle.getCurrentKm(), 0);
        assertNotNull(vehicle.getAcquisitionDate());
        assertEquals(2000, vehicle.getMaintenance(), 0);
        assertEquals(plateCertification, vehicle.getPlateCertification());
    }

_It is also recommended to organize this content by subsections._ 


## 5. Construction (Implementation)

### Class ListVehiclesCheckupController 

```java
public class ListVehiclesCheckupController {
    private VehicleRepository vehicleRepository;
    private VehicleCheckUpRepository vehiclesCheckUpsRepository;

    /**
     * This constructor instantiates it with the default vehicle and vehicles check-ups repositories.
     */
    public ListVehiclesCheckupController() {
        getVehicleRepository();
        getVehiclesCheckUpsRepository();
    }

    /**
     * This constructor instantiates it with the custom vehicles and vehicles check-ups repositories.
     * @param vehicleRepository the custom vehicle repository
     * @param vehicleCheckUpRepository the custom vehicles check-ups repository
     */
    public ListVehiclesCheckupController(VehicleRepository vehicleRepository, VehicleCheckUpRepository vehicleCheckUpRepository) {
        this.vehicleRepository = vehicleRepository;
        this.vehiclesCheckUpsRepository = vehicleCheckUpRepository;
    }
    private VehicleRepository getVehicleRepository(){
        if (vehicleRepository == null) {
            Repositories repositories = Repositories.getInstance();
            vehicleRepository = repositories.getVehicleRepository();
        }
        return vehicleRepository;
    }
    private VehicleCheckUpRepository getVehiclesCheckUpsRepository(){
        if (vehiclesCheckUpsRepository == null) {
            Repositories repositories = Repositories.getInstance();
            vehiclesCheckUpsRepository = repositories.getVehicleCheckUpRepository();
        }
        return vehiclesCheckUpsRepository;
    }

    /**
     * This method gets the vehicles needing or almost needing a check-up
     * @return a Map containing the vehicles needing or almost needing a check-up
     */
    public Map<Vehicle, VehicleCheckUp[]> getVehiclesNeedingCheckup(){
        List<Vehicle> vehicles = vehicleRepository.getVehiclesList();
        Map<Vehicle, VehicleCheckUp[]> vehiclesNeedingIt = new HashMap<>();
        for (Vehicle vehicle:
                vehicles) {
            List<VehicleCheckUp> vehicleCheckUps = vehiclesCheckUpsRepository.getVehicleCheckUps(vehicle);
            if (vehicleCheckUps.isEmpty()){
                if(isVehicleNeedingOrAlmostCheckup(vehicle)){
                    vehiclesNeedingIt.put(vehicle, null);
                }
            }
            else{
                VehicleCheckUp[] lastNextCheckups = getNextAndLastCheckup(vehicleCheckUps, vehicle);
                if(isVehicleNeedingOrAlmostCheckup(vehicle, lastNextCheckups[0])){
                    vehiclesNeedingIt.put(vehicle, lastNextCheckups);
                }
            }
        }
        return vehiclesNeedingIt;
    }

    private boolean isVehicleNeedingOrAlmostCheckup(Vehicle vehicle){
        return didVehExceededCheckup(vehicle) || isVehicleCloseToExceedCheckup(vehicle);
    }
    private boolean isVehicleNeedingOrAlmostCheckup(Vehicle vehicle, VehicleCheckUp lastCheckup){
        return didVehExceededCheckup(vehicle, lastCheckup) || isVehicleCloseToExceedCheckup(vehicle, lastCheckup);
    }
    private boolean didVehExceededCheckup(Vehicle vehicle){
        double maintenance = vehicle.getMaintenance();
        double currentKm = vehicle.getCurrentKm();
        return currentKm >= maintenance;
    }
    private boolean didVehExceededCheckup(Vehicle vehicle, VehicleCheckUp lastCheckup){
        double lastMaintenanceKms = lastCheckup.getKms();
        double maintenance = vehicle.getMaintenance();
        double currentKm = vehicle.getCurrentKm();
        return (lastMaintenanceKms + maintenance <= currentKm);
    }
    private boolean isVehicleCloseToExceedCheckup(Vehicle vehicle){
        double maintenance = vehicle.getMaintenance();
        double currentKm = vehicle.getCurrentKm();
        double dif = maintenance - currentKm;
        return dif <= maintenance * 0.05;
    }
    private boolean isVehicleCloseToExceedCheckup(Vehicle vehicle, VehicleCheckUp lastCheckup){
        double lastMaintenanceKms = lastCheckup.getKms();
        double maintenance = vehicle.getMaintenance();
        double currentKm = vehicle.getCurrentKm();
        double dif = lastMaintenanceKms + maintenance - currentKm;
        return dif <= maintenance * 0.05;
    }
    private VehicleCheckUp[] getNextAndLastCheckup(List<VehicleCheckUp> vehicleCheckUpList, Vehicle vehicle){
        VehicleCheckUp lastCheckup = null;
        VehicleCheckUp nextCheckup = null;
        double currentKms = vehicle.getCurrentKm();
        for (VehicleCheckUp vehCheckUp:
                vehicleCheckUpList) {
            if (nextCheckup == null && vehCheckUp.getKms() >= currentKms) {
                nextCheckup = vehCheckUp;
            }
            if (nextCheckup != null && vehCheckUp.getKms() <= nextCheckup.getKms() && vehCheckUp.getKms() >= currentKms) {
                nextCheckup = vehCheckUp;
            }
            if (lastCheckup == null && vehCheckUp.getKms() < currentKms) {
                lastCheckup = vehCheckUp;
            }
            if (lastCheckup != null && vehCheckUp.getKms() >= lastCheckup.getKms() && vehCheckUp.getKms() < currentKms) {
                lastCheckup = vehCheckUp;
            }
        }
        return new VehicleCheckUp[]{lastCheckup, nextCheckup};
    }
}
```

### Class Organization

```java
public List<Vehicle> getVehiclesList() {
        // This is a defensive copy, so that the repository cannot be modified from the outside.
        return List.copyOf(vehiclesList);
        }
```


## 6. Integration and Demo 

* A new option on the Vehicle Fleet Manager menu options was added.


## 7. Observations

n/a