# US029 - Record the completion of a task


## 1. Requirements Engineering

### 1.1. User Story Description

As a Collaborator, I want to record the completion of a task.

### 1.2. Customer Specifications and Clarifications 

**From the specifications document:**

> Collaborator– a person who is an employee in the organization and
carries out design, construction and/or maintenance tasks for green
areas, depending on their skills.

> MS has a wide range of employees who carry out numerous tasks regarding
the design and management of green spaces. 

> Thus, an employee has a
main occupation (job) and a set of skills that enables him to take on certain
tasks and responsibilities, for example, driving different types of vehicles
(e.g. light, or heavy), operating machines such as backhoes or tractors, tree
pruning, application of agriculture phytopharmaceuticals.
 
> Tasks are carried out on an occasional or regular basis, in one or more
green spaces, for example: tree pruning, installation of an irrigation system,
and installation of a lighting system.

**From the client clarifications:**

> **Question:** Do collaborators log in with a password (created by the respective manager when creating the collaborator), or with other information like the BI number or the TaxPayer?
> 
> **Answer:** One can use email or taxpayer number.

> **Question:** "As a Collaborator, I want to record the completion of a task."
> This "record" refers to the act of only changing the status of the task, or do we want to save a list of the completed tasks within each Collaborator?
> 
> **Answer:** It means to record that a task was completed (changing the status) with the finish time.

> **Question:** "As a Collaborator, I want to record the completion of a task."
> 
> This "record" refers to the act of only changing the status of the task, or do we want to save a list of the completed tasks within each Collaborator?
>
> **Answer:** It means to record that a task was completed (changing the status) with the finish time.

> **Question:** Can a collaborator mark a task as "done" only if it is in the "planned" status?
> 
> **Answer:** It depends in the status set your team decide to have/use. But if you consider only status refered in the text and in the forum my answer would be, yes, just the "Planned" status can be changed to "Done".

> **Question:** The collaborator should be able to change the status of any task or only tasks assigned to him?
> 
> **Answer:** yes.

> **Question:** As far as I understand, when a GSM wants to cancel a task or a Collaborator wants to record the completion of a task, the task just changes its status in the Agenda to "Canceled" or "Done", respectively.
>
> So, my question is the following: does the task associated with the Agenda entry in which this happens remain in the To-do List or can it be removed, unlike what happens in the Agenda? Or even, would this process be different between a completed task and a canceled task?
>
> **Answer:** Yes.
> 
> I suppose when a task goes to the Agenda, it leaves the To-Do list but maybe a different flow could be considered.

> **Question:** The collaborator can see what type of entrys? Like what status can he filter ? Can he see canceled Entry's?
>
> **Answer:** The ones assigned to him.
> 
> He can filter by the different values the status of the status, like planned, executed, canceled ...

> **Question:** When a collaborator records a task, it should be asked for any observations regarding the completed task?
>
> **Answer:** Maybe if optional, not mandatory.

> **Question:** Can an employee record more than one completed task at a time?
>
> **Answer:** It's a matter of UX/UI, each dev team can decide about it.

### 1.3. Acceptance Criteria

* None.

### 1.4. Found out Dependencies

* There is a dependency on "US22 - As a GSM, I want to add a new entry in the Agenda." as there must be, at least, one task in the Agenda.

### 1.5 Input and Output Data

**Input Data:**

* Typed data:
    * None.
	
* Selected data:
    * The task.

**Output Data:**

* (In)success of the operation

### 1.6. System Sequence Diagram (SSD)

![System Sequence Diagram - Alternative One](svg/us029-system-sequence-diagram.svg)

### 1.7 Other Relevant Remarks

*