# US029 - Record the completion of a task

## 3. Design - User Story Realization 

### 3.1. Rationale

_**Note that SSD is adopted.**_

| Interaction ID | Question: Which class is responsible for...       | Answer                           | Justification (with patterns)                                                                                 |
|:---------------|:--------------------------------------------------|:---------------------------------|:--------------------------------------------------------------------------------------------------------------|
| Step 1  		     | 	... interacting with the actor?                  | RecordCompletionOfTaskUI         | Pure Fabrication: there is no reason to assign this responsibility to any existing class in the Domain Model. |
|                | ... coordinating the US?                          | RecordCompletionOfTaskController | Controller                                                                                                    |
|                | ... creates the RecordCompletionOfTaskController? |   RecordCompletionOfTaskUI                               | Creator (Rule 3): RecordCompletionOfTaskUI closely uses RecordCompletionOfTaskController |
|                | ... knowing the Task status?                      | AgendaEntry                      | IE: The AgendaEntry knows the Task information when it is on a entry of agenda.                               |
| Step 2         | ... knows every Task with different status?       | AgendaEntryRepository            | IE: The AgendaEntryRepository knows every Task assigned to the Agenda.                                        |
|         | ... knows all the available repositories?         | Repositories                     | IE:  Repositories knows all the repositories                                                                  |

### Systematization ##

According to the taken rationale, the conceptual classes promoted to software classes are: 

* Task
* AgendaEntry

Other software classes (i.e. Pure Fabrication) identified: 

* RecordCompletionOfTaskUI  
* RecordCompletionOfTaskController

## 3.2. Sequence Diagram (SD)

_**Note that SSD - Alternative Two is adopted.**_

### Full Diagram

This diagram shows the full sequence of interactions between the classes involved in the realization of this user story.

![Sequence Diagram - Full](svg/us029-sequence-diagram-full.svg)

## 3.3. Class Diagram (CD)

![Class Diagram](svg/us029-class-diagram.svg)