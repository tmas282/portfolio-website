# US001 - As a Human Resource Manager I want to Register Skills to Collaborators

## 2. Analysis

### 2.1. Relevant Domain Model Excerpt 

![Domain Model](svg/us025-domain-model.svg)

### 2.2. Other Remarks

n/a