# US025 - Cancel Entry Agenda

## 3. Design - User Story Realization 

### 3.1. Rationale

_**Note that SSD is adopted.**_

| Interaction ID | Question: Which class is responsible for...           | Answer                      | Justification (with patterns)                                                                                 |
|:---------------|:------------------------------------------------------|:----------------------------|:--------------------------------------------------------------------------------------------------------------|
| Step 1  		     | 	... interacting with the actor?                      | CancelEntryAgendaUI         | Pure Fabrication: there is no reason to assign this responsibility to any existing class in the Domain Model. |
| 			  	         | 	... coordinating the US?                             | CancelEntryAgendaController | Controller.                                                                                                   |
| 			  	         | 	... obtaining the entrys list?                       | AgendaRepository            | Information Expert.                                                                                           |
| Step 2  		     | 	... displaying the entrys list?                      | CancelEntryAgendaUI         | Pure Fabrication.                                                                                             |
| Step 3  		     | 	... validating the selected data?                    | Agenda                      | Creator.                                                                                                      |
| 			  	         | 	... temporarily keeping the selected data?           | CancelEntryAgendaUI         | Pure Fabrication.                                                                                             |
| Step 4  		     | 	... displaying the form for the actor to input data? | CancelEntryAgendaUI         | Pure Fabrication.                                                                                             |
| Step 5  		     | 	... validating inputed data?                         | Agenda                      | Creator.                                                                                                      |
| 			  	         | 	... temporarily keeping input data?                  | PostponeEntryAgendaUI       | Pure Fabrication.                                                                                             |
| Step 6  		     | 	... displaying all the data before submitting?       | CancelEntryAgendaUI         | Pure Fabrication.                                                                                             |
| Step 7  		     | 	                                                     |                             |                                                                                                               |
| Step 8  		     | 	... informing operation success?                     | CancelEntryAgendaUI         | Pure Fabrication.                                                                                             |

### Systematization ##

According to the taken rationale, the conceptual classes promoted to software classes are: 

* Agenda

Other software classes (i.e. Pure Fabrication) identified: 

* CancelEntryAgendaUI
* CancelEntryAgendaController
* Repositories
* AgendaRepository

## 3.2. Sequence Diagram (SD)

_**Note that SSD - Alternative Two is adopted.**_

### Full Diagram

This diagram shows the full sequence of interactions between the classes involved in the realization of this user story.

![Sequence Diagram - Full](svg/us025-sequence-diagram-full.svg)

## 3.3. Class Diagram (CD)

![Class Diagram](svg/us025-class-diagram.svg)