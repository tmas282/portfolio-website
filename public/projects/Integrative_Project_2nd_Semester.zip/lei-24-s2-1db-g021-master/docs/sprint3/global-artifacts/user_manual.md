# USER MANUAL - LARP2

| Name             | Number  | Email               |
|------------------|---------|---------------------|
| João Jorge       | 1231080 | 1231080@isep.ipp.pt |
| Tomás Moreira    | 1231087 | 1231087@isep.ipp.pt |
| Bernardo Cardoso | 1231070 | 1231070@isep.ipp.pt |

### Group 21: Mushroomers
### Class: 1DB | June 2024

# Index
1. [Introduction](#introduction)
    1. [Purpose and Scope](#purpose-and-scope)
2. [Glossary](#glossary)
3. [System Diagram](#system-diagram)
4. [System Overview](#system-overview)
5. [Features](#features)
    1. [Register skills | Human Resource Manager](#register-skills--human-resource-manager)
    2. [Register a job | Human Resource Manager](#register-a-job--human-resource-manager)
    3. [Assign one or more skills to a collaborator | Human Resource Manager](#assign-one-or-more-skills-to-a-collaborator--human-resource-manager)
    4. [Generate a team proposal automatically | Human Resource Manager](#generate-a-team-proposal-automatically--human-resource-manager)
    5. [Register a vehicle | Vehicle and Equipment Fleet Manager](#register-a-vehicle--vehicle-and-equipment-fleet-manager)
    6. [Register a vehicle’s check-up | Vehicle and Equipment Fleet Manager](#register-a-vehicles-check-up--vehicle-and-equipment-fleet-manager)
    7. [List the vehicles needing the check-up | Vehicle and Equipment Fleet Manager](#list-the-vehicles-needing-the-check-up--vehicle-and-equipment-fleet-manager)
    8. [Know the exact costs referring to water consumption of specific green space | Green Spaces Manager](#know-the-exact-costs-referring-to-water-consumption-of-specific-green-space--green-spaces-manager)
    9. [Know which piece(s) of equipment is/are used in each day | Green Spaces Manager](#know-which-pieces-of-equipment-isare-used-in-each-day--green-spaces-manager)
    10. [Collect data from the user portal about the use of the park | Green Spaces Manager](#collect-data-from-the-user-portal-about-the-use-of-the-park--green-spaces-manager)
    11. [Import a .csv file containing lines with: Water Point X, Water Point Y, Distance into a unique data structure | Green Spaces Manager](#import-a-csv-file-containing-lines-with-water-point-x-water-point-y-distance-into-a-unique-data-structure--green-spaces-manager)
    12. [Apply an algorithm that returns the routes to be opened and pipes needed to be laid with a minimum accumulated cost | Green Spaces Manager](#apply-an-algorithm-that-returns-the-routes-to-be-opened-and-pipes-needed-to-be-laid-with-a-minimum-accumulated-cost--green-spaces-manager)
    13. [Run tests for inputs of variable size | Software Quality Assessment Team Manager](#run-tests-for-inputs-of-variable-size--software-quality-assessment-team-manager)

# Introduction
## Purpose and Scope

<p style="text-align: justify">
As part of the Integrative Project (IP), namely in the discipline of Laboratory / 
Project II (LAPR2), the purpose of this document is to gather relevant information 
for the User Manual, intended firstly for the collective use of the MusgoSublime 
organisation and finally for users of the urban green spaces. <br>
This User Manual describes an urban green space management application 
for the MusgoSublime organisation, additionally with a section that collects feedback from 
users of the urban green spaces managed by this organisation. In this manual, the 
user can find information related to some business transactions (functionalities), 
which are aimed at MusgoSublime members. Subsequently, the user of the urban green 
space can find details on how the application works, namely how to send feedback on 
the urban green space they have used.<br>
Next, but not less important, there is a section reserved for statistical analysis to 
study some KPIs (key performance indicators) such as: water or energy consumption, the most 
used equipment and the profile of the park's users by age.
Also related is the study of linear and polynomial regression, the aim of which is to analyze the results obtained in the statistical analysis features.<br>
Finally, there is also a section on the implementation of efficient irrigation systems created 
using an algorithm that reads the different routes in a park (topographical survey) and 
defines the most efficient and least expensive route. In order to maintain the maximum security of all the 
parks, assembly points and evacuation routes have been set up in all of them so that, in the worst case scenario, 
the parks can be evacuated without material or human damage.
</p>

# Glossary

<p style="text-align: justify">The glossary, in its simplest form, is just a list of terms and their meanings within 
the scope of the business. Its purpose is to facilitate communication between members of the development team and the client. 
It can detail any element: an attribute of an object or terms used in other artifacts. Glossary terms should 
be placed in alphabetical order and terms should be in the singular.</p>

**Link to the glossary:**
[Glossary](01.requirements-engineering/glossary.md)

# System Diagram

<p style="text-align: justify">
The system diagram represents all the functionalities of a business, namely about the application
developed for the MusgoSublime company. This type of diagram is very useful when developing an application 
because it allows you to visualize the tasks/functions to be implemented, as well as who they are aimed at, 
making a distinction between the type of users the application will have.
</p>

![System Diagram - Functionalities](system-diagram.svg)

# System Overview
<p style="text-align: justify">
The aim of this green space management application is to speed up and facilitate the whole process
of managing a green space. To do this, it applies theoretical knowledge of statistical analysis and
linear regression. In the conversion to development (practical part), algorithms such as Kruskal and 
Dijkstra are covered, which are important in the efficient planning of irrigation systems and the 
creation of meeting points and evacuation routes for a park, respectively.<br>
For the functionalities present in the system overview, through the object-oriented programming (OOP) approach and a 
correct structure in OO Design and class diagrams (CD), a model is created that shows a visualization of the system as a whole.<br>
This system is designed to help manage human resources, vehicle fleets, and the maintenance of green spaces. Below, you will find 
an explanation of how each part of the system works and how you can use it efficiently.
</p>

## Human Resources

### Managing Collaborators
**HumanResourceManager**: This person is responsible for managing everything related to collaborators, including their skills, job positions, and teams.

#### Collaborators
- **Personal Information**: Each collaborator has information such as admission date, phone number, email, and taxpayer number.
- **Documents**: The system allows you to record important documents of the collaborator, such as name, date of birth, and card number.
- **Address**: You can record the collaborator's address, including door number, street, and locality.
- **Skills and Job Positions**: Each collaborator can have various skills and be assigned to different job positions.

### Teams
- **Creating Teams**: You can create teams composed of several collaborators.
- **Team Agenda**: Each team has an agenda to organize tasks and activities.

## Vehicle Fleet Management

### Managing Vehicles
**VehicleFleetManager**: This manager is responsible for registering and maintaining vehicles.

#### Vehicles
- **Vehicle Information**: You can register information such as current mileage, acquisition date, and maintenance details.
- **Plate Certification**: Each vehicle has a plate certification where you can record the type, registration date, and vehicle model.

### Vehicle Check-ups
- **Check-up Records**: The system allows you to record and track vehicle check-ups, including the date, place, and mileage at the time of the check-up.

## Green Spaces Management

### Managing Green Spaces
**GreenSpaceManager**: This person is responsible for registering and maintaining green spaces.

#### Green Spaces
- **Green Space Information**: You can register the name, size classification, and area of the green space.
- **Address**: Each green space can have an address recorded.
- **Agenda**: Similar to teams, green spaces have an agenda to organize maintenance tasks.

### Tasks
- **Task Registration**: You can register various tasks related to the maintenance of green spaces, including name, type, status, and description.

## How to Use the System
1. **Register Collaborators**: Start by registering the collaborators' information, their skills, job positions, and documents.
2. **Create Teams**: Organize collaborators into teams and create agendas to plan tasks.
3. **Register Vehicles**: Add vehicles to the fleet, including all important information and maintenance records.
4. **Maintain Green Spaces**: Register green spaces and plan their maintenance through agendas and tasks.

<br>

![Domain Model](02.analysis/svg/project-domain-model.svg)


# Features

### Register skills | Human Resource Manager

1. **Ask for Skill Details**
   - Prompt the user to enter the skill name.
2. **Set Skill Attributes**
   - Assign the entered details to the corresponding fields in the system.
3. **Store Skill in Repository**
   - Save the skill information in the `Skills` repository.
4. **Confirm Registration**
   - Notify the user that the skill has been successfully registered.

---

### Register a job | Human Resource Manager

1. **Ask for Job Details**
   - Prompt the user to enter the job title.
2. **Set Job Attributes**
   - Assign the entered details to the corresponding fields in the system.
3. **Store Job in Repository**
   - Save the job information in the `Jobs` repository.
4. **Confirm Registration**
   - Notify the user that the job has been successfully registered.

---

### Assign one or more skills to a collaborator | Human Resource Manager

1. **Ask for Collaborator**
   - Prompt the user to select a collaborator from a list or search by name.
2. **Set Collaborator**
   - Confirm the selected collaborator in the system.
3. **Ask for Skills**
   - Prompt the user to select one or more skills to assign to the collaborator.
   - Allow the user to choose "none" if no skills need to be assigned.
4. **Set Skills**
   - Assign the selected skills to the collaborator.
5. **Store Assignment in Repository**
   - Save the skill assignments in the Collaborator which is saved on `Collaborators` repository.
6. **Confirm Assignment**
   - Notify the user that the skills have been successfully assigned to the collaborator.

---

### Generate a team proposal automatically | Human Resource Manager

1. **Ask for Team Criteria**
   - Prompt the user to enter the required skills for the team.
   - Prompt the user to specify the number of team members needed.
2. **Generate Team Proposal**
   - Use an algorithm to form a team based on the provided criteria.
3. **Review Team Proposal**
   - Display the proposed team to the user for review and adjustments if necessary.
4. **Confirm Team Formation**
   - Notify the user that the team has been successfully generated and saved.

---

### Register a vehicle | Vehicle and Equipment Fleet Manager

1. **Ask for Vehicle Details**
   - Prompt the user to enter the vehicle brand, model and type.
   - Prompt the user to enter the vehicle tare weight, gross weight, current Km and maintenance Km.
   - Prompt the user to enter the vehicle acquisition date and register date.
2. **Set Vehicle Attributes**
   - Assign the entered details to the corresponding fields in the system.
3. **Store Vehicle in Repository**
   - Save the vehicle information in the `Vehicles` repository.
4. **Confirm Registration**
   - Notify the user that the vehicle has been successfully registered.

---

### Register a vehicle’s check-up | Vehicle and Equipment Fleet Manager

1. **Ask for Check-Up Details**
   - Prompt the user to enter the kms of the check-up.
   - Prompt the user to specify the vehicle plate.
   - Prompt the user to enter the date and the address of the check-up.
2. **Set Check-Up Attributes**
   - Assign the entered details to the corresponding fields in the system.
3. **Store Check-Up in Repository**
   - Save the check-up information in the `VehicleCheckUp` repository.
4. **Confirm Check-Up Registration**
   - Notify the user that the vehicle’s check-up has been successfully registered.

---

### List the vehicles needing the check-up | Vehicle and Equipment Fleet Manager

1. **Retrieve Check-Up Data**
   - Query the repository for vehicles that are due for a check-up.
   - Show the list of vehicles needing a check-up in a user-friendly format.
3. **Confirm List Display**
   - Ensure the user can see and, possibly, interact with the list.

---

### Know the exact costs referring to water consumption of specific green space | Green Spaces Manager

1. **Collect Water Consumption Data**
   - Import the "water consumption.csv" file containing daily water usage records for each park.

2. **Analyze Data**
   - **Monthly Water Consumption Barplot**:
      - Filter data by user-specified year, StartMonth, EndMonth, and park identification.
      - Aggregate daily data into monthly consumption.
   - **Average Monthly Water Costs**:
      - Filter data for specified parks.
      - Calculate monthly consumption and associated costs (0.7 AC/m³ up to 1000 m³/month, additional 15% fee for higher consumption).
      - Compute average monthly costs per park.
   - **Statistical Comparison**:
      - Identify parks with the highest and lowest non-null daily consumption.
      - Calculate mean, median, standard deviation, and coefficient of skewness for daily consumption.
      - Create relative and absolute frequency tables with 5 classes.
      - Detect outliers using the 1.5 IQR rule.
      - Generate histograms with 10 and 100 classes.

3. **Display Analysis**
   - **Barplots**: Represent monthly consumption as barplots for specified periods and parks.
   - **Cost Reports**: Summarize average monthly water costs for each park in a report.
   - **Statistical Reports**: Compare statistical indicators, frequency tables, and histograms for parks with highest and lowest consumption.

4. **Confirm Data Accuracy**
   - Verify the calculations and data transformations to ensure accurate representation of water consumption and costs.


---

### Know which piece(s) of equipment is/are used in each day | Green Spaces Manager

1. **Collect Equipment Usage Data**
   - Import the "EquipmentUsed.csv" file containing records of equipment choices made by 1000 users.

2. **Analyze Data**
   - **User Preferences**:
     - Extract data on the usage of each piece of equipment from the file.
     - Count the occurrences of each equipment being used.

3. **Display Analysis**
   - **Pie Chart**: Create a pie chart to represent the percentage usage of each piece of equipment.

4. **Confirm Data Accuracy**
   - Verify the data extraction and counting process to ensure the pie chart accurately reflects the equipment usage preferences of the users.

---

### Collect data from the user portal about the use of the park | Green Spaces Manager


1. **Collect Survey Data**
   - Import the "Inquiry.csv" file containing responses to the three-question survey about park usage.

2. **Analyze Data**
   - **Variable Types**:
     - Identify the types of each of the three variables
   - **Proportion of Recommendations**:
     - Calculate the proportion of users from each age group who would recommend the park to others.

3. **Display Analysis**
   - **Proportion Chart**: Create a chart showing the proportion of users from each age group who would recommend the park.
   - **Boxplot of Monthly Visits**:
     - Generate a boxplot for each age group to represent the monthly frequency of park visits.
     - Draw conclusions from the boxplot regarding the usage patterns of each age group.

4. **Confirm Data Accuracy**
   - Verify the data extraction, calculations, and graphical representations to ensure they accurately reflect the survey responses and park usage patterns.
---

### Import a .csv file containing lines with: Water Point X, Water Point Y, Distance into a unique data structure | Green Spaces Manager

1. **Import CSV File Data**
   - Import the .csv file containing lines with:
     - Water Point X
     - Water Point Y
     - Distance

2. **Structure Data**
   - **Data Structure**:
     - Create a unique data structure to store information about the possible routes.
     - Each entry should include the water points (X and Y) and the distance (or installation cost).

3. **Analyze Data**
   - **Possible Routes**:
     - List all possible routes that can be opened to lay pipes between each pair of water points.
     - Include the associated installation costs (distance or another cost parameter).

4. **Confirm Data Accuracy**
   - Verify the accuracy of the data import and organization to ensure that all routes and their respective costs are correctly represented in the data structure.

---

### Apply an algorithm that returns the routes to be opened and pipes needed to be laid with a minimum accumulated cost | Green Spaces Manager

1. **Implement Minimum Cost Algorithm**
   - Develop an algorithm to determine routes and pipe laying with minimum accumulated cost, ensuring adequate supply to all points, using only primitive operations in Java.
2. **Generate Output Subgraph and Visualization**
   - Execute the algorithm to produce a .csv file with the output subgraph format (vertice, vertice, edge cost) and total cost. Additionally, visualize the input and output graphs using Graphviz or GraphStream.
3. **Organize Delivery Folder**
   - Prepare a delivery folder containing drawings of input and output graphs for two garden examples, the .csv file with the output graph and total cost, and a print detailing the implemented procedure(s) to solve the problem.

---

### Run tests for inputs of variable size | Software Quality Assessment Team Manager

1. **Run Tests**
   - Execute tests to observe the asymptotic behavior of the execution time of the algorithm for inputs of variable size.
2. **Generate Execution Time Data**
   - Run the algorithm for 30 given files and collect data on input size and execution time.
3. **Create Visualization**
   - Use a package like Gnuplot to create a graphic depicting the execution time as a function of input size.
4. **Organize Delivery Folder**
   - Prepare a folder containing:
      - A .csv file with input size and execution time data for the 30 examples.
      - An image file displaying the execution time graphic based on the .csv data.

---

### Predicting Water Consumption Cost for New Park | Green Spaces Manager

1. **Study Feasibility of Linear Adjustment**
   - Utilized data from "water consumption updated.csv" and "Area.csv".
   - Conducted exploratory data analysis to assess linearity between park area and water consumption cost.
   - Implemented linear regression modeling to determine the relationship between park size and water consumption cost.

2. **Linear Regression Model**
   - Utilized park area (in hectares) as the independent variable.
   - Average monthly cost for water consumption served as the response variable.
   - Developed a regression model to predict water consumption cost based on park size.

3. **Prediction for New 55-Hectare Park**
   - Applied the established regression model to forecast the average monthly cost of water consumption for the new park.
   - Utilized the park's size (55 hectares) as input to the model.

4. **Result**
   - Predicted average monthly cost for water consumption in the new 55-hectare park.

---

### Polynomial Regression Analysis | Green Spaces Manager

1. **Analyze Data**
   - Apply polynomial regression to the data.
   - Use the "solution us14.csv" file if US 14 was not completed.

2. **Display Analysis**
   - Use visualizations to present the results.

3. **Confirm Data Accuracy**
   - Verify the calculations and data transformations.

---

### Emergency Evacuation Route (Single Assembly Point) | Green Spaces Manager

1. **Import CSV File Data**
   - Import data from a .csv file containing a weighted matrix W.
   - Ensure matrix entries represent the cost between points, with 0 indicating no edge.

2. **Implement Shortest Route Algorithm**
   - Develop an algorithm to find the shortest route to the Assembly Point using only primitive operations.

3. **Display Analysis**
   - Output the routes in a .csv file.
   - Visualize the input graph and output paths.

4. **Confirm Data Accuracy**
   - Verify the accuracy of the algorithm and the output.

---

### Emergency Evacuation Route (Multiple Assembly Points) | Green Spaces Manager

1. **Import CSV File Data**
   - Import data from a .csv file containing a weighted matrix W.
   - Ensure matrix entries represent the cost between points, with 0 indicating no edge.

2. **Implement Shortest Route Algorithm**
   - Develop an algorithm to find the shortest route to multiple Assembly Points using only primitive operations.

3. **Display Analysis**
   - Output the routes in a .csv file.
   - Visualize the input graph and output paths.

4. **Confirm Data Accuracy**
   - Verify the accuracy of the algorithm and the output.

---

### Worst-Case Time Complexity Analysis | Green Spaces Manager

1. **Introduction**
   - The objective is to conclude about the worst-case time complexity of procedures developed in US13, US17, and US18.
   - Theoretical framework and analysis of worst-case time complexity will be presented in a PDF format.
   - Pseudo-code for each algorithm will be provided, along with complexity analysis.

2. **Procedure Analysis**
   - US13: *Describe procedure and provide pseudo-code.*
      - Perform complexity analysis for US13 procedure.
   - US17: *Describe procedure and provide pseudo-code.*
      - Perform complexity analysis for US17 procedure.
   - US18: *Describe procedure and provide pseudo-code.*
      - Perform complexity analysis for US18 procedure.

3. **Theoretical Framework**
   - Discuss the theoretical aspects of time complexity analysis.
   - Explain common notation (Big O, Big Theta, Big Omega) used in complexity analysis.

4. **Analysis of Worst-Case Time Complexity**
   - Present the worst-case time complexity analysis for each procedure.
   - Compare the complexities and identify the procedure with the highest worst-case time complexity.

5. **Conclusion**
   - Summarize the findings regarding the worst-case time complexity of procedures developed in US13, US17, and US18.
   - Provide insights into the implications of these complexities on system performance and scalability.

---

### Registering Green Space and Area | Green Spaces Manager

1. **Introduction**
   - The objective is to enable the Green Space Manager (GSM) to register a green space along with its respective area.
   - Green spaces include gardens, medium-sized parks, or large-sized parks.

2. **User Story Description**
   - GSM will input the details of the green space, including its type (garden, medium-sized park, or large-sized park) and area.
   - The system will store this information for future reference.

3. **Procedure**
   - GSM initiates the registration process.
   - The system prompts GSM to enter details such as green space type and area.
   - GSM provides the necessary information.
   - The system verifies the input and stores the green space details along with its area.

4. **Output**
   - The system confirms the successful registration of the green space and its area.
   - GSM can verify the registered green spaces and their respective areas in the system.

5. **Acceptance Criteria**
   - The system must allow GSM to register green spaces of different types (garden, medium-sized park, or large-sized park).
   - The system must accurately store and retrieve the area information of each registered green space.

---

### Adding Entry to To-Do List | Green Spaces Manager

1. **Introduction**
   - The objective is to enable the Green Spaces Manager (GSM) to add a new entry to the To-Do List.
   - The new entry must be associated with a green space managed by the GSM.
   - The GSM should choose the green space for the new entry from a presented list.

2. **User Story Description**
   - GSM initiates the process to add a new entry to the To-Do List.
   - The system presents a list of green spaces managed by the GSM.
   - GSM selects the appropriate green space for the new entry.
   - GSM provides details for the new entry, such as task description, priority, and due date.
   - The system adds the new entry to the To-Do List, associated with the chosen green space.

3. **Procedure**
   - GSM triggers the addition of a new entry to the To-Do List.
   - The system displays a list of green spaces managed by GSM.
   - GSM selects the desired green space.
   - GSM provides details for the new entry, including task description, priority, and due date.
   - The system verifies the input and adds the new entry to the To-Do List, associated with the chosen green space.

4. **Output**
   - The system confirms the successful addition of the new entry to the To-Do List.
   - GSM can view the updated To-Do List with the new entry associated with the chosen green space.

5. **Acceptance Criteria**
   - The system must present a list of green spaces managed by GSM for selection.
   - The new entry must be associated with the chosen green space.
   - GSM should be able to provide details for the new entry, including task description, priority, and due date.

---

### Adding Entry to Agenda | Green Spaces Manager

1. **Introduction**
   - The objective is to enable the Green Spaces Manager (GSM) to add a new entry to the Agenda.
   - The new entry must be associated with a green space managed by the GSM.
   - Additionally, the new entry must already exist in the To-Do list.

2. **User Story Description**
   - GSM initiates the process to add a new entry to the Agenda.
   - The system verifies that the new entry already exists in the To-Do list.
   - GSM selects the appropriate green space for the new entry.
   - GSM provides additional details for the new entry, such as date and time.
   - The system adds the new entry to the Agenda, associated with the chosen green space.

3. **Procedure**
   - GSM triggers the addition of a new entry to the Agenda.
   - The system checks if the new entry exists in the To-Do list.
   - GSM selects the desired green space for the new entry.
   - GSM provides date and time details for the new entry.
   - The system verifies the input and adds the new entry to the Agenda, associated with the chosen green space.

4. **Output**
   - The system confirms the successful addition of the new entry to the Agenda.
   - GSM can view the updated Agenda with the new entry associated with the chosen green space.

5. **Acceptance Criteria**
   - The new entry must already exist in the To-Do list.
   - The new entry must be associated with a green space managed by GSM.
   - GSM should be able to provide additional details such as date and time for the new entry.

---

### Assigning Team to Agenda Entry | Green Spaces Manager

1. **Introduction**
   - The objective is to enable the Green Spaces Manager (GSM) to assign a team to an entry in the Agenda.
   - Upon assignment, a message must be sent to all team members to inform them about the assignment.
   - Different email services can be used to send the message, and these services must be defined through a configuration file to allow the use of different platforms.

2. **User Story Description**
   - GSM initiates the process to assign a team to an entry in the Agenda.
   - The system allows GSM to select the team members to be assigned to the entry.
   - Upon assignment, the system sends a message to all team members to inform them about the assignment.
   - Email services for sending messages are configured through a configuration file, enabling the use of different platforms.

3. **Procedure**
   - GSM selects the entry in the Agenda to which a team will be assigned.
   - GSM selects the team members to be assigned to the entry.
   - The system sends a message to all selected team members to inform them about the assignment.
   - Email services used for sending messages are defined and configured through a configuration file.

4. **Output**
   - The system confirms the successful assignment of the team to the entry in the Agenda.
   - All team members receive a message informing them about the assignment.

5. **Acceptance Criteria**
   - Upon assignment, a message must be sent to all team members to inform them about the assignment.
   - Different email services can be used to send the message, and these services must be defined through a configuration file.

---

### Postponing Agenda Entry to a Specific Future Date | Green Spaces Manager

1. **Introduction**
   - The goal is to allow the Green Spaces Manager (GSM) to postpone an entry in the Agenda to a specific future date.

2. **User Story Description**
   - GSM initiates the process to postpone an entry in the Agenda to a future date.
   - The system facilitates GSM in selecting the entry to be postponed.
   - GSM specifies the precise future date to which the entry will be postponed.
   - The system updates the Agenda entry with the new postponed date.

3. **Procedure**
   - GSM selects the entry in the Agenda to be postponed.
   - GSM specifies the future date to which the entry will be postponed.
   - The system updates the selected Agenda entry with the new postponed date.

4. **Output**
   - The system confirms the successful postponement of the Agenda entry to the specified future date.

5. **Acceptance Criteria**
   - The system should enable GSM to select an entry in the Agenda for postponement.
   - GSM should be able to specify the specific future date to which the entry will be postponed.
   - The system must accurately update the Agenda entry with the new postponed date.

---

### Cancelling Agenda Entry | Green Spaces Manager

1. **Introduction**
   - The objective is to enable the Green Spaces Manager (GSM) to cancel an entry in the Agenda.

2. **User Story Description**
   - GSM initiates the process to cancel an entry in the Agenda.
   - Instead of deleting the task, the system changes its state to "cancelled".
   - The cancelled entry remains in the Agenda but with a different state.

3. **Procedure**
   - GSM selects the entry in the Agenda to be cancelled.
   - The system changes the state of the selected entry to "cancelled".

4. **Output**
   - The system confirms the successful cancellation of the Agenda entry.

5. **Acceptance Criteria**
   - Cancelling a task should not result in its deletion, but rather a change in its state to "cancelled".
   - The system must accurately reflect the state change of the cancelled entry in the Agenda.

---

### Assigning Vehicles to Agenda Entry | Green Spaces Manager

1. **Introduction**
   - The objective is to enable the Green Spaces Manager (GSM) to assign one or more vehicles to an entry in the Agenda.

2. **User Story Description**
   - GSM initiates the process to assign vehicles to an entry in the Agenda.
   - The system allows GSM to select the entry to which vehicles will be assigned.
   - GSM specifies one or more vehicles to be assigned to the selected entry.
   - The system updates the Agenda entry with the assigned vehicles.

3. **Procedure**
   - GSM selects the entry in the Agenda to which vehicles will be assigned.
   - GSM specifies one or more vehicles to be assigned to the selected entry.
   - The system updates the selected Agenda entry with the assigned vehicles.

4. **Output**
   - The system confirms the successful assignment of vehicles to the Agenda entry.

5. **Acceptance Criteria**
   - The system should allow GSM to select an entry in the Agenda for vehicle assignment.
   - GSM should be able to specify one or more vehicles to be assigned to the selected entry.
   - The system must accurately update the Agenda entry with the assigned vehicles.

---

### Listing Green Spaces Managed by GSM | Green Spaces Manager

1. **Introduction**
   - The goal is to allow the Green Spaces Manager (GSM) to list all green spaces managed by them.
   - The list of green spaces must be sorted by size in descending order, with area in hectares being used as the sorting criteria.
   - The sorting algorithm used by the application must be defined through a configuration file, with at least two sorting algorithms available.

2. **User Story Description**
   - GSM initiates the process to list all green spaces managed by them.
   - The system retrieves the list of green spaces and sorts them by size in descending order according to the defined sorting algorithm.
   - GSM can view the sorted list of green spaces managed by them.

3. **Procedure**
   - GSM triggers the listing of all green spaces managed by them.
   - The system retrieves the list of green spaces and applies the configured sorting algorithm to sort them by size in descending order.
   - The system presents the sorted list of green spaces to GSM.

4. **Output**
   - The system presents the sorted list of green spaces managed by GSM, sorted by size in descending order according to the selected sorting algorithm.

5. **Acceptance Criteria**
   - The system must allow GSM to list all green spaces managed by them.
   - The list of green spaces must be sorted by size in descending order.
   - At least two sorting algorithms should be available for sorting the list of green spaces.

---

### Consulting Assigned Tasks for Collaborator | Collaborator

1. **Introduction**
   - The objective is to enable a Collaborator to consult the tasks assigned to them between two dates.
   - The list of tasks must be sorted by date, and the Collaborator should be able to filter the results by the status of the task.

2. **User Story Description**
   - The Collaborator initiates the process to consult assigned tasks between two dates.
   - The system retrieves the list of tasks assigned to the Collaborator within the specified date range.
   - The list of tasks is sorted by date.
   - The Collaborator can filter the results by the status of the task, such as "pending", "completed", or "cancelled".

3. **Procedure**
   - The Collaborator specifies the start and end dates for the consultation.
   - The system retrieves the list of tasks assigned to the Collaborator within the specified date range.
   - The system sorts the list of tasks by date.
   - The Collaborator can filter the results by the status of the task.

4. **Output**
   - The system presents the list of tasks assigned to the Collaborator between the specified dates, sorted by date.
   - The Collaborator can view the filtered results based on the status of the task.

5. **Acceptance Criteria**
   - The system must allow a Collaborator to consult assigned tasks between two dates.
   - The list of tasks must be sorted by date.
   - The Collaborator should be able to filter the results by the status of the task.

---

### Recording Task Completion | Collaborator

1. **Introduction**
   - The aim is to allow an employee to record the completion of a task.

2. **Description of the User Story**
   - The employee starts the process to record the completion of a task.
   - The system allows the Collaborator to select the task that has been completed.
   - The Collaborator provides additional details, if necessary, about the task's completion.
   - The system updates the task status to “completed”.

3. **Procedure**
   - The Collaborator selects the task they want to mark as completed.
   - The Collaborator provides additional details, such as remarks or comments on the task's completion.
   - The system updates the task status to “completed”.

4. **Output**
   - The system confirms that the task has been successfully completed.
   - The task status is updated to “completed”.

5. **Acceptance Criteria**
   - The system must allow an employee to record the completion of a task.
   - Upon completion, the task status must be updated to “completed”.

# Troubleshooting

This section includes a list of possible error situations that might occur when handling the application to 
help the user identify and solve those problems. For any questions regarding the application, a support email 
is available: “supportmusgosublime@gmail.com”. As an additional resource, it is advisable to carefully read 
the information contained in the user manual, the aim of which is to avoid the following possible mistakes by the user.

### Register Skills

As simple as it may seem to just register the name of a skill, the user can make the mistake of adding characters that are not commonly used (special characters). For this reason, the application has some alertsthat warn of this problem, so that the skill with this error is not added successfully.

### Register Jobs

The same goes for entering the name of a job, which can't contain any special characters. For this reason, the application has some alerts that warn of this problem, so that the job name with this error is not added successfully.

### Register Vehicles

As you may know, MusgoSublime has various types of vehicles to help with the day-to-day maintenance of green spaces. For this reason, there are certain attributes that we must pay special attention to. The fact that all the vehicles are purchased as new, the registration date is after the purchase date of the vehicle, so there are notifications to alert the user when the two dates are entered. The validation of the km of the different vehicles is taken into account so as not to allow the user to enter negative values for these fields.

### Register Vehicle's Check-Up

A common mistake that many users can make is entering a vehicle's check-up. Remember that in order to register a vehicle's check-up, the vehicle must have been previously registered with all valid attributes. The solution to this problem is to show the user alerts if this error occurs.

### Assign Job and Skills to a Collaborator

Another common mistake that deserves our attention is assigning skills and professions to different collaborators.
Therefore, when you want to assign an employee these attributes, you need to register skills and professions first, and if in the list of professions and skills there is no option to choose one of the attributes, you may be experiencing this error.

### Generate Team Proposal

When you ask the application to generate a team of employees with skills and jobs, in addition to taking into account these last two attributes and the previous registration of employees, you must also pay attention to the minimum and maximum number of employees in that team, so invalid numbers will not be accepted, and you will receive an alert to warn you of this problem.

### Add Entry to the ToDo List

The set of tasks found in the Task List must be associated with a green space, so the absence of one green space will not allow the new task to be added. As with previous common errors, there are validations and alerts that prevent and help the user avoid making this mistake a second time.

### Add Entry to the Agenda

The Agenda collects a lot of information, from work teams to the task associated with a green space. For this reason, consideration is given to implementing correct validations for this data and warning the user that, for an entry in Agenda, there are many dependencies that must be created first.

### Postpone and Cancel an Entry in the Agenda

For these two functionalities, the user may think that the entry in the agenda, in the first, is postponed, and in the second, it would be deleted from the agenda because it has been canceled. However, taking this error into account, when using one of these functionalities, the diary entry is duplicated, with only the date of completion and the status of that entry changing.

### Consult Tasks Assigned to a Collaborator between two Dates

In this error, it is important for the user to keep in mind that when searching for the tasks assigned to himself, the fact that no task assigned between those two dates appears in the list does not mean that the user has no tasks created or that he has to create them immediately afterward in order to appear in the list. He should keep in mind that, for that time interval he has entered, he may not have any tasks assigned, but if he puts them in for the following week, for example, they may already appear on the list.

# Frequently Asked Questions (FAQs)

This section includes a list of questions the users may ask about the application, and the respective answers for each feature.

### Register skills
Q: Which information can be introduced to create a new skill?
A: The skill name.

### Register a job
Q: What are the inputs for creating a profession?
A: The profession name.

### Assign one or more skills to a collaborator
Q: Is if there is a minimum and maximum number of skills? Are there any special characteristics that the collaborator needs to have in order to have these skills added?
A: No. No

### Generate a team proposal automatically
Q: Which business rules apply for the input data to generate a team proposal?
A: Max and min team size, and a list of skills needed.

### Register a vehicle
Q: Should the application identify a registered vehicle by a serial number or other attribute?
A: By plate id.

### Register a vehicle’s check-up
Q: What is the unit of measurement used to estimate the check-up frequency (Kms, months, etc.)?
A: In real context all could be considered, in the scope of this project just kms will be considered.

### List the vehicles needing the check-up
Q: What information will appear on the final list regarding the vehicle,besides the needing for check-up?
A: Data that allow to identify the vehicle like Plate, brand and model, as well as, the data that allowed to select/insert te vehicle in the list, number of kms, frequency of checkup and the last checkup.

### Know the exact costs referring to water consumption of specific green space
Q: Should we output all the information to a file or show it on the screen and offer that option to the user?
A: The output should be shown on the screen to the user.

### Know which piece(s) of equipment is/are used in each day
Q: Should the program allow to save the result pie chart or just show it on the screen?
A: The output should be shown on the screen to the user.

### Collect data from the user portal about the use of the park
Q: Should the program collect the data or just process an CSV file with the information?
A: The data is saved on a .csv file.

### Import a .csv file containing lines with: Water Point X, Water Point Y, Distance into a unique data structure
Q: Will we be given the distance and/or costs between different water points?
A: You only have one value assigned between different water points, called the "cost", that could mean a distance or something else.

### Apply an algorithm that returns the routes to be opened and pipes needed to be laid with a minimum accumulated cost
Q: Is there any specific tool we should use for the graph drawing and visualization?
A: You may use any package you want. Suggestions: Graphviz, GraphStream...

### Run tests for inputs of variable size
Q: In the US14, what does the variable size refer to?
A: Inputs of variable size.

### Predicting Water Consumption Costs
Q: To clarify we are only asked for the expected value of the average monthly cost paid?
A: The aim is to predict a new response "y".

### Polynomial Regression Analysis
Q: Should the user be shown the line with a polynomial equation?
A: In the output, yes.

### Emergency Evacuation Route (Single Assembly Point)
Q: Is it to present a drawing of all the points up to the assembly point, or is it to deliver separate drawings of all the paths?
A: Two alternatives are accepted: either a single drawing with a shortest path from each point to the AP, or a drawing for each point.

### Emergency Evacuation Route (Multiple Assembly Points)
Q: it is mentioned that one of the things that should be in the pdf is the drawing of the graph with the shortest path to the meeting
point, in which case we decide which one to put in the pdf, or is it to put an image for all the points?
A: You don't need to deliver that images.

### Asymptotic Behavior Analysis
Q: What must be present to analyze the worst case of complexity?
A: The respective pseudocode of the implemented procedure and a table with its analysis.

### Worst-Case Time Complexity Analysis
Q: In the registration of a green space, should a green space's name be allowed to contain digits and special characters, or just letters and whitespaces?
A: Same rules for other names in the business, letters, spaces and dashes.

### Registering Green Space and Area
Q: One task can be associated to more than one green space?
A: A generic task, yes; like "Pruning Trees" but not a concrete task, like "Pruning Trees" in Parque da Cidade.

### Adding Entry to To-Do List
Q: When the GSM plans a task (that was previously in To-Do) into the Agenda, what additional data/information does he need to input when planning?
A: The starting date for the task. Later the GSM will be able to add the Team and vehicles (if required).

### Adding Entry to Agenda
Q: Can a Team be assigned to multiple entrys?
A: Yes.

### Postponing Agenda Entry
Q: What are the input to postpone an entry? From my perspective the Green Spaces Manager only needs to select the entry and introduce the new date.
A: Yes, you are correct.

### Cancelling Agenda Entry
Q: When a task is cancelled, is it possible to put it back on the agenda again later?
A: Yes.

### Assigning Vehicles to Agenda Entry
Q: Should all the company's vehicles be available for assignment to an entry in the schedule, or only vehicles that have been properly maintained?
A: All vehicles that are not assigned to a task in the same period.

### Listing Green Spaces Managed by GSM
Q: You only want to list the Green Spaces manage by the GSM. Due to this, the GSM should  be registered in the app previously, isn't it? Which attributes should it have?
A: Yes, the app can have multiple GSM registered.

### Consulting Assigned Tasks for Collaborator
Q: When a collaborator is registered, they are given an account with the registered email and a password?
A: Yes, it makes sense.

### Recording Task Completion
Q: The collaborator should be able to change the status of any task or only tasks assigned to him?
A: Yes.