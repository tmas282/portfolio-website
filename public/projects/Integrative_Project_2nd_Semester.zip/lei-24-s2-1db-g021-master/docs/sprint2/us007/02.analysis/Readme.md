# US007 - Register Vehicle´s Check-up

## 2. Analysis

### 2.1. Relevant Domain Model Excerpt 

![Domain Model](svg/us007-domain-model.svg)

### 2.2. Other Remarks

n/a