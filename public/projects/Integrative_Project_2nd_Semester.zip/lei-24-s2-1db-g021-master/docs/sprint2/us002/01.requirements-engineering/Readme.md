# US002 - Register Job


## 1. Requirements Engineering

### 1.1. User Story Description

As an HRM, I want to register a job that a collaborator need to have.

### 1.2. Customer Specifications and Clarifications 

**From the specifications document:**

> MS has a wide range of employees who carry out the most varied tasks in the context of designing and managing green spaces. Some job examples are designer, budgetist, gardener, electrician or bricklayer.

**From the client clarifications:**

> **Question:**
>É relevante associar uma área ou setor específico a cada Job? (Por exemplo, "Jardineiro" seria inserido no setor de "Manutenção"). Deve-se incluir informações como salário, tipo de contratação (full-time ou part-time), e modalidade de trabalho (presencial, remoto ou híbrido) no Job? Ou essas informações encaixam-se melhor no âmbito do colaborador, ou talvez nem sejam necessárias? Or is this information better suited to the employee, or perhaps not necessary at all? Que outras informações acha necessárias associar ao Job?
>
> **Answer:** Bom dia, não é  necessário na medida que não existem US que sugiram que isso possa vir a ser necessário; - idem; - para já nenhumas. De nada.

> **Question:**
>What are the acceptance criteria? When are creating a job that already exit, what the system do?
>
> **Answer:** By definition a set can´t have duplicates. Assuring no duplicates is not a business rule is a technical issue.

> **Question:**
>Quais são os dados de entrada para a criação de uma profissão?
>
> **Answer:** O Nome da profissão: jardineiro, calceteiro, electricista, condutor,...

> **Question:**
>After register a job/vehicle's checkup should a message (sucess or failure) or a resume of the register appear?
>
> **Answer:** The UX/UI is up to dev teams.

> **Question:**
>Should we add a description or anything attribute for the Job registration? The id of Job is generated automatically by the system? 
> I guess a job can be assigned to a collaborator if he has the skills require for this job. How do we manage this relation. Does he HRM do it manually, or should we have an atribute in job specifiying the skills needed? 
> Do the job has to be registered before registering a collaborator? When we register a team, the collaborators has to have a job? What do you want to see as an output?
>
> **Answer:** Not need to, job is just a name; don't know what is job id, job is just a name; no; a collaborator is hired for a job and can have skills or not; 
>a collaborator is hired for a (valid) job; see 3 and 4; the UX/UI is to be decided by dev team.

> **Question:**
>For registering a job into system manager needs to type just "Job tilte" ? we do not need other attributes such as below: 
>1. Job ID, for identifying each job from Administration prespective.
>2. Job category : for classifying jobs like gardening, drivers, administration employees , etc
>3. Job Skills: for assigning qualified employee/collaborator in future (having same qualities and skills) or other attributes...
>
> **Answer:** I'll repeat:
a job is just the job name!
>1. Don't know what means job ID, because in the client perspective, a job is just the job name;
>2. there is no job category;
>3. There is the concept of skill but not directly related (atm) with job;

> **Question:**
>Can special characters and numbers be entered when registering a job? I assume that a job name cannot be empty. Is that right?
>
> **Answer:** No; That's right.

> **Question:**
>Hello Client. Where do you want the jobs and skills to be stored and validated? Do you which to have a skill and job repository or do you want them to be stored in the organization?
>
> **Answer:** Hello, the business rules regarding skills and stored were already provided in this forum; I have no knowledge about repositories.

### 1.3. Acceptance Criteria

* **AC1:** A job name can’t have special characters or digits.

### 1.4. Found out Dependencies

* This User Storie doesn't have any dependencies.

### 1.5 Input and Output Data

**Input Data:**

* Typed data:
  * The name of the profession/job.

* Selected data:
  * The name of the profession/job.

**Output Data:**

* List of existing professions/jobs.

### 1.6. System Sequence Diagram (SSD)

![System Sequence Diagram - Alternative One](svg/us002-system-sequence-diagram-alternative-one.svg)

### 1.7 Other Relevant Remarks