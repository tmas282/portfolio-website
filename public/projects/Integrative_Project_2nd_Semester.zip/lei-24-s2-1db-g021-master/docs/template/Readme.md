# Template folder

This folder contains the template files for the documentation.

Once you start documenting your project, you can delete this folder.