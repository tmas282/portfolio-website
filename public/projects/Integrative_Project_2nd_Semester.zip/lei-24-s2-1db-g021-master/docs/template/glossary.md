# Glossary

**Terms, Expressions and Acronyms (TEA) must be organized alphabetically.**

_(Complete according to the provided example)_

| **_TEA_** (EN) |  **_Description_** (EN)                                           |                                       
|:---------------|:--------------------------------------------|
| **Clerk**      |  Person responsible for carrying out various business supporting activities on the system. |
| **CLK**        |  Acronym for _Clerk_.|
| **..**         |  ...|